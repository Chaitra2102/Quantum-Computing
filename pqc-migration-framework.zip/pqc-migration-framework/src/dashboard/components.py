"""
src/dashboard/components.py
Post-Quantum Secure Communication & Migration Framework

Reusable Streamlit UI components, callouts, and limitation banners.

Phase 13: Interactive Dashboard & Visualization
"""

from __future__ import annotations

from typing import Any
import streamlit as st


def render_header() -> None:
    """Render the dashboard research header."""
    st.markdown(
        """
        <div style="padding: 1.2rem 1.5rem; background: linear-gradient(135deg, #1e293b 0%, #0f172a 100%); border-radius: 10px; margin-bottom: 1.5rem; border: 1px solid #334155; color: white;">
            <h1 style="margin: 0; font-size: 1.8rem; font-weight: 700; color: #f8fafc;">
                Post-Quantum Secure Communication & Migration Framework
            </h1>
            <p style="margin: 0.4rem 0 0 0; font-size: 1.0rem; color: #94a3b8;">
                Experimental Cryptographic Performance, Communication Overhead & Staged Migration Dashboard
            </p>
        </div>
        """,
        unsafe_allow_html=True,
    )


def render_sidebar(datasets: dict[str, Any]) -> dict[str, Any]:
    """Render the dashboard sidebar with navigation, dataset validation status, and filters."""
    st.sidebar.title("Framework Hub")
    st.sidebar.markdown("**Post-Quantum Migration Framework**")
    st.sidebar.divider()

    st.sidebar.subheader("Navigation")
    view_options = ["🚀 Live Demonstration", "📊 Research & Experimental Dashboard"]
    current_index = 0
    if st.session_state.get("main_view") == "research_dashboard":
        current_index = 1

    selected_view = st.sidebar.radio(
        "Select Experience",
        options=view_options,
        index=current_index,
        key="sidebar_nav_selection",
    )

    if selected_view == "🚀 Live Demonstration":
        st.session_state["main_view"] = "live_demo"
    else:
        st.session_state["main_view"] = "research_dashboard"

    st.sidebar.divider()
    st.sidebar.subheader("Authoritative Datasets")
    val_status = datasets.get("validation_status", {})
    for name, status in val_status.items():
        if status == "VALID":
            st.sidebar.markdown(f":white_check_mark: `{name}`")
        else:
            st.sidebar.markdown(f":x: `{name}`: {status}")

    mode_filter = ["Mode A", "Mode B", "Mode C", "Mode D (ML-DSA)", "Mode D (SLH-DSA)", "Mode D (ECDSA)"]
    if st.session_state.get("main_view") == "research_dashboard":
        st.sidebar.divider()
        st.sidebar.subheader("Filters")
        mode_filter = st.sidebar.multiselect(
            "Filter Modes",
            options=["Mode A", "Mode B", "Mode C", "Mode D (ML-DSA)", "Mode D (SLH-DSA)", "Mode D (ECDSA)"],
            default=["Mode A", "Mode B", "Mode C", "Mode D (ML-DSA)", "Mode D (SLH-DSA)", "Mode D (ECDSA)"],
        )

    st.sidebar.divider()
    st.sidebar.markdown(
        """
        <small style="color: #64748b;">
        <b>Discipline Notice:</b><br>
        All metrics derived strictly from machine-readable Phase 10, 11, and 12 datasets. No scores, rankings, or algorithm recommendations are generated.
        </small>
        """,
        unsafe_allow_html=True,
    )

    return {"selected_modes": mode_filter, "selected_view": st.session_state["main_view"]}


def render_provider_limitation_banner() -> None:
    """Render the AD-17 provider limitation callout."""
    st.info(
        "**Implementation & Provider Environment Notice (AD-17):** "
        "Performance measurements reflect the implementation and provider environment used in this project. "
        "In particular, SLH-DSA measurements were obtained through `slh-dsa` 0.2.5 (Pure Python), "
        "while ML-KEM and ML-DSA measurements use `cryptography` 48.0.0 (C/Rust). "
        "Therefore, empirical differences should not be attributed to the cryptographic algorithms alone."
    )


def render_replay_limitation_banner() -> None:
    """Render the Phase 9/12 replay limitation callout."""
    st.warning(
        "**Protocol Scope Notice (Replay Detection):** "
        "The migration framework operates on a stateless message model. "
        "Replay detection, sequence numbers, and replay caches are outside the current experimental scope "
        "and are identified for future transport-layer protocol hardening."
    )
