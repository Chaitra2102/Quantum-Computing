"""
src/dashboard/data_loader.py
Post-Quantum Secure Communication & Migration Framework

Centralized data-loading, schema validation, and dataset parsing layer.

Phase 13: Interactive Dashboard & Visualization

Loads only verified, machine-readable datasets produced by Phases 10, 11, and 12.
Strictly secret-free.
"""

from __future__ import annotations

import csv
import json
import logging
from pathlib import Path
from typing import Any

import pandas as pd

logger = logging.getLogger(__name__)


class DatasetNotFoundError(FileNotFoundError):
    """Raised when an authoritative project dataset is missing."""


class DatasetValidationError(ValueError):
    """Raised when a dataset fails schema or integrity validation."""


def get_default_project_root() -> Path:
    """Resolve the default project root path."""
    return Path(__file__).resolve().parent.parent.parent


def load_benchmark_summary(project_root: Path | None = None) -> dict[str, Any]:
    """
    Load and validate Phase 10 benchmark summary dataset.

    Returns
    -------
    dict[str, Any]
        Parsed JSON benchmark summary containing environment, key establishment,
        signatures, symmetric/KDF, and end-to-end measurements.
    """
    root = project_root or get_default_project_root()
    path = root / "results" / "benchmarks" / "benchmark_summary.json"
    if not path.exists():
        raise DatasetNotFoundError(f"Authoritative benchmark summary file missing at: {path}")

    try:
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
    except Exception as e:
        raise DatasetValidationError(f"Failed to parse benchmark_summary.json: {e}") from e

    required_keys = ["environment", "benchmark_parameters", "key_establishment", "signatures", "symmetric_and_kdf", "end_to_end"]
    for k in required_keys:
        if k not in data:
            raise DatasetValidationError(f"benchmark_summary.json missing required top-level key: {k!r}")

    return data


def load_benchmark_sizes(project_root: Path | None = None) -> dict[str, Any]:
    """
    Load and validate Phase 10 benchmark size matrix dataset.

    Returns
    -------
    dict[str, Any]
        Parsed JSON containing raw and wire size measurements across all modes.
    """
    root = project_root or get_default_project_root()
    path = root / "results" / "benchmarks" / "benchmark_sizes.json"
    if not path.exists():
        raise DatasetNotFoundError(f"Authoritative benchmark sizes file missing at: {path}")

    try:
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
    except Exception as e:
        raise DatasetValidationError(f"Failed to parse benchmark_sizes.json: {e}") from e

    if "matrix" not in data or not isinstance(data["matrix"], list):
        raise DatasetValidationError("benchmark_sizes.json missing 'matrix' array.")

    return data


def load_migration_results(project_root: Path | None = None) -> dict[str, Any]:
    """
    Load and validate Phase 12 migration experiment results dataset.

    Returns
    -------
    dict[str, Any]
        Parsed JSON containing migration paths, steps, functional validation,
        and security tamper outcomes.
    """
    root = project_root or get_default_project_root()
    path = root / "results" / "migration" / "migration_results.json"
    if not path.exists():
        raise DatasetNotFoundError(f"Authoritative migration results file missing at: {path}")

    try:
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
    except Exception as e:
        raise DatasetValidationError(f"Failed to parse migration_results.json: {e}") from e

    if "paths" not in data:
        raise DatasetValidationError("migration_results.json missing 'paths' key.")

    return data


def load_migration_history(project_root: Path | None = None) -> list[dict[str, Any]]:
    """
    Load and validate Phase 12 migration history log.

    Returns
    -------
    list[dict[str, Any]]
        List of path transition history records.
    """
    root = project_root or get_default_project_root()
    path = root / "results" / "migration" / "migration_history.json"
    if not path.exists():
        raise DatasetNotFoundError(f"Authoritative migration history file missing at: {path}")

    try:
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
    except Exception as e:
        raise DatasetValidationError(f"Failed to parse migration_history.json: {e}") from e

    if not isinstance(data, list):
        raise DatasetValidationError("migration_history.json must be a list of history records.")

    return data


def load_compatibility_matrix(project_root: Path | None = None) -> pd.DataFrame:
    """
    Load and validate Phase 12 pairwise cross-suite compatibility matrix CSV.

    Returns
    -------
    pd.DataFrame
        DataFrame with columns: sender_suite, receiver_suite, sender_stage,
        receiver_stage, expected_outcome, actual_outcome, isolation_preserved, rejection_reason.
    """
    root = project_root or get_default_project_root()
    path = root / "results" / "migration" / "migration_compatibility.csv"
    if not path.exists():
        raise DatasetNotFoundError(f"Authoritative compatibility matrix file missing at: {path}")

    try:
        df = pd.read_csv(path)
    except Exception as e:
        raise DatasetValidationError(f"Failed to parse migration_compatibility.csv: {e}") from e

    required_cols = {"sender_suite", "receiver_suite", "expected_outcome", "actual_outcome", "isolation_preserved"}
    if not required_cols.issubset(set(df.columns)):
        raise DatasetValidationError(f"migration_compatibility.csv missing required columns: {required_cols - set(df.columns)}")

    return df


def load_migration_deltas(project_root: Path | None = None) -> pd.DataFrame:
    """
    Load and validate Phase 12 migration transition deltas CSV.

    Returns
    -------
    pd.DataFrame
        DataFrame containing latency, wire size, and raw crypto size deltas between steps.
    """
    root = project_root or get_default_project_root()
    path = root / "results" / "migration" / "migration_deltas.csv"
    if not path.exists():
        raise DatasetNotFoundError(f"Authoritative migration deltas file missing at: {path}")

    try:
        df = pd.read_csv(path)
    except Exception as e:
        raise DatasetValidationError(f"Failed to parse migration_deltas.csv: {e}") from e

    required_cols = {"transition_id", "source_suite", "target_suite", "latency_delta_us", "latency_pct_delta", "wire_size_delta_bytes", "wire_size_pct_delta"}
    if not required_cols.issubset(set(df.columns)):
        raise DatasetValidationError(f"migration_deltas.csv missing required columns: {required_cols - set(df.columns)}")

    return df


def load_all_datasets(project_root: Path | None = None) -> dict[str, Any]:
    """
    Load and validate all project datasets into a single validated dictionary.

    Returns
    -------
    dict[str, Any]
        Dictionary containing:
          - benchmark_summary
          - benchmark_sizes
          - migration_results
          - migration_history
          - compatibility_matrix (DataFrame)
          - migration_deltas (DataFrame)
          - validation_status (dict)
    """
    root = project_root or get_default_project_root()
    status: dict[str, str] = {}
    datasets: dict[str, Any] = {}

    try:
        datasets["benchmark_summary"] = load_benchmark_summary(root)
        status["benchmark_summary.json"] = "VALID"
    except Exception as e:
        status["benchmark_summary.json"] = f"ERROR: {e}"

    try:
        datasets["benchmark_sizes"] = load_benchmark_sizes(root)
        status["benchmark_sizes.json"] = "VALID"
    except Exception as e:
        status["benchmark_sizes.json"] = f"ERROR: {e}"

    try:
        datasets["migration_results"] = load_migration_results(root)
        status["migration_results.json"] = "VALID"
    except Exception as e:
        status["migration_results.json"] = f"ERROR: {e}"

    try:
        datasets["migration_history"] = load_migration_history(root)
        status["migration_history.json"] = "VALID"
    except Exception as e:
        status["migration_history.json"] = f"ERROR: {e}"

    try:
        datasets["compatibility_matrix"] = load_compatibility_matrix(root)
        status["migration_compatibility.csv"] = "VALID"
    except Exception as e:
        status["migration_compatibility.csv"] = f"ERROR: {e}"

    try:
        datasets["migration_deltas"] = load_migration_deltas(root)
        status["migration_deltas.csv"] = "VALID"
    except Exception as e:
        status["migration_deltas.csv"] = f"ERROR: {e}"

    datasets["validation_status"] = status
    datasets["all_valid"] = all(v == "VALID" for v in status.values())

    return datasets
