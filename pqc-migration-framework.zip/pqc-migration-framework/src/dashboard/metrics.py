"""
src/dashboard/metrics.py
Post-Quantum Secure Communication & Migration Framework

Data aggregation, summary tables, and research metrics formatting.

Phase 13: Interactive Dashboard & Visualization
"""

from __future__ import annotations

from typing import Any
import pandas as pd


def get_modes_summary_table() -> pd.DataFrame:
    """Generate factual cryptographic modes comparison table."""
    data = [
        {
            "Mode": "Mode A",
            "Stage": "Classical",
            "Key Establishment": "ECDH P-384",
            "Digital Signature": "ECDSA P-384",
            "Symmetric Cipher": "AES-256-GCM",
            "Suite Identifier": "CLASSICAL_ECDH_ECDSA_AES256_GCM",
            "KEX Public Key": "97 B",
            "Sig Public Key": "120 B",
            "Signature": "104 B",
            "Provider Backend": "PyCA cryptography 48.0.0 (C/Rust)",
        },
        {
            "Mode": "Mode B",
            "Stage": "Pure PQC",
            "Key Establishment": "ML-KEM-768",
            "Digital Signature": "ML-DSA-65",
            "Symmetric Cipher": "AES-256-GCM",
            "Suite Identifier": "PQC_MLKEM_MLDSA_AES256_GCM",
            "KEX Public Key": "1,184 B",
            "Sig Public Key": "1,952 B",
            "Signature": "3,309 B",
            "Provider Backend": "PyCA cryptography 48.0.0 (C/Rust)",
        },
        {
            "Mode": "Mode C",
            "Stage": "Pure PQC",
            "Key Establishment": "ML-KEM-768",
            "Digital Signature": "SLH-DSA-SHAKE-128f",
            "Symmetric Cipher": "AES-256-GCM",
            "Suite Identifier": "PQC_MLKEM_SLHDSA_AES256_GCM",
            "KEX Public Key": "1,184 B",
            "Sig Public Key": "32 B",
            "Signature": "17,088 B",
            "Provider Backend": "slh-dsa 0.2.5 (Pure Python)",
        },
        {
            "Mode": "Mode D (ML-DSA)",
            "Stage": "Hybrid Dual",
            "Key Establishment": "ECDH P-384 + ML-KEM-768",
            "Digital Signature": "ML-DSA-65",
            "Symmetric Cipher": "AES-256-GCM",
            "Suite Identifier": "HYBRID_ECDH_MLKEM_MLDSA_AES256_GCM",
            "KEX Public Key": "1,283 B",
            "Sig Public Key": "1,952 B",
            "Signature": "3,309 B",
            "Provider Backend": "cryptography 48.0.0 (Hybrid Dual)",
        },
        {
            "Mode": "Mode D (SLH-DSA)",
            "Stage": "Hybrid Dual",
            "Key Establishment": "ECDH P-384 + ML-KEM-768",
            "Digital Signature": "SLH-DSA-SHAKE-128f",
            "Symmetric Cipher": "AES-256-GCM",
            "Suite Identifier": "HYBRID_ECDH_MLKEM_SLHDSA_AES256_GCM",
            "KEX Public Key": "1,283 B",
            "Sig Public Key": "32 B",
            "Signature": "17,088 B",
            "Provider Backend": "cryptography + slh-dsa (Multi-Provider)",
        },
        {
            "Mode": "Mode D (ECDSA)",
            "Stage": "Hybrid Dual",
            "Key Establishment": "ECDH P-384 + ML-KEM-768",
            "Digital Signature": "ECDSA P-384",
            "Symmetric Cipher": "AES-256-GCM",
            "Suite Identifier": "HYBRID_ECDH_MLKEM_ECDSA_AES256_GCM",
            "KEX Public Key": "1,283 B",
            "Sig Public Key": "120 B",
            "Signature": "104 B",
            "Provider Backend": "cryptography 48.0.0 (Hybrid Dual)",
        },
    ]
    return pd.DataFrame(data)


def get_security_validation_table() -> pd.DataFrame:
    """Generate structured security and tamper testing validation table."""
    data = [
        {
            "Adversarial Testing Category": "Ciphertext Bit Flip Mutation",
            "Tested Configurations": "Modes A, B, C, D (ML-DSA, SLH-DSA, ECDSA)",
            "Trials Evaluated": "49 vectors (Phase 9) + 15 vectors (Phase 12)",
            "Observed Rejection": "100.0% REJECTED",
            "Primary Rejection Mechanism": "SignatureVerificationError (Verify-then-Decrypt)",
            "Invariant Preserved": "YES",
        },
        {
            "Adversarial Testing Category": "Nonce Bit Flip Mutation",
            "Tested Configurations": "Modes A, B, C, D (All Variants)",
            "Trials Evaluated": "49 vectors (Phase 9) + 15 vectors (Phase 12)",
            "Observed Rejection": "100.0% REJECTED",
            "Primary Rejection Mechanism": "SignatureVerificationError (Bound to Signed Data)",
            "Invariant Preserved": "YES",
        },
        {
            "Adversarial Testing Category": "Digital Signature Byte Mutation",
            "Tested Configurations": "Modes A, B, C, D (All Variants)",
            "Trials Evaluated": "49 vectors (Phase 9) + 15 vectors (Phase 12)",
            "Observed Rejection": "100.0% REJECTED",
            "Primary Rejection Mechanism": "SignatureVerificationError",
            "Invariant Preserved": "YES",
        },
        {
            "Adversarial Testing Category": "Algorithm Suite ID Substitution",
            "Tested Configurations": "Cross-Suite Combinations",
            "Trials Evaluated": "30 mismatched matrix pairs (Phase 12)",
            "Observed Rejection": "100.0% REJECTED",
            "Primary Rejection Mechanism": "ModeMismatchError (Strict Suite Binding)",
            "Invariant Preserved": "YES",
        },
        {
            "Adversarial Testing Category": "KEX Ciphertext / Key Truncation",
            "Tested Configurations": "Modes B, C, D",
            "Trials Evaluated": "12 truncation vectors (Phase 9)",
            "Observed Rejection": "100.0% REJECTED",
            "Primary Rejection Mechanism": "MalformedMessageError / InvalidKeyError",
            "Invariant Preserved": "YES",
        },
        {
            "Adversarial Testing Category": "Replay Characterization Experiment",
            "Tested Configurations": "All Modes",
            "Trials Evaluated": "Stateless protocol validation",
            "Observed Rejection": "N/A (Stateless Protocol)",
            "Primary Rejection Mechanism": "Replay detection is outside current scope",
            "Invariant Preserved": "Stateless Behavior Preserved",
        },
    ]
    return pd.DataFrame(data)


def get_research_questions_summary() -> list[dict[str, Any]]:
    """Retrieve structured research questions and factual findings from Phase 11."""
    return [
        {
            "rq": "RQ1: ML-KEM vs ECDH Key Establishment",
            "question": "How do key generation, encapsulation, and decapsulation of ML-KEM compare to ECDH P-384?",
            "finding": "ML-KEM-768 key generation (301.0 μs) was 77.44% faster than ECDH P-384 key generation (1,334.5 μs). The measured combined ML-KEM-768 encapsulation (68.7 μs) and decapsulation (99.1 μs) required 167.8 μs (-90.89% execution time vs ECDH derivation of 1,842.5 μs); however, these represent structurally different key-establishment mechanisms.",
            "limitation": "Comparisons reflect the PyCA cryptography 48.0.0 implementation environment.",
        },
        {
            "rq": "RQ2: ML-DSA vs ECDSA Digital Signatures",
            "question": "How do ML-DSA-65 signatures compare to classical ECDSA P-384 in performance and artifact sizes?",
            "finding": "ML-DSA-65 verification (298.3 μs) was 79.00% faster than ECDSA P-384 verification (1,420.4 μs). Median ML-DSA signing (1,039.6 μs) was 28.39% faster than ECDSA signing (1,451.6 μs), but exhibited variance due to rejection sampling (p95: 3,593.2 μs). ML-DSA artifacts are substantially larger: public key 1,952 B (+1,526.7%) and signature 3,309 B (+3,081.7%).",
            "limitation": "Rejection sampling induces non-deterministic signing latency distributions in ML-DSA.",
        },
        {
            "rq": "RQ3: SLH-DSA Characteristics",
            "question": "What are the computational and communication characteristics of SLH-DSA-SHAKE-128f?",
            "finding": "In the measured pure-Python slh-dsa 0.2.5 environment, SLH-DSA signing required 245.70 ms and verification required 12.75 ms. SLH-DSA provides the most compact public key (32 B, -98.36% vs ML-DSA) but the largest signature (17,088 B, +416.41% vs ML-DSA).",
            "limitation": "Multi-millisecond execution is primarily attributable to pure-Python interpretation overhead (AD-17).",
        },
        {
            "rq": "RQ4: Communication & Serialization Overhead",
            "question": "What wire communication overhead is introduced by post-quantum cryptographic artifacts and JSON/Base64 encoding?",
            "finding": "Total wire sizes for 1 KiB plaintext: Mode A = 2,084 B, Mode B = 11,693 B (+461.08%), Mode C = 27,506 B (+1,219.87%), Mode D (ML-DSA) = 11,965 B (+474.14%). Serialization expansion varied by configuration: Mode A = +51.78%, Mode B = +36.20%, Mode C = +34.54%, Mode D (ML-DSA) = +36.23%.",
            "limitation": "Base64 framing overhead percentage decreases slightly as raw payload size increases.",
        },
        {
            "rq": "RQ5: Hybrid Construction Overhead",
            "question": "What incremental performance and wire overhead is incurred by combining ECDH and ML-KEM?",
            "finding": "Hybrid key establishment combines classical ECDH P-384 and post-quantum ML-KEM-768 key-establishment mechanisms, with a measured +2.33% incremental wire-size increase (+272 B) over pure-PQC Mode B. The HKDF hybrid combiner required an average of 13.75 μs.",
            "limitation": "Hybrid key generation and encapsulation latencies are dominated by classical scalar multiplication.",
        },
        {
            "rq": "RQ6: Security & Protocol Robustness",
            "question": "How effectively does the framework maintain message integrity and reject adversarial tampering across modes?",
            "finding": "100% of tested tamper mutations (ciphertext, nonce, signature, algorithm ID) and 100% of cross-suite mismatch interactions were rejected. Verify-then-decrypt ordering was preserved across all modes.",
            "limitation": "The protocol is stateless; replay protection remains outside experimental scope.",
        },
        {
            "rq": "RQ7: Crypto-Agility & Staged Migration",
            "question": "Can the framework transition across classical, hybrid, and pure PQC configurations seamlessly?",
            "finding": "The ModeFactory and CryptoConfig architecture achieved 100% functional continuity across all 5 migration paths without modifying high-level application workflows.",
            "limitation": "Real-world migration requires enterprise PKI, CA hierarchies, and network MTU fragmentation management.",
        },
    ]
