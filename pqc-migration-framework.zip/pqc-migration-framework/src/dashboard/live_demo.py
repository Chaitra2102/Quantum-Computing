"""
src/dashboard/live_demo.py
Post-Quantum Secure Communication & Migration Framework

Live Demonstration Engine & UI Components for Lecturer-Facing Presentation.

Features:
  - Executes real secure communication workflows via SecureSession / ModeFactory.
  - Tests Classical (Mode A), Pure PQC (Modes B & C), and Hybrid (Mode D) configurations.
  - Interactive controlled tampering testing via Phase 9 AttackSimulator.
  - Visual end-to-end communication pipeline and step-by-step verification progress.
  - Side-by-side comparison matrix of runtime results.
  - Migration path visualizer using Phase 12 migration specifications.
  - Zero-secret guarantee: strictly excludes private keys, AES keys, and shared secrets.
"""

from __future__ import annotations

import base64
import html
import logging
import time
from typing import Any
import pandas as pd
import streamlit as st

from src.communication.session import SecureSession
from src.config.crypto_config import CryptoConfig, ModeFactory
from src.config.modes import (
    CLASSICAL_ECDH_ECDSA_AES256_GCM,
    HYBRID_ECDH_MLKEM_ECDSA_AES256_GCM,
    HYBRID_ECDH_MLKEM_MLDSA_AES256_GCM,
    HYBRID_ECDH_MLKEM_SLHDSA_AES256_GCM,
    PQC_MLKEM_MLDSA_AES256_GCM,
    PQC_MLKEM_SLHDSA_AES256_GCM,
    Mode,
)
from src.migration.migration_path import get_standard_paths
from src.security_tests.attack_simulator import AttackSimulator

logger = logging.getLogger(__name__)


# =============================================================================
# LIVE DEMONSTRATION WORKFLOW RUNNER
# =============================================================================

def execute_single_demo(
    name: str,
    category: str,
    mode: Mode | str,
    sig_type: str | None = None,
    kem_param: str = "ML-KEM-768",
    sig_param: str | None = None,
    plaintext: str = "Hello Lecturer! This is a post-quantum secure communication demonstration.",
    aad_str: str = "",
) -> dict[str, Any]:
    """
    Execute a real end-to-end secure communication workflow for a single configuration.

    Parameters
    ----------
    name : str
        Display title (e.g. 'Mode A — Classical Baseline').
    category : str
        Algorithm category ('Classical', 'Pure PQC', 'Pure PQC Hash-Based', 'Hybrid').
    mode : Mode | str
        Operational Mode.
    sig_type : str | None
        Signature provider selector for parameterized modes (e.g. Mode D).
    kem_param : str
        KEM parameter set.
    sig_param : str | None
        Signature parameter set.
    plaintext : str
        Input plaintext message.
    aad_str : str
        Optional Additional Authenticated Data string.

    Returns
    -------
    dict[str, Any]
        Safe, non-secret structured dictionary containing live execution results.
    """
    raw_plaintext = plaintext.encode("utf-8") if isinstance(plaintext, str) else b""
    raw_aad = aad_str.encode("utf-8") if aad_str else None

    # Step tracking
    steps: list[dict[str, str]] = []
    t_start = time.perf_counter()

    try:
        # [1] Configuration Selection & Build
        build_kwargs: dict[str, Any] = {"kem_parameter_set": kem_param}
        if sig_type:
            build_kwargs["sig_provider_type"] = sig_type
        if sig_param:
            build_kwargs["sig_parameter_set"] = sig_param

        cfg = ModeFactory.build(mode, **build_kwargs)
        session = SecureSession(config=cfg)
        steps.append({
            "step": "1. Configuration selected",
            "status": "✓ SUCCESS",
            "detail": f"Suite: {cfg.algorithm_id}",
        })

        # [2] Key Establishment
        rx_kp = cfg.key_exchange.generate_keypair()
        steps.append({
            "step": "2. Key establishment",
            "status": "✓ SUCCESS",
            "detail": f"Generated ephemeral keypair using {type(cfg.key_exchange).__name__}",
        })

        # [3-6] Sender Send Pipeline (HKDF, Encryption, Signature, Framing)
        sender_keypairs, secure_msg = session._communicator.send(
            plaintext=raw_plaintext,
            receiver_ke_public_key=rx_kp.public_key,
            aad=raw_aad,
            metadata={"source": "live_demo", "session_id": session.session_id},
        )
        steps.append({
            "step": "3. HKDF key derivation",
            "status": "✓ SUCCESS",
            "detail": "Derived 256-bit AES key with domain-separated label",
        })
        steps.append({
            "step": "4. AES-256-GCM encryption",
            "status": "✓ SUCCESS",
            "detail": f"Encrypted payload -> {len(secure_msg.ciphertext)} ciphertext bytes, 12-byte nonce",
        })
        steps.append({
            "step": "5. Digital signature",
            "status": "✓ SUCCESS",
            "detail": f"Signed (ciphertext || nonce) -> {len(secure_msg.signature)} signature bytes",
        })

        # [7-8] Receiver Verify-Then-Decrypt Pipeline
        decrypted = session._communicator.receive(
            message=secure_msg,
            receiver_ke_private_key=rx_kp.private_key,
            aad=raw_aad,
        )
        steps.append({
            "step": "6. Signature verification",
            "status": "✓ SUCCESS",
            "detail": "Verified signature over payload before decryption (strict verify-then-decrypt)",
        })
        steps.append({
            "step": "7. Decryption",
            "status": "✓ SUCCESS",
            "detail": "Authenticated decryption successful via AES-256-GCM",
        })

        recovered_text = decrypted.decode("utf-8", errors="replace")
        steps.append({
            "step": "8. Message recovery",
            "status": "✓ SUCCESS",
            "detail": f"Recovered {len(decrypted)} bytes identical to original",
        })

        t_elapsed_ms = (time.perf_counter() - t_start) * 1000.0

        # Wire size metrics
        wire_bytes = len(secure_msg.to_json().encode("utf-8"))
        ct_bytes = len(secure_msg.ciphertext)
        sig_bytes = len(secure_msg.signature)
        ke_ct_bytes = len(secure_msg.ke_ciphertext) if secure_msg.ke_ciphertext else 0
        sender_ke_pk_bytes = len(secure_msg.sender_ke_public_key)
        sender_sig_pk_bytes = len(secure_msg.sender_sig_public_key)

        provider_meta = session.inspect_config()

        return {
            "name": name,
            "category": category,
            "mode": Mode.from_string(mode).value,
            "algorithm_id": cfg.algorithm_id,
            "key_establishment": provider_meta.get("key_establishment", "N/A"),
            "signature": provider_meta.get("signature", "N/A"),
            "encryption": "AES-256-GCM",
            "kdf": "HKDF-SHA-384",
            "verification_status": "✓ SUCCESS",
            "decryption_status": "✓ SUCCESS",
            "message_recovery_status": "✓ MATCH",
            "overall_status": "✓ SUCCESS",
            "recovered_plaintext": recovered_text,
            "is_match": recovered_text == plaintext,
            "elapsed_ms": t_elapsed_ms,
            "wire_bytes": wire_bytes,
            "ciphertext_bytes": ct_bytes,
            "signature_bytes": sig_bytes,
            "ke_ciphertext_bytes": ke_ct_bytes,
            "sender_ke_pk_bytes": sender_ke_pk_bytes,
            "sender_sig_pk_bytes": sender_sig_pk_bytes,
            "steps": steps,
            "error": None,
        }

    except Exception as exc:
        t_elapsed_ms = (time.perf_counter() - t_start) * 1000.0
        logger.error("Live demo execution failed for %s: %s", name, exc)
        steps.append({
            "step": "Execution halted",
            "status": "✗ FAILED",
            "detail": f"Operation error: {type(exc).__name__}",
        })
        return {
            "name": name,
            "category": category,
            "mode": str(mode),
            "algorithm_id": "Error",
            "key_establishment": "Error",
            "signature": "Error",
            "encryption": "AES-256-GCM",
            "kdf": "HKDF-SHA-384",
            "verification_status": "✗ FAILED",
            "decryption_status": "✗ FAILED",
            "message_recovery_status": "✗ FAILED",
            "overall_status": "✗ FAILED",
            "recovered_plaintext": "",
            "is_match": False,
            "elapsed_ms": t_elapsed_ms,
            "wire_bytes": 0,
            "ciphertext_bytes": 0,
            "signature_bytes": 0,
            "ke_ciphertext_bytes": 0,
            "sender_ke_pk_bytes": 0,
            "sender_sig_pk_bytes": 0,
            "steps": steps,
            "error": f"{type(exc).__name__}: {str(exc)}",
        }


def run_all_live_configurations(
    plaintext: str,
    aad_str: str = "",
) -> list[dict[str, Any]]:
    """
    Run all 6 operational configurations defined in PROJECT_SPEC.md.

    Configurations:
      1. A — Classical Baseline (ECDH P-384 + ECDSA P-384)
      2. B — Pure PQC Lattice (ML-KEM-768 + ML-DSA-65)
      3. C — Pure PQC Hash-Based (ML-KEM-768 + SLH-DSA-SHAKE-128f)
      4. D — Hybrid + ML-DSA (ECDH P-384 + ML-KEM-768 + ML-DSA-65)
      5. D — Hybrid + SLH-DSA (ECDH P-384 + ML-KEM-768 + SLH-DSA-SHAKE-128f)
      6. D — Hybrid + ECDSA (ECDH P-384 + ML-KEM-768 + ECDSA P-384)
    """
    configs_to_test = [
        {
            "name": "A — Classical Baseline",
            "category": "Classical",
            "mode": Mode.A,
            "sig_type": None,
            "kem_param": "ML-KEM-768",
            "sig_param": None,
        },
        {
            "name": "B — Pure PQC Lattice",
            "category": "Pure PQC",
            "mode": Mode.B,
            "sig_type": None,
            "kem_param": "ML-KEM-768",
            "sig_param": "ML-DSA-65",
        },
        {
            "name": "C — Pure PQC Hash-Based",
            "category": "Pure PQC Hash-Based",
            "mode": Mode.C,
            "sig_type": None,
            "kem_param": "ML-KEM-768",
            "sig_param": "SLH-DSA-SHAKE-128f",
        },
        {
            "name": "D — Hybrid Dual KEX + ML-DSA",
            "category": "Hybrid (ML-DSA)",
            "mode": Mode.D,
            "sig_type": "mldsa",
            "kem_param": "ML-KEM-768",
            "sig_param": "ML-DSA-65",
        },
        {
            "name": "D — Hybrid Dual KEX + SLH-DSA",
            "category": "Hybrid (SLH-DSA)",
            "mode": Mode.D,
            "sig_type": "slhdsa",
            "kem_param": "ML-KEM-768",
            "sig_param": "SLH-DSA-SHAKE-128f",
        },
        {
            "name": "D — Hybrid Dual KEX + ECDSA",
            "category": "Hybrid (ECDSA)",
            "mode": Mode.D,
            "sig_type": "ecdsa",
            "kem_param": "ML-KEM-768",
            "sig_param": None,
        },
    ]

    results = []
    for item in configs_to_test:
        res = execute_single_demo(
            name=item["name"],
            category=item["category"],
            mode=item["mode"],
            sig_type=item["sig_type"],
            kem_param=item["kem_param"],
            sig_param=item["sig_param"],
            plaintext=plaintext,
            aad_str=aad_str,
        )
        results.append(res)
    return results


def run_controlled_tamper_demonstration(
    mode_str: str = "B",
    sig_type: str | None = None,
) -> list[dict[str, Any]]:
    """
    Execute controlled mutation attacks using Phase 9 AttackSimulator.

    Returns structured non-secret outcomes demonstrating verify-then-decrypt rejection.
    """
    results: list[dict[str, Any]] = []

    # 1. Ciphertext Bit Flip
    res_ct = AttackSimulator.simulate_ciphertext_bit_flip(mode=mode_str, sig_type=sig_type)
    results.append({
        "scenario": "1. Ciphertext Bit Modification",
        "component": "Ciphertext (AES-256-GCM)",
        "mutation": res_ct.mutation_description,
        "detection": "✓ PASS" if res_ct.passed else "✗ FAIL",
        "recovery": "✓ REJECTED (0 Bytes Leaked)" if not res_ct.plaintext_recovered else "✗ LEAKED",
        "rejection_type": res_ct.rejection_type or "Rejected",
        "description": "Adversary modifies encrypted bits in transit. Receiver detects integrity failure and drops message.",
    })

    # 2. Nonce Tampering
    res_nonce = AttackSimulator.simulate_nonce_tampering(mode=mode_str, sig_type=sig_type)
    results.append({
        "scenario": "2. Nonce Manipulation",
        "component": "Nonce (12-byte IV)",
        "mutation": res_nonce.mutation_description,
        "detection": "✓ PASS" if res_nonce.passed else "✗ FAIL",
        "recovery": "✓ REJECTED (0 Bytes Leaked)" if not res_nonce.plaintext_recovered else "✗ LEAKED",
        "rejection_type": res_nonce.rejection_type or "Rejected",
        "description": "Adversary alters the 96-bit initialization vector. Signature verification detects alteration before decryption.",
    })

    # 3. Signature Forgery / Corruption
    res_sig = AttackSimulator.simulate_signature_tampering(mode=mode_str, sig_type=sig_type)
    results.append({
        "scenario": "3. Digital Signature Modification",
        "component": "Signature Payload",
        "mutation": res_sig.mutation_description,
        "detection": "✓ PASS" if res_sig.passed else "✗ FAIL",
        "recovery": "✓ REJECTED (0 Bytes Leaked)" if not res_sig.plaintext_recovered else "✗ LEAKED",
        "rejection_type": res_sig.rejection_type or "SignatureVerificationError",
        "description": "Adversary presents forged or corrupted signature bytes. Message rejected immediately prior to decryption.",
    })

    return results


# =============================================================================
# STREAMLIT UI PRESENTATION FUNCTIONS
# =============================================================================

def render_pipeline_diagram() -> None:
    """Render the academic communication pipeline diagram."""
    st.markdown(
        """
        <div style="background: #0f172a; border: 1px solid #334155; border-radius: 8px; padding: 1rem; margin-bottom: 1.5rem;">
            <div style="font-weight: 600; font-size: 0.95rem; color: #38bdf8; margin-bottom: 0.6rem; text-transform: uppercase; letter-spacing: 0.05em;">
                🛡️ End-to-End Secure Communication Pipeline (Verify-Then-Decrypt)
            </div>
            <div style="display: flex; flex-wrap: wrap; align-items: center; justify-content: space-between; font-size: 0.82rem; color: #cbd5e1; gap: 0.4rem;">
                <span style="background: #1e293b; padding: 0.35rem 0.6rem; border-radius: 6px; border: 1px solid #475569;">1. PLAINTEXT</span>
                <span style="color: #64748b;">➔</span>
                <span style="background: #1e293b; padding: 0.35rem 0.6rem; border-radius: 6px; border: 1px solid #475569;">2. KEY ESTABLISHMENT</span>
                <span style="color: #64748b;">➔</span>
                <span style="background: #1e293b; padding: 0.35rem 0.6rem; border-radius: 6px; border: 1px solid #475569;">3. HKDF (SHA-384)</span>
                <span style="color: #64748b;">➔</span>
                <span style="background: #1e293b; padding: 0.35rem 0.6rem; border-radius: 6px; border: 1px solid #475569;">4. AES-256-GCM</span>
                <span style="color: #64748b;">➔</span>
                <span style="background: #1e293b; padding: 0.35rem 0.6rem; border-radius: 6px; border: 1px solid #475569;">5. SIGNATURE</span>
                <span style="color: #38bdf8; font-weight: bold;">⚡ WIRE ⚡</span>
                <span style="background: #1e293b; padding: 0.35rem 0.6rem; border-radius: 6px; border: 1px solid #38bdf8;">6. VERIFY SIG</span>
                <span style="color: #64748b;">➔</span>
                <span style="background: #1e293b; padding: 0.35rem 0.6rem; border-radius: 6px; border: 1px solid #475569;">7. DECAPSULATE</span>
                <span style="color: #64748b;">➔</span>
                <span style="background: #1e293b; padding: 0.35rem 0.6rem; border-radius: 6px; border: 1px solid #475569;">8. DECRYPT</span>
                <span style="color: #64748b;">➔</span>
                <span style="background: #10b981; color: #022c22; font-weight: bold; padding: 0.35rem 0.6rem; border-radius: 6px;">9. RECOVERED</span>
            </div>
        </div>
        """,
        unsafe_allow_html=True,
    )


def render_live_results_cards(results: list[dict[str, Any]]) -> None:
    """Render 3 structured result cards (Classical, Pure PQC, Hybrid)."""
    st.markdown("### Execution Result Cards")

    # Group into Classical, Pure PQC, Hybrid
    classical = next((r for r in results if r["mode"] == "A"), None)
    pqc_mldsa = next((r for r in results if r["mode"] == "B"), None)
    hybrid_mldsa = next((r for r in results if r["algorithm_id"] == HYBRID_ECDH_MLKEM_MLDSA_AES256_GCM), None)

    col1, col2, col3 = st.columns(3)

    if classical:
        with col1:
            st.markdown(
                f"""
                <div style="background: #1e293b; border-radius: 8px; border: 1px solid #3b82f6; padding: 1.1rem; height: 100%;">
                    <div style="color: #60a5fa; font-size: 1.15rem; font-weight: 700; margin-bottom: 0.5rem;">
                        CLASSICAL BASELINE
                    </div>
                    <div style="font-size: 0.85rem; color: #94a3b8; margin-bottom: 0.8rem;">Mode A • Legacy NIST Suite</div>
                    <hr style="border-color: #334155; margin: 0.5rem 0;">
                    <p style="margin: 0.3rem 0; font-size: 0.88rem;"><b>Key Establishment:</b><br><span style="color: #e2e8f0;">{classical['key_establishment']}</span></p>
                    <p style="margin: 0.3rem 0; font-size: 0.88rem;"><b>Digital Signature:</b><br><span style="color: #e2e8f0;">{classical['signature']}</span></p>
                    <p style="margin: 0.3rem 0; font-size: 0.88rem;"><b>Encryption:</b><br><span style="color: #e2e8f0;">AES-256-GCM</span></p>
                    <hr style="border-color: #334155; margin: 0.5rem 0;">
                    <p style="margin: 0.3rem 0; font-size: 0.88rem;"><b>Verification:</b> <span style="color: #10b981; font-weight: 600;">{classical['verification_status']}</span></p>
                    <p style="margin: 0.3rem 0; font-size: 0.88rem;"><b>Decryption:</b> <span style="color: #10b981; font-weight: 600;">{classical['decryption_status']}</span></p>
                    <p style="margin: 0.3rem 0; font-size: 0.88rem;"><b>Handshake Wire Size:</b> <span style="color: #cbd5e1;">{classical['wire_bytes']:,} B</span></p>
                    <p style="margin: 0.3rem 0; font-size: 0.88rem;"><b>Live Exec Time:</b> <span style="color: #cbd5e1;">{classical['elapsed_ms']:.2f} ms</span><br><small style="color: #64748b;">(demonstration only)</small></p>
                    <hr style="border-color: #334155; margin: 0.5rem 0;">
                    <div style="background: #0f172a; padding: 0.5rem; border-radius: 5px; font-size: 0.82rem;">
                        <b>Recovered Message:</b><br>
                        <span style="color: #38bdf8; font-family: monospace;">"{html.escape(classical['recovered_plaintext'])}"</span>
                    </div>
                </div>
                """,
                unsafe_allow_html=True,
            )

    if pqc_mldsa:
        with col2:
            st.markdown(
                f"""
                <div style="background: #1e293b; border-radius: 8px; border: 1px solid #10b981; padding: 1.1rem; height: 100%;">
                    <div style="color: #34d399; font-size: 1.15rem; font-weight: 700; margin-bottom: 0.5rem;">
                        PURE POST-QUANTUM
                    </div>
                    <div style="font-size: 0.85rem; color: #94a3b8; margin-bottom: 0.8rem;">Mode B • FIPS 203 + FIPS 204</div>
                    <hr style="border-color: #334155; margin: 0.5rem 0;">
                    <p style="margin: 0.3rem 0; font-size: 0.88rem;"><b>Key Establishment:</b><br><span style="color: #e2e8f0;">{pqc_mldsa['key_establishment']}</span></p>
                    <p style="margin: 0.3rem 0; font-size: 0.88rem;"><b>Digital Signature:</b><br><span style="color: #e2e8f0;">{pqc_mldsa['signature']}</span></p>
                    <p style="margin: 0.3rem 0; font-size: 0.88rem;"><b>Encryption:</b><br><span style="color: #e2e8f0;">AES-256-GCM</span></p>
                    <hr style="border-color: #334155; margin: 0.5rem 0;">
                    <p style="margin: 0.3rem 0; font-size: 0.88rem;"><b>Verification:</b> <span style="color: #10b981; font-weight: 600;">{pqc_mldsa['verification_status']}</span></p>
                    <p style="margin: 0.3rem 0; font-size: 0.88rem;"><b>Decryption:</b> <span style="color: #10b981; font-weight: 600;">{pqc_mldsa['decryption_status']}</span></p>
                    <p style="margin: 0.3rem 0; font-size: 0.88rem;"><b>Handshake Wire Size:</b> <span style="color: #cbd5e1;">{pqc_mldsa['wire_bytes']:,} B</span></p>
                    <p style="margin: 0.3rem 0; font-size: 0.88rem;"><b>Live Exec Time:</b> <span style="color: #cbd5e1;">{pqc_mldsa['elapsed_ms']:.2f} ms</span><br><small style="color: #64748b;">(demonstration only)</small></p>
                    <hr style="border-color: #334155; margin: 0.5rem 0;">
                    <div style="background: #0f172a; padding: 0.5rem; border-radius: 5px; font-size: 0.82rem;">
                        <b>Recovered Message:</b><br>
                        <span style="color: #38bdf8; font-family: monospace;">"{html.escape(pqc_mldsa['recovered_plaintext'])}"</span>
                    </div>
                </div>
                """,
                unsafe_allow_html=True,
            )

    if hybrid_mldsa:
        with col3:
            st.markdown(
                f"""
                <div style="background: #1e293b; border-radius: 8px; border: 1px solid #a855f7; padding: 1.1rem; height: 100%;">
                    <div style="color: #c084fc; font-size: 1.15rem; font-weight: 700; margin-bottom: 0.5rem;">
                        HYBRID DUAL KEX
                    </div>
                    <div style="font-size: 0.85rem; color: #94a3b8; margin-bottom: 0.8rem;">Mode D • Dual Security Defense</div>
                    <hr style="border-color: #334155; margin: 0.5rem 0;">
                    <p style="margin: 0.3rem 0; font-size: 0.88rem;"><b>Key Establishment:</b><br><span style="color: #e2e8f0;">{hybrid_mldsa['key_establishment']}</span></p>
                    <p style="margin: 0.3rem 0; font-size: 0.88rem;"><b>Digital Signature:</b><br><span style="color: #e2e8f0;">{hybrid_mldsa['signature']}</span></p>
                    <p style="margin: 0.3rem 0; font-size: 0.88rem;"><b>Encryption:</b><br><span style="color: #e2e8f0;">AES-256-GCM</span></p>
                    <hr style="border-color: #334155; margin: 0.5rem 0;">
                    <p style="margin: 0.3rem 0; font-size: 0.88rem;"><b>Verification:</b> <span style="color: #10b981; font-weight: 600;">{hybrid_mldsa['verification_status']}</span></p>
                    <p style="margin: 0.3rem 0; font-size: 0.88rem;"><b>Decryption:</b> <span style="color: #10b981; font-weight: 600;">{hybrid_mldsa['decryption_status']}</span></p>
                    <p style="margin: 0.3rem 0; font-size: 0.88rem;"><b>Handshake Wire Size:</b> <span style="color: #cbd5e1;">{hybrid_mldsa['wire_bytes']:,} B</span></p>
                    <p style="margin: 0.3rem 0; font-size: 0.88rem;"><b>Live Exec Time:</b> <span style="color: #cbd5e1;">{hybrid_mldsa['elapsed_ms']:.2f} ms</span><br><small style="color: #64748b;">(demonstration only)</small></p>
                    <hr style="border-color: #334155; margin: 0.5rem 0;">
                    <div style="background: #0f172a; padding: 0.5rem; border-radius: 5px; font-size: 0.82rem;">
                        <b>Recovered Message:</b><br>
                        <span style="color: #38bdf8; font-family: monospace;">"{html.escape(hybrid_mldsa['recovered_plaintext'])}"</span>
                    </div>
                </div>
                """,
                unsafe_allow_html=True,
            )


def render_side_by_side_table(results: list[dict[str, Any]]) -> None:
    """Render the comprehensive side-by-side comparison table."""
    st.markdown("### Side-by-Side Configuration Matrix")
    st.markdown(
        "<small style='color: #94a3b8;'>Demonstrating identical message transmission across distinct cryptographic configurations at runtime.</small>",
        unsafe_allow_html=True,
    )

    table_data = []
    for r in results:
        table_data.append({
            "Configuration": r["name"],
            "Key Establishment": r["key_establishment"],
            "Digital Signature": r["signature"],
            "Encryption": r["encryption"],
            "Verification": r["verification_status"],
            "Decryption": r["decryption_status"],
            "Wire Size": f"{r['wire_bytes']:,} B",
            "Live Exec Time": f"{r['elapsed_ms']:.2f} ms",
        })

    df = pd.DataFrame(table_data)
    st.dataframe(df, use_container_width=True, hide_index=True)
    st.caption("Note: 'Live Exec Time' is demonstration execution latency measured for this interaction and does not replace formal Phase 10 benchmark datasets.")


def render_step_details_expander(results: list[dict[str, Any]]) -> None:
    """Render expandable operational progress for each configuration."""
    with st.expander("🔍 View Detailed Step-by-Step Execution Logs", expanded=False):
        for r in results:
            st.markdown(f"#### {r['name']} (`{r['algorithm_id']}`)")
            for s in r["steps"]:
                st.markdown(f"- **{s['step']}**: `{s['status']}` — {s['detail']}")
            st.markdown("---")


def render_migration_path_explorer() -> None:
    """Render interactive staged migration paths explorer."""
    st.markdown("### Staged Post-Quantum Migration Paths")
    st.markdown(
        "<small style='color: #94a3b8;'>Explore how systems transition from legacy classical cryptography to hybrid and pure post-quantum algorithms without communication disruption.</small>",
        unsafe_allow_html=True,
    )

    paths = list(get_standard_paths().values())
    path_options = [p.name for p in paths]
    selected_name = st.selectbox("Select Migration Scenario", options=path_options, index=0)
    selected_path = next((p for p in paths if p.name == selected_name), paths[0])

    st.markdown(f"**Description:** {selected_path.description}")

    # Render step cards
    cols = st.columns(len(selected_path.steps))
    for i, step in enumerate(selected_path.steps):
        with cols[i]:
            stage_badge_color = {
                "CLASSICAL": "#3b82f6",
                "HYBRID": "#a855f7",
                "PURE_PQC": "#10b981",
            }.get(step.stage.value, "#64748b")

            st.markdown(
                f"""
                <div style="background: #1e293b; border-radius: 8px; border: 1px solid {stage_badge_color}; padding: 0.9rem; min-height: 190px;">
                    <div style="background: {stage_badge_color}; color: #ffffff; display: inline-block; padding: 0.2rem 0.5rem; border-radius: 4px; font-size: 0.75rem; font-weight: 700; margin-bottom: 0.5rem;">
                        STAGE {i+1}: {step.stage.value}
                    </div>
                    <div style="font-weight: 600; font-size: 0.9rem; color: #f8fafc; margin-bottom: 0.3rem;">
                        {step.label}
                    </div>
                    <div style="font-size: 0.8rem; color: #94a3b8; font-family: monospace; word-break: break-all; margin-bottom: 0.5rem;">
                        {step.algorithm_id}
                    </div>
                    <div style="font-size: 0.78rem; color: #cbd5e1;">
                        {step.description}
                    </div>
                </div>
                """,
                unsafe_allow_html=True,
            )


# =============================================================================
# MAIN LIVE DEMONSTRATION UI ENTRYPOINT
# =============================================================================

def render_live_demonstration(datasets: dict[str, Any]) -> None:
    """
    Main entry point for the Live Demonstration experience.
    """
    # Header Banner
    st.markdown(
        """
        <div style="padding: 1.2rem 1.5rem; background: linear-gradient(135deg, #1e293b 0%, #0f172a 100%); border-radius: 10px; margin-bottom: 1.2rem; border: 1px solid #334155; color: white;">
            <div style="display: flex; justify-content: space-between; align-items: center;">
                <div>
                    <h1 style="margin: 0; font-size: 1.75rem; font-weight: 700; color: #f8fafc;">
                        POST-QUANTUM SECURE COMMUNICATION
                    </h1>
                    <p style="margin: 0.3rem 0 0 0; font-size: 0.95rem; color: #94a3b8;">
                        Interactive demonstration of classical, hybrid, and post-quantum secure communication.
                    </p>
                </div>
                <div style="background: #0284c7; padding: 0.4rem 0.8rem; border-radius: 6px; font-size: 0.8rem; font-weight: 600;">
                    LIVE ENVIRONMENT
                </div>
            </div>
        </div>
        """,
        unsafe_allow_html=True,
    )

    # Communication pipeline visualization
    render_pipeline_diagram()

    # Input Fields
    st.markdown("### Message Transmission Input")
    col_in1, col_in2 = st.columns([3, 1])

    with col_in1:
        default_msg = "Hello Lecturer! This is a post-quantum secure communication demonstration."
        user_message = st.text_area(
            "Enter message to securely transmit",
            value=default_msg,
            height=85,
            help="Enter any arbitrary plaintext message. The framework will encrypt, sign, verify, and decrypt it across all 6 configurations.",
        )

    with col_in2:
        user_aad = st.text_input(
            "Additional Authenticated Data (AAD) [Optional]",
            value="",
            help="Optional unencrypted authenticated header tied to AES-GCM and signature.",
        )
        st.markdown(
            "<small style='color: #64748b;'>AAD is authenticated but unencrypted metadata.</small>",
            unsafe_allow_html=True,
        )

    # Action Buttons
    col_b1, col_b2, col_b3 = st.columns([2, 2, 2])

    with col_b1:
        btn_check = st.button("🛡️ CHECK SECURE COMMUNICATION", type="primary", use_container_width=True)

    with col_b2:
        btn_tamper = st.button("⚠️ TEST CONTROLLED TAMPERING", use_container_width=True)

    with col_b3:
        btn_to_dash = st.button("📊 VIEW EXPERIMENTAL RESULTS →", use_container_width=True)

    if btn_to_dash:
        st.session_state["main_view"] = "research_dashboard"
        st.rerun()

    st.markdown("---")

    # Handle State Persistence for Live Executions
    if "live_results" not in st.session_state:
        st.session_state["live_results"] = None

    if "tamper_results" not in st.session_state:
        st.session_state["tamper_results"] = None

    # Execution Trigger 1: Check Secure Communication
    if btn_check:
        with st.spinner("Executing real cryptographic workflows across Classical, PQC, and Hybrid suites..."):
            results = run_all_live_configurations(
                plaintext=user_message,
                aad_str=user_aad,
            )
            st.session_state["live_results"] = results
            st.session_state["tamper_results"] = None

    # Execution Trigger 2: Test Controlled Tampering
    if btn_tamper:
        with st.spinner("Executing controlled adversarial mutation attacks via Phase 9 AttackSimulator..."):
            tamper_res = run_controlled_tamper_demonstration(mode_str="B", sig_type="mldsa")
            st.session_state["tamper_results"] = tamper_res

    # Render Live Results if available
    if st.session_state["live_results"]:
        results = st.session_state["live_results"]
        render_live_results_cards(results)
        st.markdown("---")
        render_side_by_side_table(results)
        render_step_details_expander(results)

    # Render Tampering Results if available
    if st.session_state["tamper_results"]:
        st.markdown("### ⚠️ Controlled Tampering Simulation (Phase 9 Invariants)")
        st.markdown(
            """
            <div style="background: #0f172a; border: 1px solid #475569; border-radius: 8px; padding: 1rem; margin-bottom: 1rem;">
                <div style="font-weight: 600; color: #f8fafc; margin-bottom: 0.4rem;">
                    Adversarial Pipeline:
                </div>
                <div style="font-size: 0.85rem; color: #cbd5e1; font-family: monospace;">
                    Original Message ➔ Secure Message Created ➔ Controlled Tampering ➔ Receiver Verification ➔ <span style="color: #ef4444; font-weight: bold;">REJECTED</span>
                </div>
            </div>
            """,
            unsafe_allow_html=True,
        )

        tamper_rows = []
        for t in st.session_state["tamper_results"]:
            tamper_rows.append({
                "Adversarial Scenario": t["scenario"],
                "Target Component": t["component"],
                "Tamper Detection": t["detection"],
                "Message Recovery": t["recovery"],
                "Rejection Type": t["rejection_type"],
                "Security Guarantee": t["description"],
            })

        st.dataframe(pd.DataFrame(tamper_rows), use_container_width=True, hide_index=True)

        st.success("✓ **Controlled tampering scenario rejected as expected.** All modified payloads were rejected before decryption without plaintext recovery.")
        st.info("ℹ️ **Protocol Scope Notice:** Replay detection is outside the current stateless protocol scope.")

    # Always show Migration Explorer
    st.markdown("---")
    render_migration_path_explorer()

    # Footer navigation callout
    st.markdown("---")
    c_f1, c_f2 = st.columns([3, 1])
    with c_f1:
        st.markdown(
            "**Ready to explore the full empirical dataset?** "
            "Examine the 9 formal research tabs including microsecond benchmarks, MTU packet analysis, and 36-pair compatibility matrices."
        )
    with c_f2:
        if st.button("📊 Open Research Dashboard", type="primary", use_container_width=True):
            st.session_state["main_view"] = "research_dashboard"
            st.rerun()
