"""
src/dashboard/charts.py
Post-Quantum Secure Communication & Migration Framework

Interactive Plotly chart builders for benchmark and migration visualizations.

Phase 13: Interactive Dashboard & Visualization

Design Principles:
  - High aesthetic research presentation (clean palettes, precise hover tooltips).
  - Explicit units (microseconds vs milliseconds, bytes vs KiB).
  - No misleading multi-scale single axes; distinct charts or log-scales where appropriate.
  - Zero value-judgment styling (no green/red "good vs bad" rankings).
"""

from __future__ import annotations

from typing import Any
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go

# Research color palette (category-based, neutral)
COLOR_CLASSICAL = "#1f77b4"  # Muted Blue
COLOR_PQC = "#2ca02c"        # Muted Emerald
COLOR_HYBRID = "#ff7f0e"     # Muted Amber
COLOR_HASH = "#9467bd"       # Muted Purple

CATEGORY_COLORS = {
    "Mode A": COLOR_CLASSICAL,
    "Mode B": COLOR_PQC,
    "Mode C": COLOR_HASH,
    "Mode D (ML-DSA)": COLOR_HYBRID,
    "Mode D (SLH-DSA)": "#e377c2",
    "Mode D (ECDSA)": "#8c564b",
    "Classical": COLOR_CLASSICAL,
    "Pure PQC": COLOR_PQC,
    "Hybrid": COLOR_HYBRID,
}


def create_keygen_latency_chart(benchmark_summary: dict[str, Any]) -> go.Figure:
    """Create bar chart comparing key generation latencies."""
    ke = benchmark_summary.get("key_establishment", {})

    items = [
        {"Algorithm": "ECDH P-384", "Configuration": "Mode A (Classical)", "Mean Latency (μs)": ke.get("ecdh_p384_keygen", {}).get("mean", 1334.5), "P95": ke.get("ecdh_p384_keygen", {}).get("p95", 2201.3), "StdDev": ke.get("ecdh_p384_keygen", {}).get("stddev", 430.1)},
        {"Algorithm": "ML-KEM-768", "Configuration": "Mode B / C (Pure PQC)", "Mean Latency (μs)": ke.get("mlkem_768_keygen", {}).get("mean", 301.0), "P95": ke.get("mlkem_768_keygen", {}).get("p95", 473.5), "StdDev": ke.get("mlkem_768_keygen", {}).get("stddev", 90.0)},
        {"Algorithm": "ECDH P-384 + ML-KEM-768", "Configuration": "Mode D (Hybrid Dual)", "Mean Latency (μs)": ke.get("hybrid_p384_mlkem768_keygen", {}).get("mean", 1748.6), "P95": ke.get("hybrid_p384_mlkem768_keygen", {}).get("p95", 2681.9), "StdDev": ke.get("hybrid_p384_mlkem768_keygen", {}).get("stddev", 524.5)},
    ]
    df = pd.DataFrame(items)

    fig = px.bar(
        df,
        x="Algorithm",
        y="Mean Latency (μs)",
        color="Configuration",
        error_y="StdDev",
        text="Mean Latency (μs)",
        title="Key Generation Latency Comparison (Mean ± StdDev)",
        hover_data=["P95", "Configuration"],
        color_discrete_map={
            "Mode A (Classical)": COLOR_CLASSICAL,
            "Mode B / C (Pure PQC)": COLOR_PQC,
            "Mode D (Hybrid Dual)": COLOR_HYBRID,
        },
    )
    fig.update_traces(texttemplate="%{text:.1f} μs", textposition="outside")
    fig.update_layout(yaxis_title="Latency (microseconds, μs)", xaxis_title="Key Generation Primitive", template="plotly_white", margin=dict(t=50, b=40, l=40, r=40))
    return fig


def create_key_establishment_ops_chart(benchmark_summary: dict[str, Any]) -> go.Figure:
    """Create grouped bar chart for key establishment operations."""
    ke = benchmark_summary.get("key_establishment", {})

    items = [
        {"Operation": "ECDH Shared Secret Derivation", "Type": "Classical Derivation", "Mean Latency (μs)": ke.get("ecdh_p384_derivation", {}).get("mean", 1842.5), "Median": ke.get("ecdh_p384_derivation", {}).get("median", 1550.7)},
        {"Operation": "ML-KEM-768 Encapsulation", "Type": "PQC Encapsulation", "Mean Latency (μs)": ke.get("mlkem_768_encapsulate", {}).get("mean", 68.7), "Median": ke.get("mlkem_768_encapsulate", {}).get("median", 65.2)},
        {"Operation": "ML-KEM-768 Decapsulation", "Type": "PQC Decapsulation", "Mean Latency (μs)": ke.get("mlkem_768_decapsulate", {}).get("mean", 99.1), "Median": ke.get("mlkem_768_decapsulate", {}).get("median", 95.3)},
        {"Operation": "Hybrid Total Encapsulation", "Type": "Hybrid KEX", "Mean Latency (μs)": ke.get("hybrid_total_encapsulate", {}).get("mean", 3207.5), "Median": ke.get("hybrid_total_encapsulate", {}).get("median", 2824.2)},
        {"Operation": "Hybrid Total Decapsulation", "Type": "Hybrid KEX", "Mean Latency (μs)": ke.get("hybrid_total_decapsulate", {}).get("mean", 1932.4), "Median": ke.get("hybrid_total_decapsulate", {}).get("median", 1638.1)},
    ]
    df = pd.DataFrame(items)

    fig = px.bar(
        df,
        x="Operation",
        y="Mean Latency (μs)",
        color="Type",
        text="Mean Latency (μs)",
        title="Key Establishment Operations Latency (Mean)",
        hover_data=["Median", "Type"],
        color_discrete_map={
            "Classical Derivation": COLOR_CLASSICAL,
            "PQC Encapsulation": COLOR_PQC,
            "PQC Decapsulation": "#20b2aa",
            "Hybrid KEX": COLOR_HYBRID,
        },
    )
    fig.update_traces(texttemplate="%{text:.1f} μs", textposition="outside")
    fig.update_layout(yaxis_title="Latency (microseconds, μs)", xaxis_title="", template="plotly_white", margin=dict(t=50, b=40, l=40, r=40))
    return fig


def create_signature_latency_charts(benchmark_summary: dict[str, Any]) -> tuple[go.Figure, go.Figure]:
    """Create separate signature signing and verification charts to handle C-Rust vs Pure-Python scale cleanly."""
    sig = benchmark_summary.get("signatures", {})

    # 1. C/Rust implementations (ECDSA & ML-DSA in microseconds)
    items_fast = [
        {"Algorithm": "ECDSA P-384", "Operation": "Sign (1 KiB)", "Latency (μs)": sig.get("ecdsa_p384_sign_1KiB", {}).get("mean", 1451.6)},
        {"Algorithm": "ECDSA P-384", "Operation": "Verify (1 KiB)", "Latency (μs)": sig.get("ecdsa_p384_verify_1KiB", {}).get("mean", 1420.4)},
        {"Algorithm": "ML-DSA-65", "Operation": "Sign (1 KiB)", "Latency (μs)": sig.get("mldsa_65_sign_1KiB", {}).get("mean", 1039.6)},
        {"Algorithm": "ML-DSA-65", "Operation": "Verify (1 KiB)", "Latency (μs)": sig.get("mldsa_65_verify_1KiB", {}).get("mean", 298.3)},
    ]
    df_fast = pd.DataFrame(items_fast)
    fig_fast = px.bar(
        df_fast,
        x="Algorithm",
        y="Latency (μs)",
        color="Operation",
        barmode="group",
        text="Latency (μs)",
        title="Digital Signature Latency: ECDSA P-384 vs ML-DSA-65 (cryptography 48.0.0)",
        color_discrete_map={"Sign (1 KiB)": "#3366cc", "Verify (1 KiB)": "#109618"},
    )
    fig_fast.update_traces(texttemplate="%{text:.1f} μs", textposition="outside")
    fig_fast.update_layout(yaxis_title="Latency (microseconds, μs)", template="plotly_white")

    # 2. SLH-DSA in milliseconds (Pure Python implementation)
    items_slh = [
        {"Algorithm": "SLH-DSA-SHAKE-128f", "Operation": "Sign (1 KiB)", "Latency (ms)": sig.get("slhdsa_shake_128f_sign_1KiB", {}).get("mean", 245.70)},
        {"Algorithm": "SLH-DSA-SHAKE-128f", "Operation": "Verify (1 KiB)", "Latency (ms)": sig.get("slhdsa_shake_128f_verify_1KiB", {}).get("mean", 12.75)},
    ]
    df_slh = pd.DataFrame(items_slh)
    fig_slh = px.bar(
        df_slh,
        x="Operation",
        y="Latency (ms)",
        color="Operation",
        text="Latency (ms)",
        title="SLH-DSA-SHAKE-128f Latency (slh-dsa 0.2.5 Pure Python)",
        color_discrete_map={"Sign (1 KiB)": "#990099", "Verify (1 KiB)": "#ff9900"},
    )
    fig_slh.update_traces(texttemplate="%{text:.2f} ms", textposition="outside")
    fig_slh.update_layout(yaxis_title="Latency (milliseconds, ms)", template="plotly_white")

    return fig_fast, fig_slh


def create_e2e_latency_chart(benchmark_summary: dict[str, Any]) -> go.Figure:
    """Create end-to-end communication roundtrip latency chart."""
    e2e = benchmark_summary.get("end_to_end", {})

    items = [
        {"Configuration": "Mode A", "Suite": "Classical ECDH + ECDSA", "Send (μs)": e2e.get("Mode A", {}).get("send", {}).get("mean", 5127.2), "Receive (μs)": e2e.get("Mode A", {}).get("receive", {}).get("mean", 2551.0), "Roundtrip (μs)": e2e.get("Mode A", {}).get("roundtrip", {}).get("mean", 7678.2)},
        {"Configuration": "Mode B", "Suite": "Pure PQC ML-KEM + ML-DSA", "Send (μs)": e2e.get("Mode B", {}).get("send", {}).get("mean", 1820.2), "Receive (μs)": e2e.get("Mode B", {}).get("receive", {}).get("mean", 388.8), "Roundtrip (μs)": e2e.get("Mode B", {}).get("roundtrip", {}).get("mean", 2209.0)},
        {"Configuration": "Mode D (ML-DSA)", "Suite": "Hybrid Dual KEX + ML-DSA", "Send (μs)": e2e.get("Mode D (ML-DSA)", {}).get("send", {}).get("mean", 5246.5), "Receive (μs)": e2e.get("Mode D (ML-DSA)", {}).get("receive", {}).get("mean", 1565.1), "Roundtrip (μs)": e2e.get("Mode D (ML-DSA)", {}).get("roundtrip", {}).get("mean", 6811.6)},
        {"Configuration": "Mode D (ECDSA)", "Suite": "Hybrid Dual KEX + ECDSA", "Send (μs)": e2e.get("Mode D (ECDSA)", {}).get("send", {}).get("mean", 6395.1), "Receive (μs)": e2e.get("Mode D (ECDSA)", {}).get("receive", {}).get("mean", 2548.1), "Roundtrip (μs)": e2e.get("Mode D (ECDSA)", {}).get("roundtrip", {}).get("mean", 8943.2)},
    ]
    df = pd.DataFrame(items)

    fig = px.bar(
        df,
        x="Configuration",
        y="Roundtrip (μs)",
        color="Configuration",
        text="Roundtrip (μs)",
        title="End-to-End Round-Trip Latency (Mean, 1 KiB Payload)",
        hover_data=["Send (μs)", "Receive (μs)", "Suite"],
        color_discrete_map={
            "Mode A": COLOR_CLASSICAL,
            "Mode B": COLOR_PQC,
            "Mode D (ML-DSA)": COLOR_HYBRID,
            "Mode D (ECDSA)": "#8c564b",
        },
    )
    fig.update_traces(texttemplate="%{text:.1f} μs", textposition="outside")
    fig.update_layout(yaxis_title="Roundtrip Latency (microseconds, μs)", template="plotly_white")
    return fig


def create_size_comparison_chart(benchmark_sizes: dict[str, Any]) -> go.Figure:
    """Create grouped bar chart comparing Raw Cryptographic Artifact size vs Wire JSON size."""
    matrix = benchmark_sizes.get("matrix", [])
    items = []
    for row in matrix:
        items.append({
            "Configuration": row.get("label", "Unknown"),
            "Size Category": "Raw Cryptographic Artifacts (Bytes)",
            "Bytes": int(row.get("raw_crypto_total_bytes", 0)),
        })
        items.append({
            "Configuration": row.get("label", "Unknown"),
            "Size Category": "Total Serialized Wire Size (Bytes)",
            "Bytes": int(row.get("wire_json_total_bytes", 0)),
        })
    df = pd.DataFrame(items)

    fig = px.bar(
        df,
        x="Configuration",
        y="Bytes",
        color="Size Category",
        barmode="group",
        text="Bytes",
        title="Communication Payload Size Comparison (1 KiB Plaintext)",
        color_discrete_map={
            "Raw Cryptographic Artifacts (Bytes)": "#4682b4",
            "Total Serialized Wire Size (Bytes)": "#ff8c00",
        },
    )
    fig.update_traces(texttemplate="%{text:,} B", textposition="outside")
    fig.update_layout(yaxis_title="Size (Bytes)", xaxis_title="", template="plotly_white")
    return fig


def create_wire_overhead_chart(benchmark_sizes: dict[str, Any]) -> go.Figure:
    """Create chart showing percentage wire overhead relative to Mode A baseline."""
    matrix = benchmark_sizes.get("matrix", [])
    base_wire = 2084
    for r in matrix:
        if r.get("label") == "Mode A":
            base_wire = int(r.get("wire_json_total_bytes", 2084))
            break

    items = []
    for r in matrix:
        w = int(r.get("wire_json_total_bytes", 0))
        pct = ((w - base_wire) / base_wire) * 100.0
        items.append({
            "Configuration": r.get("label", ""),
            "Wire Size (Bytes)": w,
            "Wire Overhead vs Mode A (%)": round(pct, 2),
        })
    df = pd.DataFrame(items)

    fig = px.bar(
        df,
        x="Configuration",
        y="Wire Overhead vs Mode A (%)",
        color="Configuration",
        text="Wire Overhead vs Mode A (%)",
        title="Wire Overhead Percentage Relative to Mode A Baseline (2,084 B)",
        color_discrete_map=CATEGORY_COLORS,
    )
    fig.update_traces(texttemplate="+%{text:.1f}%", textposition="outside")
    fig.update_layout(yaxis_title="Overhead Relative to Mode A (%)", template="plotly_white")
    return fig


def create_transition_deltas_chart(deltas_df: pd.DataFrame) -> tuple[go.Figure, go.Figure]:
    """Create transition latency and wire size delta charts."""
    # 1. Latency deltas
    fig_lat = px.bar(
        deltas_df,
        x="transition_id",
        y="latency_pct_delta",
        color="transition_type",
        text="latency_pct_delta",
        title="Migration Transition Latency Delta (%) Relative to Step Baseline",
        hover_data=["source_suite", "target_suite", "latency_delta_us"],
        color_discrete_map={
            "FORWARD": "#2ca02c",
            "ROLLBACK": "#d62728",
            "INTRA_STAGE": "#9467bd",
        },
    )
    fig_lat.update_traces(texttemplate="%{text:+.1f}%", textposition="outside")
    fig_lat.update_layout(yaxis_title="Latency Delta (%)", xaxis_title="Migration Transition", template="plotly_white")

    # 2. Wire size deltas
    fig_wire = px.bar(
        deltas_df,
        x="transition_id",
        y="wire_size_delta_bytes",
        color="transition_type",
        text="wire_size_delta_bytes",
        title="Migration Transition Wire Size Delta (Bytes)",
        hover_data=["source_suite", "target_suite", "wire_size_pct_delta"],
        color_discrete_map={
            "FORWARD": "#2ca02c",
            "ROLLBACK": "#d62728",
            "INTRA_STAGE": "#9467bd",
        },
    )
    fig_wire.update_traces(texttemplate="%{text:+,} B", textposition="outside")
    fig_wire.update_layout(yaxis_title="Wire Size Delta (Bytes)", xaxis_title="Migration Transition", template="plotly_white")

    return fig_lat, fig_wire


def create_compatibility_heatmap(compat_df: pd.DataFrame) -> go.Figure:
    """Create 6x6 pairwise compatibility matrix heatmap."""
    pivot = compat_df.pivot(index="sender_suite", columns="receiver_suite", values="actual_outcome")

    short_labels = {
        "CLASSICAL_ECDH_ECDSA_AES256_GCM": "Mode A",
        "PQC_MLKEM_MLDSA_AES256_GCM": "Mode B",
        "PQC_MLKEM_SLHDSA_AES256_GCM": "Mode C",
        "HYBRID_ECDH_MLKEM_MLDSA_AES256_GCM": "Mode D (ML-DSA)",
        "HYBRID_ECDH_MLKEM_SLHDSA_AES256_GCM": "Mode D (SLH-DSA)",
        "HYBRID_ECDH_MLKEM_ECDSA_AES256_GCM": "Mode D (ECDSA)",
    }

    index_labels = [short_labels.get(idx, idx) for idx in pivot.index]
    col_labels = [short_labels.get(col, col) for col in pivot.columns]

    z_vals = [[1 if val == "ACCEPT" else 0 for val in row] for row in pivot.values]
    text_vals = [[val for val in row] for row in pivot.values]

    fig = go.Figure(
        data=go.Heatmap(
            z=z_vals,
            x=col_labels,
            y=index_labels,
            text=text_vals,
            texttemplate="%{text}",
            textfont=dict(size=14, color="white"),
            colorscale=[[0, "#4a5568"], [1, "#2b6cb0"]],  # Neutral Dark Slate to Slate Blue (not red/green)
            showscale=False,
        )
    )
    fig.update_layout(
        title="Pairwise Cross-Suite Compatibility Matrix (6×6 Matrix / 36 Interactions)",
        xaxis_title="Receiver Configured Suite",
        yaxis_title="Sender Configured Suite",
        template="plotly_white",
        margin=dict(t=50, b=50, l=120, r=50),
    )
    return fig
