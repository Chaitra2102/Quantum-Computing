"""
src/communication/secure_communicator.py
Post-Quantum Secure Communication & Migration Framework

SecureCommunicator — mode-agnostic send/receive orchestration.

This class implements the full secure communication workflow defined in
ARCHITECTURE.md § 4.  It depends ONLY on provider interfaces (base.py),
never on concrete implementations.  Algorithm selection is fully determined
by the CryptoConfig injected at construction time.

Workflow (sender side):
  [1] Generate sender key pairs (KE + signature)
  [2] Key establishment (DH exchange or KEM encapsulate)
  [3] Derive AES key via HKDF
  [4] Encrypt plaintext → (ciphertext, nonce)
  [5] Sign (ciphertext || nonce)
  [6] Package into SecureMessage

Workflow (receiver side):
  [7] Verify signature over (ciphertext || nonce) — REJECT if false
  [8] Recover shared secret (DH exchange or KEM decapsulate)
  [9] Re-derive AES key via HKDF
  [10] Decrypt ciphertext → plaintext

Security policy:
  - Steps are executed in strict order; no step is skipped.
  - Signature verification (step 7) happens BEFORE decryption (step 10).
    This follows the "verify-then-decrypt" principle.
  - Authentication failure during decryption raises AuthenticationFailureError.
  - Signature failure raises SignatureVerificationError.
  - Neither error reveals key material.
  - HKDF info label is fixed per algorithm_id — ties the derived key to the suite.

ARCHITECTURE.md § 3.2 — SecureCommunicator
"""

from __future__ import annotations

import logging

from src.communication.message_bundle import PROTOCOL_VERSION, SecureMessage
from src.config.crypto_config import CryptoConfig
from src.exceptions import ModeMismatchError, SignatureVerificationError
from src.providers.base import KeyPair
from src.providers.symmetric.hkdf_provider import AES256_KEY_LENGTH

logger = logging.getLogger(__name__)

# HKDF info label — ties derived keys to this framework and key purpose.
# Changing this label invalidates all previously derived keys.
_HKDF_INFO_AES = b"pqcf-v1-aes256-session-key"


class SecureCommunicator:
    """
    Mode-agnostic secure communication orchestrator.

    Parameters
    ----------
    config:
        A CryptoConfig object containing concrete provider instances for
        key exchange, signature, encryption, and key derivation.
        This is the ONLY algorithm-specific dependency.

    Usage::

        config = ModeFactory.build(Mode.A)
        comm   = SecureCommunicator(config)

        # Sender side
        sender_keypairs, message = comm.send(
            plaintext=b"Hello, Bob!",
            receiver_ke_public_key=receiver_ke_kp.public_key,
        )

        # Receiver side
        plaintext = comm.receive(
            message=message,
            receiver_ke_private_key=receiver_ke_kp.private_key,
        )
    """

    def __init__(self, config: CryptoConfig) -> None:
        self._config = config

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def send(
        self,
        plaintext: bytes,
        receiver_ke_public_key: object,
        *,
        aad: bytes | None = None,
        metadata: dict | None = None,
    ) -> tuple[dict[str, KeyPair], SecureMessage]:
        """
        Perform the full sender-side secure communication workflow.

        Parameters
        ----------
        plaintext:
            Message bytes to encrypt and sign.
        receiver_ke_public_key:
            Receiver's key-establishment public key (already imported;
            type depends on the active KeyExchangeProvider).
        aad:
            Optional additional authenticated data for AES-GCM.
        metadata:
            Optional non-sensitive metadata to embed in the message.

        Returns
        -------
        (sender_keypairs, message)
            sender_keypairs: dict with keys "ke" and "sig", each a KeyPair.
              Callers should retain the KE keypair for the DH path (ECDH).
              Callers should retain the sig keypair to allow the receiver to
              verify the signature using the sig public key in the message.
            message: SecureMessage ready for transmission.

        Raises
        ------
        Various PQCFrameworkError subclasses on cryptographic failure.
        """
        cfg = self._config
        logger.info("SecureCommunicator.send: algorithm=%s", cfg.algorithm_id)

        # [1] Generate sender key pairs
        sender_ke_kp:  KeyPair = cfg.key_exchange.generate_keypair()
        sender_sig_kp: KeyPair = cfg.signature.generate_keypair()
        logger.debug("SecureCommunicator: sender key pairs generated")

        # [2] Key establishment — KEM path (ML-KEM) or DH path (ECDH)
        try:
            shared_secret, ke_ciphertext = cfg.key_exchange.encapsulate(receiver_ke_public_key)
            logger.debug("SecureCommunicator: KEM key encapsulation complete")
        except NotImplementedError:
            shared_secret = cfg.key_exchange.exchange(
                sender_ke_kp.private_key,
                receiver_ke_public_key,
            )
            ke_ciphertext = None
            logger.debug("SecureCommunicator: DH key exchange complete")

        # [3] Derive AES-256 session key
        aes_key: bytes = cfg.kdf.derive(
            input_keying_material=shared_secret,
            length=AES256_KEY_LENGTH,
            info=_HKDF_INFO_AES,
        )
        # SECURITY: aes_key and shared_secret are NOT logged.
        logger.debug("SecureCommunicator: AES key derived via HKDF")

        # [4] Encrypt plaintext
        payload = cfg.encryption.encrypt(aes_key, plaintext, aad)
        logger.debug(
            "SecureCommunicator: plaintext encrypted (%d bytes ciphertext)",
            len(payload.ciphertext),
        )

        # [5] Sign (ciphertext || nonce)
        # We build a temporary SecureMessage to get the canonical signed_data().
        # The signature is over ciphertext+nonce so it binds both the
        # encrypted content and the unique nonce.
        signed_data: bytes = payload.ciphertext + payload.nonce
        signature: bytes = cfg.signature.sign(sender_sig_kp.private_key, signed_data)
        logger.debug(
            "SecureCommunicator: message signed (%d bytes signature)",
            len(signature),
        )

        # [6] Export public keys for wire transmission
        ke_pub_bytes:  bytes = cfg.key_exchange.export_public_key_bytes(sender_ke_kp.public_key)
        sig_pub_bytes: bytes = cfg.signature.export_public_key_bytes(sender_sig_kp.public_key)

        # [6] Assemble SecureMessage
        message = SecureMessage(
            protocol_version=PROTOCOL_VERSION,
            algorithm_id=cfg.algorithm_id,
            sender_ke_public_key=ke_pub_bytes,
            sender_sig_public_key=sig_pub_bytes,
            ciphertext=payload.ciphertext,
            nonce=payload.nonce,
            signature=signature,
            ke_ciphertext=ke_ciphertext,
            metadata=metadata,
        )
        logger.info("SecureCommunicator.send: message assembled successfully")

        sender_keypairs = {"ke": sender_ke_kp, "sig": sender_sig_kp}
        return sender_keypairs, message

    def receive(
        self,
        message: SecureMessage,
        receiver_ke_private_key: object,
        *,
        aad: bytes | None = None,
    ) -> bytes:
        """
        Perform the full receiver-side secure communication workflow.

        Steps are executed in strict order:
          [7] Verify signature — REJECT on failure (raises SignatureVerificationError)
          [8] Recover shared secret
          [9] Re-derive AES key
          [10] Decrypt ciphertext → plaintext

        Parameters
        ----------
        message:
            SecureMessage received from the sender.
        receiver_ke_private_key:
            Receiver's key-establishment private key (DH path or KEM path).
        aad:
            Optional additional authenticated data; must match what was
            supplied during send().

        Returns
        -------
        bytes
            Decrypted plaintext if and only if all verifications pass.

        Raises
        ------
        SignatureVerificationError
            If signature verification fails. The message is REJECTED.
        AuthenticationFailureError
            If AES-GCM authentication fails. The message is REJECTED.
        Various PQCFrameworkError subclasses on other cryptographic failure.
        """
        cfg = self._config
        logger.info("SecureCommunicator.receive: algorithm=%s", cfg.algorithm_id)

        # [0] Verify algorithm suite binding to prevent mode confusion / downgrade
        if message.algorithm_id != cfg.algorithm_id:
            logger.warning(
                "SecureCommunicator.receive: algorithm ID mismatch. Message algorithm=%s, Configured algorithm=%s",
                message.algorithm_id,
                cfg.algorithm_id,
            )
            raise ModeMismatchError(
                f"Message algorithm '{message.algorithm_id}' does not match receiver configured algorithm '{cfg.algorithm_id}'"
            )

        # [7] Import sender's signing public key and VERIFY SIGNATURE FIRST
        sender_sig_pub = cfg.signature.import_public_key_bytes(message.sender_sig_public_key)
        signed_data: bytes = message.signed_data()  # ciphertext || nonce
        valid: bool = cfg.signature.verify(sender_sig_pub, signed_data, message.signature)

        if not valid:
            logger.warning(
                "SecureCommunicator.receive: SIGNATURE VERIFICATION FAILED — message rejected"
            )
            raise SignatureVerificationError(
                "Signature verification failed. The message has been rejected. "
                "Possible causes: message tampering, wrong signing key, or corrupt signature."
            )
        logger.debug("SecureCommunicator: signature verified")

        # [8] Recover shared secret — KEM path (ML-KEM) or DH path (ECDH)
        if message.ke_ciphertext is not None:
            shared_secret = cfg.key_exchange.decapsulate(
                receiver_ke_private_key,
                message.ke_ciphertext,
            )
            logger.debug("SecureCommunicator: KEM decapsulation complete")
        else:
            sender_ke_pub = cfg.key_exchange.import_public_key_bytes(message.sender_ke_public_key)
            shared_secret = cfg.key_exchange.exchange(
                receiver_ke_private_key,
                sender_ke_pub,
            )
            logger.debug("SecureCommunicator: DH key exchange recovered")
        logger.debug("SecureCommunicator: shared secret recovered")

        # [9] Re-derive AES key (same parameters as sender)
        aes_key: bytes = cfg.kdf.derive(
            input_keying_material=shared_secret,
            length=AES256_KEY_LENGTH,
            info=_HKDF_INFO_AES,
        )
        # SECURITY: aes_key and shared_secret are NOT logged.
        logger.debug("SecureCommunicator: AES key re-derived via HKDF")

        # [10] Decrypt ciphertext (AES-GCM authenticates + decrypts in one step)
        from src.providers.base import EncryptedPayload
        payload = EncryptedPayload(ciphertext=message.ciphertext, nonce=message.nonce)
        plaintext: bytes = cfg.encryption.decrypt(aes_key, payload, aad)
        logger.info(
            "SecureCommunicator.receive: decryption successful (%d bytes plaintext)",
            len(plaintext),
        )
        return plaintext
