"""
src/communication/session.py
Post-Quantum Secure Communication & Migration Framework

High-Level Secure Communication Session Abstraction.

ARCHITECTURE.md § 3.2 & PROJECT_SPEC.md
Phase 8: Encapsulates end-to-end communication workflows, state management,
cryptographic configuration inspection, and metadata generation across
Modes A, B, C, and D.

Security Invariants:
  - Interacts exclusively with SecureCommunicator and ModeFactory.
  - Never exposes private keys, shared secrets, AES session keys, or raw
    cryptographic key objects through the public API or serialized outputs.
  - Session identifiers are non-secret random identifiers generated via secrets.
"""

from __future__ import annotations

import dataclasses
import logging
import secrets
from typing import Any

from src.communication.message_bundle import PROTOCOL_VERSION, SecureMessage
from src.communication.secure_communicator import SecureCommunicator
from src.config.crypto_config import CryptoConfig, ModeFactory
from src.config.modes import Mode
from src.exceptions import PQCFrameworkError

logger = logging.getLogger(__name__)


def _extract_provider_metadata(config: CryptoConfig) -> dict[str, str]:
    """
    Extract human-readable, non-secret algorithm and provider metadata.
    """
    ke_type = type(config.key_exchange).__name__
    sig_type = type(config.signature).__name__

    # Key Establishment label
    if ke_type == "ECDHProvider":
        ke_label = "ECDH P-384"
    elif ke_type == "MLKEMProvider":
        param = getattr(config.key_exchange, "parameter_set", "ML-KEM-768")
        ke_label = param
    elif ke_type == "HybridKEProvider":
        kem_param = getattr(config.key_exchange, "kem_parameter_set", "ML-KEM-768")
        ke_label = f"Hybrid (ECDH P-384 + {kem_param})"
    else:
        ke_label = ke_type

    # Signature label
    if sig_type == "ECDSAProvider":
        sig_label = "ECDSA P-384"
    elif sig_type == "MLDSAProvider":
        param = getattr(config.signature, "parameter_set", "ML-DSA-65")
        sig_label = param
    elif sig_type == "SLHDSAProvider":
        param = getattr(config.signature, "parameter_set", "SLH-DSA-SHAKE-128f")
        sig_label = param
    else:
        sig_label = sig_type

    return {
        "key_establishment": ke_label,
        "signature": sig_label,
        "encryption": "AES-256-GCM",
        "kdf": "HKDF-SHA-384",
        "ke_provider_class": ke_type,
        "sig_provider_class": sig_type,
    }


@dataclasses.dataclass(frozen=True)
class SessionResult:
    """
    Structured outcome of a secure communication session exchange.

    Contains only verified message payloads, public identifiers, and inspection metadata.
    Does NOT contain secret keys or intermediate shared secrets.
    """

    status: str
    session_id: str
    mode: Mode
    algorithm_id: str
    plaintext: bytes
    message: SecureMessage
    config_metadata: dict[str, str]
    metadata: dict[str, Any] | None = None

    @property
    def plaintext_str(self) -> str:
        """Decode plaintext as UTF-8 string, falling back to ASCII representation."""
        try:
            return self.plaintext.decode("utf-8")
        except UnicodeDecodeError:
            return self.plaintext.decode("ascii", errors="replace")

    def inspect_message(self) -> dict[str, Any]:
        """Return safe, non-secret message inspection metrics."""
        return {
            "protocol_version": self.message.protocol_version,
            "algorithm_id": self.message.algorithm_id,
            "ciphertext_bytes": len(self.message.ciphertext),
            "nonce_bytes": len(self.message.nonce),
            "signature_bytes": len(self.message.signature),
            "ke_ciphertext_bytes": len(self.message.ke_ciphertext) if self.message.ke_ciphertext else 0,
            "sender_ke_public_key_bytes": len(self.message.sender_ke_public_key),
            "sender_sig_public_key_bytes": len(self.message.sender_sig_public_key),
            "message_metadata": self.message.metadata,
        }

    def to_dict(self) -> dict[str, Any]:
        """
        Produce a JSON-serializable dictionary summary.
        Guaranteed to contain NO private keys, shared secrets, or AES keys.
        """
        return {
            "status": self.status,
            "session_id": self.session_id,
            "mode": self.mode.value,
            "algorithm_id": self.algorithm_id,
            "recovered_plaintext": self.plaintext_str,
            "plaintext_bytes_length": len(self.plaintext),
            "key_establishment": self.config_metadata.get("key_establishment"),
            "signature": self.config_metadata.get("signature"),
            "encryption": self.config_metadata.get("encryption"),
            "kdf": self.config_metadata.get("kdf"),
            "message_inspection": self.inspect_message(),
            "metadata": self.metadata,
        }

    def __repr__(self) -> str:
        return (
            f"<SessionResult status={self.status!r} session_id={self.session_id[:8]}... "
            f"mode={self.mode.value} algorithm_id={self.algorithm_id!r} "
            f"recovered_bytes={len(self.plaintext)}>"
        )


class SecureSession:
    """
    High-level operational session wrapper for secure communications.

    Encapsulates the lifecycle:
      Session Creation -> Configuration -> Communicator Initialization ->
      End-to-End Exchange -> Verification -> Decryption -> Structured Result.
    """

    def __init__(self, config: CryptoConfig, session_id: str | None = None) -> None:
        """
        Initialize a SecureSession with a validated CryptoConfig.
        """
        self._config = config
        self._session_id = session_id or secrets.token_hex(16)
        self._communicator = SecureCommunicator(config)
        self._state = "INITIALIZED"
        self._last_result: SessionResult | None = None
        self._provider_meta = _extract_provider_metadata(config)

    @property
    def session_id(self) -> str:
        """Unique non-secret session identifier string."""
        return self._session_id

    @property
    def config(self) -> CryptoConfig:
        """Immutable CryptoConfig bound to this session."""
        return self._config

    @property
    def mode(self) -> Mode:
        """Active experimental Mode (A, B, C, or D)."""
        return self._config.mode

    @property
    def algorithm_id(self) -> str:
        """Active canonical cryptographic suite identifier."""
        return self._config.algorithm_id

    @property
    def state(self) -> str:
        """Current session operational state."""
        return self._state

    @property
    def last_result(self) -> SessionResult | None:
        """Result from the most recent exchange execution."""
        return self._last_result

    @classmethod
    def create(
        cls,
        mode: Mode | str = Mode.D,
        *,
        session_id: str | None = None,
        **kwargs: Any,
    ) -> SecureSession:
        """
        Factory method to construct a SecureSession directly from a Mode and options.

        Parameters
        ----------
        mode:
            Requested Mode enum or string representation ('A', 'B', 'C', 'D').
        session_id:
            Optional explicit non-secret session identifier.
        **kwargs:
            Optional provider parameters (e.g. sig_provider_type="slhdsa", kem_parameter_set="ML-KEM-768").

        Returns
        -------
        SecureSession
            Ready-to-use high-level session.
        """
        cfg = ModeFactory.build(mode, **kwargs)
        return cls(config=cfg, session_id=session_id)

    def run_exchange(
        self,
        plaintext: bytes | str,
        *,
        aad: bytes | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> SessionResult:
        """
        Execute a complete end-to-end secure communication workflow:
          1. Generate receiver keypair
          2. Sender encrypts, encapsulates/exchanges, and signs message
          3. Receiver verifies signature and decrypts payload
          4. Returns structured SessionResult.

        Parameters
        ----------
        plaintext:
            Plaintext message bytes or UTF-8 string to transmit.
        aad:
            Optional additional authenticated data.
        metadata:
            Optional non-sensitive application metadata.

        Returns
        -------
        SessionResult
            Complete structured outcome of the exchange.
        """
        if isinstance(plaintext, str):
            raw_plaintext = plaintext.encode("utf-8")
        elif isinstance(plaintext, (bytes, bytearray)):
            raw_plaintext = bytes(plaintext)
        else:
            raise PQCFrameworkError(f"Plaintext must be str or bytes, got {type(plaintext).__name__}")

        # Embed session identifier into non-sensitive metadata
        combined_metadata: dict[str, Any] = {"session_id": self._session_id}
        if metadata:
            combined_metadata.update(metadata)

        try:
            # 1. Receiver generates key establishment keypair
            rx_kp = self._config.key_exchange.generate_keypair()

            # 2. Sender executes full send pipeline
            _, message = self._communicator.send(
                plaintext=raw_plaintext,
                receiver_ke_public_key=rx_kp.public_key,
                aad=aad,
                metadata=combined_metadata,
            )

            # 3. Receiver executes full verify-then-decrypt pipeline
            decrypted = self._communicator.receive(
                message=message,
                receiver_ke_private_key=rx_kp.private_key,
                aad=aad,
            )

            # 4. Construct result
            result = SessionResult(
                status="SUCCESS",
                session_id=self._session_id,
                mode=self._config.mode,
                algorithm_id=self._config.algorithm_id,
                plaintext=decrypted,
                message=message,
                config_metadata=self._provider_meta,
                metadata=combined_metadata,
            )
            self._state = "COMPLETED"
            self._last_result = result
            return result

        except Exception as exc:
            self._state = "FAILED"
            logger.error("SecureSession: exchange failed: %s", exc)
            raise

    def inspect_config(self) -> dict[str, Any]:
        """
        Return safe, non-sensitive inspection metadata for this session's configuration.
        """
        return {
            "session_id": self._session_id,
            "mode": self._config.mode.value,
            "algorithm_id": self._config.algorithm_id,
            "key_establishment": self._provider_meta["key_establishment"],
            "signature": self._provider_meta["signature"],
            "encryption": self._provider_meta["encryption"],
            "kdf": self._provider_meta["kdf"],
            "ke_provider": self._provider_meta["ke_provider_class"],
            "sig_provider": self._provider_meta["sig_provider_class"],
            "status": self._state,
        }

    def inspect_message(self, message: SecureMessage) -> dict[str, Any]:
        """
        Return safe, non-sensitive inspection metrics for a given SecureMessage.
        """
        return {
            "protocol_version": message.protocol_version,
            "algorithm_id": message.algorithm_id,
            "ciphertext_bytes": len(message.ciphertext),
            "nonce_bytes": len(message.nonce),
            "signature_bytes": len(message.signature),
            "ke_ciphertext_bytes": len(message.ke_ciphertext) if message.ke_ciphertext else 0,
            "sender_ke_public_key_bytes": len(message.sender_ke_public_key),
            "sender_sig_public_key_bytes": len(message.sender_sig_public_key),
            "metadata": message.metadata,
        }

    def to_dict(self) -> dict[str, Any]:
        """Return safe dictionary summary of the session."""
        d = self.inspect_config()
        if self._last_result:
            d["last_result"] = self._last_result.to_dict()
        return d

    def __repr__(self) -> str:
        return (
            f"<SecureSession id={self._session_id[:8]}... mode={self._config.mode.value} "
            f"algorithm_id={self._config.algorithm_id!r} state={self._state}>"
        )
