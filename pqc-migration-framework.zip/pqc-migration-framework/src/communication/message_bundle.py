"""
src/communication/message_bundle.py
Post-Quantum Secure Communication & Migration Framework

SecureMessage — the wire-format data structure for a secure communication.

Design requirements (Phase 2):
  - Algorithm-agnostic: the same structure is used for all modes (A/B/C/D).
  - No private keys; no shared secrets; no AES keys.
  - Self-describing: includes protocol version + algorithm identifier so the
    receiver can identify the algorithm suite used.
  - Serialisable: to/from dict for JSON serialisation (or any other format).
  - Immutable after construction (frozen dataclass).

Fields:
  protocol_version  — framework protocol version string (e.g., "pqcf-v1")
  algorithm_id      — algorithm suite identifier (e.g., CLASSICAL_ECDH_ECDSA_AES256_GCM)
  sender_ke_public_key   — sender's key-establishment public key (bytes, wire format)
  sender_sig_public_key  — sender's signing public key (bytes, wire format)
  ciphertext             — encrypted message (bytes; includes GCM auth tag)
  nonce                  — AES-GCM nonce (bytes; 12 bytes for GCM)
  ke_ciphertext          — KEM ciphertext (bytes; None for DH modes like ECDH)
  signature              — digital signature over (ciphertext || nonce) (bytes)
  metadata               — optional non-sensitive metadata dict

ARCHITECTURE.md § 4 — Data Flow / Step [6] Transmitted bundle
"""

from __future__ import annotations

import base64
import dataclasses
import json
from typing import Any

from src.exceptions import MalformedMessageError, SerializationError

# Current protocol version — increment on breaking changes to the wire format.
PROTOCOL_VERSION = "pqcf-v1"


@dataclasses.dataclass(frozen=True)
class SecureMessage:
    """
    Algorithm-agnostic wire representation of a secure message.

    All byte fields are stored as raw bytes internally.
    Serialisation converts them to base64 for JSON compatibility.

    Security invariants:
      - No private keys are stored here.
      - No shared secrets are stored here.
      - No AES keys are stored here.
      - ke_ciphertext is None for DH modes (ECDH); populated for KEM modes (ML-KEM).
    """

    protocol_version: str
    algorithm_id: str
    sender_ke_public_key: bytes       # Key-establishment public key (wire bytes)
    sender_sig_public_key: bytes      # Signing public key (wire bytes)
    ciphertext: bytes                 # Encrypted message + embedded GCM auth tag
    nonce: bytes                      # AES-GCM nonce
    signature: bytes                  # ECDSA / ML-DSA / SLH-DSA signature
    ke_ciphertext: bytes | None = None  # KEM encapsulation ciphertext (PQC/Hybrid only)
    metadata: dict[str, Any] | None = None  # Optional non-sensitive metadata

    def to_dict(self) -> dict[str, Any]:
        """
        Serialise to a JSON-compatible dict.

        Byte fields are base64-encoded. The metadata dict is included as-is
        (caller must ensure it contains only JSON-serialisable values).

        Returns
        -------
        dict[str, Any]
            JSON-serialisable dictionary representation.

        Raises
        ------
        SerializationError
            If serialisation fails for any field.
        """
        try:
            d: dict[str, Any] = {
                "protocol_version":       self.protocol_version,
                "algorithm_id":           self.algorithm_id,
                "sender_ke_public_key":   _b64(self.sender_ke_public_key),
                "sender_sig_public_key":  _b64(self.sender_sig_public_key),
                "ciphertext":             _b64(self.ciphertext),
                "nonce":                  _b64(self.nonce),
                "signature":              _b64(self.signature),
                "ke_ciphertext":          _b64(self.ke_ciphertext) if self.ke_ciphertext is not None else None,
                "metadata":               self.metadata,
            }
        except Exception as exc:
            raise SerializationError(
                f"SecureMessage serialisation failed: {exc}"
            ) from exc
        return d

    def to_json(self) -> str:
        """
        Serialise to a JSON string.

        Returns
        -------
        str
            JSON string representation.
        """
        try:
            return json.dumps(self.to_dict(), indent=2)
        except Exception as exc:
            raise SerializationError(
                f"SecureMessage JSON serialisation failed: {exc}"
            ) from exc

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "SecureMessage":
        """
        Deserialise from a JSON-compatible dict.

        Parameters
        ----------
        data:
            Dictionary produced by to_dict() (or equivalent).

        Returns
        -------
        SecureMessage

        Raises
        ------
        MalformedMessageError
            If required fields are missing or bytes cannot be decoded.
        """
        required = {
            "protocol_version",
            "algorithm_id",
            "sender_ke_public_key",
            "sender_sig_public_key",
            "ciphertext",
            "nonce",
            "signature",
        }
        missing = required - set(data.keys())
        if missing:
            raise MalformedMessageError(
                f"SecureMessage is missing required fields: {sorted(missing)}"
            )

        try:
            ke_ct_b64 = data.get("ke_ciphertext")
            return cls(
                protocol_version=str(data["protocol_version"]),
                algorithm_id=str(data["algorithm_id"]),
                sender_ke_public_key=_unb64(data["sender_ke_public_key"]),
                sender_sig_public_key=_unb64(data["sender_sig_public_key"]),
                ciphertext=_unb64(data["ciphertext"]),
                nonce=_unb64(data["nonce"]),
                signature=_unb64(data["signature"]),
                ke_ciphertext=_unb64(ke_ct_b64) if ke_ct_b64 is not None else None,
                metadata=data.get("metadata"),
            )
        except MalformedMessageError:
            raise
        except Exception as exc:
            raise MalformedMessageError(
                f"SecureMessage deserialisation failed: {exc}"
            ) from exc

    @classmethod
    def from_json(cls, json_str: str) -> "SecureMessage":
        """
        Deserialise from a JSON string.

        Parameters
        ----------
        json_str:
            JSON string produced by to_json() (or equivalent).

        Returns
        -------
        SecureMessage

        Raises
        ------
        MalformedMessageError
            If the string is not valid JSON or required fields are missing.
        """
        try:
            data = json.loads(json_str)
        except json.JSONDecodeError as exc:
            raise MalformedMessageError(
                f"SecureMessage JSON parsing failed: {exc}"
            ) from exc
        return cls.from_dict(data)

    def signed_data(self) -> bytes:
        """
        Return the byte sequence that is signed/verified.

        The signature is computed over ciphertext || nonce, which binds
        the signature to both the encrypted content and the specific
        encryption context (nonce).

        This method is used by both the sender (before signing) and the
        receiver (before verifying), ensuring they use identical byte sequences.

        ARCHITECTURE.md § 4 — Step [5] and Step [7]:
          SignatureProvider.sign(sender_private_sig, ciphertext || nonce)
          SignatureProvider.verify(sender_public_sig_key, ciphertext || nonce, signature)
        """
        return self.ciphertext + self.nonce


# ---------------------------------------------------------------------------
# Internal helpers — no public exposure of base64 details
# ---------------------------------------------------------------------------


def _b64(data: bytes) -> str:
    """Encode bytes to a base64 string."""
    return base64.b64encode(data).decode("ascii")


def _unb64(data: str) -> bytes:
    """Decode a base64 string to bytes."""
    try:
        return base64.b64decode(data)
    except Exception as exc:
        raise MalformedMessageError(
            f"Invalid base64 in SecureMessage field: {exc}"
        ) from exc
