"""
src/config/crypto_config.py
Post-Quantum Secure Communication & Migration Framework

CryptoConfig dataclass and ModeFactory.

ARCHITECTURE.md § 3.5 — Configuration Layer
Phase 6: Comprehensive provider validation, immutable configuration,
and centralized mode construction.
"""

from __future__ import annotations

import dataclasses
import logging
from typing import Any

from src.config.modes import (
    ALL_ALGORITHM_IDS,
    CLASSICAL_ECDH_ECDSA_AES256_GCM,
    HYBRID_ECDH_MLKEM_AES256_GCM,
    HYBRID_ECDH_MLKEM_ECDSA_AES256_GCM,
    HYBRID_ECDH_MLKEM_MLDSA_AES256_GCM,
    HYBRID_ECDH_MLKEM_SLHDSA_AES256_GCM,
    MODE_TO_ALGORITHM_ID,
    PQC_MLKEM_ECDSA_AES256_GCM,
    PQC_MLKEM_MLDSA_AES256_GCM,
    PQC_MLKEM_SLHDSA_AES256_GCM,
    Mode,
)
from src.exceptions import ConfigurationError, UnsupportedAlgorithmError
from src.providers.base import (
    EncryptionProvider,
    KeyDerivationProvider,
    KeyExchangeProvider,
    SignatureProvider,
)

logger = logging.getLogger(__name__)


@dataclasses.dataclass(frozen=True)
class CryptoConfig:
    """
    Bound immutable configuration object: maps a Mode to concrete provider instances.

    Attributes
    ----------
    mode:
        The experimental mode (A / B / C / D).
    algorithm_id:
        Human-readable algorithm suite identifier string (e.g.,
        ``CLASSICAL_ECDH_ECDSA_AES256_GCM``). Stored in SecureMessage.
    key_exchange:
        Provider for key establishment (ECDH / ML-KEM / Hybrid).
    signature:
        Provider for digital signatures (ECDSA / ML-DSA / SLH-DSA).
    encryption:
        Provider for authenticated symmetric encryption (AES-256-GCM).
    kdf:
        Provider for key derivation (HKDF).
    """

    mode: Mode
    algorithm_id: str
    key_exchange: KeyExchangeProvider
    signature: SignatureProvider
    encryption: EncryptionProvider
    kdf: KeyDerivationProvider

    def __post_init__(self) -> None:
        """
        Strictly validate provider types, algorithm IDs, and suite compatibility.

        Raises
        ------
        ConfigurationError
            If any provider is missing, wrong type, or incompatible with the declared mode.
        """
        # 1. Validate Mode
        if not isinstance(self.mode, Mode):
            raise ConfigurationError(
                f"Invalid mode type: {type(self.mode).__name__}. Must be an instance of Mode."
            )

        # 2. Validate Algorithm ID
        if not isinstance(self.algorithm_id, str) or not self.algorithm_id:
            raise ConfigurationError(
                f"algorithm_id must be a non-empty string, got {self.algorithm_id!r}"
            )
        if self.algorithm_id not in ALL_ALGORITHM_IDS:
            raise ConfigurationError(
                f"Unknown or unrecognized algorithm_id: {self.algorithm_id!r}"
            )

        # 3. Validate Provider Abstract Interfaces
        if not isinstance(self.key_exchange, KeyExchangeProvider):
            raise ConfigurationError(
                f"key_exchange must implement KeyExchangeProvider, got {type(self.key_exchange).__name__}"
            )
        if not isinstance(self.signature, SignatureProvider):
            raise ConfigurationError(
                f"signature must implement SignatureProvider, got {type(self.signature).__name__}"
            )
        if not isinstance(self.encryption, EncryptionProvider):
            raise ConfigurationError(
                f"encryption must implement EncryptionProvider, got {type(self.encryption).__name__}"
            )
        if not isinstance(self.kdf, KeyDerivationProvider):
            raise ConfigurationError(
                f"kdf must implement KeyDerivationProvider, got {type(self.kdf).__name__}"
            )

        # 4. Mode-Provider Compatibility Matrix
        ke_type_name = type(self.key_exchange).__name__
        sig_type_name = type(self.signature).__name__

        if self.mode is Mode.A:
            if ke_type_name != "ECDHProvider":
                raise ConfigurationError(
                    f"Mode A requires ECDHProvider for key exchange, got {ke_type_name}"
                )
            if sig_type_name != "ECDSAProvider":
                raise ConfigurationError(
                    f"Mode A requires ECDSAProvider for signatures, got {sig_type_name}"
                )
            if self.algorithm_id != CLASSICAL_ECDH_ECDSA_AES256_GCM:
                raise ConfigurationError(
                    f"Mode A algorithm_id mismatch: expected {CLASSICAL_ECDH_ECDSA_AES256_GCM}, got {self.algorithm_id}"
                )

        elif self.mode is Mode.B:
            if ke_type_name != "MLKEMProvider":
                raise ConfigurationError(
                    f"Mode B requires MLKEMProvider for key exchange, got {ke_type_name}"
                )
            if sig_type_name not in ("MLDSAProvider", "ECDSAProvider"):
                raise ConfigurationError(
                    f"Mode B requires MLDSAProvider (or ECDSAProvider for baseline), got {sig_type_name}"
                )
            if self.algorithm_id not in (PQC_MLKEM_MLDSA_AES256_GCM, PQC_MLKEM_ECDSA_AES256_GCM):
                raise ConfigurationError(
                    f"Mode B algorithm_id mismatch: got {self.algorithm_id}"
                )

        elif self.mode is Mode.C:
            if ke_type_name != "MLKEMProvider":
                raise ConfigurationError(
                    f"Mode C requires MLKEMProvider for key exchange, got {ke_type_name}"
                )
            if sig_type_name != "SLHDSAProvider":
                raise ConfigurationError(
                    f"Mode C requires SLHDSAProvider for signatures, got {sig_type_name}"
                )
            if self.algorithm_id != PQC_MLKEM_SLHDSA_AES256_GCM:
                raise ConfigurationError(
                    f"Mode C algorithm_id mismatch: expected {PQC_MLKEM_SLHDSA_AES256_GCM}, got {self.algorithm_id}"
                )

        elif self.mode is Mode.D:
            if ke_type_name != "HybridKEProvider":
                raise ConfigurationError(
                    f"Mode D requires HybridKEProvider for key exchange, got {ke_type_name}"
                )
            if sig_type_name == "MLDSAProvider":
                if self.algorithm_id not in (HYBRID_ECDH_MLKEM_MLDSA_AES256_GCM, "HYBRID_ECDH_MLKEM_AES256_GCM"):
                    raise ConfigurationError(
                        f"Mode D with MLDSAProvider requires algorithm_id={HYBRID_ECDH_MLKEM_MLDSA_AES256_GCM}, got {self.algorithm_id}"
                    )
            elif sig_type_name == "SLHDSAProvider":
                if self.algorithm_id != HYBRID_ECDH_MLKEM_SLHDSA_AES256_GCM:
                    raise ConfigurationError(
                        f"Mode D with SLHDSAProvider requires algorithm_id={HYBRID_ECDH_MLKEM_SLHDSA_AES256_GCM}, got {self.algorithm_id}"
                    )
            elif sig_type_name == "ECDSAProvider":
                if self.algorithm_id != HYBRID_ECDH_MLKEM_ECDSA_AES256_GCM:
                    raise ConfigurationError(
                        f"Mode D with ECDSAProvider requires algorithm_id={HYBRID_ECDH_MLKEM_ECDSA_AES256_GCM}, got {self.algorithm_id}"
                    )
            else:
                raise ConfigurationError(
                    f"Mode D requires a valid SignatureProvider (MLDSAProvider, SLHDSAProvider, or ECDSAProvider), got {sig_type_name}"
                )


class ModeFactory:
    """
    Authoritative factory that builds a validated CryptoConfig for the requested Mode.

    Provides a clean, polymorphic abstraction separating application code
    from cryptographic provider instantiation.
    """

    @staticmethod
    def build(mode: Mode | str, **kwargs: Any) -> CryptoConfig:
        """
        Build and return a complete, validated CryptoConfig for the specified mode.

        Parameters
        ----------
        mode:
            The requested experimental mode (Mode enum or string representation).
        **kwargs:
            Optional parameter sets for specific providers:
              - kem_parameter_set (e.g. "ML-KEM-768", "ML-KEM-1024")
              - sig_provider_type (e.g. "mldsa", "slhdsa", "ecdsa")
              - sig_parameter_set (e.g. "ML-DSA-65", "SLH-DSA-SHAKE-128f")

        Returns
        -------
        CryptoConfig
            A fully bound, validated, immutable configuration object.

        Raises
        ------
        UnsupportedAlgorithmError
            If the mode is unknown or not yet implemented.
        ConfigurationError
            If provider instantiation or validation fails.
        """
        resolved_mode = Mode.from_string(mode)

        if resolved_mode is Mode.A:
            return ModeFactory._build_mode_a()

        if resolved_mode is Mode.B:
            kem_param = kwargs.get("kem_parameter_set", "ML-KEM-768")
            sig_param = kwargs.get("sig_parameter_set", "ML-DSA-65")
            return ModeFactory._build_mode_b(kem_parameter_set=kem_param, sig_parameter_set=sig_param)

        if resolved_mode is Mode.C:
            kem_param = kwargs.get("kem_parameter_set", "ML-KEM-768")
            sig_param = kwargs.get("sig_parameter_set", "SLH-DSA-SHAKE-128f")
            return ModeFactory._build_mode_c(kem_parameter_set=kem_param, sig_parameter_set=sig_param)

        if resolved_mode is Mode.D:
            kem_param = kwargs.get("kem_parameter_set", "ML-KEM-768")
            sig_type = kwargs.get("sig_provider_type", "mldsa")
            sig_param = kwargs.get("sig_parameter_set", None)
            return ModeFactory._build_mode_d(
                kem_parameter_set=kem_param,
                sig_provider_type=sig_type,
                sig_parameter_set=sig_param,
            )

        raise UnsupportedAlgorithmError(f"Unsupported mode: {resolved_mode!r}")

    @staticmethod
    def supported_modes() -> list[Mode]:
        """
        Return the list of currently implemented and active experimental modes.

        Returns
        -------
        list[Mode]
            [Mode.A, Mode.B, Mode.C, Mode.D]
        """
        return [Mode.A, Mode.B, Mode.C, Mode.D]

    @staticmethod
    def get_algorithm_id(mode: Mode | str) -> str:
        """
        Lookup the primary algorithm suite identifier string for a given Mode.

        Parameters
        ----------
        mode:
            Mode enum or string.

        Returns
        -------
        str
            Suite identifier string.
        """
        resolved_mode = Mode.from_string(mode)
        if resolved_mode not in MODE_TO_ALGORITHM_ID:
            raise UnsupportedAlgorithmError(f"No algorithm identifier for mode: {resolved_mode!r}")
        return MODE_TO_ALGORITHM_ID[resolved_mode]

    @staticmethod
    def _build_mode_a() -> CryptoConfig:
        """
        Mode A — Classical Baseline (Phase 2).
        ECDH (P-384) + HKDF-SHA-384 + AES-256-GCM + ECDSA (P-384).
        """
        from src.providers.classical.ecdh_provider import ECDHProvider
        from src.providers.classical.ecdsa_provider import ECDSAProvider
        from src.providers.symmetric.aesgcm_provider import AESGCM256Provider
        from src.providers.symmetric.hkdf_provider import HKDFDerivationProvider

        logger.info("ModeFactory: building Mode A (CLASSICAL_ECDH_ECDSA_AES256_GCM)")

        return CryptoConfig(
            mode=Mode.A,
            algorithm_id=MODE_TO_ALGORITHM_ID[Mode.A],
            key_exchange=ECDHProvider(),
            signature=ECDSAProvider(),
            encryption=AESGCM256Provider(),
            kdf=HKDFDerivationProvider(),
        )

    @staticmethod
    def _build_mode_b(
        kem_parameter_set: str = "ML-KEM-768",
        sig_parameter_set: str = "ML-DSA-65",
    ) -> CryptoConfig:
        """
        Mode B — Full Post-Quantum Lattice (Phase 4).
        ML-KEM (FIPS 203) + HKDF-SHA-384 + AES-256-GCM + ML-DSA (FIPS 204).
        """
        from src.providers.pqc.mldsa_provider import MLDSAProvider
        from src.providers.pqc.mlkem_provider import MLKEMProvider
        from src.providers.symmetric.aesgcm_provider import AESGCM256Provider
        from src.providers.symmetric.hkdf_provider import HKDFDerivationProvider

        logger.info(
            "ModeFactory: building Mode B (%s + %s + AES256-GCM)",
            kem_parameter_set,
            sig_parameter_set,
        )

        return CryptoConfig(
            mode=Mode.B,
            algorithm_id=MODE_TO_ALGORITHM_ID[Mode.B],
            key_exchange=MLKEMProvider(parameter_set=kem_parameter_set),
            signature=MLDSAProvider(parameter_set=sig_parameter_set),
            encryption=AESGCM256Provider(),
            kdf=HKDFDerivationProvider(),
        )

    @staticmethod
    def _build_mode_c(
        kem_parameter_set: str = "ML-KEM-768",
        sig_parameter_set: str = "SLH-DSA-SHAKE-128f",
    ) -> CryptoConfig:
        """
        Mode C — Post-Quantum Hash-Based (Phase 5).
        ML-KEM (FIPS 203) + HKDF-SHA-384 + AES-256-GCM + SLH-DSA (FIPS 205).
        """
        from src.providers.pqc.mlkem_provider import MLKEMProvider
        from src.providers.pqc.slhdsa_provider import SLHDSAProvider
        from src.providers.symmetric.aesgcm_provider import AESGCM256Provider
        from src.providers.symmetric.hkdf_provider import HKDFDerivationProvider

        logger.info(
            "ModeFactory: building Mode C (%s + %s + AES256-GCM)",
            kem_parameter_set,
            sig_parameter_set,
        )

        return CryptoConfig(
            mode=Mode.C,
            algorithm_id=MODE_TO_ALGORITHM_ID[Mode.C],
            key_exchange=MLKEMProvider(parameter_set=kem_parameter_set),
            signature=SLHDSAProvider(parameter_set=sig_parameter_set),
            encryption=AESGCM256Provider(),
            kdf=HKDFDerivationProvider(),
        )

    @staticmethod
    def build_mlkem_baseline(parameter_set: str = "ML-KEM-768") -> CryptoConfig:
        """
        Phase 3 baseline configuration: ML-KEM + classical ECDSA + AES-256-GCM + HKDF.
        """
        from src.providers.classical.ecdsa_provider import ECDSAProvider
        from src.providers.pqc.mlkem_provider import MLKEMProvider
        from src.providers.symmetric.aesgcm_provider import AESGCM256Provider
        from src.providers.symmetric.hkdf_provider import HKDFDerivationProvider

        logger.info(
            "ModeFactory: building ML-KEM baseline (%s + ECDSA + AES256-GCM)",
            parameter_set,
        )

        return CryptoConfig(
            mode=Mode.B,
            algorithm_id=PQC_MLKEM_ECDSA_AES256_GCM,
            key_exchange=MLKEMProvider(parameter_set=parameter_set),
            signature=ECDSAProvider(),
            encryption=AESGCM256Provider(),
            kdf=HKDFDerivationProvider(),
        )

    @staticmethod
    def _build_mode_d(
        kem_parameter_set: str = "ML-KEM-768",
        sig_provider_type: str = "mldsa",
        sig_parameter_set: str | None = None,
    ) -> CryptoConfig:
        """
        Mode D — Hybrid Key Establishment (Phase 7).
        Hybrid (ECDH P-384 + ML-KEM-768) + HKDF-SHA-384 + AES-256-GCM + Configurable Signature.
        """
        from src.config.modes import HYBRID_ECDH_MLKEM_AES256_GCM
        from src.providers.hybrid.hybrid_ke_provider import HybridKEProvider
        from src.providers.symmetric.aesgcm_provider import AESGCM256Provider
        from src.providers.symmetric.hkdf_provider import HKDFDerivationProvider

        # Select signature provider and bind unambiguous suite identifier
        sig_norm = sig_provider_type.lower().strip()
        if sig_norm in ("mldsa", "ml-dsa", "pqc_lattice"):
            from src.providers.pqc.mldsa_provider import MLDSAProvider
            sig_provider = MLDSAProvider(parameter_set=sig_parameter_set or "ML-DSA-65")
            suite_id = HYBRID_ECDH_MLKEM_MLDSA_AES256_GCM
        elif sig_norm in ("slhdsa", "slh-dsa", "sphincs+", "pqc_hash"):
            from src.providers.pqc.slhdsa_provider import SLHDSAProvider
            sig_provider = SLHDSAProvider(parameter_set=sig_parameter_set or "SLH-DSA-SHAKE-128f")
            suite_id = HYBRID_ECDH_MLKEM_SLHDSA_AES256_GCM
        elif sig_norm in ("ecdsa", "classical"):
            from src.providers.classical.ecdsa_provider import ECDSAProvider
            sig_provider = ECDSAProvider()
            suite_id = HYBRID_ECDH_MLKEM_ECDSA_AES256_GCM
        else:
            raise UnsupportedAlgorithmError(
                f"Unsupported signature provider type for Mode D: {sig_provider_type!r}"
            )

        logger.info(
            "ModeFactory: building Mode D (Hybrid ECDH/P-384 + %s + %s + AES256-GCM) -> suite=%s",
            kem_parameter_set,
            type(sig_provider).__name__,
            suite_id,
        )

        return CryptoConfig(
            mode=Mode.D,
            algorithm_id=suite_id,
            key_exchange=HybridKEProvider(kem_parameter_set=kem_parameter_set),
            signature=sig_provider,
            encryption=AESGCM256Provider(),
            kdf=HKDFDerivationProvider(),
        )

