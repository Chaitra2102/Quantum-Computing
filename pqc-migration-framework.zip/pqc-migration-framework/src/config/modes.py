"""
src/config/modes.py
Post-Quantum Secure Communication & Migration Framework

Mode enumeration, configuration identifier constants, and negotiation foundation.

ARCHITECTURE.md § 3.5 — Configuration Layer
Phase 6–7: Centralized algorithm identifiers and crypto-agility mode management.
"""

from __future__ import annotations

from enum import Enum
from typing import Sequence

from src.exceptions import NegotiationError, UnsupportedAlgorithmError


class Mode(str, Enum):
    """
    Experimental mode selector.

    A — Classical (ECDH P-384 + ECDSA P-384 + AES-256-GCM + HKDF-SHA-384)
    B — Post-Quantum ML-DSA (ML-KEM-768 + ML-DSA-65 + AES-256-GCM + HKDF-SHA-384)
    C — Post-Quantum SLH-DSA (ML-KEM-768 + SLH-DSA-SHAKE-128f + AES-256-GCM + HKDF-SHA-384)
    D — Hybrid (ECDH P-384 + ML-KEM-768 + Configurable Signature + AES-256-GCM + HKDF-SHA-384)
    """

    A = "A"  # Classical baseline — Phase 2
    B = "B"  # PQC ML-DSA (FIPS 204) — Phase 4
    C = "C"  # PQC SLH-DSA (FIPS 205) — Phase 5
    D = "D"  # Hybrid Key Establishment — Phase 7

    # Aliases for explicit MODE_* naming convention
    MODE_A = "A"
    MODE_B = "B"
    MODE_C = "C"
    MODE_D = "D"

    @classmethod
    def from_string(cls, value: str | Mode) -> Mode:
        """
        Coerce a string or Mode instance to a valid Mode enum member.

        Parameters
        ----------
        value:
            String such as "A", "Mode.A", "MODE_A", or an existing Mode.

        Returns
        -------
        Mode
            The corresponding Mode enum member.

        Raises
        ------
        UnsupportedAlgorithmError
            If the value cannot be parsed as a known Mode.
        """
        if isinstance(value, cls):
            return value

        if not isinstance(value, str):
            raise UnsupportedAlgorithmError(f"Invalid mode type: {type(value).__name__}")

        normalized = value.strip().upper()
        if normalized.startswith("MODE."):
            normalized = normalized[5:]
        elif normalized.startswith("MODE_"):
            normalized = normalized[5:]

        for member in cls:
            if normalized == member.value or normalized == member.name:
                return member

        raise UnsupportedAlgorithmError(f"Unsupported or unrecognized mode: {value!r}")


# ---------------------------------------------------------------------------
# Authoritative Configuration Identifier Strings (Crypto-Agility Labels)
# PROJECT_SPEC.md § 3 / ARCHITECTURE.md § 2
#
# These identifiers appear in SecureMessage.algorithm_id and bound the message
# to its exact cryptographic suite to prevent downgrade and cross-mode attacks.
# ---------------------------------------------------------------------------

#: Classical Mode A identifier: ECDH (P-384) + ECDSA (P-384) + AES-256-GCM + HKDF-SHA-384
CLASSICAL_ECDH_ECDSA_AES256_GCM = "CLASSICAL_ECDH_ECDSA_AES256_GCM"

#: Intermediate Phase 3 baseline: ML-KEM-768 + Classical ECDSA + AES-256-GCM + HKDF-SHA-384
PQC_MLKEM_ECDSA_AES256_GCM = "PQC_MLKEM_ECDSA_AES256_GCM"

#: Full PQC Mode B: ML-KEM-768 + ML-DSA-65 + AES-256-GCM + HKDF-SHA-384
PQC_MLKEM_MLDSA_AES256_GCM = "PQC_MLKEM_MLDSA_AES256_GCM"

#: Hash-Based PQC Mode C: ML-KEM-768 + SLH-DSA-SHAKE-128f + AES-256-GCM + HKDF-SHA-384
PQC_MLKEM_SLHDSA_AES256_GCM = "PQC_MLKEM_SLHDSA_AES256_GCM"

#: Canonical Hybrid Mode D identifiers (Phase 7 corrective patch):
#: 1. Hybrid Key Establishment + ML-DSA-65 (Default)
HYBRID_ECDH_MLKEM_MLDSA_AES256_GCM = "HYBRID_ECDH_MLKEM_MLDSA_AES256_GCM"

#: 2. Hybrid Key Establishment + SLH-DSA-SHAKE-128f
HYBRID_ECDH_MLKEM_SLHDSA_AES256_GCM = "HYBRID_ECDH_MLKEM_SLHDSA_AES256_GCM"

#: 3. Hybrid Key Establishment + ECDSA (P-384)
HYBRID_ECDH_MLKEM_ECDSA_AES256_GCM = "HYBRID_ECDH_MLKEM_ECDSA_AES256_GCM"

#: Backward compatibility alias for Mode D default suite
HYBRID_ECDH_MLKEM_AES256_GCM = HYBRID_ECDH_MLKEM_MLDSA_AES256_GCM

#: All known authoritative suite identifiers for validation
ALL_ALGORITHM_IDS: frozenset[str] = frozenset(
    {
        CLASSICAL_ECDH_ECDSA_AES256_GCM,
        PQC_MLKEM_ECDSA_AES256_GCM,
        PQC_MLKEM_MLDSA_AES256_GCM,
        PQC_MLKEM_SLHDSA_AES256_GCM,
        HYBRID_ECDH_MLKEM_MLDSA_AES256_GCM,
        HYBRID_ECDH_MLKEM_SLHDSA_AES256_GCM,
        HYBRID_ECDH_MLKEM_ECDSA_AES256_GCM,
        "HYBRID_ECDH_MLKEM_AES256_GCM",  # backward-compat string
    }
)

#: Map Mode enum → its primary suite identifier
MODE_TO_ALGORITHM_ID: dict[Mode, str] = {
    Mode.A: CLASSICAL_ECDH_ECDSA_AES256_GCM,
    Mode.B: PQC_MLKEM_MLDSA_AES256_GCM,
    Mode.C: PQC_MLKEM_SLHDSA_AES256_GCM,
    Mode.D: HYBRID_ECDH_MLKEM_MLDSA_AES256_GCM,
}

#: Map suite identifier → Mode enum
ALGORITHM_ID_TO_MODE: dict[str, Mode] = {
    CLASSICAL_ECDH_ECDSA_AES256_GCM: Mode.A,
    PQC_MLKEM_ECDSA_AES256_GCM: Mode.B,  # Intermediate PQC KEM mode
    PQC_MLKEM_MLDSA_AES256_GCM: Mode.B,
    PQC_MLKEM_SLHDSA_AES256_GCM: Mode.C,
    HYBRID_ECDH_MLKEM_MLDSA_AES256_GCM: Mode.D,
    HYBRID_ECDH_MLKEM_SLHDSA_AES256_GCM: Mode.D,
    HYBRID_ECDH_MLKEM_ECDSA_AES256_GCM: Mode.D,
    "HYBRID_ECDH_MLKEM_AES256_GCM": Mode.D,
}


# ---------------------------------------------------------------------------
# Protocol Negotiation Foundation (Phase 6–7)
# ---------------------------------------------------------------------------


def negotiate_mode(
    client_supported: Sequence[Mode | str],
    server_supported: Sequence[Mode | str],
    *,
    preference_order: Sequence[Mode | str] | None = None,
) -> Mode:
    """
    Deterministically negotiate a cryptographic Mode between client and server.

    Security Policy:
      - Negotiation is explicit and deterministic.
      - Default priority order: [Mode.D, Mode.B, Mode.C, Mode.A]
      - Never silently fall back to an unrequested or weaker mode.
      - If no mutual mode exists, raises NegotiationError immediately.

    Parameters
    ----------
    client_supported:
        Sequence of modes supported by the client.
    server_supported:
        Sequence of modes supported by the server.
    preference_order:
        Optional custom priority list for mode selection. If omitted,
        the server's preference order is followed.

    Returns
    -------
    Mode
        The selected mutual Mode.

    Raises
    ------
    NegotiationError
        If no common mode exists between client and server.
    """
    client_modes = [Mode.from_string(m) for m in client_supported]
    server_modes = [Mode.from_string(m) for m in server_supported]

    client_set = set(client_modes)
    server_set = set(server_modes)
    mutual_set = client_set.intersection(server_set)

    if not mutual_set:
        raise NegotiationError(
            f"Cryptographic mode negotiation failed. "
            f"Client supports {[m.value for m in client_modes]}, "
            f"Server supports {[m.value for m in server_modes]}. "
            f"No mutual mode found."
        )

    if preference_order is not None:
        order = [Mode.from_string(m) for m in preference_order]
        for mode in order:
            if mode in mutual_set:
                return mode

    # Follow server preference order (server_modes)
    for mode in server_modes:
        if mode in mutual_set:
            return mode

    return next(iter(mutual_set))
