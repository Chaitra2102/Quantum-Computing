"""
src/config/__init__.py
Post-Quantum Secure Communication & Migration Framework

Crypto-agility configuration, mode definitions, and factory constructors.
"""

from src.config.crypto_config import CryptoConfig, ModeFactory
from src.config.modes import (
    ALL_ALGORITHM_IDS,
    CLASSICAL_ECDH_ECDSA_AES256_GCM,
    HYBRID_ECDH_MLKEM_AES256_GCM,
    HYBRID_ECDH_MLKEM_ECDSA_AES256_GCM,
    HYBRID_ECDH_MLKEM_MLDSA_AES256_GCM,
    HYBRID_ECDH_MLKEM_SLHDSA_AES256_GCM,
    MODE_TO_ALGORITHM_ID,
    PQC_MLKEM_ECDSA_AES256_GCM,
    PQC_MLKEM_MLDSA_AES256_GCM,
    PQC_MLKEM_SLHDSA_AES256_GCM,
    ALGORITHM_ID_TO_MODE,
    Mode,
    negotiate_mode,
)

__all__ = [
    "CryptoConfig",
    "ModeFactory",
    "Mode",
    "negotiate_mode",
    "ALL_ALGORITHM_IDS",
    "CLASSICAL_ECDH_ECDSA_AES256_GCM",
    "PQC_MLKEM_ECDSA_AES256_GCM",
    "PQC_MLKEM_MLDSA_AES256_GCM",
    "PQC_MLKEM_SLHDSA_AES256_GCM",
    "HYBRID_ECDH_MLKEM_AES256_GCM",
    "HYBRID_ECDH_MLKEM_MLDSA_AES256_GCM",
    "HYBRID_ECDH_MLKEM_SLHDSA_AES256_GCM",
    "HYBRID_ECDH_MLKEM_ECDSA_AES256_GCM",
    "MODE_TO_ALGORITHM_ID",
    "ALGORITHM_ID_TO_MODE",
]
