"""
src/providers/base.py
Post-Quantum Secure Communication & Migration Framework

Abstract base classes (provider interfaces) that define the crypto-agility layer.

Design rationale:
  - All concrete providers implement exactly one of these interfaces.
  - SecureCommunicator depends only on these abstractions, never on concrete classes.
  - Phase 3+ PQC providers slot in by implementing the same interfaces.
  - No algorithm-specific code belongs outside the providers package.

ARCHITECTURE.md § 3.3 — Crypto-Agility Layer (Provider Interfaces)
"""

from __future__ import annotations

import dataclasses
from abc import ABC, abstractmethod


# ---------------------------------------------------------------------------
# Shared data containers
# ---------------------------------------------------------------------------


@dataclasses.dataclass(frozen=True)
class KeyPair:
    """
    Holds a cryptographic key pair.

    private_key: opaque object (algorithm-specific; never serialised to wire)
    public_key:  opaque object (algorithm-specific; may be serialised to wire)

    Policy: private_key must not be exposed in logs, exceptions, or wire messages.
    """

    private_key: object
    public_key: object


@dataclasses.dataclass(frozen=True)
class EncryptedPayload:
    """
    Self-contained output of EncryptionProvider.encrypt().

    Contains everything the receiver needs to decrypt (except the secret key).
    No secrets are stored here.
    """

    ciphertext: bytes  # Encrypted message bytes
    nonce: bytes       # IV / nonce used during encryption


# ---------------------------------------------------------------------------
# Provider interfaces
# ---------------------------------------------------------------------------


class KeyExchangeProvider(ABC):
    """
    Abstract interface for key establishment (both DH and KEM styles).

    DH path  (ECDH / classical):
        exchange(sender_private, receiver_public) -> shared_secret

    KEM path (ML-KEM / PQC):
        encapsulate(receiver_public)  -> (shared_secret, ciphertext)
        decapsulate(receiver_private, ciphertext) -> shared_secret

    Phase 2 uses the DH path.
    Phase 3+ will implement the KEM path.
    """

    @abstractmethod
    def generate_keypair(self) -> KeyPair:
        """Generate a new key pair. Returns a KeyPair with private and public keys."""
        ...

    @abstractmethod
    def exchange(self, private_key: object, peer_public_key: object) -> bytes:
        """
        Perform Diffie-Hellman key agreement.

        Returns raw shared secret bytes; callers MUST pass this through
        KeyDerivationProvider.derive() before using it as an AES key.
        """
        ...

    def encapsulate(self, public_key: object) -> tuple[bytes, bytes]:
        """
        KEM encapsulation path (PQC only).

        Returns (shared_secret, ciphertext).
        Raises NotImplementedError for DH providers.
        """
        raise NotImplementedError(
            f"{type(self).__name__} does not support KEM encapsulation (DH-style provider)."
        )

    def decapsulate(self, private_key: object, ciphertext: bytes) -> bytes:
        """
        KEM decapsulation path (PQC only).

        Returns shared_secret.
        Raises NotImplementedError for DH providers.
        """
        raise NotImplementedError(
            f"{type(self).__name__} does not support KEM decapsulation (DH-style provider)."
        )

    @abstractmethod
    def export_public_key_bytes(self, public_key: object) -> bytes:
        """Serialise a public key to raw bytes for wire transmission."""
        ...

    @abstractmethod
    def import_public_key_bytes(self, raw_bytes: bytes) -> object:
        """Deserialise a public key from raw bytes received from the wire."""
        ...


class SignatureProvider(ABC):
    """
    Abstract interface for digital signature generation and verification.

    Phase 2 implements ECDSA.
    Phase 4+ will implement ML-DSA (FIPS 204) via liboqs-python.
    Phase 5+ will implement SLH-DSA (FIPS 205) via liboqs-python.
    """

    @abstractmethod
    def generate_keypair(self) -> KeyPair:
        """Generate a new signing key pair."""
        ...

    @abstractmethod
    def sign(self, private_key: object, message: bytes) -> bytes:
        """
        Sign message with private_key.

        Returns raw signature bytes.
        """
        ...

    @abstractmethod
    def verify(self, public_key: object, message: bytes, signature: bytes) -> bool:
        """
        Verify signature over message using public_key.

        Returns True if valid, False otherwise.
        Must NOT raise on an invalid signature — return False instead.
        """
        ...

    @abstractmethod
    def export_public_key_bytes(self, public_key: object) -> bytes:
        """Serialise a signing public key to raw bytes for wire transmission."""
        ...

    @abstractmethod
    def import_public_key_bytes(self, raw_bytes: bytes) -> object:
        """Deserialise a signing public key from raw bytes received from the wire."""
        ...


class EncryptionProvider(ABC):
    """
    Abstract interface for authenticated symmetric encryption.

    Phase 2+ uses AES-256-GCM exclusively (shared across all modes).
    """

    @abstractmethod
    def encrypt(self, key: bytes, plaintext: bytes, aad: bytes | None = None) -> EncryptedPayload:
        """
        Encrypt plaintext with key.

        aad: optional Additional Authenticated Data (not encrypted, but authenticated).
        Returns EncryptedPayload containing ciphertext + nonce.
        """
        ...

    @abstractmethod
    def decrypt(
        self,
        key: bytes,
        payload: EncryptedPayload,
        aad: bytes | None = None,
    ) -> bytes:
        """
        Decrypt and authenticate payload with key.

        Raises InvalidSignature / equivalent on authentication failure.
        Never returns unauthenticated plaintext.
        """
        ...


class KeyDerivationProvider(ABC):
    """
    Abstract interface for key derivation.

    Converts raw shared secret material (from ECDH or ML-KEM) into a
    cryptographically suitable AES key of the required length.

    Phase 2+ uses HKDF-SHA-256 exclusively.
    """

    @abstractmethod
    def derive(
        self,
        input_keying_material: bytes,
        length: int,
        *,
        salt: bytes | None = None,
        info: bytes = b"",
    ) -> bytes:
        """
        Derive a key of `length` bytes from `input_keying_material`.

        salt: optional, recommended for security.
        info: context/label bytes; different info values produce independent keys.

        Returns derived key bytes (length bytes).
        """
        ...
