"""
src/providers/hybrid/hybrid_ke_provider.py
Post-Quantum Secure Communication & Migration Framework

HybridKEProvider — Hybrid key establishment composing classical ECDH (P-384)
and post-quantum ML-KEM (ML-KEM-768).

ARCHITECTURE.md § 3.4 — Hybrid Key Establishment
Phase 7: Full KeyExchangeProvider abstraction implementation.

Security policy:
  - Delegates directly to existing ECDHProvider and MLKEMProvider.
  - Generates ephemeral ECDH keypair per encapsulation session.
  - Combines classical and PQC secrets using HybridSecretCombiner (HKDF-SHA-384).
  - Only the resulting hybrid shared secret is returned; raw component secrets
    are never exposed outside the provider.
  - Ciphertexts and public keys are canonically structured with length framing.
"""

from __future__ import annotations

import dataclasses
import logging
from typing import Any

from cryptography.hazmat.primitives.asymmetric.ec import (
    EllipticCurvePrivateKey,
    EllipticCurvePublicKey,
)
from cryptography.hazmat.primitives.asymmetric.mlkem import (
    MLKEM768PrivateKey,
    MLKEM768PublicKey,
    MLKEM1024PrivateKey,
    MLKEM1024PublicKey,
)

from src.exceptions import InvalidKeyError
from src.providers.base import KeyExchangeProvider, KeyPair
from src.providers.classical.ecdh_provider import ECDHProvider
from src.providers.hybrid.hybrid_combiner import (
    DEFAULT_HYBRID_INFO,
    DEFAULT_HYBRID_OUTPUT_LENGTH,
    HybridSecretCombiner,
)
from src.providers.pqc.mlkem_provider import MLKEMProvider

logger = logging.getLogger(__name__)


@dataclasses.dataclass(frozen=True)
class HybridPrivateKey:
    """
    Composite private key containing both ECDH and ML-KEM private keys.
    """

    ecdh_private_key: EllipticCurvePrivateKey
    mlkem_private_key: MLKEM768PrivateKey | MLKEM1024PrivateKey

    def __repr__(self) -> str:
        return "<HybridPrivateKey: ECDH(P-384) + ML-KEM [redacted]>"


@dataclasses.dataclass(frozen=True)
class HybridPublicKey:
    """
    Composite public key containing both ECDH and ML-KEM public keys.
    """

    ecdh_public_key: EllipticCurvePublicKey
    mlkem_public_key: MLKEM768PublicKey | MLKEM1024PublicKey

    def __repr__(self) -> str:
        return "<HybridPublicKey: ECDH(P-384) + ML-KEM>"


class HybridKEProvider(KeyExchangeProvider):
    """
    Hybrid Key Establishment Provider (ECDH P-384 + ML-KEM-768).

    Implements the KEM interface (encapsulate/decapsulate) for the hybrid suite.
    """

    def __init__(
        self,
        kem_parameter_set: str = "ML-KEM-768",
        info: bytes = DEFAULT_HYBRID_INFO,
        output_length: int = DEFAULT_HYBRID_OUTPUT_LENGTH,
    ) -> None:
        self._ecdh_provider = ECDHProvider()
        self._mlkem_provider = MLKEMProvider(parameter_set=kem_parameter_set)
        self._combiner = HybridSecretCombiner(info=info, output_length=output_length)
        self._kem_parameter_set = kem_parameter_set

    @property
    def kem_parameter_set(self) -> str:
        """Configured ML-KEM parameter set name."""
        return self._kem_parameter_set

    def generate_keypair(self) -> KeyPair:
        """
        Generate a composite hybrid key pair.

        Returns
        -------
        KeyPair
            KeyPair holding HybridPrivateKey and HybridPublicKey.
        """
        ecdh_kp = self._ecdh_provider.generate_keypair()
        mlkem_kp = self._mlkem_provider.generate_keypair()

        priv = HybridPrivateKey(
            ecdh_private_key=ecdh_kp.private_key,  # type: ignore
            mlkem_private_key=mlkem_kp.private_key,  # type: ignore
        )
        pub = HybridPublicKey(
            ecdh_public_key=ecdh_kp.public_key,  # type: ignore
            mlkem_public_key=mlkem_kp.public_key,  # type: ignore
        )
        logger.debug("HybridKEProvider: generated composite keypair")
        return KeyPair(private_key=priv, public_key=pub)

    def export_public_key_bytes(self, public_key: object) -> bytes:
        """
        Serialise a HybridPublicKey to wire bytes.

        Wire format:
          [2 bytes: ecdh_pub_len (big-endian uint16)]
          [ecdh_pub_len bytes: uncompressed ECDH point]
          [remaining bytes: raw ML-KEM public key]

        Parameters
        ----------
        public_key:
            HybridPublicKey instance.

        Returns
        -------
        bytes
            Framed composite public key bytes.
        """
        if not isinstance(public_key, HybridPublicKey):
            raise InvalidKeyError(
                f"Expected HybridPublicKey, got {type(public_key).__name__}"
            )

        ecdh_bytes = self._ecdh_provider.export_public_key_bytes(public_key.ecdh_public_key)
        mlkem_bytes = self._mlkem_provider.export_public_key_bytes(public_key.mlkem_public_key)

        ecdh_len = len(ecdh_bytes)
        return ecdh_len.to_bytes(2, "big") + ecdh_bytes + mlkem_bytes

    def import_public_key_bytes(self, raw_bytes: bytes) -> HybridPublicKey:
        """
        Deserialise wire bytes to a HybridPublicKey.

        Parameters
        ----------
        raw_bytes:
            Framed composite public key bytes.

        Returns
        -------
        HybridPublicKey

        Raises
        ------
        InvalidKeyError
            If bytes are malformed or invalid.
        """
        if not isinstance(raw_bytes, (bytes, bytearray)):
            raise InvalidKeyError("raw_bytes must be bytes")

        if len(raw_bytes) < 4:
            raise InvalidKeyError("raw_bytes too short for framed HybridPublicKey")

        ecdh_len = int.from_bytes(raw_bytes[:2], "big")
        if len(raw_bytes) < 2 + ecdh_len:
            raise InvalidKeyError("raw_bytes truncated for framed ECDH public key")

        ecdh_bytes = raw_bytes[2 : 2 + ecdh_len]
        mlkem_bytes = raw_bytes[2 + ecdh_len :]

        if len(mlkem_bytes) == 0:
            raise InvalidKeyError("Missing ML-KEM public key portion in hybrid wire bytes")

        ecdh_pub = self._ecdh_provider.import_public_key_bytes(ecdh_bytes)
        mlkem_pub = self._mlkem_provider.import_public_key_bytes(mlkem_bytes)

        return HybridPublicKey(ecdh_public_key=ecdh_pub, mlkem_public_key=mlkem_pub)

    def encapsulate(self, public_key: object) -> tuple[bytes, bytes]:
        """
        Perform hybrid key encapsulation.

        Steps:
          1. Generate ephemeral ECDH keypair.
          2. Compute classical ECDH shared secret: ecdh_ss = ECDH(ephemeral_sk, peer_ecdh_pk).
          3. Encapsulate against peer ML-KEM public key: (mlkem_ss, mlkem_ct) = ML-KEM-Enc(peer_mlkem_pk).
          4. Derive hybrid shared secret: hybrid_ss = Combiner(ecdh_ss, mlkem_ss).
          5. Frame hybrid ciphertext: [2 bytes ephemeral_ecdh_len] + [ephemeral_ecdh_bytes] + [mlkem_ct].

        Parameters
        ----------
        public_key:
            Peer's HybridPublicKey.

        Returns
        -------
        (hybrid_shared_secret, hybrid_ciphertext)
        """
        if not isinstance(public_key, HybridPublicKey):
            raise InvalidKeyError(
                f"Expected HybridPublicKey, got {type(public_key).__name__}"
            )

        # 1. Ephemeral ECDH exchange
        ephemeral_ecdh_kp = self._ecdh_provider.generate_keypair()
        ecdh_ss = self._ecdh_provider.exchange(
            ephemeral_ecdh_kp.private_key,
            public_key.ecdh_public_key,
        )
        ephemeral_ecdh_bytes = self._ecdh_provider.export_public_key_bytes(
            ephemeral_ecdh_kp.public_key
        )

        # 2. ML-KEM encapsulation
        mlkem_ss, mlkem_ct = self._mlkem_provider.encapsulate(public_key.mlkem_public_key)

        # 3. Combine secrets
        hybrid_ss = self._combiner.combine(ecdh_ss, mlkem_ss)

        # 4. Assemble hybrid ciphertext
        ecdh_len = len(ephemeral_ecdh_bytes)
        hybrid_ciphertext = ecdh_len.to_bytes(2, "big") + ephemeral_ecdh_bytes + mlkem_ct

        logger.debug("HybridKEProvider: encapsulation complete")
        return hybrid_ss, hybrid_ciphertext

    def decapsulate(self, private_key: object, ciphertext: bytes) -> bytes:
        """
        Perform hybrid key decapsulation.

        Steps:
          1. Parse ephemeral ECDH public key and ML-KEM ciphertext.
          2. Recover classical ECDH shared secret: ecdh_ss = ECDH(peer_ecdh_sk, ephemeral_ecdh_pk).
          3. Decapsulate ML-KEM ciphertext: mlkem_ss = ML-KEM-Dec(peer_mlkem_sk, mlkem_ct).
          4. Derive hybrid shared secret: hybrid_ss = Combiner(ecdh_ss, mlkem_ss).

        Parameters
        ----------
        private_key:
            Receiver's HybridPrivateKey.
        ciphertext:
            Framed hybrid ciphertext.

        Returns
        -------
        bytes
            Recovered hybrid shared secret.
        """
        if not isinstance(private_key, HybridPrivateKey):
            raise InvalidKeyError(
                f"Expected HybridPrivateKey, got {type(private_key).__name__}"
            )
        if not isinstance(ciphertext, (bytes, bytearray)):
            raise InvalidKeyError("ciphertext must be bytes")

        if len(ciphertext) < 4:
            raise InvalidKeyError("ciphertext too short for framed hybrid ciphertext")

        ecdh_len = int.from_bytes(ciphertext[:2], "big")
        if len(ciphertext) < 2 + ecdh_len:
            raise InvalidKeyError("ciphertext truncated for ephemeral ECDH public key")

        ephemeral_ecdh_bytes = ciphertext[2 : 2 + ecdh_len]
        mlkem_ct = ciphertext[2 + ecdh_len :]

        if len(mlkem_ct) == 0:
            raise InvalidKeyError("Missing ML-KEM ciphertext portion in hybrid ciphertext")

        # 1. Recover ECDH secret
        ephemeral_ecdh_pub = self._ecdh_provider.import_public_key_bytes(ephemeral_ecdh_bytes)
        ecdh_ss = self._ecdh_provider.exchange(
            private_key.ecdh_private_key,
            ephemeral_ecdh_pub,
        )

        # 2. Recover ML-KEM secret
        mlkem_ss = self._mlkem_provider.decapsulate(
            private_key.mlkem_private_key,
            mlkem_ct,
        )

        # 3. Combine secrets
        hybrid_ss = self._combiner.combine(ecdh_ss, mlkem_ss)
        logger.debug("HybridKEProvider: decapsulation complete")
        return hybrid_ss

    def exchange(self, private_key: object, peer_public_key: object) -> bytes:
        """
        DH exchange is not supported directly for HybridKEProvider (uses KEM path).
        """
        raise NotImplementedError(
            "HybridKEProvider operates via encapsulate() and decapsulate()."
        )
