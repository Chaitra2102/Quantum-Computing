"""
src/providers/hybrid/hybrid_combiner.py
Post-Quantum Secure Communication & Migration Framework

HybridSecretCombiner — HKDF-SHA-384 combination of classical ECDH and post-quantum ML-KEM secrets.

ARCHITECTURE.md § 3.4 — Hybrid Key Establishment
Phase 7: Dedicated, deterministic secret combiner.

Construction details:
  - Underlying primitives: ECDH (NIST P-384), ML-KEM (FIPS 203), HKDF (RFC 5869).
  - Hash algorithm: SHA-384 (providing 192-bit collision resistance matching P-384 and ML-KEM-768).
  - Input Keying Material (IKM): ecdh_shared_secret || mlkem_shared_secret
    (Exact ordering: classical ECDH shared secret first, post-quantum ML-KEM shared secret second).
  - Salt: None (standard HKDF extract uses hash_len zero-filled salt per RFC 5869 § 2.2).
  - Context / Info string: b"pqcf-v1-hybrid-ecdh-mlkem-shared-secret" (domain separation).
  - Output key length: 48 bytes (384 bits).
"""

from __future__ import annotations

import logging

from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.kdf.hkdf import HKDF

from src.exceptions import InvalidKeyError

logger = logging.getLogger(__name__)

# Default domain separation context string for the hybrid key combiner
DEFAULT_HYBRID_INFO = b"pqcf-v1-hybrid-ecdh-mlkem-shared-secret"

# Default hybrid output length in bytes (384 bits)
DEFAULT_HYBRID_OUTPUT_LENGTH = 48


class HybridSecretCombiner:
    """
    Combines classical and post-quantum shared secrets via HKDF-SHA-384.

    Security Properties:
      - 2-of-2 Hybrid Security: Compromising only ECDH (via quantum computer) or
        only ML-KEM (via classical mathematical breakthrough) does NOT compromise
        the output secret as long as HKDF acts as a secure pseudorandom function.
      - Deterministic Ordering: Swapping the concatenation order produces an entirely
        different, non-interchangeable output secret.
      - Domain Separation: Specific info string isolates this hybrid derivation from
        all other HKDF operations in the framework.
    """

    def __init__(
        self,
        info: bytes = DEFAULT_HYBRID_INFO,
        output_length: int = DEFAULT_HYBRID_OUTPUT_LENGTH,
    ) -> None:
        if not isinstance(info, bytes):
            raise InvalidKeyError("info must be bytes")
        if not isinstance(output_length, int) or output_length <= 0:
            raise InvalidKeyError("output_length must be a positive integer")

        self._info = info
        self._output_length = output_length

    @property
    def info(self) -> bytes:
        """Domain separation info string."""
        return self._info

    @property
    def output_length(self) -> int:
        """Derived output secret length in bytes."""
        return self._output_length

    def combine(
        self,
        ecdh_shared_secret: bytes,
        mlkem_shared_secret: bytes,
        *,
        info: bytes | None = None,
        salt: bytes | None = None,
    ) -> bytes:
        """
        Combine ECDH and ML-KEM shared secrets into a single hybrid secret.

        Parameters
        ----------
        ecdh_shared_secret:
            Raw shared secret bytes from ECDH (e.g. 48 bytes for P-384).
        mlkem_shared_secret:
            Raw shared secret bytes from ML-KEM (e.g. 32 bytes for ML-KEM-768).
        info:
            Optional override for domain separation info context.
        salt:
            Optional salt for HKDF extraction.

        Returns
        -------
        bytes
            The combined hybrid shared secret (default 48 bytes).

        Raises
        ------
        InvalidKeyError
            If either input secret is invalid or empty.
        """
        if not isinstance(ecdh_shared_secret, (bytes, bytearray)) or len(ecdh_shared_secret) == 0:
            raise InvalidKeyError("ecdh_shared_secret must be non-empty bytes")
        if not isinstance(mlkem_shared_secret, (bytes, bytearray)) or len(mlkem_shared_secret) == 0:
            raise InvalidKeyError("mlkem_shared_secret must be non-empty bytes")

        context = self._info if info is None else info
        if not isinstance(context, bytes):
            raise InvalidKeyError("info must be bytes")

        # Concatenation order: ecdh_ss || mlkem_ss
        ikm = bytes(ecdh_shared_secret) + bytes(mlkem_shared_secret)

        hkdf = HKDF(
            algorithm=hashes.SHA384(),
            length=self._output_length,
            salt=salt,
            info=context,
        )

        hybrid_secret: bytes = hkdf.derive(ikm)
        logger.debug(
            "HybridSecretCombiner: combined %d bytes ECDH + %d bytes ML-KEM -> %d bytes hybrid secret",
            len(ecdh_shared_secret),
            len(mlkem_shared_secret),
            len(hybrid_secret),
        )
        return hybrid_secret
