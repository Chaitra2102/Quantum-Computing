"""
src/providers/pqc/slhdsa_provider.py
Post-Quantum Secure Communication & Migration Framework

SLHDSAProvider — post-quantum digital signatures via SLH-DSA (FIPS 205).

Historical lineage:
  SPHINCS+ is the pre-standardization research family; NIST standardized it
  as SLH-DSA (Stateless Hash-Based Digital Signature Algorithm, FIPS 205).
  This provider implements the standardized SLH-DSA family exclusively.

Decision record:
  AD-12 resolved: SLH-DSA-SHAKE-128f (default) selected as primary for fast signing,
  with SLH-DSA-SHAKE-128s, SLH-DSA-SHA2-128f, and SLH-DSA-SHAKE-192f supported.
  AD-16: SPHINCS+ lineage mapping is preserved in documentation.

Security policy:
  - Private keys are not serialised to the wire, logged, or included in any message.
  - Public keys are serialised to raw bytes (32 bytes for 128-bit variants).
  - Signatures are raw bytes (17,088 bytes for 128f; 7,856 bytes for 128s).
  - verify() returns False on invalid/tampered signatures; never raises on mismatch.

Library: slhdsa (Pure Python / C-accelerated FIPS 205 implementation)
ARCHITECTURE.md § 3.4 — SLHDSAProvider
"""

from __future__ import annotations

import logging
from typing import Any

import slhdsa

from src.exceptions import (
    InvalidKeyError,
    InvalidSignatureError,
    UnsupportedAlgorithmError,
)
from src.providers.base import KeyPair, SignatureProvider

logger = logging.getLogger(__name__)

# Supported parameter sets (FIPS 205) and their key/signature dimensions
SUPPORTED_PARAMETER_SETS: dict[str, dict[str, Any]] = {
    "SLH-DSA-SHAKE-128f": {
        "param_obj": slhdsa.shake_128f,
        "public_key_size": 32,
        "signature_size": 17088,
        "security_level": 1,
    },
    "SLH-DSA-SHAKE-128s": {
        "param_obj": slhdsa.shake_128s,
        "public_key_size": 32,
        "signature_size": 7856,
        "security_level": 1,
    },
    "SLH-DSA-SHA2-128f": {
        "param_obj": slhdsa.sha2_128f,
        "public_key_size": 32,
        "signature_size": 17088,
        "security_level": 1,
    },
    "SLH-DSA-SHA2-128s": {
        "param_obj": slhdsa.sha2_128s,
        "public_key_size": 32,
        "signature_size": 7856,
        "security_level": 1,
    },
    "SLH-DSA-SHAKE-192f": {
        "param_obj": slhdsa.shake_192f,
        "public_key_size": 48,
        "signature_size": 35664,
        "security_level": 3,
    },
    "SLH-DSA-SHAKE-256f": {
        "param_obj": slhdsa.shake_256f,
        "public_key_size": 64,
        "signature_size": 49856,
        "security_level": 5,
    },
}

# Alias pre-standardization SPHINCS+ names to standardized SLH-DSA names
_ALIAS_MAP: dict[str, str] = {
    "SPHINCS+-SHAKE-128f": "SLH-DSA-SHAKE-128f",
    "SPHINCS+-SHAKE-128s": "SLH-DSA-SHAKE-128s",
    "SPHINCS+-SHA2-128f": "SLH-DSA-SHA2-128f",
    "SPHINCS+-SHA2-128s": "SLH-DSA-SHA2-128s",
    "SPHINCS+-SHAKE-192f": "SLH-DSA-SHAKE-192f",
    "SPHINCS+-SHAKE-256f": "SLH-DSA-SHAKE-256f",
}

DEFAULT_PARAMETER_SET = "SLH-DSA-SHAKE-128f"


class SLHDSAProvider(SignatureProvider):
    """
    SLH-DSA Stateless Hash-Based Digital Signature Algorithm provider (FIPS 205).

    Implements SignatureProvider:
      generate_keypair() -> KeyPair
      sign(private_key, message) -> signature bytes
      verify(public_key, message, signature) -> bool
      export_public_key_bytes(public_key) -> raw bytes
      import_public_key_bytes(raw_bytes) -> slhdsa.PublicKey
    """

    def __init__(self, parameter_set: str = DEFAULT_PARAMETER_SET) -> None:
        canonical_name = _ALIAS_MAP.get(parameter_set, parameter_set)
        if canonical_name not in SUPPORTED_PARAMETER_SETS:
            raise UnsupportedAlgorithmError(
                f"Unsupported SLH-DSA parameter set: {parameter_set!r}. "
                f"Supported sets are: {list(SUPPORTED_PARAMETER_SETS.keys())}"
            )
        self._parameter_set = canonical_name
        self._spec = SUPPORTED_PARAMETER_SETS[canonical_name]
        self._param_obj = self._spec["param_obj"]

    @property
    def parameter_set(self) -> str:
        """Name of the configured SLH-DSA parameter set."""
        return self._parameter_set

    @property
    def public_key_size(self) -> int:
        """Expected public key size in bytes."""
        return self._spec["public_key_size"]

    @property
    def signature_size(self) -> int:
        """Expected signature size in bytes."""
        return self._spec["signature_size"]

    def generate_keypair(self) -> KeyPair:
        """
        Generate a fresh SLH-DSA signing key pair.

        Returns
        -------
        KeyPair
            private_key: slhdsa.SecretKey instance (never serialised to wire)
            public_key: slhdsa.PublicKey instance
        """
        try:
            kp = slhdsa.KeyPair.gen(self._param_obj)
            logger.debug("SLHDSAProvider: generated %s key pair", self._parameter_set)
            return KeyPair(private_key=kp.sec, public_key=kp.pub)
        except Exception as exc:
            raise InvalidKeyError(f"SLH-DSA key pair generation failed: {exc}") from exc

    def sign(self, private_key: object, message: bytes) -> bytes:
        """
        Sign message using private_key.

        Parameters
        ----------
        private_key:
            Local slhdsa.SecretKey instance.
        message:
            Raw message bytes to sign.

        Returns
        -------
        bytes
            Signature bytes (e.g. 17088 bytes for SLH-DSA-SHAKE-128f).

        Raises
        ------
        InvalidKeyError
            If private_key is None or incorrect type.
        InvalidSignatureError
            If message is None or signing fails.
        """
        if private_key is None:
            raise InvalidKeyError("SLH-DSA sign: private_key must not be None.")

        if not isinstance(private_key, slhdsa.SecretKey):
            raise InvalidKeyError(
                f"SLH-DSA sign requires a slhdsa.SecretKey instance, "
                f"got {type(private_key).__name__}."
            )

        if message is None:
            raise InvalidSignatureError("SLH-DSA sign: message must not be None.")

        if not isinstance(message, (bytes, bytearray)):
            raise InvalidSignatureError("SLH-DSA sign: message must be bytes.")

        try:
            signature = private_key.sign(bytes(message))
        except Exception as exc:
            raise InvalidSignatureError(f"SLH-DSA signing failed: {exc}") from exc

        if len(signature) != self.signature_size:
            raise InvalidSignatureError(
                f"Unexpected signature size: expected {self.signature_size}, got {len(signature)}"
            )

        logger.debug(
            "SLHDSAProvider: message signed (%d bytes signature)",
            len(signature),
        )
        return bytes(signature)

    def verify(self, public_key: object, message: bytes, signature: bytes) -> bool:
        """
        Verify signature over message using public_key.

        Parameters
        ----------
        public_key:
            Signer's slhdsa.PublicKey instance.
        message:
            Original message bytes that were signed.
        signature:
            Signature bytes.

        Returns
        -------
        bool
            True if signature is valid, False otherwise.

        Raises
        ------
        InvalidKeyError
            If public_key is None or incorrect type.
        InvalidSignatureError
            If message or signature is None.
        """
        if public_key is None:
            raise InvalidKeyError("SLH-DSA verify: public_key must not be None.")

        if not isinstance(public_key, slhdsa.PublicKey):
            raise InvalidKeyError(
                f"SLH-DSA verify requires a slhdsa.PublicKey instance, "
                f"got {type(public_key).__name__}."
            )

        if message is None:
            raise InvalidSignatureError("SLH-DSA verify: message must not be None.")

        if signature is None:
            raise InvalidSignatureError("SLH-DSA verify: signature must not be None.")

        if not isinstance(message, (bytes, bytearray)):
            return False

        if not isinstance(signature, (bytes, bytearray)):
            return False

        try:
            valid = public_key.verify(bytes(message), bytes(signature))
            if valid:
                logger.debug("SLHDSAProvider: signature verified successfully")
                return True
            else:
                logger.debug("SLHDSAProvider: signature verification failed")
                return False
        except Exception as exc:
            logger.debug("SLHDSAProvider: signature verification failed (%s)", exc)
            return False

    def export_public_key_bytes(self, public_key: object) -> bytes:
        """
        Serialise an SLH-DSA public key to raw bytes.

        Parameters
        ----------
        public_key:
            slhdsa.PublicKey instance.

        Returns
        -------
        bytes
            Raw public key bytes (e.g. 32 bytes for SLH-DSA-SHAKE-128f).

        Raises
        ------
        InvalidKeyError
            If public_key is None or incorrect type.
        """
        if public_key is None:
            raise InvalidKeyError("Cannot export None public key.")

        if not isinstance(public_key, slhdsa.PublicKey):
            raise InvalidKeyError(
                f"export_public_key_bytes requires a slhdsa.PublicKey instance, "
                f"got {type(public_key).__name__}."
            )

        try:
            return public_key.digest()
        except Exception as exc:
            raise InvalidKeyError(f"Failed to export SLH-DSA public key: {exc}") from exc

    def import_public_key_bytes(self, raw_bytes: bytes) -> object:
        """
        Deserialise an SLH-DSA public key from raw bytes.

        Parameters
        ----------
        raw_bytes:
            Raw public key bytes.

        Returns
        -------
        slhdsa.PublicKey
            Deserialised public key instance.

        Raises
        ------
        InvalidKeyError
            If raw_bytes is empty, wrong length, or malformed.
        """
        if not raw_bytes:
            raise InvalidKeyError("Cannot import empty public key bytes.")

        if not isinstance(raw_bytes, (bytes, bytearray)):
            raise InvalidKeyError("import_public_key_bytes requires bytes.")

        if len(raw_bytes) != self.public_key_size:
            raise InvalidKeyError(
                f"Invalid SLH-DSA public key length for {self._parameter_set}: "
                f"expected {self.public_key_size} bytes, got {len(raw_bytes)} bytes."
            )

        try:
            return slhdsa.PublicKey.from_digest(bytes(raw_bytes), self._param_obj)
        except Exception as exc:
            raise InvalidKeyError(f"Failed to import SLH-DSA public key: {exc}") from exc
