"""
src/providers/pqc/mlkem_provider.py
Post-Quantum Secure Communication & Migration Framework

MLKEMProvider — post-quantum key establishment via ML-KEM (FIPS 203).

Decision record:
  AD-10 resolved: ML-KEM-768 (default) and ML-KEM-1024 supported.
  Rationale: ML-KEM-768 provides NIST Level 3 (192-bit) security, matching P-384
  and AES-256 security targets for the migration framework.

Security policy:
  - Raw ML-KEM shared secret (32 bytes) is passed to KeyDerivationProvider (HKDF)
    before use as an AES key.
  - Private keys are not serialised to the wire, logged, or included in any message.
  - Public keys are serialised to raw bytes (1184 bytes for ML-KEM-768, 1568 bytes for ML-KEM-1024).
  - Ciphertexts are 1088 bytes (ML-KEM-768) or 1568 bytes (ML-KEM-1024).

Library: cryptography (PyCA) — cryptography.hazmat.primitives.asymmetric.mlkem
ARCHITECTURE.md § 3.4 — MLKEMProvider
"""

from __future__ import annotations

import logging
from typing import Any

from cryptography.hazmat.primitives.asymmetric import mlkem
from cryptography.hazmat.primitives.asymmetric.mlkem import (
    MLKEM768PrivateKey,
    MLKEM768PublicKey,
    MLKEM1024PrivateKey,
    MLKEM1024PublicKey,
)

from src.exceptions import InvalidKeyError, UnsupportedAlgorithmError
from src.providers.base import KeyExchangeProvider, KeyPair

logger = logging.getLogger(__name__)

# Supported parameter sets and their key/ciphertext dimensions
SUPPORTED_PARAMETER_SETS: dict[str, dict[str, Any]] = {
    "ML-KEM-768": {
        "priv_cls": MLKEM768PrivateKey,
        "pub_cls": MLKEM768PublicKey,
        "public_key_size": 1184,
        "ciphertext_size": 1088,
        "shared_secret_size": 32,
        "security_level": 3,
    },
    "ML-KEM-1024": {
        "priv_cls": MLKEM1024PrivateKey,
        "pub_cls": MLKEM1024PublicKey,
        "public_key_size": 1568,
        "ciphertext_size": 1568,
        "shared_secret_size": 32,
        "security_level": 5,
    },
}

DEFAULT_PARAMETER_SET = "ML-KEM-768"


class MLKEMProvider(KeyExchangeProvider):
    """
    ML-KEM Key Encapsulation Mechanism provider (FIPS 203).

    Implements the KEM path of KeyExchangeProvider:
      generate_keypair() -> KeyPair
      encapsulate(public_key) -> (shared_secret, ciphertext)
      decapsulate(private_key, ciphertext) -> shared_secret
      export_public_key_bytes(public_key) -> raw public key bytes
      import_public_key_bytes(raw_bytes) -> MLKEMPublicKey

    DH exchange() raises NotImplementedError because ML-KEM is a KEM,
    not a Diffie-Hellman key agreement scheme.
    """

    def __init__(self, parameter_set: str = DEFAULT_PARAMETER_SET) -> None:
        if parameter_set not in SUPPORTED_PARAMETER_SETS:
            raise UnsupportedAlgorithmError(
                f"Unsupported ML-KEM parameter set: {parameter_set!r}. "
                f"Supported sets are: {list(SUPPORTED_PARAMETER_SETS.keys())}"
            )
        self._parameter_set = parameter_set
        self._spec = SUPPORTED_PARAMETER_SETS[parameter_set]
        self._priv_cls = self._spec["priv_cls"]
        self._pub_cls = self._spec["pub_cls"]

    @property
    def parameter_set(self) -> str:
        """Name of the configured ML-KEM parameter set."""
        return self._parameter_set

    @property
    def public_key_size(self) -> int:
        """Expected public key size in bytes."""
        return self._spec["public_key_size"]

    @property
    def ciphertext_size(self) -> int:
        """Expected ciphertext size in bytes."""
        return self._spec["ciphertext_size"]

    @property
    def shared_secret_size(self) -> int:
        """Size of the output shared secret in bytes (always 32)."""
        return self._spec["shared_secret_size"]

    def generate_keypair(self) -> KeyPair:
        """
        Generate a fresh ML-KEM key pair.

        Returns
        -------
        KeyPair
            private_key: MLKEMPrivateKey instance
            public_key: MLKEMPublicKey instance
        """
        try:
            priv = self._priv_cls.generate()
            pub = priv.public_key()
            logger.debug("MLKEMProvider: generated %s key pair", self._parameter_set)
            return KeyPair(private_key=priv, public_key=pub)
        except Exception as exc:
            raise InvalidKeyError(f"ML-KEM key pair generation failed: {exc}") from exc

    def encapsulate(self, public_key: object) -> tuple[bytes, bytes]:
        """
        Perform KEM encapsulation using the peer's public key.

        Parameters
        ----------
        public_key:
            Peer's MLKEMPublicKey instance.

        Returns
        -------
        tuple[bytes, bytes]
            (shared_secret, ciphertext)

        Raises
        ------
        InvalidKeyError
            If public_key is invalid or encapsulation fails.
        """
        if public_key is None:
            raise InvalidKeyError("ML-KEM encapsulation requires a non-None public key.")

        if not isinstance(public_key, self._pub_cls):
            raise InvalidKeyError(
                f"ML-KEM encapsulate requires an instance of {self._pub_cls.__name__}, "
                f"got {type(public_key).__name__}."
            )

        try:
            shared_secret, ciphertext = public_key.encapsulate()
        except Exception as exc:
            raise InvalidKeyError(f"ML-KEM encapsulation failed: {exc}") from exc

        if len(shared_secret) != self.shared_secret_size:
            raise InvalidKeyError(
                f"Unexpected shared secret length: expected {self.shared_secret_size}, "
                f"got {len(shared_secret)}"
            )
        if len(ciphertext) != self.ciphertext_size:
            raise InvalidKeyError(
                f"Unexpected ciphertext length: expected {self.ciphertext_size}, "
                f"got {len(ciphertext)}"
            )

        logger.debug(
            "MLKEMProvider: encapsulation succeeded (%d bytes ct, %d bytes ss)",
            len(ciphertext),
            len(shared_secret),
        )
        return shared_secret, ciphertext

    def decapsulate(self, private_key: object, ciphertext: bytes) -> bytes:
        """
        Perform KEM decapsulation using the local private key and peer's ciphertext.

        Parameters
        ----------
        private_key:
            Local MLKEMPrivateKey instance.
        ciphertext:
            Raw encapsulation ciphertext bytes received from the sender.

        Returns
        -------
        bytes
            Recovered shared secret (32 bytes).

        Raises
        ------
        InvalidKeyError
            If private_key is invalid, ciphertext is malformed/wrong length,
            or decapsulation fails.
        """
        if private_key is None:
            raise InvalidKeyError("ML-KEM decapsulation requires a non-None private key.")

        if not isinstance(private_key, self._priv_cls):
            raise InvalidKeyError(
                f"ML-KEM decapsulate requires an instance of {self._priv_cls.__name__}, "
                f"got {type(private_key).__name__}."
            )

        if not isinstance(ciphertext, (bytes, bytearray)):
            raise InvalidKeyError("ML-KEM decapsulation ciphertext must be bytes.")

        if len(ciphertext) != self.ciphertext_size:
            raise InvalidKeyError(
                f"Invalid ML-KEM ciphertext length: expected {self.ciphertext_size} bytes, "
                f"got {len(ciphertext)} bytes."
            )

        try:
            shared_secret = private_key.decapsulate(bytes(ciphertext))
        except Exception as exc:
            raise InvalidKeyError(f"ML-KEM decapsulation failed: {exc}") from exc

        if len(shared_secret) != self.shared_secret_size:
            raise InvalidKeyError(
                f"Unexpected decapsulated shared secret length: {len(shared_secret)}"
            )

        logger.debug(
            "MLKEMProvider: decapsulation succeeded (%d bytes shared secret)",
            len(shared_secret),
        )
        return shared_secret

    def export_public_key_bytes(self, public_key: object) -> bytes:
        """
        Serialise an ML-KEM public key to raw bytes.

        Parameters
        ----------
        public_key:
            MLKEMPublicKey instance.

        Returns
        -------
        bytes
            Raw public key bytes (1184 bytes for ML-KEM-768, 1568 bytes for ML-KEM-1024).

        Raises
        ------
        InvalidKeyError
            If public_key is None or wrong type.
        """
        if public_key is None:
            raise InvalidKeyError("Cannot export None public key.")

        if not isinstance(public_key, self._pub_cls):
            raise InvalidKeyError(
                f"export_public_key_bytes requires an instance of {self._pub_cls.__name__}, "
                f"got {type(public_key).__name__}."
            )

        try:
            return public_key.public_bytes_raw()
        except Exception as exc:
            raise InvalidKeyError(f"Failed to export ML-KEM public key: {exc}") from exc

    def import_public_key_bytes(self, raw_bytes: bytes) -> object:
        """
        Deserialise an ML-KEM public key from raw bytes.

        Parameters
        ----------
        raw_bytes:
            Raw public key bytes.

        Returns
        -------
        MLKEMPublicKey
            Deserialised public key instance.

        Raises
        ------
        InvalidKeyError
            If raw_bytes is empty, wrong length, or malformed.
        """
        if not raw_bytes:
            raise InvalidKeyError("Cannot import empty public key bytes.")

        if not isinstance(raw_bytes, (bytes, bytearray)):
            raise InvalidKeyError("import_public_key_bytes requires bytes.")

        if len(raw_bytes) != self.public_key_size:
            raise InvalidKeyError(
                f"Invalid ML-KEM public key length for {self._parameter_set}: "
                f"expected {self.public_key_size} bytes, got {len(raw_bytes)} bytes."
            )

        try:
            return self._pub_cls.from_public_bytes(bytes(raw_bytes))
        except Exception as exc:
            raise InvalidKeyError(f"Failed to import ML-KEM public key: {exc}") from exc

    def exchange(self, private_key: object, peer_public_key: object) -> bytes:
        """
        Diffie-Hellman exchange is unsupported for ML-KEM.

        Raises
        ------
        NotImplementedError
            Always, because ML-KEM is a KEM (use encapsulate/decapsulate).
        """
        raise NotImplementedError(
            "MLKEMProvider is a Key Encapsulation Mechanism (KEM) and does not support "
            "Diffie-Hellman style exchange(). Use encapsulate() and decapsulate() instead."
        )
