"""
src/providers/pqc/mldsa_provider.py
Post-Quantum Secure Communication & Migration Framework

MLDSAProvider — post-quantum digital signatures via ML-DSA (FIPS 204).

Decision record:
  AD-11 resolved: ML-DSA-65 (default) selected as primary, with ML-DSA-44 and
  ML-DSA-87 supported.
  Rationale: ML-DSA-65 provides NIST Level 3 (192-bit) security, matching ML-KEM-768,
  P-384, and AES-256 security targets for the migration framework.

Security policy:
  - Private keys are not serialised to the wire, logged, or included in any message.
  - Public keys are serialised to raw bytes (1952 bytes for ML-DSA-65).
  - Signatures are deterministic or randomized raw bytes (3309 bytes for ML-DSA-65).
  - verify() returns False on invalid/tampered signatures; never raises on mismatch.

Library: cryptography (PyCA) — cryptography.hazmat.primitives.asymmetric.mldsa
ARCHITECTURE.md § 3.4 — MLDSAProvider
"""

from __future__ import annotations

import logging
from typing import Any

from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives.asymmetric import mldsa
from cryptography.hazmat.primitives.asymmetric.mldsa import (
    MLDSA44PrivateKey,
    MLDSA44PublicKey,
    MLDSA65PrivateKey,
    MLDSA65PublicKey,
    MLDSA87PrivateKey,
    MLDSA87PublicKey,
)

from src.exceptions import (
    InvalidKeyError,
    InvalidSignatureError,
    UnsupportedAlgorithmError,
)
from src.providers.base import KeyPair, SignatureProvider

logger = logging.getLogger(__name__)

# Supported ML-DSA parameter sets and their key/signature dimensions (FIPS 204)
SUPPORTED_PARAMETER_SETS: dict[str, dict[str, Any]] = {
    "ML-DSA-44": {
        "priv_cls": MLDSA44PrivateKey,
        "pub_cls": MLDSA44PublicKey,
        "public_key_size": 1312,
        "signature_size": 2420,
        "security_level": 2,
    },
    "ML-DSA-65": {
        "priv_cls": MLDSA65PrivateKey,
        "pub_cls": MLDSA65PublicKey,
        "public_key_size": 1952,
        "signature_size": 3309,
        "security_level": 3,
    },
    "ML-DSA-87": {
        "priv_cls": MLDSA87PrivateKey,
        "pub_cls": MLDSA87PublicKey,
        "public_key_size": 2592,
        "signature_size": 4627,
        "security_level": 5,
    },
}

DEFAULT_PARAMETER_SET = "ML-DSA-65"


class MLDSAProvider(SignatureProvider):
    """
    ML-DSA Digital Signature Algorithm provider (FIPS 204).

    Implements SignatureProvider:
      generate_keypair() -> KeyPair
      sign(private_key, message) -> signature bytes
      verify(public_key, message, signature) -> bool
      export_public_key_bytes(public_key) -> raw bytes
      import_public_key_bytes(raw_bytes) -> MLDSAPublicKey
    """

    def __init__(self, parameter_set: str = DEFAULT_PARAMETER_SET) -> None:
        if parameter_set not in SUPPORTED_PARAMETER_SETS:
            raise UnsupportedAlgorithmError(
                f"Unsupported ML-DSA parameter set: {parameter_set!r}. "
                f"Supported sets are: {list(SUPPORTED_PARAMETER_SETS.keys())}"
            )
        self._parameter_set = parameter_set
        self._spec = SUPPORTED_PARAMETER_SETS[parameter_set]
        self._priv_cls = self._spec["priv_cls"]
        self._pub_cls = self._spec["pub_cls"]

    @property
    def parameter_set(self) -> str:
        """Name of the configured ML-DSA parameter set."""
        return self._parameter_set

    @property
    def public_key_size(self) -> int:
        """Expected public key size in bytes."""
        return self._spec["public_key_size"]

    @property
    def signature_size(self) -> int:
        """Expected signature size in bytes."""
        return self._spec["signature_size"]

    def generate_keypair(self) -> KeyPair:
        """
        Generate a fresh ML-DSA signing key pair.

        Returns
        -------
        KeyPair
            private_key: MLDSAPrivateKey instance (never serialised to wire)
            public_key: MLDSAPublicKey instance
        """
        try:
            priv = self._priv_cls.generate()
            pub = priv.public_key()
            logger.debug("MLDSAProvider: generated %s key pair", self._parameter_set)
            return KeyPair(private_key=priv, public_key=pub)
        except Exception as exc:
            raise InvalidKeyError(f"ML-DSA key pair generation failed: {exc}") from exc

    def sign(self, private_key: object, message: bytes) -> bytes:
        """
        Sign message using private_key.

        Parameters
        ----------
        private_key:
            Local MLDSAPrivateKey instance.
        message:
            Raw message bytes to sign.

        Returns
        -------
        bytes
            Signature bytes (e.g. 3309 bytes for ML-DSA-65).

        Raises
        ------
        InvalidKeyError
            If private_key is None or incorrect type.
        InvalidSignatureError
            If message is None or signing fails.
        """
        if private_key is None:
            raise InvalidKeyError("ML-DSA sign: private_key must not be None.")

        if not isinstance(private_key, self._priv_cls):
            raise InvalidKeyError(
                f"ML-DSA sign requires an instance of {self._priv_cls.__name__}, "
                f"got {type(private_key).__name__}."
            )

        if message is None:
            raise InvalidSignatureError("ML-DSA sign: message must not be None.")

        if not isinstance(message, (bytes, bytearray)):
            raise InvalidSignatureError("ML-DSA sign: message must be bytes.")

        try:
            signature = private_key.sign(bytes(message))
        except Exception as exc:
            raise InvalidSignatureError(f"ML-DSA signing failed: {exc}") from exc

        if len(signature) != self.signature_size:
            raise InvalidSignatureError(
                f"Unexpected signature size: expected {self.signature_size}, got {len(signature)}"
            )

        logger.debug(
            "MLDSAProvider: message signed (%d bytes signature)",
            len(signature),
        )
        return signature

    def verify(self, public_key: object, message: bytes, signature: bytes) -> bool:
        """
        Verify signature over message using public_key.

        Parameters
        ----------
        public_key:
            Signer's MLDSAPublicKey instance.
        message:
            Original message bytes that were signed.
        signature:
            Signature bytes.

        Returns
        -------
        bool
            True if signature is valid, False otherwise.

        Raises
        ------
        InvalidKeyError
            If public_key is None or incorrect type.
        InvalidSignatureError
            If message or signature is None.
        """
        if public_key is None:
            raise InvalidKeyError("ML-DSA verify: public_key must not be None.")

        if not isinstance(public_key, self._pub_cls):
            raise InvalidKeyError(
                f"ML-DSA verify requires an instance of {self._pub_cls.__name__}, "
                f"got {type(public_key).__name__}."
            )

        if message is None:
            raise InvalidSignatureError("ML-DSA verify: message must not be None.")

        if signature is None:
            raise InvalidSignatureError("ML-DSA verify: signature must not be None.")

        if not isinstance(message, (bytes, bytearray)):
            return False

        if not isinstance(signature, (bytes, bytearray)):
            return False

        try:
            public_key.verify(bytes(signature), bytes(message))
            logger.debug("MLDSAProvider: signature verified successfully")
            return True
        except InvalidSignature:
            logger.debug("MLDSAProvider: signature verification failed (invalid signature)")
            return False
        except Exception as exc:
            logger.debug("MLDSAProvider: signature verification failed (%s)", exc)
            return False

    def export_public_key_bytes(self, public_key: object) -> bytes:
        """
        Serialise an ML-DSA public key to raw bytes.

        Parameters
        ----------
        public_key:
            MLDSAPublicKey instance.

        Returns
        -------
        bytes
            Raw public key bytes (e.g. 1952 bytes for ML-DSA-65).

        Raises
        ------
        InvalidKeyError
            If public_key is None or incorrect type.
        """
        if public_key is None:
            raise InvalidKeyError("Cannot export None public key.")

        if not isinstance(public_key, self._pub_cls):
            raise InvalidKeyError(
                f"export_public_key_bytes requires an instance of {self._pub_cls.__name__}, "
                f"got {type(public_key).__name__}."
            )

        try:
            return public_key.public_bytes_raw()
        except Exception as exc:
            raise InvalidKeyError(f"Failed to export ML-DSA public key: {exc}") from exc

    def import_public_key_bytes(self, raw_bytes: bytes) -> object:
        """
        Deserialise an ML-DSA public key from raw bytes.

        Parameters
        ----------
        raw_bytes:
            Raw public key bytes.

        Returns
        -------
        MLDSAPublicKey
            Deserialised public key instance.

        Raises
        ------
        InvalidKeyError
            If raw_bytes is empty, wrong length, or malformed.
        """
        if not raw_bytes:
            raise InvalidKeyError("Cannot import empty public key bytes.")

        if not isinstance(raw_bytes, (bytes, bytearray)):
            raise InvalidKeyError("import_public_key_bytes requires bytes.")

        if len(raw_bytes) != self.public_key_size:
            raise InvalidKeyError(
                f"Invalid ML-DSA public key length for {self._parameter_set}: "
                f"expected {self.public_key_size} bytes, got {len(raw_bytes)} bytes."
            )

        try:
            return self._pub_cls.from_public_bytes(bytes(raw_bytes))
        except Exception as exc:
            raise InvalidKeyError(f"Failed to import ML-DSA public key: {exc}") from exc
