"""
src/providers/symmetric/hkdf_provider.py
Post-Quantum Secure Communication & Migration Framework

HKDFDerivationProvider — key derivation using HKDF-SHA-384.

Decision record:
  AD-06 resolved: HKDF-SHA-384 for P-384 / ML-KEM-768 security level.
  Rationale: SHA-384 matches the 192-bit security level of P-384.
  Using SHA-256 would produce only 128-bit security — mismatched for P-384.

Purpose:
  Convert raw shared secrets (ECDH / ML-KEM) into 32-byte AES-256 keys.
  In hybrid mode (Phase 6): HKDF(ECDH_secret || ML-KEM_secret) produces
  a combined key — this is why the interface accepts arbitrary IKM bytes.

Security policy:
  - IKM (input keying material) = raw shared secret; never logged.
  - Salt is optional but recommended; defaults to None (HKDF uses hash-sized
    zero bytes when salt is None, per RFC 5869).
  - Info is a non-secret context label; different labels produce independent keys.
  - Output is returned as raw bytes; caller is responsible for use.

Library: cryptography (PyCA) — cryptography.hazmat.primitives.kdf.hkdf.HKDF
ARCHITECTURE.md § 3.4 — HKDFDerivationProvider
"""

from __future__ import annotations

import logging

from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.kdf.hkdf import HKDF

from src.exceptions import InvalidKeyError
from src.providers.base import KeyDerivationProvider

logger = logging.getLogger(__name__)

# AD-06 resolved: SHA-384 for P-384 security level.
_HASH_ALG = hashes.SHA384()

# AES-256 requires a 32-byte key.
AES256_KEY_LENGTH = 32  # bytes


class HKDFDerivationProvider(KeyDerivationProvider):
    """
    HKDF-SHA-384 key derivation provider.

    Converts raw shared secret bytes (from ECDH or ML-KEM) into
    AES-256 key material of the required length.

    Usage::

        provider = HKDFDerivationProvider()
        aes_key = provider.derive(
            input_keying_material=shared_secret,
            length=AES256_KEY_LENGTH,
            info=b"pqc-framework-v1-aes-key",
        )
    """

    def derive(
        self,
        input_keying_material: bytes,
        length: int,
        *,
        salt: bytes | None = None,
        info: bytes = b"",
    ) -> bytes:
        """
        Derive a key of `length` bytes from `input_keying_material`.

        Parameters
        ----------
        input_keying_material:
            Raw shared secret (e.g., ECDH output, ML-KEM shared secret).
            MUST NOT be empty.
        length:
            Desired output key length in bytes. Must be > 0 and ≤ 255 * hash_len
            (hash_len = 48 for SHA-384).
        salt:
            Optional salt bytes. If None, HKDF internally uses hash-length
            zero bytes per RFC 5869 § 2.2. A random salt improves security
            when the IKM has low entropy.
        info:
            Context/label bytes (non-secret). Different info values produce
            independent keys from the same IKM. Use to separate key uses.

        Returns
        -------
        bytes
            Derived key of exactly `length` bytes.

        Raises
        ------
        InvalidKeyError
            If input_keying_material is empty or None.
        ValueError
            If length is non-positive or info is None.
        """
        if not input_keying_material:
            raise InvalidKeyError(
                "HKDF derive: input_keying_material must not be empty or None."
            )
        if length <= 0:
            raise ValueError(f"HKDF derive: length must be positive, got {length}.")
        if info is None:
            raise ValueError("HKDF derive: info must not be None (use b'' for empty).")

        try:
            hkdf = HKDF(
                algorithm=hashes.SHA384(),
                length=length,
                salt=salt,
                info=info,
            )
            derived: bytes = hkdf.derive(input_keying_material)
        except Exception as exc:
            raise InvalidKeyError(
                f"HKDF derivation failed: {exc}"
            ) from exc

        logger.debug(
            "HKDFDerivationProvider: derived %d-byte key (info=%r)",
            len(derived),
            info,
        )
        # Security: do NOT log the derived key bytes.
        return derived
