"""
src/providers/symmetric/aesgcm_provider.py
Post-Quantum Secure Communication & Migration Framework

AESGCM256Provider — authenticated encryption using AES-256-GCM.

Decision record:
  AD-05: AES-256-GCM provides confidentiality + integrity in one primitive.
  GCM mode eliminates the need for a separate MAC; authentication tag is
  verified as part of decryption.

Security policy:
  - Keys must be exactly 32 bytes (256-bit). Any other length raises ValueError.
  - Nonces are generated freshly for every encrypt() call via os.urandom().
    Do NOT reuse a nonce with the same key — GCM security depends on uniqueness.
  - Authentication failure (wrong key, modified ciphertext/AAD) raises
    AuthenticationFailureError. Unauthenticated plaintext is NEVER returned.
  - Nonces are 96 bits (12 bytes) — the recommended GCM nonce length.
  - The authentication tag is embedded in the ciphertext by the cryptography library
    (appended at the end, 16 bytes). It is not stored separately.

Library: cryptography (PyCA) — cryptography.hazmat.primitives.ciphers.aead.AESGCM
ARCHITECTURE.md § 3.4 — AESGCM256Provider
"""

from __future__ import annotations

import logging
import os

from cryptography.exceptions import InvalidTag
from cryptography.hazmat.primitives.ciphers.aead import AESGCM

from src.exceptions import AuthenticationFailureError
from src.providers.base import EncryptedPayload, EncryptionProvider

logger = logging.getLogger(__name__)

# AES-256 key length: 32 bytes (256 bits)
AES_KEY_LENGTH = 32  # bytes

# GCM nonce length: 96 bits is the NIST/IETF recommended length.
# Using a non-standard length is not supported here.
GCM_NONCE_LENGTH = 12  # bytes


class AESGCM256Provider(EncryptionProvider):
    """
    AES-256-GCM authenticated encryption provider.

    Implements EncryptionProvider:
      encrypt(key, plaintext, aad=None) → EncryptedPayload
      decrypt(key, payload, aad=None) → bytes

    The library's AESGCM class appends the 16-byte authentication tag to
    the ciphertext internally; consumers of EncryptedPayload.ciphertext
    receive the combined ciphertext+tag blob.

    Optional Additional Authenticated Data (AAD) is authenticated but not
    encrypted. If AAD is used during encrypt(), the identical AAD value MUST
    be supplied to decrypt() or decryption/authentication will fail.
    """

    def encrypt(
        self,
        key: bytes,
        plaintext: bytes,
        aad: bytes | None = None,
    ) -> EncryptedPayload:
        """
        Encrypt plaintext with AES-256-GCM.

        A fresh 96-bit nonce is generated on every call via os.urandom().

        Parameters
        ----------
        key:
            32-byte AES-256 key. Do NOT pass a raw ECDH shared secret here
            — pass the HKDF-derived key.
        plaintext:
            Plaintext message bytes.
        aad:
            Optional additional authenticated data (not encrypted, but
            authenticated). Must be supplied again on decrypt().

        Returns
        -------
        EncryptedPayload
            Contains ciphertext (with embedded GCM authentication tag)
            and the nonce used.

        Raises
        ------
        ValueError
            If key length is not 32 bytes, or key/plaintext is None.
        """
        if key is None:
            raise ValueError("AES-256-GCM encrypt: key must not be None.")
        if len(key) != AES_KEY_LENGTH:
            raise ValueError(
                f"AES-256-GCM encrypt: key must be {AES_KEY_LENGTH} bytes "
                f"(256-bit); got {len(key)} bytes."
            )
        if plaintext is None:
            raise ValueError("AES-256-GCM encrypt: plaintext must not be None.")

        # Generate a fresh nonce for each encryption. NEVER reuse.
        nonce: bytes = os.urandom(GCM_NONCE_LENGTH)

        try:
            aesgcm = AESGCM(key)
            # AESGCM.encrypt() returns ciphertext || authentication_tag (16 bytes)
            ciphertext: bytes = aesgcm.encrypt(nonce, plaintext, aad)
        except Exception as exc:
            raise ValueError(
                "AES-256-GCM encryption failed. Check key and plaintext."
            ) from exc

        logger.debug(
            "AESGCM256Provider: encrypted %d bytes plaintext → %d bytes ciphertext+tag, "
            "nonce length: %d bytes",
            len(plaintext),
            len(ciphertext),
            len(nonce),
        )
        # Security: do NOT log key, plaintext, or nonce values.
        return EncryptedPayload(ciphertext=ciphertext, nonce=nonce)

    def decrypt(
        self,
        key: bytes,
        payload: EncryptedPayload,
        aad: bytes | None = None,
    ) -> bytes:
        """
        Decrypt and authenticate an AES-256-GCM ciphertext.

        Authentication is performed automatically by the library as part of
        decryption. Unauthenticated plaintext is NEVER returned.

        Parameters
        ----------
        key:
            32-byte AES-256 key. Must be identical to the key used for encrypt().
        payload:
            EncryptedPayload containing ciphertext and nonce.
        aad:
            Optional additional authenticated data. Must be identical to the
            aad supplied during encrypt() or authentication will fail.

        Returns
        -------
        bytes
            Decrypted plaintext.

        Raises
        ------
        AuthenticationFailureError
            If the authentication tag does not match — indicating ciphertext
            tampering, wrong key, modified nonce, or mismatched AAD.
        ValueError
            If key length is not 32 bytes, or key/payload is None.
        """
        if key is None:
            raise ValueError("AES-256-GCM decrypt: key must not be None.")
        if len(key) != AES_KEY_LENGTH:
            raise ValueError(
                f"AES-256-GCM decrypt: key must be {AES_KEY_LENGTH} bytes "
                f"(256-bit); got {len(key)} bytes."
            )
        if payload is None:
            raise ValueError("AES-256-GCM decrypt: payload must not be None.")
        if len(payload.nonce) != GCM_NONCE_LENGTH:
            raise ValueError(
                f"AES-256-GCM decrypt: nonce must be {GCM_NONCE_LENGTH} bytes; "
                f"got {len(payload.nonce)} bytes."
            )

        try:
            aesgcm = AESGCM(key)
            plaintext: bytes = aesgcm.decrypt(payload.nonce, payload.ciphertext, aad)
        except InvalidTag as exc:
            # Security event: tampered ciphertext, wrong key, or wrong AAD.
            raise AuthenticationFailureError(
                "AES-256-GCM authentication FAILED. "
                "Ciphertext may be tampered, the key may be wrong, "
                "or the nonce/AAD does not match."
            ) from exc
        except Exception as exc:
            raise AuthenticationFailureError(
                "AES-256-GCM decryption failed."
            ) from exc

        logger.debug(
            "AESGCM256Provider: authenticated decryption succeeded (%d bytes plaintext)",
            len(plaintext),
        )
        return plaintext
