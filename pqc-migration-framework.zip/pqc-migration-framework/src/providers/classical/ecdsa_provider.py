"""
src/providers/classical/ecdsa_provider.py
Post-Quantum Secure Communication & Migration Framework

ECDSAProvider — digital signatures using ECDSA on NIST P-384 with SHA-384.

Decision record:
  AD-09 resolved: P-384 (secp384r1).
  Hash: SHA-384 (matches curve security level per NIST recommendations).

Security policy:
  - Private keys are never serialised, logged, or included in any message.
  - Public keys are serialised to DER SubjectPublicKeyInfo for wire transmission.
  - verify() returns False (not raises) for incorrect signatures.
  - InvalidSignatureError is raised only for structurally malformed signatures.
  - Signatures are produced with ECDSA + SHA-384 (deterministic where possible,
    but the library uses RFC 6979 by default which is deterministic).

Library: cryptography (PyCA) — cryptography.hazmat.primitives.asymmetric.ec
ARCHITECTURE.md § 3.4 — ECDSAProvider
"""

from __future__ import annotations

import logging

from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import ec
from cryptography.hazmat.primitives.asymmetric.ec import (
    ECDSA,
    EllipticCurvePrivateKey,
    EllipticCurvePublicKey,
)

from src.exceptions import InvalidKeyError, InvalidSignatureError
from src.providers.base import KeyPair, SignatureProvider

logger = logging.getLogger(__name__)

# AD-09: P-384 selected
_CURVE     = ec.SECP384R1()
_HASH_ALG  = hashes.SHA384()

# Public-key serialisation format for wire transmission
_PK_ENCODING = serialization.Encoding.DER
_PK_FORMAT   = serialization.PublicFormat.SubjectPublicKeyInfo


class ECDSAProvider(SignatureProvider):
    """
    ECDSA digital signature provider using NIST P-384 + SHA-384.

    Implements SignatureProvider:
      generate_keypair() → KeyPair
      sign(private_key, message) → signature bytes
      verify(public_key, message, signature) → bool
      export_public_key_bytes(public_key) → DER bytes
      import_public_key_bytes(bytes) → EllipticCurvePublicKey
    """

    def generate_keypair(self) -> KeyPair:
        """
        Generate a fresh P-384 ECDSA signing key pair.

        Returns
        -------
        KeyPair
            private_key: EllipticCurvePrivateKey (never logged/serialised)
            public_key:  EllipticCurvePublicKey
        """
        private_key: EllipticCurvePrivateKey = ec.generate_private_key(_CURVE)
        public_key: EllipticCurvePublicKey = private_key.public_key()
        logger.debug("ECDSAProvider: generated P-384 signing key pair")
        return KeyPair(private_key=private_key, public_key=public_key)

    def sign(
        self,
        private_key: EllipticCurvePrivateKey,
        message: bytes,
    ) -> bytes:
        """
        Sign message with the P-384 ECDSA private key.

        The library uses RFC 6979 deterministic nonce generation.

        Parameters
        ----------
        private_key:
            Signer's P-384 private key.
        message:
            Raw bytes to sign. The library hashes internally with SHA-384.

        Returns
        -------
        bytes
            DER-encoded ECDSA signature.

        Raises
        ------
        InvalidKeyError
            If private_key is None or not an EllipticCurvePrivateKey.
        """
        if private_key is None:
            raise InvalidKeyError("ECDSA signing requires a non-None private key.")
        if not isinstance(private_key, EllipticCurvePrivateKey):
            raise InvalidKeyError(
                "ECDSA sign: private_key must be an EllipticCurvePrivateKey."
            )
        if not isinstance(private_key.curve, type(_CURVE)):
            raise InvalidKeyError(
                f"ECDSA sign: key is on curve {private_key.curve.name!r}; "
                f"expected {_CURVE.name!r}."
            )
        if message is None:
            raise ValueError("ECDSA sign: message must not be None.")

        try:
            signature: bytes = private_key.sign(message, ECDSA(_HASH_ALG))
        except Exception as exc:
            raise InvalidSignatureError(
                "ECDSA signing failed. Ensure the key is valid."
            ) from exc

        logger.debug(
            "ECDSAProvider: message signed (signature length: %d bytes)",
            len(signature),
        )
        return signature

    def verify(
        self,
        public_key: EllipticCurvePublicKey,
        message: bytes,
        signature: bytes,
    ) -> bool:
        """
        Verify an ECDSA signature.

        Returns True if valid, False if the signature does not match.
        Raises InvalidSignatureError only for structurally malformed signatures
        (not for merely incorrect signatures).

        Parameters
        ----------
        public_key:
            Signer's P-384 public key.
        message:
            Original message bytes.
        signature:
            DER-encoded ECDSA signature bytes.

        Returns
        -------
        bool
            True if the signature is valid; False if it is not.

        Raises
        ------
        InvalidKeyError
            If public_key is None or not an EllipticCurvePublicKey.
        InvalidSignatureError
            If the signature bytes are structurally malformed (not parseable).
        """
        if public_key is None:
            raise InvalidKeyError("ECDSA verify: public_key must not be None.")
        if not isinstance(public_key, EllipticCurvePublicKey):
            raise InvalidKeyError(
                "ECDSA verify: public_key must be an EllipticCurvePublicKey."
            )
        if signature is None:
            raise InvalidSignatureError("ECDSA verify: signature must not be None.")

        try:
            public_key.verify(signature, message, ECDSA(_HASH_ALG))
            logger.debug("ECDSAProvider: signature verified successfully")
            return True
        except InvalidSignature:
            logger.debug("ECDSAProvider: signature verification FAILED")
            return False
        except Exception as exc:
            # A genuinely malformed (unparseable) signature
            raise InvalidSignatureError(
                "ECDSA verify: signature is structurally malformed."
            ) from exc

    def export_public_key_bytes(self, public_key: EllipticCurvePublicKey) -> bytes:
        """
        Serialise a P-384 signing public key to DER SubjectPublicKeyInfo.

        Parameters
        ----------
        public_key:
            EllipticCurvePublicKey to serialise.

        Returns
        -------
        bytes
            DER-encoded SubjectPublicKeyInfo bytes.

        Raises
        ------
        InvalidKeyError
            If public_key is None or not an EllipticCurvePublicKey.
        """
        if public_key is None:
            raise InvalidKeyError("Cannot export None signing public key.")
        if not isinstance(public_key, EllipticCurvePublicKey):
            raise InvalidKeyError(
                "export_public_key_bytes requires an EllipticCurvePublicKey."
            )
        try:
            return public_key.public_bytes(_PK_ENCODING, _PK_FORMAT)
        except Exception as exc:
            raise InvalidKeyError("Failed to serialise ECDSA public key.") from exc

    def import_public_key_bytes(self, raw_bytes: bytes) -> EllipticCurvePublicKey:
        """
        Deserialise a P-384 signing public key from DER SubjectPublicKeyInfo bytes.

        Parameters
        ----------
        raw_bytes:
            DER-encoded SubjectPublicKeyInfo bytes.

        Returns
        -------
        EllipticCurvePublicKey

        Raises
        ------
        InvalidKeyError
            If raw_bytes is malformed or does not represent a valid P-384 key.
        """
        if not raw_bytes:
            raise InvalidKeyError("Cannot import empty signing public key bytes.")
        try:
            from cryptography.hazmat.primitives.serialization import load_der_public_key
            public_key = load_der_public_key(raw_bytes)
            if not isinstance(public_key, EllipticCurvePublicKey):
                raise InvalidKeyError(
                    "Imported key is not an elliptic-curve public key."
                )
            if not isinstance(public_key.curve, type(_CURVE)):
                raise InvalidKeyError(
                    f"Imported key is on curve {public_key.curve.name!r}; "
                    f"expected {_CURVE.name!r}."
                )
            return public_key
        except InvalidKeyError:
            raise
        except Exception as exc:
            raise InvalidKeyError(
                "Failed to import ECDSA public key: bytes are malformed."
            ) from exc
