"""
src/providers/classical/ecdh_provider.py
Post-Quantum Secure Communication & Migration Framework

ECDHProvider — classical key establishment via ECDH on NIST P-384.

Decision record:
  AD-09 resolved: P-384 (secp384r1) is used.
  Rationale: P-384 provides 192-bit classical security, matching ML-KEM-768
  security level for future side-by-side comparison (Phase 3–6).
  P-384 ECDH uses HKDF-SHA-384 for key derivation (see HKDFDerivationProvider).

Security policy:
  - Raw ECDH output (shared_key_bytes) is NEVER used directly as an AES key.
  - Callers receive raw shared secret bytes and MUST pass them through
    HKDFDerivationProvider.derive() before symmetric encryption.
  - Private keys are not serialised, logged, or included in any message.
  - Public keys are serialised to uncompressed point form for wire transmission.

Library: cryptography (PyCA) — cryptography.hazmat.primitives.asymmetric.ec
ARCHITECTURE.md § 3.4 — ECDHProvider
"""

from __future__ import annotations

import logging

from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import ec
from cryptography.hazmat.primitives.asymmetric.ec import (
    ECDH,
    EllipticCurvePrivateKey,
    EllipticCurvePublicKey,
)

from src.exceptions import InvalidKeyError
from src.providers.base import KeyExchangeProvider, KeyPair

logger = logging.getLogger(__name__)

# AD-09: P-384 selected; use secp384r1 throughout.
_CURVE = ec.SECP384R1()

# Public-key serialisation format for wire transmission.
_PK_ENCODING = serialization.Encoding.X962
_PK_FORMAT   = serialization.PublicFormat.UncompressedPoint


class ECDHProvider(KeyExchangeProvider):
    """
    ECDH key establishment using NIST P-384 (secp384r1).

    Implements the DH path of KeyExchangeProvider:
      generate_keypair() → KeyPair
      exchange(private, peer_public) → raw shared secret bytes
      export_public_key_bytes(public) → uncompressed point bytes
      import_public_key_bytes(bytes) → EllipticCurvePublicKey

    KEM path (encapsulate / decapsulate) raises NotImplementedError —
    the DH interface does not use ciphertexts.
    """

    def generate_keypair(self) -> KeyPair:
        """
        Generate a fresh P-384 ECDH key pair.

        Returns
        -------
        KeyPair
            private_key: EllipticCurvePrivateKey (never logged/serialised)
            public_key:  EllipticCurvePublicKey
        """
        private_key: EllipticCurvePrivateKey = ec.generate_private_key(_CURVE)
        public_key: EllipticCurvePublicKey = private_key.public_key()
        logger.debug("ECDHProvider: generated P-384 key pair")
        return KeyPair(private_key=private_key, public_key=public_key)

    def exchange(
        self,
        private_key: EllipticCurvePrivateKey,
        peer_public_key: EllipticCurvePublicKey,
    ) -> bytes:
        """
        Perform ECDH key agreement.

        Parameters
        ----------
        private_key:
            Local party's P-384 private key.
        peer_public_key:
            Remote party's P-384 public key.

        Returns
        -------
        bytes
            Raw shared secret (48 bytes for P-384).

        Raises
        ------
        InvalidKeyError
            If either key is None, not a P-384 key, or the exchange fails.

        Security note:
            This raw output MUST be passed through HKDF before use as an AES key.
        """
        if private_key is None or peer_public_key is None:
            raise InvalidKeyError("ECDH exchange requires non-None private and public keys.")

        # Type validation
        if not isinstance(private_key, EllipticCurvePrivateKey):
            raise InvalidKeyError(
                "ECDH private_key must be an EllipticCurvePrivateKey instance."
            )
        if not isinstance(peer_public_key, EllipticCurvePublicKey):
            raise InvalidKeyError(
                "ECDH peer_public_key must be an EllipticCurvePublicKey instance."
            )

        # Curve validation — both keys must be on P-384
        if not isinstance(private_key.curve, type(_CURVE)):
            raise InvalidKeyError(
                f"ECDH private_key is on curve {private_key.curve.name!r}; "
                f"expected {_CURVE.name!r}."
            )
        if not isinstance(peer_public_key.curve, type(_CURVE)):
            raise InvalidKeyError(
                f"ECDH peer_public_key is on curve {peer_public_key.curve.name!r}; "
                f"expected {_CURVE.name!r}."
            )

        try:
            shared_secret: bytes = private_key.exchange(ECDH(), peer_public_key)
        except Exception as exc:
            # Do not include key material in the exception message.
            raise InvalidKeyError(
                "ECDH key agreement failed. Ensure both keys are valid P-384 keys."
            ) from exc

        logger.debug(
            "ECDHProvider: key agreement succeeded (shared secret length: %d bytes)",
            len(shared_secret),
        )
        # Return raw shared secret — caller MUST derive AES key via HKDF
        return shared_secret

    def export_public_key_bytes(self, public_key: EllipticCurvePublicKey) -> bytes:
        """
        Serialise a P-384 public key to uncompressed X9.62 point form.

        Format: 0x04 || X || Y (97 bytes for P-384)

        Parameters
        ----------
        public_key:
            The EllipticCurvePublicKey to serialise.

        Returns
        -------
        bytes
            97-byte uncompressed point representation.

        Raises
        ------
        InvalidKeyError
            If public_key is None or not an EllipticCurvePublicKey.
        """
        if public_key is None:
            raise InvalidKeyError("Cannot export None public key.")
        if not isinstance(public_key, EllipticCurvePublicKey):
            raise InvalidKeyError(
                "export_public_key_bytes requires an EllipticCurvePublicKey."
            )
        try:
            return public_key.public_bytes(_PK_ENCODING, _PK_FORMAT)
        except Exception as exc:
            raise InvalidKeyError("Failed to serialise ECDH public key.") from exc

    def import_public_key_bytes(self, raw_bytes: bytes) -> EllipticCurvePublicKey:
        """
        Deserialise a P-384 public key from uncompressed X9.62 point bytes.

        Parameters
        ----------
        raw_bytes:
            97-byte uncompressed point representation (0x04 || X || Y).

        Returns
        -------
        EllipticCurvePublicKey

        Raises
        ------
        InvalidKeyError
            If raw_bytes is malformed, wrong length, or not a valid P-384 point.
        """
        if not raw_bytes:
            raise InvalidKeyError("Cannot import empty public key bytes.")
        try:
            return ec.EllipticCurvePublicKey.from_encoded_point(_CURVE, raw_bytes)
        except Exception as exc:
            raise InvalidKeyError(
                "Failed to import ECDH public key: bytes are malformed or not a valid P-384 point."
            ) from exc
