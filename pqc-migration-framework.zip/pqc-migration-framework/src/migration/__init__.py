"""
src/migration/__init__.py
Post-Quantum Secure Communication & Migration Framework

Phase 12: Post-Quantum Migration Experimentation & Validation Layer.

Exports:
  - MigrationStage: Enum of explicit migration stages (CLASSICAL, HYBRID, PURE_PQC).
  - MigrationStep: Individual cryptographic configuration step.
  - MigrationPath: Ordered sequence of migration steps.
  - MigrationExperimentRunner: Execution harness for migration experiments and compatibility evaluations.
  - StepExecutionResult, TransitionResult, CompatibilityResult, MigrationExperimentReport: Secret-free result models.
"""

from src.migration.migration_experiment import MigrationExperimentRunner
from src.migration.migration_path import (
    PATH_ALTERNATIVE_SLHDSA,
    PATH_HYBRID_ECDSA,
    PATH_PRIMARY_MLDSA,
    PATH_PURE_PQC_TRANSITION,
    PATH_ROLLBACK_MLDSA,
    STEP_CLASSICAL_MODE_A,
    STEP_HYBRID_MODE_D_ECDSA,
    STEP_HYBRID_MODE_D_MLDSA,
    STEP_HYBRID_MODE_D_SLHDSA,
    STEP_PURE_PQC_MODE_B,
    STEP_PURE_PQC_MODE_C,
    MigrationPath,
    MigrationStep,
    get_standard_paths,
)
from src.migration.migration_result import (
    CompatibilityResult,
    MigrationExperimentReport,
    StepExecutionResult,
    TransitionResult,
)
from src.migration.migration_stage import (
    MigrationStage,
    stage_from_mode,
    stage_from_suite,
    validate_stage_transition,
)

__all__ = [
    "MigrationStage",
    "MigrationStep",
    "MigrationPath",
    "MigrationExperimentRunner",
    "StepExecutionResult",
    "TransitionResult",
    "CompatibilityResult",
    "MigrationExperimentReport",
    "stage_from_mode",
    "stage_from_suite",
    "validate_stage_transition",
    "get_standard_paths",
    "STEP_CLASSICAL_MODE_A",
    "STEP_HYBRID_MODE_D_MLDSA",
    "STEP_PURE_PQC_MODE_B",
    "STEP_HYBRID_MODE_D_SLHDSA",
    "STEP_PURE_PQC_MODE_C",
    "STEP_HYBRID_MODE_D_ECDSA",
    "PATH_PRIMARY_MLDSA",
    "PATH_ALTERNATIVE_SLHDSA",
    "PATH_HYBRID_ECDSA",
    "PATH_ROLLBACK_MLDSA",
    "PATH_PURE_PQC_TRANSITION",
]
