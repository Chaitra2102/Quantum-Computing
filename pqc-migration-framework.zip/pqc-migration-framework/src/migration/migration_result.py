"""
src/migration/migration_result.py
Post-Quantum Secure Communication & Migration Framework

Structured, secret-free migration data classes and reporting structures.

PROJECT_SPEC.md & ARCHITECTURE.md § 3.5
Phase 12: Migration Experimentation & Validation

SECURITY INVARIANT:
No private keys, shared secrets, AES keys, or HKDF intermediates are ever
stored or exported in these structures.
"""

from __future__ import annotations

import dataclasses
from typing import Any


@dataclasses.dataclass(frozen=True)
class StepExecutionResult:
    """
    Structured outcome of executing functional and security validation on a MigrationStep.

    Attributes
    ----------
    step_id : str
        Step identifier.
    stage : str
        Migration stage (CLASSICAL, HYBRID, PURE_PQC).
    mode : str
        Operational Mode ("A", "B", "C", "D").
    algorithm_id : str
        Cryptographic suite identifier.
    key_establishment_strategy : str
        Descriptive KEX name (e.g., "ECDH P-384 + ML-KEM-768").
    signature_strategy : str
        Descriptive signature name (e.g., "ML-DSA-65").
    key_establishment_valid : bool
        True if key establishment and shared secret derivation succeeded.
    authentication_valid : bool
        True if digital signature generation and verification succeeded.
    encryption_valid : bool
        True if authenticated encryption (AES-256-GCM) succeeded.
    decryption_valid : bool
        True if authenticated decryption succeeded.
    plaintext_integrity_valid : bool
        True if decrypted plaintext matches original plaintext byte-for-byte across all tested payload sizes.
    tamper_rejection_valid : bool
        True if all controlled adversarial tamper mutations were strictly rejected.
    cross_suite_rejection_valid : bool
        True if messages from mismatched suites were strictly rejected.
    payload_bytes_tested : list[int]
        List of tested payload sizes in bytes (e.g. [64, 1024, 16384]).
    success : bool
        True if all functional and security assertions passed.
    notes : str
        Optional annotations or observations.
    """

    step_id: str
    stage: str
    mode: str
    algorithm_id: str
    key_establishment_strategy: str
    signature_strategy: str
    key_establishment_valid: bool
    authentication_valid: bool
    encryption_valid: bool
    decryption_valid: bool
    plaintext_integrity_valid: bool
    tamper_rejection_valid: bool
    cross_suite_rejection_valid: bool
    payload_bytes_tested: list[int]
    success: bool
    notes: str = ""

    def to_dict(self) -> dict[str, Any]:
        """Convert result to a secret-free JSON-serializable dictionary."""
        return {
            "step_id": self.step_id,
            "stage": self.stage,
            "mode": self.mode,
            "algorithm_id": self.algorithm_id,
            "key_establishment_strategy": self.key_establishment_strategy,
            "signature_strategy": self.signature_strategy,
            "key_establishment_valid": self.key_establishment_valid,
            "authentication_valid": self.authentication_valid,
            "encryption_valid": self.encryption_valid,
            "decryption_valid": self.decryption_valid,
            "plaintext_integrity_valid": self.plaintext_integrity_valid,
            "tamper_rejection_valid": self.tamper_rejection_valid,
            "cross_suite_rejection_valid": self.cross_suite_rejection_valid,
            "payload_bytes_tested": self.payload_bytes_tested,
            "success": self.success,
            "notes": self.notes,
        }


@dataclasses.dataclass(frozen=True)
class TransitionResult:
    """
    Quantitative and structural delta between two adjacent migration steps along a path.

    Attributes
    ----------
    transition_id : str
        Unique transition identifier.
    source_step_id : str
        Preceding step identifier.
    target_step_id : str
        Succeeding step identifier.
    source_stage : str
        Originating migration stage.
    target_stage : str
        Target migration stage.
    source_suite : str
        Originating suite identifier.
    target_suite : str
        Target suite identifier.
    transition_type : str
        Classification ("FORWARD", "ROLLBACK", "CROSS_PQC", "INTRA_STAGE").
    transition_valid : bool
        True if transition satisfies architectural policy rules.
    latency_delta_us : float
        Target round-trip latency minus source round-trip latency in microseconds.
    latency_pct_delta : float
        Percentage latency change relative to source ((target - source) / source) * 100.
    wire_size_delta_bytes : int
        Target wire size minus source wire size in bytes.
    wire_size_pct_delta : float
        Percentage wire size change relative to source.
    raw_crypto_size_delta_bytes : int
        Target raw cryptographic size minus source raw size in bytes.
    raw_crypto_size_pct_delta : float
        Percentage raw crypto size change relative to source.
    notes : str
        Observations and contextual notes.
    """

    transition_id: str
    source_step_id: str
    target_step_id: str
    source_stage: str
    target_stage: str
    source_suite: str
    target_suite: str
    transition_type: str
    transition_valid: bool
    latency_delta_us: float
    latency_pct_delta: float
    wire_size_delta_bytes: int
    wire_size_pct_delta: float
    raw_crypto_size_delta_bytes: int
    raw_crypto_size_pct_delta: float
    notes: str = ""

    def to_dict(self) -> dict[str, Any]:
        """Convert transition delta to a secret-free JSON-serializable dictionary."""
        return {
            "transition_id": self.transition_id,
            "source_step_id": self.source_step_id,
            "target_step_id": self.target_step_id,
            "source_stage": self.source_stage,
            "target_stage": self.target_stage,
            "source_suite": self.source_suite,
            "target_suite": self.target_suite,
            "transition_type": self.transition_type,
            "transition_valid": self.transition_valid,
            "latency_delta_us": round(self.latency_delta_us, 3),
            "latency_pct_delta": round(self.latency_pct_delta, 2),
            "wire_size_delta_bytes": self.wire_size_delta_bytes,
            "wire_size_pct_delta": round(self.wire_size_pct_delta, 2),
            "raw_crypto_size_delta_bytes": self.raw_crypto_size_delta_bytes,
            "raw_crypto_size_pct_delta": round(self.raw_crypto_size_pct_delta, 2),
            "notes": self.notes,
        }


@dataclasses.dataclass(frozen=True)
class CompatibilityResult:
    """
    Outcome of an explicit pairwise compatibility exchange between sender and receiver configurations.

    Attributes
    ----------
    sender_suite : str
        Sender cryptographic suite identifier.
    receiver_suite : str
        Receiver cryptographic suite identifier.
    sender_stage : str
        Sender migration stage.
    receiver_stage : str
        Receiver migration stage.
    expected_outcome : str
        "ACCEPT" if suites are identical and compatible; "REJECT" otherwise.
    actual_outcome : str
        Observed communication outcome ("ACCEPT" or "REJECT").
    isolation_preserved : bool
        True if actual_outcome equals expected_outcome.
    rejection_reason : str
        Error type or explanation if rejected.
    """

    sender_suite: str
    receiver_suite: str
    sender_stage: str
    receiver_stage: str
    expected_outcome: str
    actual_outcome: str
    isolation_preserved: bool
    rejection_reason: str = ""

    def to_dict(self) -> dict[str, Any]:
        """Convert compatibility record to a secret-free dictionary."""
        return {
            "sender_suite": self.sender_suite,
            "receiver_suite": self.receiver_suite,
            "sender_stage": self.sender_stage,
            "receiver_stage": self.receiver_stage,
            "expected_outcome": self.expected_outcome,
            "actual_outcome": self.actual_outcome,
            "isolation_preserved": self.isolation_preserved,
            "rejection_reason": self.rejection_reason,
        }


@dataclasses.dataclass(frozen=True)
class MigrationExperimentReport:
    """
    Comprehensive experimental migration report for a MigrationPath.

    Attributes
    ----------
    experiment_id : str
        Unique experiment run identifier.
    timestamp_utc : str
        ISO 8601 UTC timestamp of execution.
    path_id : str
        Migration path identifier.
    path_name : str
        Human-readable path title.
    steps : list[StepExecutionResult]
        Execution results for each step.
    transitions : list[TransitionResult]
        Quantitative transition deltas between consecutive steps.
    history : list[dict[str, str]]
        Chronological migration history log.
    all_functional_passed : bool
        True if all steps achieved functional continuity.
    all_security_passed : bool
        True if all security and isolation invariants were satisfied.
    status : str
        "SUCCESS" or "FAILED".
    """

    experiment_id: str
    timestamp_utc: str
    path_id: str
    path_name: str
    steps: list[StepExecutionResult]
    transitions: list[TransitionResult]
    history: list[dict[str, str]]
    all_functional_passed: bool
    all_security_passed: bool
    status: str

    def to_dict(self) -> dict[str, Any]:
        """Convert full report to a secret-free dictionary."""
        return {
            "experiment_id": self.experiment_id,
            "timestamp_utc": self.timestamp_utc,
            "path_id": self.path_id,
            "path_name": self.path_name,
            "all_functional_passed": self.all_functional_passed,
            "all_security_passed": self.all_security_passed,
            "status": self.status,
            "history": self.history,
            "steps": [s.to_dict() for s in self.steps],
            "transitions": [t.to_dict() for t in self.transitions],
        }
