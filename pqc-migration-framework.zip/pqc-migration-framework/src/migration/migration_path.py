"""
src/migration/migration_path.py
Post-Quantum Secure Communication & Migration Framework

Migration step, migration path model, and standard experimental transition paths.

PROJECT_SPEC.md & ARCHITECTURE.md § 3.5
Phase 12: Migration Experimentation & Validation
"""

from __future__ import annotations

import dataclasses
import logging
from typing import Any

from src.config.crypto_config import CryptoConfig, ModeFactory
from src.config.modes import (
    CLASSICAL_ECDH_ECDSA_AES256_GCM,
    HYBRID_ECDH_MLKEM_ECDSA_AES256_GCM,
    HYBRID_ECDH_MLKEM_MLDSA_AES256_GCM,
    HYBRID_ECDH_MLKEM_SLHDSA_AES256_GCM,
    PQC_MLKEM_MLDSA_AES256_GCM,
    PQC_MLKEM_SLHDSA_AES256_GCM,
    Mode,
)
from src.exceptions import ConfigurationError
from src.migration.migration_stage import (
    MigrationStage,
    stage_from_mode,
    validate_stage_transition,
)

logger = logging.getLogger(__name__)


@dataclasses.dataclass(frozen=True)
class MigrationStep:
    """
    A single cryptographic configuration step within a migration path.

    Attributes
    ----------
    step_id : str
        Unique identifier for the step (e.g. "step-0-classical").
    stage : MigrationStage
        Associated migration stage (CLASSICAL, HYBRID, or PURE_PQC).
    mode : Mode
        Framework operational Mode (Mode.A, Mode.B, Mode.C, or Mode.D).
    algorithm_id : str
        Authoritative cryptographic suite identifier string.
    sig_provider_type : str | None
        Signature provider selector for parameterized modes (e.g., Mode D "mldsa", "slhdsa", "ecdsa").
    kem_parameter_set : str | None
        KEM parameter set (e.g. "ML-KEM-768").
    sig_parameter_set : str | None
        Signature parameter set (e.g. "ML-DSA-65", "SLH-DSA-SHAKE-128f").
    label : str
        Human-readable display name for this step.
    description : str
        Narrative summary of the cryptographic configuration and purpose.
    """

    step_id: str
    stage: MigrationStage
    mode: Mode
    algorithm_id: str
    sig_provider_type: str | None = None
    kem_parameter_set: str | None = "ML-KEM-768"
    sig_parameter_set: str | None = None
    label: str = ""
    description: str = ""

    def build_config(self) -> CryptoConfig:
        """
        Build and validate the concrete CryptoConfig for this migration step using ModeFactory.

        Returns
        -------
        CryptoConfig
            Validated, immutable configuration instance.
        """
        kwargs: dict[str, Any] = {}
        if self.kem_parameter_set is not None:
            kwargs["kem_parameter_set"] = self.kem_parameter_set
        if self.sig_provider_type is not None:
            kwargs["sig_provider_type"] = self.sig_provider_type
        if self.sig_parameter_set is not None:
            kwargs["sig_parameter_set"] = self.sig_parameter_set

        return ModeFactory.build(self.mode, **kwargs)

    def to_dict(self) -> dict[str, Any]:
        """Convert step definition to a JSON-serializable, secret-free dictionary."""
        return {
            "step_id": self.step_id,
            "stage": self.stage.value,
            "mode": self.mode.value,
            "algorithm_id": self.algorithm_id,
            "sig_provider_type": self.sig_provider_type,
            "kem_parameter_set": self.kem_parameter_set,
            "sig_parameter_set": self.sig_parameter_set,
            "label": self.label,
            "description": self.description,
        }


@dataclasses.dataclass(frozen=True)
class MigrationPath:
    """
    An ordered sequence of MigrationStep transitions representing an experimental migration journey.

    Attributes
    ----------
    path_id : str
        Unique identifier (e.g. "path_primary_mldsa").
    name : str
        Human-readable title.
    description : str
        Detailed description of the migration path and objectives.
    steps : list[MigrationStep]
        Ordered sequence of steps.
    """

    path_id: str
    name: str
    description: str
    steps: list[MigrationStep]

    def __post_init__(self) -> None:
        if not self.steps:
            raise ConfigurationError(f"MigrationPath {self.path_id!r} must contain at least one step.")

    @property
    def step_count(self) -> int:
        return len(self.steps)

    @property
    def initial_step(self) -> MigrationStep:
        return self.steps[0]

    @property
    def final_step(self) -> MigrationStep:
        return self.steps[-1]

    def validate_path(self, allow_rollback: bool = True) -> tuple[bool, list[str]]:
        """
        Validate all consecutive stage transitions along the path.

        Parameters
        ----------
        allow_rollback : bool, default True
            Whether rollbacks are allowed.

        Returns
        -------
        tuple[bool, list[str]]
            (is_valid, list_of_step_validation_messages)
        """
        if len(self.steps) <= 1:
            return True, ["Single-step path is valid by default."]

        messages: list[str] = []
        overall_valid = True

        for i in range(len(self.steps) - 1):
            src = self.steps[i]
            dst = self.steps[i + 1]
            valid, msg = validate_stage_transition(src.stage, dst.stage, allow_rollback=allow_rollback)
            messages.append(f"Transition [{src.step_id} ({src.stage.value}) -> {dst.step_id} ({dst.stage.value})]: {msg}")
            if not valid:
                overall_valid = False

        return overall_valid, messages

    def to_dict(self) -> dict[str, Any]:
        """Convert migration path metadata and steps to a dictionary."""
        return {
            "path_id": self.path_id,
            "name": self.name,
            "description": self.description,
            "step_count": len(self.steps),
            "steps": [s.to_dict() for s in self.steps],
        }


# =====================================================================
# STANDARD MIGRATION STEPS DEFINITIONS
# =====================================================================

STEP_CLASSICAL_MODE_A = MigrationStep(
    step_id="step_classical_a",
    stage=MigrationStage.CLASSICAL,
    mode=Mode.A,
    algorithm_id=CLASSICAL_ECDH_ECDSA_AES256_GCM,
    label="Mode A: Classical Baseline",
    description="Baseline classical cryptography using ECDH P-384 and ECDSA P-384.",
)

STEP_HYBRID_MODE_D_MLDSA = MigrationStep(
    step_id="step_hybrid_d_mldsa",
    stage=MigrationStage.HYBRID,
    mode=Mode.D,
    algorithm_id=HYBRID_ECDH_MLKEM_MLDSA_AES256_GCM,
    sig_provider_type="mldsa",
    kem_parameter_set="ML-KEM-768",
    sig_parameter_set="ML-DSA-65",
    label="Mode D: Hybrid Dual KEX + ML-DSA",
    description="Hybrid key establishment (ECDH P-384 + ML-KEM-768) with lattice-based ML-DSA-65 signatures.",
)

STEP_PURE_PQC_MODE_B = MigrationStep(
    step_id="step_pqc_b_mldsa",
    stage=MigrationStage.PURE_PQC,
    mode=Mode.B,
    algorithm_id=PQC_MLKEM_MLDSA_AES256_GCM,
    kem_parameter_set="ML-KEM-768",
    sig_parameter_set="ML-DSA-65",
    label="Mode B: Pure PQC (ML-KEM + ML-DSA)",
    description="Primary post-quantum suite using ML-KEM-768 key encapsulation and ML-DSA-65 digital signatures.",
)

STEP_HYBRID_MODE_D_SLHDSA = MigrationStep(
    step_id="step_hybrid_d_slhdsa",
    stage=MigrationStage.HYBRID,
    mode=Mode.D,
    algorithm_id=HYBRID_ECDH_MLKEM_SLHDSA_AES256_GCM,
    sig_provider_type="slhdsa",
    kem_parameter_set="ML-KEM-768",
    sig_parameter_set="SLH-DSA-SHAKE-128f",
    label="Mode D: Hybrid Dual KEX + SLH-DSA",
    description="Hybrid key establishment (ECDH P-384 + ML-KEM-768) with state-free hash-based SLH-DSA signatures.",
)

STEP_PURE_PQC_MODE_C = MigrationStep(
    step_id="step_pqc_c_slhdsa",
    stage=MigrationStage.PURE_PQC,
    mode=Mode.C,
    algorithm_id=PQC_MLKEM_SLHDSA_AES256_GCM,
    kem_parameter_set="ML-KEM-768",
    sig_parameter_set="SLH-DSA-SHAKE-128f",
    label="Mode C: Pure PQC (ML-KEM + SLH-DSA)",
    description="Alternative post-quantum suite using ML-KEM-768 key encapsulation and SLH-DSA-SHAKE-128f signatures.",
)

STEP_HYBRID_MODE_D_ECDSA = MigrationStep(
    step_id="step_hybrid_d_ecdsa",
    stage=MigrationStage.HYBRID,
    mode=Mode.D,
    algorithm_id=HYBRID_ECDH_MLKEM_ECDSA_AES256_GCM,
    sig_provider_type="ecdsa",
    kem_parameter_set="ML-KEM-768",
    label="Mode D: Hybrid Dual KEX + Classical ECDSA",
    description="Hybrid key establishment (ECDH P-384 + ML-KEM-768) while retaining classical ECDSA P-384 signatures for legacy auth compatibility.",
)


# =====================================================================
# STANDARD EXPERIMENTAL MIGRATION PATHS
# =====================================================================

PATH_PRIMARY_MLDSA = MigrationPath(
    path_id="EXP_1_PRIMARY_MLDSA",
    name="Primary Staged Migration (Mode A -> Mode D [ML-DSA] -> Mode B)",
    description="Standard two-stage migration path transitioning from classical ECDH/ECDSA to hybrid dual-KEX + ML-DSA, and finally to pure PQC ML-KEM/ML-DSA.",
    steps=[
        STEP_CLASSICAL_MODE_A,
        STEP_HYBRID_MODE_D_MLDSA,
        STEP_PURE_PQC_MODE_B,
    ],
)

PATH_ALTERNATIVE_SLHDSA = MigrationPath(
    path_id="EXP_2_ALTERNATIVE_SLHDSA",
    name="Alternative Hash-Based Migration (Mode A -> Mode D [SLH-DSA] -> Mode C)",
    description="Alternative migration path transitioning from classical to hybrid dual-KEX with SLH-DSA hash-based signatures, and finally to pure PQC ML-KEM/SLH-DSA.",
    steps=[
        STEP_CLASSICAL_MODE_A,
        STEP_HYBRID_MODE_D_SLHDSA,
        STEP_PURE_PQC_MODE_C,
    ],
)

PATH_HYBRID_ECDSA = MigrationPath(
    path_id="EXP_3_HYBRID_ECDSA",
    name="KEX-First Staged Migration (Mode A -> Mode D [ECDSA])",
    description="Migration scenario upgrading key establishment to quantum-resistant hybrid dual-KEX while retaining legacy ECDSA signatures.",
    steps=[
        STEP_CLASSICAL_MODE_A,
        STEP_HYBRID_MODE_D_ECDSA,
    ],
)

PATH_ROLLBACK_MLDSA = MigrationPath(
    path_id="EXP_4_ROLLBACK_MLDSA",
    name="Controlled Experimental Rollback (Mode D [ML-DSA] -> Mode A)",
    description="Simulated emergency rollback from hybrid configuration back to classical baseline due to unexpected peer incompatibility.",
    steps=[
        STEP_HYBRID_MODE_D_MLDSA,
        STEP_CLASSICAL_MODE_A,
    ],
)

PATH_PURE_PQC_TRANSITION = MigrationPath(
    path_id="EXP_5_PURE_PQC_TRANSITION",
    name="Pure PQC Signature Migration (Mode B [ML-DSA] -> Mode C [SLH-DSA])",
    description="Intra-PQC transition between lattice-based and hash-based signature strategies demonstrating agile algorithm replacement.",
    steps=[
        STEP_PURE_PQC_MODE_B,
        STEP_PURE_PQC_MODE_C,
    ],
)


def get_standard_paths() -> dict[str, MigrationPath]:
    """
    Retrieve dictionary of all standard experimental migration paths.

    Returns
    -------
    dict[str, MigrationPath]
        Mapping of path IDs to MigrationPath instances.
    """
    return {
        PATH_PRIMARY_MLDSA.path_id: PATH_PRIMARY_MLDSA,
        PATH_ALTERNATIVE_SLHDSA.path_id: PATH_ALTERNATIVE_SLHDSA,
        PATH_HYBRID_ECDSA.path_id: PATH_HYBRID_ECDSA,
        PATH_ROLLBACK_MLDSA.path_id: PATH_ROLLBACK_MLDSA,
        PATH_PURE_PQC_TRANSITION.path_id: PATH_PURE_PQC_TRANSITION,
    }
