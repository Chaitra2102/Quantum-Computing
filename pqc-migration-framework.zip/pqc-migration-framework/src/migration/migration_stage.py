"""
src/migration/migration_stage.py
Post-Quantum Secure Communication & Migration Framework

Migration stage definitions, mappings, and transition validation rules.

PROJECT_SPEC.md & ARCHITECTURE.md § 3.5
Phase 12: Migration Experimentation & Validation
"""

from __future__ import annotations

from enum import Enum
import logging
from typing import Any

from src.config.modes import (
    CLASSICAL_ECDH_ECDSA_AES256_GCM,
    HYBRID_ECDH_MLKEM_ECDSA_AES256_GCM,
    HYBRID_ECDH_MLKEM_MLDSA_AES256_GCM,
    HYBRID_ECDH_MLKEM_SLHDSA_AES256_GCM,
    PQC_MLKEM_MLDSA_AES256_GCM,
    PQC_MLKEM_SLHDSA_AES256_GCM,
    Mode,
)
from src.exceptions import ConfigurationError

logger = logging.getLogger(__name__)


class MigrationStage(str, Enum):
    """
    Explicit post-quantum migration stages.

    Stages:
      CLASSICAL: Classical public-key algorithms (ECDH P-384, ECDSA P-384).
      HYBRID: Dual-mechanism key establishment combining classical and post-quantum algorithms.
      PURE_PQC: Pure post-quantum cryptographic suites (ML-KEM, ML-DSA, SLH-DSA).
    """

    CLASSICAL = "CLASSICAL"
    HYBRID = "HYBRID"
    PURE_PQC = "PURE_PQC"

    def __str__(self) -> str:
        return self.value


# Authoritative mapping from algorithm ID to migration stage
SUITE_TO_STAGE: dict[str, MigrationStage] = {
    CLASSICAL_ECDH_ECDSA_AES256_GCM: MigrationStage.CLASSICAL,
    HYBRID_ECDH_MLKEM_MLDSA_AES256_GCM: MigrationStage.HYBRID,
    HYBRID_ECDH_MLKEM_SLHDSA_AES256_GCM: MigrationStage.HYBRID,
    HYBRID_ECDH_MLKEM_ECDSA_AES256_GCM: MigrationStage.HYBRID,
    PQC_MLKEM_MLDSA_AES256_GCM: MigrationStage.PURE_PQC,
    PQC_MLKEM_SLHDSA_AES256_GCM: MigrationStage.PURE_PQC,
}

MODE_TO_STAGE: dict[Mode, MigrationStage] = {
    Mode.A: MigrationStage.CLASSICAL,
    Mode.B: MigrationStage.PURE_PQC,
    Mode.C: MigrationStage.PURE_PQC,
    Mode.D: MigrationStage.HYBRID,
}


def stage_from_mode(mode: Mode | str) -> MigrationStage:
    """
    Resolve the MigrationStage corresponding to an experimental Mode.

    Parameters
    ----------
    mode : Mode or str
        Mode enum or mode string ("A", "B", "C", "D").

    Returns
    -------
    MigrationStage
        The corresponding migration stage.
    """
    resolved_mode = Mode.from_string(mode)
    if resolved_mode in MODE_TO_STAGE:
        return MODE_TO_STAGE[resolved_mode]
    raise ConfigurationError(f"Cannot map mode {mode!r} to a MigrationStage.")


def stage_from_suite(suite_id: str) -> MigrationStage:
    """
    Resolve the MigrationStage corresponding to a concrete algorithm suite identifier.

    Parameters
    ----------
    suite_id : str
        Canonical algorithm identifier string.

    Returns
    -------
    MigrationStage
        The corresponding migration stage.
    """
    if suite_id in SUITE_TO_STAGE:
        return SUITE_TO_STAGE[suite_id]
    raise ConfigurationError(f"Cannot map unknown suite {suite_id!r} to a MigrationStage.")


def validate_stage_transition(
    source: MigrationStage,
    target: MigrationStage,
    allow_rollback: bool = True,
) -> tuple[bool, str]:
    """
    Validate whether a transition between two migration stages is valid under framework policy.

    Allowed transitions:
      Forward Staged:
        - CLASSICAL -> HYBRID (Stage 0 -> Stage 1)
        - HYBRID -> PURE_PQC (Stage 1 -> Stage 2)
      Direct Flash-Cut:
        - CLASSICAL -> PURE_PQC (Permitted experimentally, though staged hybrid is primary)
      Same-Stage Transition:
        - CLASSICAL -> CLASSICAL
        - HYBRID -> HYBRID (e.g. changing signature variant)
        - PURE_PQC -> PURE_PQC (e.g. Mode B ML-DSA -> Mode C SLH-DSA)
      Controlled Rollback (if allow_rollback=True):
        - HYBRID -> CLASSICAL
        - PURE_PQC -> HYBRID
        - PURE_PQC -> CLASSICAL

    Parameters
    ----------
    source : MigrationStage
        Originating migration stage.
    target : MigrationStage
        Target migration stage.
    allow_rollback : bool, default True
        Whether controlled rollback transitions are permitted.

    Returns
    -------
    tuple[bool, str]
        (is_valid, reason_description)
    """
    if not isinstance(source, MigrationStage) or not isinstance(target, MigrationStage):
        return False, f"Invalid stage types: source={type(source)}, target={type(target)}"

    if source == target:
        return True, f"Intra-stage transition within {source.value}"

    if source == MigrationStage.CLASSICAL and target == MigrationStage.HYBRID:
        return True, "Standard forward transition: Classical -> Hybrid"

    if source == MigrationStage.HYBRID and target == MigrationStage.PURE_PQC:
        return True, "Standard forward transition: Hybrid -> Pure PQC"

    if source == MigrationStage.CLASSICAL and target == MigrationStage.PURE_PQC:
        return True, "Direct flash-cut transition: Classical -> Pure PQC"

    # Rollback cases
    if allow_rollback:
        if source == MigrationStage.HYBRID and target == MigrationStage.CLASSICAL:
            return True, "Controlled experimental rollback: Hybrid -> Classical"
        if source == MigrationStage.PURE_PQC and target == MigrationStage.HYBRID:
            return True, "Controlled experimental rollback: Pure PQC -> Hybrid"
        if source == MigrationStage.PURE_PQC and target == MigrationStage.CLASSICAL:
            return True, "Controlled experimental rollback: Pure PQC -> Classical"

    return False, f"Unauthorized migration transition: {source.value} -> {target.value} (rollback={allow_rollback})"
