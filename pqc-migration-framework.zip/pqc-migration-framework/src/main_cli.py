"""
src/main_cli.py
Post-Quantum Secure Communication & Migration Framework

Command-Line Interface for Secure Communication Workflows and Crypto-Agility Inspection.

ARCHITECTURE.md § 3.2 & PROJECT_SPEC.md
Phase 8: Provides runtime mode selection, secure message transmission,
metadata inspection, mode discovery, and structured JSON output.

Security Invariants:
  - Never logs, prints, or serializes private keys, shared secrets, AES keys,
    or internal secret key handles.
  - Uses existing ModeFactory, CryptoConfig, and SecureCommunicator architecture.
  - Errors are cleanly formatted to prevent sensitive information leakage.
"""

from __future__ import annotations

import argparse
import json
import logging
import sys
from typing import Any, Sequence

from src.communication.session import SecureSession
from src.config.modes import (
    CLASSICAL_ECDH_ECDSA_AES256_GCM,
    HYBRID_ECDH_MLKEM_ECDSA_AES256_GCM,
    HYBRID_ECDH_MLKEM_MLDSA_AES256_GCM,
    HYBRID_ECDH_MLKEM_SLHDSA_AES256_GCM,
    PQC_MLKEM_MLDSA_AES256_GCM,
    PQC_MLKEM_SLHDSA_AES256_GCM,
    Mode,
)
from src.exceptions import (
    AuthenticationFailureError,
    ConfigurationError,
    MalformedMessageError,
    ModeMismatchError,
    NegotiationError,
    PQCFrameworkError,
    SignatureVerificationError,
    UnsupportedAlgorithmError,
)

logger = logging.getLogger("pqc_cli")


def build_parser() -> argparse.ArgumentParser:
    """Build the command-line argument parser."""
    parser = argparse.ArgumentParser(
        prog="python -m src.main_cli",
        description="Post-Quantum Secure Communication & Migration Framework CLI",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  python -m src.main_cli --list-modes
  python -m src.main_cli --mode A --message "Hello Classical"
  python -m src.main_cli --mode B --message "Hello Lattice PQC"
  python -m src.main_cli --mode C --message "Hello Hash PQC"
  python -m src.main_cli --mode D --signature mldsa --message "Hello Hybrid"
  python -m src.main_cli --mode D --signature slhdsa --inspect
  python -m src.main_cli --mode B --message "Secret" --json
        """,
    )

    parser.add_argument(
        "-m",
        "--mode",
        type=str,
        default=None,
        help="Cryptographic mode: A (Classical), B (PQC ML-DSA), C (PQC SLH-DSA), D (Hybrid).",
    )
    parser.add_argument(
        "-s",
        "--signature",
        type=str,
        default=None,
        help="Signature strategy for Mode D: 'mldsa' (default), 'slhdsa', or 'ecdsa'.",
    )
    parser.add_argument(
        "-msg",
        "--message",
        type=str,
        default=None,
        help="Plaintext message payload to encrypt, sign, transmit, and decrypt.",
    )
    parser.add_argument(
        "-i",
        "--inspect",
        action="store_true",
        help="Inspect cryptographic configuration and message metadata without secrets.",
    )
    parser.add_argument(
        "-l",
        "--list-modes",
        action="store_true",
        help="Display all supported cryptographic modes and composite suite identifiers.",
    )
    parser.add_argument(
        "--security-test",
        action="store_true",
        help="Run comprehensive controlled adversarial tampering & attack simulation suite.",
    )
    parser.add_argument(
        "-j",
        "--json",
        action="store_true",
        help="Output structured results or metadata in JSON format.",
    )
    parser.add_argument(
        "--aad",
        type=str,
        default=None,
        help="Optional Additional Authenticated Data (AAD) for AES-GCM.",
    )
    parser.add_argument(
        "--kem-param",
        type=str,
        default=None,
        help="Optional KEM parameter set (e.g. 'ML-KEM-768', 'ML-KEM-1024').",
    )
    parser.add_argument(
        "--sig-param",
        type=str,
        default=None,
        help="Optional signature parameter set (e.g. 'ML-DSA-65', 'SLH-DSA-SHAKE-128f').",
    )
    parser.add_argument(
        "--debug",
        action="store_true",
        help="Enable debug logging and show traceback on unexpected internal exceptions.",
    )

    return parser


def get_supported_modes_catalog() -> dict[str, Any]:
    """Return the authoritative catalog of supported modes and suite identifiers."""
    return {
        "Mode A": {
            "title": "Classical Baseline",
            "suite_id": CLASSICAL_ECDH_ECDSA_AES256_GCM,
            "key_establishment": "ECDH P-384",
            "signature": "ECDSA P-384",
            "encryption": "AES-256-GCM",
            "kdf": "HKDF-SHA-384",
        },
        "Mode B": {
            "title": "Full Post-Quantum Lattice",
            "suite_id": PQC_MLKEM_MLDSA_AES256_GCM,
            "key_establishment": "ML-KEM-768",
            "signature": "ML-DSA-65",
            "encryption": "AES-256-GCM",
            "kdf": "HKDF-SHA-384",
        },
        "Mode C": {
            "title": "Post-Quantum Hash-Based",
            "suite_id": PQC_MLKEM_SLHDSA_AES256_GCM,
            "key_establishment": "ML-KEM-768",
            "signature": "SLH-DSA-SHAKE-128f",
            "encryption": "AES-256-GCM",
            "kdf": "HKDF-SHA-384",
        },
        "Mode D": {
            "title": "Hybrid Key Establishment",
            "variants": [
                {
                    "variant": "mldsa (Default)",
                    "suite_id": HYBRID_ECDH_MLKEM_MLDSA_AES256_GCM,
                    "key_establishment": "Hybrid (ECDH P-384 + ML-KEM-768)",
                    "signature": "ML-DSA-65",
                    "encryption": "AES-256-GCM",
                    "kdf": "HKDF-SHA-384",
                },
                {
                    "variant": "slhdsa",
                    "suite_id": HYBRID_ECDH_MLKEM_SLHDSA_AES256_GCM,
                    "key_establishment": "Hybrid (ECDH P-384 + ML-KEM-768)",
                    "signature": "SLH-DSA-SHAKE-128f",
                    "encryption": "AES-256-GCM",
                    "kdf": "HKDF-SHA-384",
                },
                {
                    "variant": "ecdsa",
                    "suite_id": HYBRID_ECDH_MLKEM_ECDSA_AES256_GCM,
                    "key_establishment": "Hybrid (ECDH P-384 + ML-KEM-768)",
                    "signature": "ECDSA P-384",
                    "encryption": "AES-256-GCM",
                    "kdf": "HKDF-SHA-384",
                },
            ],
        },
    }


def handle_list_modes(as_json: bool = False) -> int:
    """Print or return JSON for all supported modes."""
    catalog = get_supported_modes_catalog()
    if as_json:
        print(json.dumps({"supported_modes": catalog}, indent=2))
        return 0

    print("==================================================")
    print("Supported Cryptographic Modes & Suite Identifiers")
    print("==================================================")
    for mode_name, info in catalog.items():
        if "variants" in info:
            print(f"\n{mode_name} ({info['title']}):")
            for v in info["variants"]:
                print(f"  - Strategy: {v['variant']}")
                print(f"    Suite ID:           {v['suite_id']}")
                print(f"    Key Establishment:  {v['key_establishment']}")
                print(f"    Signature:          {v['signature']}")
                print(f"    Cipher:             {v['encryption']}")
                print(f"    KDF:                {v['kdf']}")
        else:
            print(f"\n{mode_name} ({info['title']}):")
            print(f"  Suite ID:           {info['suite_id']}")
            print(f"  Key Establishment:  {info['key_establishment']}")
            print(f"  Signature:          {info['signature']}")
            print(f"  Cipher:             {info['encryption']}")
            print(f"  KDF:                {info['kdf']}")
    print("\n==================================================")
    return 0


def run_cli(args_list: Sequence[str] | None = None) -> int:
    """
    Main CLI dispatcher and execution controller.

    Returns exit code (0 for success, non-zero for error).
    """
    parser = build_parser()
    args = parser.parse_args(args_list)

    if args.debug:
        logging.basicConfig(level=logging.DEBUG)
    else:
        logging.basicConfig(level=logging.WARNING)

    # 1. Mode Discovery
    if args.list_modes:
        return handle_list_modes(as_json=args.json)

    # 1b. Controlled Security Test Harness
    if args.security_test:
        if not args.debug:
            logging.disable(logging.WARNING)
        from src.security_tests.attack_simulator import AttackSimulator
        results = AttackSimulator.run_comprehensive_suite()
        if not args.debug:
            logging.disable(logging.NOTSET)
        passed_count = sum(1 for r in results if r.passed)
        failed_count = len(results) - passed_count

        if args.json:
            print(json.dumps({
                "status": "success" if failed_count == 0 else "failed",
                "total_tests": len(results),
                "passed": passed_count,
                "failed": failed_count,
                "results": [r.to_dict() for r in results],
            }, indent=2))
            return 0 if failed_count == 0 else 1

        print("==================================================")
        print("Controlled Security & Tampering Attack Test Summary")
        print("==================================================")
        print(f"Total Attack Scenarios: {len(results)}")
        print(f"Passed:                 {passed_count}")
        print(f"Failed:                 {failed_count}")
        print("\n--- Detailed Attack Matrix ---")
        for r in results:
            status = "PASS" if r.passed else "FAIL"
            print(f"[{status}] {r.attack_name:30s} Mode: {r.mode:10s} Target: {r.target_component:22s} -> {r.rejection_type}")
        print("==================================================")
        return 0 if failed_count == 0 else 1

    # 2. Mode requirement check
    if not args.mode:
        if args.inspect:
            # Default to Mode D inspection if no mode is specified
            args.mode = "D"
        else:
            error_payload = {
                "status": "error",
                "error_type": "ArgumentError",
                "message": "Missing required argument: --mode (A, B, C, or D), --list-modes, or --security-test.",
            }
            if args.json:
                print(json.dumps(error_payload, indent=2))
            else:
                print("Error: Please specify a cryptographic mode using --mode (A, B, C, or D).", file=sys.stderr)
                print("Use --list-modes to inspect all supported modes, or --security-test to run attacks.", file=sys.stderr)
            return 2

    # 3. Build session kwargs
    session_kwargs: dict[str, Any] = {}
    if args.signature:
        session_kwargs["sig_provider_type"] = args.signature
    if args.kem_param:
        session_kwargs["kem_parameter_set"] = args.kem_param
    if args.sig_param:
        session_kwargs["sig_parameter_set"] = args.sig_param

    # 4. Construct SecureSession and execute workflow
    try:
        session = SecureSession.create(args.mode, **session_kwargs)

        # Case A: Inspect only (no message transmission requested)
        if args.inspect and args.message is None:
            config_meta = session.inspect_config()
            if args.json:
                print(json.dumps({"status": "success", "inspection": config_meta}, indent=2))
                return 0

            print("==================================================")
            print("Cryptographic Configuration Inspection")
            print("==================================================")
            print(f"Session ID:         {config_meta['session_id']}")
            print(f"Mode:               Mode {config_meta['mode']}")
            print(f"Algorithm ID:       {config_meta['algorithm_id']}")
            print(f"Key Establishment:  {config_meta['key_establishment']}")
            print(f"Signature:          {config_meta['signature']}")
            print(f"Encryption:         {config_meta['encryption']}")
            print(f"KDF:                {config_meta['kdf']}")
            print(f"KE Provider:        {config_meta['ke_provider']}")
            print(f"Sig Provider:       {config_meta['sig_provider']}")
            print(f"Status:             {config_meta['status']}")
            print("==================================================")
            return 0

        # Case B: Execute secure communication message exchange
        if args.message is not None:
            aad_bytes = args.aad.encode("utf-8") if args.aad else None
            result = session.run_exchange(args.message, aad=aad_bytes)

            if args.json:
                print(json.dumps(result.to_dict(), indent=2))
                return 0

            msg_insp = result.inspect_message()
            print("==================================================")
            print("Secure Communication Exchange Summary")
            print("==================================================")
            print(f"Session ID:         {result.session_id}")
            print(f"Status:             {result.status}")
            print(f"Mode:               Mode {result.mode.value}")
            print(f"Algorithm ID:       {result.algorithm_id}")
            print(f"Key Establishment:  {result.config_metadata.get('key_establishment')}")
            print(f"Signature:          {result.config_metadata.get('signature')}")
            print(f"Cipher:             {result.config_metadata.get('encryption')}")
            print(f"KDF:                {result.config_metadata.get('kdf')}")
            print("\n--- Verified Transmission Metrics ---")
            print(f"Ciphertext:         {msg_insp['ciphertext_bytes']} bytes")
            print(f"Nonce:              {msg_insp['nonce_bytes']} bytes")
            print(f"Signature:          {msg_insp['signature_bytes']} bytes")
            if msg_insp["ke_ciphertext_bytes"]:
                print(f"KEM Ciphertext:     {msg_insp['ke_ciphertext_bytes']} bytes")
            print(f"Sender KE PubKey:   {msg_insp['sender_ke_public_key_bytes']} bytes")
            print(f"Sender Sig PubKey:  {msg_insp['sender_sig_public_key_bytes']} bytes")
            print("\n--- Decrypted Payload ---")
            print(f"Recovered Message:  {result.plaintext_str}")
            print("==================================================")

            if args.inspect:
                print("\n--- Full Configuration Details ---")
                for k, v in session.inspect_config().items():
                    print(f"  {k:20s}: {v}")
                print("==================================================")

            return 0

        # Case C: Neither message nor inspect provided
        print(f"Mode {session.mode.value} initialized ({session.algorithm_id}). Provide --message to transmit data or --inspect to view metadata.", file=sys.stderr)
        return 0

    except UnsupportedAlgorithmError as exc:
        return _handle_cli_error("UnsupportedAlgorithmError", str(exc), args.json, args.debug)
    except ConfigurationError as exc:
        return _handle_cli_error("ConfigurationError", str(exc), args.json, args.debug)
    except NegotiationError as exc:
        return _handle_cli_error("NegotiationError", str(exc), args.json, args.debug)
    except ModeMismatchError as exc:
        return _handle_cli_error("ModeMismatchError", str(exc), args.json, args.debug)
    except (SignatureVerificationError, AuthenticationFailureError) as exc:
        return _handle_cli_error("SecurityVerificationError", f"Verification/decryption failed: {exc}", args.json, args.debug)
    except MalformedMessageError as exc:
        return _handle_cli_error("MalformedMessageError", str(exc), args.json, args.debug)
    except PQCFrameworkError as exc:
        return _handle_cli_error("PQCFrameworkError", str(exc), args.json, args.debug)
    except Exception as exc:
        if args.debug:
            logger.exception("Unexpected CLI failure")
        return _handle_cli_error("UnexpectedError", str(exc), args.json, args.debug)


def _handle_cli_error(error_type: str, message: str, as_json: bool, debug: bool) -> int:
    """Format and display user-readable error without exposing secret internals."""
    if as_json:
        print(json.dumps({"status": "error", "error_type": error_type, "message": message}, indent=2), file=sys.stderr)
    else:
        print(f"Error [{error_type}]: {message}", file=sys.stderr)
    return 1


if __name__ == "__main__":
    sys.exit(run_cli())
