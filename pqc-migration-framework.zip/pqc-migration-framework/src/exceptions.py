"""
src/exceptions.py
Post-Quantum Secure Communication & Migration Framework

Project-wide exception hierarchy.

Design principles:
  - Exceptions are algorithm-agnostic at the public API level.
  - No sensitive material (keys, secrets) is ever included in exception messages.
  - Callers should catch PQCFrameworkError (base) or specific subclasses.
  - Do NOT catch and suppress cryptographic failures — surface them clearly.
"""


class PQCFrameworkError(Exception):
    """Base exception for all framework errors."""


# ---------------------------------------------------------------------------
# Key-related errors
# ---------------------------------------------------------------------------


class InvalidKeyError(PQCFrameworkError):
    """
    Raised when a key is invalid, malformed, or of the wrong type/length.

    Examples: wrong curve, unexpected key length, incompatible algorithm.
    """


# ---------------------------------------------------------------------------
# Signature errors
# ---------------------------------------------------------------------------


class InvalidSignatureError(PQCFrameworkError):
    """
    Raised when a signature is structurally invalid (cannot be parsed / processed).

    Distinct from a merely *incorrect* signature: verify() returns False for that.
    """


class SignatureVerificationError(PQCFrameworkError):
    """
    Raised when a signature does not verify against the provided public key and message.

    This signals a security event: potential tampering or wrong key.
    The receiver MUST reject the message.
    """


# ---------------------------------------------------------------------------
# Encryption / decryption errors
# ---------------------------------------------------------------------------


class AuthenticationFailureError(PQCFrameworkError):
    """
    Raised when AES-GCM (or any AEAD) authentication tag verification fails.

    This signals ciphertext tampering or key mismatch.
    The receiver MUST reject the message.
    """


# ---------------------------------------------------------------------------
# Message / protocol errors
# ---------------------------------------------------------------------------


class MalformedMessageError(PQCFrameworkError):
    """
    Raised when a SecureMessage cannot be deserialised or is structurally incomplete.
    """


class UnsupportedAlgorithmError(PQCFrameworkError):
    """
    Raised when a requested algorithm identifier is not supported by this build.

    Do NOT silently fall back to a weaker algorithm — raise this instead.
    """


class SerializationError(PQCFrameworkError):
    """
    Raised when serialisation or deserialisation of a message or key fails.
    """


# ---------------------------------------------------------------------------
# Crypto-agility and configuration errors (Phase 6)
# ---------------------------------------------------------------------------


class ConfigurationError(PQCFrameworkError):
    """
    Raised when a CryptoConfig or provider setup is invalid, incomplete,
    or contains incompatible/mismatched cryptographic components.
    """


class ModeMismatchError(PQCFrameworkError):
    """
    Raised when a SecureMessage's algorithm/mode identifier does not match
    the receiver's configured cryptographic mode.

    Prevents silent cross-mode interpretation and algorithm downgrade attacks.
    """


class NegotiationError(PQCFrameworkError):
    """
    Raised when cryptographic mode negotiation between client and server fails
    (e.g., no common mutually supported mode).
    """

