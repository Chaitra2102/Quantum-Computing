"""Static Research Figures Generator.

Generates high-resolution academic charts from Phase 10 benchmark data
and saves them to docs/figures/ and results/analysis/figures/.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any, Dict

import matplotlib.pyplot as plt
import numpy as np


def setup_plot_style() -> None:
    """Configure clean publication-ready matplotlib styling."""
    plt.rcParams.update({
        "font.family": "sans-serif",
        "font.size": 10,
        "axes.labelsize": 11,
        "axes.titlesize": 12,
        "xtick.labelsize": 9,
        "ytick.labelsize": 9,
        "legend.fontsize": 9,
        "figure.titlesize": 13,
        "axes.grid": True,
        "grid.alpha": 0.3,
        "grid.linestyle": "--",
    })


def generate_all_figures(
    summary_data: Dict[str, Any],
    sizes_data: Dict[str, Any],
    output_dir: str | Path = "docs/figures",
) -> Dict[str, Path]:
    """Generate all 7 static research figures."""
    out_path = Path(output_dir)
    out_path.mkdir(parents=True, exist_ok=True)
    setup_plot_style()

    kex_data = summary_data.get("key_establishment", {})
    sig_data = summary_data.get("signatures", {})
    e2e_data = summary_data.get("end_to_end", {})
    size_matrix = sizes_data.get("matrix", [])

    created_figures: Dict[str, Path] = {}

    # -------------------------------------------------------------
    # Figure 1: Key Establishment Latency Comparison
    # -------------------------------------------------------------
    fig, ax = plt.subplots(figsize=(9, 5))
    ops = [
        "ECDH Keygen", "ML-KEM Keygen", "Hybrid Keygen",
        "ECDH Derive", "ML-KEM Encap", "ML-KEM Decap",
        "Hybrid Encap", "Hybrid Decap"
    ]
    means = [
        kex_data.get("ecdh_p384_keygen", {}).get("mean", 0),
        kex_data.get("mlkem_768_keygen", {}).get("mean", 0),
        kex_data.get("hybrid_p384_mlkem768_keygen", {}).get("mean", 0),
        kex_data.get("ecdh_p384_derivation", {}).get("mean", 0),
        kex_data.get("mlkem_768_encapsulate", {}).get("mean", 0),
        kex_data.get("mlkem_768_decapsulate", {}).get("mean", 0),
        kex_data.get("hybrid_complete_encapsulate", {}).get("mean", 0),
        kex_data.get("hybrid_complete_decapsulate", {}).get("mean", 0),
    ]
    colors = ["#2b5c8f", "#2ca02c", "#d62728", "#2b5c8f", "#2ca02c", "#2ca02c", "#d62728", "#d62728"]
    bars = ax.bar(ops, means, color=colors, edgecolor="black", linewidth=0.8, alpha=0.85)

    for bar, val in zip(bars, means):
        ax.text(bar.get_x() + bar.get_width() / 2, val + 40, f"{val:.1f} $\\mu$s", ha="center", va="bottom", fontsize=8)

    ax.set_ylabel("Execution Time (\\mu s)")
    ax.set_title("Figure 1: Key Establishment & Key Generation Latency (Mean $\\mu$s)")
    plt.xticks(rotation=30, ha="right")
    plt.tight_layout()
    fig1_path = out_path / "fig1_key_establishment_latency.png"
    fig.savefig(fig1_path, dpi=300)
    plt.close(fig)
    created_figures["fig1"] = fig1_path

    # -------------------------------------------------------------
    # Figure 2: Signature Signing Latency (64B, 1KiB, 16KiB)
    # -------------------------------------------------------------
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(10, 4.5), gridspec_kw={'width_ratios': [2, 1]})
    sizes_labels = ["64 B", "1 KiB", "16 KiB"]
    x = np.arange(len(sizes_labels))
    width = 0.35

    ecdsa_sign = [
        sig_data.get("ecdsa_p384_sign_64B", {}).get("mean", 0),
        sig_data.get("ecdsa_p384_sign_1KiB", {}).get("mean", 0),
        sig_data.get("ecdsa_p384_sign_16KiB", {}).get("mean", 0),
    ]
    mldsa_sign = [
        sig_data.get("mldsa_65_sign_64B", {}).get("mean", 0),
        sig_data.get("mldsa_65_sign_1KiB", {}).get("mean", 0),
        sig_data.get("mldsa_65_sign_16KiB", {}).get("mean", 0),
    ]
    slhdsa_sign = [
        sig_data.get("slhdsa_shake_128f_sign_64B", {}).get("mean", 0),
        sig_data.get("slhdsa_shake_128f_sign_1KiB", {}).get("mean", 0),
        sig_data.get("slhdsa_shake_128f_sign_16KiB", {}).get("mean", 0),
    ]

    ax1.bar(x - width/2, ecdsa_sign, width, label="ECDSA P-384 (C)", color="#2b5c8f", edgecolor="black", alpha=0.85)
    ax1.bar(x + width/2, mldsa_sign, width, label="ML-DSA-65 (Rust)", color="#2ca02c", edgecolor="black", alpha=0.85)
    ax1.set_ylabel("Signing Time (\\mu s)")
    ax1.set_title("Fast Providers (\\mu s)")
    ax1.set_xticks(x)
    ax1.set_xticklabels(sizes_labels)
    ax1.legend()

    ax2.bar(sizes_labels, slhdsa_sign, color="#ff7f0e", edgecolor="black", width=0.5, alpha=0.85)
    ax2.set_ylabel("Signing Time (ms)")
    ax2.set_title("SLH-DSA-SHAKE-128f (Python, ms)")

    fig.suptitle("Figure 2: Digital Signature Signing Latency Across Payload Sizes", fontsize=12)
    plt.tight_layout()
    fig2_path = out_path / "fig2_signature_signing_latency.png"
    fig.savefig(fig2_path, dpi=300)
    plt.close(fig)
    created_figures["fig2"] = fig2_path

    # -------------------------------------------------------------
    # Figure 3: Signature Verification Latency
    # -------------------------------------------------------------
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(10, 4.5), gridspec_kw={'width_ratios': [2, 1]})
    ecdsa_verify = [
        sig_data.get("ecdsa_p384_verify_64B", {}).get("mean", 0),
        sig_data.get("ecdsa_p384_verify_1KiB", {}).get("mean", 0),
        sig_data.get("ecdsa_p384_verify_16KiB", {}).get("mean", 0),
    ]
    mldsa_verify = [
        sig_data.get("mldsa_65_verify_64B", {}).get("mean", 0),
        sig_data.get("mldsa_65_verify_1KiB", {}).get("mean", 0),
        sig_data.get("mldsa_65_verify_16KiB", {}).get("mean", 0),
    ]
    slhdsa_verify = [
        sig_data.get("slhdsa_shake_128f_verify_64B", {}).get("mean", 0),
        sig_data.get("slhdsa_shake_128f_verify_1KiB", {}).get("mean", 0),
        sig_data.get("slhdsa_shake_128f_verify_16KiB", {}).get("mean", 0),
    ]

    ax1.bar(x - width/2, ecdsa_verify, width, label="ECDSA P-384 (C)", color="#2b5c8f", edgecolor="black", alpha=0.85)
    ax1.bar(x + width/2, mldsa_verify, width, label="ML-DSA-65 (Rust)", color="#2ca02c", edgecolor="black", alpha=0.85)
    ax1.set_ylabel("Verification Time (\\mu s)")
    ax1.set_title("Fast Providers (\\mu s)")
    ax1.set_xticks(x)
    ax1.set_xticklabels(sizes_labels)
    ax1.legend()

    ax2.bar(sizes_labels, slhdsa_verify, color="#ff7f0e", edgecolor="black", width=0.5, alpha=0.85)
    ax2.set_ylabel("Verification Time (ms)")
    ax2.set_title("SLH-DSA-SHAKE-128f (Python, ms)")

    fig.suptitle("Figure 3: Digital Signature Verification Latency Across Payload Sizes", fontsize=12)
    plt.tight_layout()
    fig3_path = out_path / "fig3_signature_verification_latency.png"
    fig.savefig(fig3_path, dpi=300)
    plt.close(fig)
    created_figures["fig3"] = fig3_path

    # -------------------------------------------------------------
    # Figure 4: End-to-End Round-Trip Latency
    # -------------------------------------------------------------
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(10, 4.5), gridspec_kw={'width_ratios': [2, 1]})
    fast_modes = ["Mode A", "Mode B", "Mode D (ML-DSA)", "Mode D (ECDSA)"]
    fast_rtt = [
        e2e_data.get("Mode A", {}).get("roundtrip", {}).get("mean", 0),
        e2e_data.get("Mode B", {}).get("roundtrip", {}).get("mean", 0),
        e2e_data.get("Mode D (ML-DSA)", {}).get("roundtrip", {}).get("mean", 0),
        e2e_data.get("Mode D (ECDSA)", {}).get("roundtrip", {}).get("mean", 0),
    ]
    ax1.bar(fast_modes, fast_rtt, color=["#2b5c8f", "#2ca02c", "#d62728", "#9467bd"], edgecolor="black", alpha=0.85)
    ax1.set_ylabel("Round-Trip Time (\\mu s)")
    ax1.set_title("Fast Suite Pipelines (\\mu s)")
    plt.setp(ax1.get_xticklabels(), rotation=20, ha="right")

    slh_modes = ["Mode C", "Mode D (SLH-DSA)"]
    slh_rtt = [
        e2e_data.get("Mode C", {}).get("roundtrip", {}).get("mean", 0),
        e2e_data.get("Mode D (SLH-DSA)", {}).get("roundtrip", {}).get("mean", 0),
    ]
    ax2.bar(slh_modes, slh_rtt, color=["#ff7f0e", "#8c564b"], edgecolor="black", width=0.5, alpha=0.85)
    ax2.set_ylabel("Round-Trip Time (ms)")
    ax2.set_title("Hash-Based Pipelines (ms)")
    plt.setp(ax2.get_xticklabels(), rotation=20, ha="right")

    fig.suptitle("Figure 4: End-to-End Secure Communication Round-Trip Latency (1 KiB)", fontsize=12)
    plt.tight_layout()
    fig4_path = out_path / "fig4_end_to_end_roundtrip_latency.png"
    fig.savefig(fig4_path, dpi=300)
    plt.close(fig)
    created_figures["fig4"] = fig4_path

    # -------------------------------------------------------------
    # Figure 5: Total Wire Size & Artifact Breakdown
    # -------------------------------------------------------------
    fig, ax = plt.subplots(figsize=(9, 5))
    modes = [r["label"] for r in size_matrix]
    ke_pks = [r["ke_public_key_bytes"] for r in size_matrix]
    ke_cts = [r["ke_ciphertext_bytes"] for r in size_matrix]
    sig_pks = [r["sig_public_key_bytes"] for r in size_matrix]
    sigs = [r["signature_bytes"] for r in size_matrix]
    cts = [r["ciphertext_bytes"] + r["nonce_bytes"] for r in size_matrix]

    b1 = ax.bar(modes, ke_pks, label="KE Public Key", color="#1f77b4", edgecolor="black", alpha=0.85)
    b2 = ax.bar(modes, ke_cts, bottom=ke_pks, label="KE Ciphertext", color="#aec7e8", edgecolor="black", alpha=0.85)
    b_bot2 = np.array(ke_pks) + np.array(ke_cts)
    b3 = ax.bar(modes, sig_pks, bottom=b_bot2, label="Sig Public Key", color="#ffbb78", edgecolor="black", alpha=0.85)
    b_bot3 = b_bot2 + np.array(sig_pks)
    b4 = ax.bar(modes, sigs, bottom=b_bot3, label="Signature", color="#2ca02c", edgecolor="black", alpha=0.85)
    b_bot4 = b_bot3 + np.array(sigs)
    b5 = ax.bar(modes, cts, bottom=b_bot4, label="Ciphertext + Nonce", color="#d62728", edgecolor="black", alpha=0.85)

    ax.set_ylabel("Raw Artifact Size (Bytes)")
    ax.set_title("Figure 5: Cryptographic Artifact Byte Footprint (1 KiB Payload)")
    ax.legend()
    plt.xticks(rotation=25, ha="right")
    plt.tight_layout()
    fig5_path = out_path / "fig5_total_wire_size.png"
    fig.savefig(fig5_path, dpi=300)
    plt.close(fig)
    created_figures["fig5"] = fig5_path

    # -------------------------------------------------------------
    # Figure 6: Hybrid Overhead Breakdown (Mode D vs Mode B vs Mode A)
    # -------------------------------------------------------------
    fig, ax = plt.subplots(figsize=(7, 4.5))
    labels = ["Mode A (Classical)", "Mode B (PQC ML-KEM/ML-DSA)", "Mode D (Hybrid ML-DSA)"]
    wire_sizes = [2084, 11693, 11965]
    colors = ["#2b5c8f", "#2ca02c", "#d62728"]
    bars = ax.bar(labels, wire_sizes, color=colors, edgecolor="black", width=0.5, alpha=0.85)

    for bar, val in zip(bars, wire_sizes):
        ax.text(bar.get_x() + bar.get_width() / 2, val + 200, f"{val:,} B", ha="center", va="bottom", fontsize=9, fontweight="bold")

    ax.set_ylabel("Total Wire Representation (Bytes)")
    ax.set_title("Figure 6: Hybrid Wire Overhead Comparison (1 KiB Plaintext)")
    plt.tight_layout()
    fig6_path = out_path / "fig6_hybrid_overhead_breakdown.png"
    fig.savefig(fig6_path, dpi=300)
    plt.close(fig)
    created_figures["fig6"] = fig6_path

    # -------------------------------------------------------------
    # Figure 7: Signature Size Comparison (Public Key & Signature Bytes)
    # -------------------------------------------------------------
    fig, ax = plt.subplots(figsize=(8, 4.5))
    sig_schemes = ["ECDSA P-384", "ML-DSA-65", "SLH-DSA-SHAKE-128f"]
    pk_sizes = [120, 1952, 32]
    sig_sizes = [104, 3309, 17088]

    x_idx = np.arange(len(sig_schemes))
    w = 0.35
    ax.bar(x_idx - w/2, pk_sizes, w, label="Public Key (Bytes)", color="#1f77b4", edgecolor="black", alpha=0.85)
    ax.bar(x_idx + w/2, sig_sizes, w, label="Signature (Bytes)", color="#2ca02c", edgecolor="black", alpha=0.85)

    ax.set_ylabel("Size in Bytes (Log Scale)")
    ax.set_yscale("log")
    ax.set_title("Figure 7: Digital Signature Artifact Sizes (Public Key vs Signature)")
    ax.set_xticks(x_idx)
    ax.set_xticklabels(sig_schemes)
    ax.legend()
    plt.tight_layout()
    fig7_path = out_path / "fig7_signature_size_comparison.png"
    fig.savefig(fig7_path, dpi=300)
    plt.close(fig)
    created_figures["fig7"] = fig7_path

    return created_figures
