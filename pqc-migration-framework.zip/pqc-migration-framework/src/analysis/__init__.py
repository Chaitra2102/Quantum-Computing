"""Comparative Analysis and Research Findings Module for Post-Quantum Migration.

Processes Phase 10 empirical benchmark measurements, derives comparative metrics,
computes statistical distributions and relative overheads, and maps findings to
the core research questions (RQ1–RQ7).
"""

__version__ = "0.1.0"
