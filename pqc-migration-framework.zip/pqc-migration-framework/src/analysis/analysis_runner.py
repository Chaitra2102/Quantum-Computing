"""Analysis Runner CLI for Phase 11.

Executes the full comparative analysis pipeline, normalizes Phase 10 datasets,
generates machine-readable comparative JSON/CSV outputs, and renders static research figures.

Usage:
    python -m src.analysis.analysis_runner
"""

from __future__ import annotations

import csv
import json
from pathlib import Path
from typing import Any, Dict, List

from src.analysis.comparator import (
    generate_comparative_metrics,
    generate_research_question_results,
    load_phase10_datasets,
)
from src.analysis.generate_figures import generate_all_figures


def export_derived_comparisons_csv(
    metrics: Dict[str, Any],
    filepath: Path,
) -> None:
    """Export flattened derived comparison metrics to CSV."""
    rows: List[Dict[str, Any]] = []

    # 1. Key Establishment Keygen
    kg = metrics["key_establishment"]["keygen"]
    rows.append({
        "category": "key_establishment_keygen",
        "metric_name": "ML-KEM-768 vs ECDH P-384 Keygen (Mean)",
        "baseline_val": kg["ecdh_p384_mean_us"],
        "target_val": kg["mlkem_768_mean_us"],
        "unit": "microseconds",
        "absolute_diff": kg["mlkem_vs_ecdh_mean"]["absolute"],
        "relative_diff_pct": kg["mlkem_vs_ecdh_mean"]["percentage"],
    })
    rows.append({
        "category": "key_establishment_keygen",
        "metric_name": "Hybrid vs ECDH P-384 Keygen (Mean)",
        "baseline_val": kg["ecdh_p384_mean_us"],
        "target_val": kg["hybrid_mean_us"],
        "unit": "microseconds",
        "absolute_diff": kg["hybrid_vs_ecdh_mean"]["absolute"],
        "relative_diff_pct": kg["hybrid_vs_ecdh_mean"]["percentage"],
    })

    # 2. Digital Signatures (1 KiB)
    sig_1k = metrics["signatures"]["1KiB"]
    rows.append({
        "category": "signatures_1KiB",
        "metric_name": "ML-DSA-65 vs ECDSA P-384 Signing (Median)",
        "baseline_val": sig_1k["signing"]["ecdsa_p384_median_us"],
        "target_val": sig_1k["signing"]["mldsa_65_median_us"],
        "unit": "microseconds",
        "absolute_diff": sig_1k["signing"]["mldsa_vs_ecdsa_median"]["absolute"],
        "relative_diff_pct": sig_1k["signing"]["mldsa_vs_ecdsa_median"]["percentage"],
    })
    rows.append({
        "category": "signatures_1KiB",
        "metric_name": "ML-DSA-65 vs ECDSA P-384 Verification (Mean)",
        "baseline_val": sig_1k["verification"]["ecdsa_p384_mean_us"],
        "target_val": sig_1k["verification"]["mldsa_65_mean_us"],
        "unit": "microseconds",
        "absolute_diff": sig_1k["verification"]["mldsa_vs_ecdsa_mean"]["absolute"],
        "relative_diff_pct": sig_1k["verification"]["mldsa_vs_ecdsa_mean"]["percentage"],
    })

    # 3. Communication Sizes
    for mode, data in metrics["size_breakdown"].items():
        rows.append({
            "category": "communication_size",
            "metric_name": f"{mode} Wire Size vs Mode A",
            "baseline_val": 2084,
            "target_val": data["wire_json_bytes"],
            "unit": "bytes",
            "absolute_diff": data["overhead_vs_mode_a_wire"]["absolute"],
            "relative_diff_pct": data["overhead_vs_mode_a_wire"]["percentage"],
        })

    # 4. End-to-End Latency
    for mode, data in metrics["end_to_end"].items():
        rows.append({
            "category": "end_to_end_latency",
            "metric_name": f"{mode} Round-Trip vs Mode A",
            "baseline_val": 7678.2,
            "target_val": data["roundtrip_mean_us"],
            "unit": "microseconds",
            "absolute_diff": data["roundtrip_vs_mode_a"]["absolute"],
            "relative_diff_pct": data["roundtrip_vs_mode_a"]["percentage"],
        })

    filepath.parent.mkdir(parents=True, exist_ok=True)
    fieldnames = ["category", "metric_name", "baseline_val", "target_val", "unit", "absolute_diff", "relative_diff_pct"]
    with open(filepath, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)


def run_analysis(
    summary_path: str = "results/benchmarks/benchmark_summary.json",
    sizes_path: str = "results/benchmarks/benchmark_sizes.json",
    output_dir: str = "results/analysis",
    figures_dir: str = "docs/figures",
    verbose: bool = True,
) -> Dict[str, Any]:
    """Execute complete comparative analysis pipeline and export artifacts."""
    out_path = Path(output_dir)
    out_path.mkdir(parents=True, exist_ok=True)

    if verbose:
        print("=" * 70)
        print("PHASE 11 — COMPARATIVE ANALYSIS & RESEARCH FINDINGS")
        print("=" * 70)
        print(f"Summary Source: {summary_path}")
        print(f"Sizes Source:   {sizes_path}")
        print(f"Output Dir:     {out_path.resolve()}")
        print(f"Figures Dir:    {Path(figures_dir).resolve()}")
        print("=" * 70)

    # 1. Load Data
    summary_data, sizes_data = load_phase10_datasets(summary_path, sizes_path)

    # 2. Derive Comparative Metrics
    comparative_metrics = generate_comparative_metrics(summary_data, sizes_data)

    # 3. Formulate Research Question Results
    rq_results = generate_research_question_results(comparative_metrics)

    # 4. Save JSON files
    comp_file = out_path / "comparative_metrics.json"
    rq_file = out_path / "research_question_results.json"
    csv_file = out_path / "derived_comparisons.csv"

    with open(comp_file, "w", encoding="utf-8") as f:
        json.dump(comparative_metrics, f, indent=2)

    with open(rq_file, "w", encoding="utf-8") as f:
        json.dump(rq_results, f, indent=2)

    export_derived_comparisons_csv(comparative_metrics, csv_file)

    # 5. Generate Static Figures
    created_figs = generate_all_figures(summary_data, sizes_data, output_dir=figures_dir)
    # Also mirror into results/analysis/figures/
    generate_all_figures(summary_data, sizes_data, output_dir=out_path / "figures")

    if verbose:
        print("\nAnalysis datasets generated successfully:")
        print(f"  - {comp_file}")
        print(f"  - {rq_file}")
        print(f"  - {csv_file}")
        print("\nFigures rendered successfully in docs/figures/:")
        for k, p in created_figs.items():
            print(f"  - [{k}] {p.name}")
        print("=" * 70)

    return {
        "metrics": comparative_metrics,
        "rq_results": rq_results,
        "figures": created_figs,
    }


def main() -> None:
    """CLI entrypoint for comparative analysis runner."""
    run_analysis(verbose=True)


if __name__ == "__main__":
    main()
