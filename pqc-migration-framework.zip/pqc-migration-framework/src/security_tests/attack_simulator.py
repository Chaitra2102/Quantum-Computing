"""
src/security_tests/attack_simulator.py
Post-Quantum Secure Communication & Migration Framework

Adversarial attack and tamper-injection simulation harness.

ARCHITECTURE.md § 3.2 & Phase 9 Specifications.
Controlled Security Experiment:
  - Operates exclusively in-memory on locally generated messages and test environments.
  - Tests tamper detection, cross-mode isolation, malformation rejection, and state recovery.
  - Strictly prevents exposure of private keys, shared secrets, or AES keys.
"""

from __future__ import annotations

import base64
import copy
import logging
from typing import Any, Sequence

from src.communication.message_bundle import PROTOCOL_VERSION, SecureMessage
from src.communication.secure_communicator import SecureCommunicator
from src.config.crypto_config import CryptoConfig, ModeFactory
from src.config.modes import (
    CLASSICAL_ECDH_ECDSA_AES256_GCM,
    HYBRID_ECDH_MLKEM_ECDSA_AES256_GCM,
    HYBRID_ECDH_MLKEM_MLDSA_AES256_GCM,
    HYBRID_ECDH_MLKEM_SLHDSA_AES256_GCM,
    PQC_MLKEM_MLDSA_AES256_GCM,
    PQC_MLKEM_SLHDSA_AES256_GCM,
    Mode,
)
from src.exceptions import (
    AuthenticationFailureError,
    ConfigurationError,
    InvalidKeyError,
    MalformedMessageError,
    ModeMismatchError,
    PQCFrameworkError,
    SignatureVerificationError,
    UnsupportedAlgorithmError,
)
from src.security_tests.attack_result import AttackResult

logger = logging.getLogger(__name__)

DEFAULT_TEST_PLAINTEXT = b"Classified defense payload: PQC Migration Framework validation message."


class AttackSimulator:
    """
    Controlled adversarial simulation and mutation testing harness.

    Executes deliberate tamper injections against locally generated SecureMessages
    to verify that security invariants hold across Modes A, B, C, and D.
    """

    @staticmethod
    def _create_baseline_exchange(
        config: CryptoConfig,
        plaintext: bytes = DEFAULT_TEST_PLAINTEXT,
        aad: bytes | None = b"sec-test-aad",
    ) -> tuple[SecureCommunicator, object, SecureMessage]:
        """
        Helper: Generate a legitimate baseline message and receiver private key.
        """
        comm = SecureCommunicator(config)
        rx_kp = config.key_exchange.generate_keypair()
        _, msg = comm.send(
            plaintext=plaintext,
            receiver_ke_public_key=rx_kp.public_key,
            aad=aad,
            metadata={"test_tag": "sec_sim"},
        )
        return comm, rx_kp.private_key, msg

    @staticmethod
    def simulate_ciphertext_bit_flip(
        mode: Mode | str = Mode.B,
        sig_type: str | None = None,
        bit_offset: int = 0,
        byte_index: int = 0,
    ) -> AttackResult:
        """
        Attack A: Flip bits in the ciphertext payload.
        Expected: Rejection via SignatureVerificationError or AuthenticationFailureError.
        """
        mode_enum = Mode.from_string(mode)
        cfg = ModeFactory.build(mode_enum, sig_provider_type=sig_type or "mldsa")
        comm, rx_sk, msg = AttackSimulator._create_baseline_exchange(cfg)

        d = msg.to_dict()
        ct_bytes = bytearray(msg.ciphertext)
        idx = byte_index % len(ct_bytes)
        ct_bytes[idx] ^= (1 << (bit_offset % 8))
        d["ciphertext"] = base64.b64encode(bytes(ct_bytes)).decode("ascii")
        tampered_msg = SecureMessage.from_dict(d)

        plaintext_recovered = False
        rejection_type = None
        rejected = False

        try:
            recovered = comm.receive(tampered_msg, rx_sk, aad=b"sec-test-aad")
            if recovered == DEFAULT_TEST_PLAINTEXT:
                plaintext_recovered = True
            actual = "accepted"
        except (SignatureVerificationError, AuthenticationFailureError, PQCFrameworkError) as exc:
            rejected = True
            rejection_type = type(exc).__name__
            actual = "rejected"

        passed = rejected and not plaintext_recovered
        return AttackResult(
            attack_name="ciphertext_bit_flip",
            mode=mode_enum.value,
            algorithm_id=cfg.algorithm_id,
            target_component="ciphertext",
            mutation_description=f"Flipped bit {bit_offset} at byte index {idx} in AES-GCM ciphertext",
            expected_result="rejected",
            actual_result=actual,
            accepted=not rejected,
            rejected=rejected,
            rejection_type=rejection_type,
            information_leak_detected=plaintext_recovered,
            plaintext_recovered=plaintext_recovered,
            passed=passed,
        )

    @staticmethod
    def simulate_nonce_tampering(
        mode: Mode | str = Mode.B,
        sig_type: str | None = None,
        byte_index: int = 0,
    ) -> AttackResult:
        """
        Attack B: Tamper with one byte of the AES-GCM nonce.
        Expected: Rejection via SignatureVerificationError or AuthenticationFailureError.
        """
        mode_enum = Mode.from_string(mode)
        cfg = ModeFactory.build(mode_enum, sig_provider_type=sig_type or "mldsa")
        comm, rx_sk, msg = AttackSimulator._create_baseline_exchange(cfg)

        d = msg.to_dict()
        nonce_bytes = bytearray(msg.nonce)
        idx = byte_index % len(nonce_bytes)
        nonce_bytes[idx] ^= 0xAA
        d["nonce"] = base64.b64encode(bytes(nonce_bytes)).decode("ascii")
        tampered_msg = SecureMessage.from_dict(d)

        plaintext_recovered = False
        rejection_type = None
        rejected = False

        try:
            recovered = comm.receive(tampered_msg, rx_sk, aad=b"sec-test-aad")
            if recovered == DEFAULT_TEST_PLAINTEXT:
                plaintext_recovered = True
            actual = "accepted"
        except (SignatureVerificationError, AuthenticationFailureError, PQCFrameworkError) as exc:
            rejected = True
            rejection_type = type(exc).__name__
            actual = "rejected"

        passed = rejected and not plaintext_recovered
        return AttackResult(
            attack_name="nonce_tampering",
            mode=mode_enum.value,
            algorithm_id=cfg.algorithm_id,
            target_component="nonce",
            mutation_description=f"XORed byte at index {idx} in 12-byte nonce with 0xAA",
            expected_result="rejected",
            actual_result=actual,
            accepted=not rejected,
            rejected=rejected,
            rejection_type=rejection_type,
            information_leak_detected=plaintext_recovered,
            plaintext_recovered=plaintext_recovered,
            passed=passed,
        )

    @staticmethod
    def simulate_signature_tampering(
        mode: Mode | str = Mode.B,
        sig_type: str | None = None,
        byte_index: int = 0,
    ) -> AttackResult:
        """
        Attack C: Modify one byte of the digital signature.
        Expected: Immediate rejection via SignatureVerificationError before decryption.
        """
        mode_enum = Mode.from_string(mode)
        cfg = ModeFactory.build(mode_enum, sig_provider_type=sig_type or "mldsa")
        comm, rx_sk, msg = AttackSimulator._create_baseline_exchange(cfg)

        d = msg.to_dict()
        sig_bytes = bytearray(msg.signature)
        idx = byte_index % len(sig_bytes)
        sig_bytes[idx] ^= 0xFF
        d["signature"] = base64.b64encode(bytes(sig_bytes)).decode("ascii")
        tampered_msg = SecureMessage.from_dict(d)

        plaintext_recovered = False
        rejection_type = None
        rejected = False

        try:
            recovered = comm.receive(tampered_msg, rx_sk, aad=b"sec-test-aad")
            if recovered == DEFAULT_TEST_PLAINTEXT:
                plaintext_recovered = True
            actual = "accepted"
        except (SignatureVerificationError, PQCFrameworkError) as exc:
            rejected = True
            rejection_type = type(exc).__name__
            actual = "rejected"

        passed = rejected and not plaintext_recovered and (rejection_type == "SignatureVerificationError")
        return AttackResult(
            attack_name="signature_tampering",
            mode=mode_enum.value,
            algorithm_id=cfg.algorithm_id,
            target_component="signature",
            mutation_description=f"Corrupted byte {idx} of {len(sig_bytes)}-byte signature",
            expected_result="rejected",
            actual_result=actual,
            accepted=not rejected,
            rejected=rejected,
            rejection_type=rejection_type,
            information_leak_detected=plaintext_recovered,
            plaintext_recovered=plaintext_recovered,
            passed=passed,
        )

    @staticmethod
    def simulate_kem_ciphertext_tampering(
        mode: Mode | str = Mode.B,
        sig_type: str | None = None,
        byte_index: int = -1,
    ) -> AttackResult:
        """
        Attack D: Tamper with KEM encapsulation ciphertext (Modes B, C, D).
        Expected: Derivation of wrong shared secret leading to AuthenticationFailureError.
        """
        mode_enum = Mode.from_string(mode)
        if mode_enum is Mode.A:
            raise UnsupportedAlgorithmError("Mode A does not use KEM ciphertext encapsulation.")

        cfg = ModeFactory.build(mode_enum, sig_provider_type=sig_type or "mldsa")
        comm, rx_sk, msg = AttackSimulator._create_baseline_exchange(cfg)

        d = msg.to_dict()
        assert msg.ke_ciphertext is not None
        kem_bytes = bytearray(msg.ke_ciphertext)
        idx = byte_index if byte_index >= 0 else len(kem_bytes) + byte_index
        kem_bytes[idx] ^= 0x01
        d["ke_ciphertext"] = base64.b64encode(bytes(kem_bytes)).decode("ascii")
        tampered_msg = SecureMessage.from_dict(d)

        plaintext_recovered = False
        rejection_type = None
        rejected = False

        try:
            recovered = comm.receive(tampered_msg, rx_sk, aad=b"sec-test-aad")
            if recovered == DEFAULT_TEST_PLAINTEXT:
                plaintext_recovered = True
            actual = "accepted"
        except (AuthenticationFailureError, InvalidKeyError, PQCFrameworkError) as exc:
            rejected = True
            rejection_type = type(exc).__name__
            actual = "rejected"

        passed = rejected and not plaintext_recovered
        return AttackResult(
            attack_name="kem_ciphertext_tampering",
            mode=mode_enum.value,
            algorithm_id=cfg.algorithm_id,
            target_component="ke_ciphertext",
            mutation_description=f"Flipped LSB at byte index {idx} in KEM ciphertext",
            expected_result="rejected",
            actual_result=actual,
            accepted=not rejected,
            rejected=rejected,
            rejection_type=rejection_type,
            information_leak_detected=plaintext_recovered,
            plaintext_recovered=plaintext_recovered,
            passed=passed,
        )

    @staticmethod
    def simulate_ecdh_component_tampering(
        mode: Mode | str = Mode.A,
        sig_type: str | None = None,
    ) -> AttackResult:
        """
        Attack E: Modify transmitted ECDH ephemeral/public key component (Modes A and D).
        Expected: Rejection via AuthenticationFailureError or InvalidKeyError.
        """
        mode_enum = Mode.from_string(mode)
        cfg = ModeFactory.build(mode_enum, sig_provider_type=sig_type or "mldsa")
        comm, rx_sk, msg = AttackSimulator._create_baseline_exchange(cfg)

        d = msg.to_dict()
        if mode_enum is Mode.A:
            ke_pub = bytearray(msg.sender_ke_public_key)
            ke_pub[-5] ^= 0x55
            d["sender_ke_public_key"] = base64.b64encode(bytes(ke_pub)).decode("ascii")
        else:  # Mode D
            assert msg.ke_ciphertext is not None
            kem_bytes = bytearray(msg.ke_ciphertext)
            # In Mode D, first 97 bytes of ke_ciphertext is the ephemeral ECDH public key
            kem_bytes[10] ^= 0x55
            d["ke_ciphertext"] = base64.b64encode(bytes(kem_bytes)).decode("ascii")

        tampered_msg = SecureMessage.from_dict(d)

        plaintext_recovered = False
        rejection_type = None
        rejected = False

        try:
            recovered = comm.receive(tampered_msg, rx_sk, aad=b"sec-test-aad")
            if recovered == DEFAULT_TEST_PLAINTEXT:
                plaintext_recovered = True
            actual = "accepted"
        except (AuthenticationFailureError, InvalidKeyError, PQCFrameworkError) as exc:
            rejected = True
            rejection_type = type(exc).__name__
            actual = "rejected"

        passed = rejected and not plaintext_recovered
        return AttackResult(
            attack_name="ecdh_component_tampering",
            mode=mode_enum.value,
            algorithm_id=cfg.algorithm_id,
            target_component="sender_ke_public_key" if mode_enum is Mode.A else "hybrid_ecdh_component",
            mutation_description="Mutated ephemeral ECDH public key coordinates",
            expected_result="rejected",
            actual_result=actual,
            accepted=not rejected,
            rejected=rejected,
            rejection_type=rejection_type,
            information_leak_detected=plaintext_recovered,
            plaintext_recovered=plaintext_recovered,
            passed=passed,
        )

    @staticmethod
    def simulate_signature_public_key_tampering(
        mode: Mode | str = Mode.B,
        sig_type: str | None = None,
    ) -> AttackResult:
        """
        Attack F: Mutate the sender's signing public key in the message bundle.
        Expected: Signature verification failure with modified public key.
        """
        mode_enum = Mode.from_string(mode)
        cfg = ModeFactory.build(mode_enum, sig_provider_type=sig_type or "mldsa")
        comm, rx_sk, msg = AttackSimulator._create_baseline_exchange(cfg)

        d = msg.to_dict()
        sig_pub = bytearray(msg.sender_sig_public_key)
        sig_pub[-1] ^= 0x01
        d["sender_sig_public_key"] = base64.b64encode(bytes(sig_pub)).decode("ascii")
        tampered_msg = SecureMessage.from_dict(d)

        plaintext_recovered = False
        rejection_type = None
        rejected = False

        try:
            recovered = comm.receive(tampered_msg, rx_sk, aad=b"sec-test-aad")
            if recovered == DEFAULT_TEST_PLAINTEXT:
                plaintext_recovered = True
            actual = "accepted"
        except (SignatureVerificationError, InvalidKeyError, PQCFrameworkError) as exc:
            rejected = True
            rejection_type = type(exc).__name__
            actual = "rejected"

        passed = rejected and not plaintext_recovered
        return AttackResult(
            attack_name="signature_public_key_tampering",
            mode=mode_enum.value,
            algorithm_id=cfg.algorithm_id,
            target_component="sender_sig_public_key",
            mutation_description="Mutated sender signing public key bytes",
            expected_result="rejected",
            actual_result=actual,
            accepted=not rejected,
            rejected=rejected,
            rejection_type=rejection_type,
            information_leak_detected=plaintext_recovered,
            plaintext_recovered=plaintext_recovered,
            passed=passed,
        )

    @staticmethod
    def simulate_algorithm_id_tampering(
        source_mode: Mode | str = Mode.A,
        target_suite_id: str = PQC_MLKEM_MLDSA_AES256_GCM,
        sig_type: str | None = None,
    ) -> AttackResult:
        """
        Attack G: Tamper with algorithm_id string to attempt cross-mode suite confusion.
        Expected: Rejection via ModeMismatchError.
        """
        mode_enum = Mode.from_string(source_mode)
        cfg = ModeFactory.build(mode_enum, sig_provider_type=sig_type or "mldsa")
        comm, rx_sk, msg = AttackSimulator._create_baseline_exchange(cfg)

        d = msg.to_dict()
        d["algorithm_id"] = target_suite_id
        tampered_msg = SecureMessage.from_dict(d)

        plaintext_recovered = False
        rejection_type = None
        rejected = False

        try:
            recovered = comm.receive(tampered_msg, rx_sk, aad=b"sec-test-aad")
            if recovered == DEFAULT_TEST_PLAINTEXT:
                plaintext_recovered = True
            actual = "accepted"
        except (ModeMismatchError, PQCFrameworkError) as exc:
            rejected = True
            rejection_type = type(exc).__name__
            actual = "rejected"

        passed = rejected and not plaintext_recovered and (rejection_type == "ModeMismatchError")
        return AttackResult(
            attack_name="algorithm_id_tampering",
            mode=mode_enum.value,
            algorithm_id=target_suite_id,
            target_component="algorithm_id",
            mutation_description=f"Altered algorithm_id from {cfg.algorithm_id} to {target_suite_id}",
            expected_result="rejected",
            actual_result=actual,
            accepted=not rejected,
            rejected=rejected,
            rejection_type=rejection_type,
            information_leak_detected=plaintext_recovered,
            plaintext_recovered=plaintext_recovered,
            passed=passed,
        )

    @staticmethod
    def simulate_truncation_attack(
        mode: Mode | str = Mode.B,
        target_field: str = "ciphertext",
        sig_type: str | None = None,
        truncate_bytes: int = 8,
    ) -> AttackResult:
        """
        Attack I: Truncate message payload or signature fields.
        Expected: Controlled rejection without unhandled crash.
        """
        mode_enum = Mode.from_string(mode)
        cfg = ModeFactory.build(mode_enum, sig_provider_type=sig_type or "mldsa")
        comm, rx_sk, msg = AttackSimulator._create_baseline_exchange(cfg)

        d = msg.to_dict()
        raw_val = base64.b64decode(d[target_field])
        if len(raw_val) > truncate_bytes:
            truncated = raw_val[:-truncate_bytes]
        else:
            truncated = raw_val[:1]
        d[target_field] = base64.b64encode(truncated).decode("ascii")
        tampered_msg = SecureMessage.from_dict(d)

        plaintext_recovered = False
        rejection_type = None
        rejected = False

        try:
            recovered = comm.receive(tampered_msg, rx_sk, aad=b"sec-test-aad")
            if recovered == DEFAULT_TEST_PLAINTEXT:
                plaintext_recovered = True
            actual = "accepted"
        except (SignatureVerificationError, AuthenticationFailureError, MalformedMessageError, PQCFrameworkError) as exc:
            rejected = True
            rejection_type = type(exc).__name__
            actual = "rejected"

        passed = rejected and not plaintext_recovered
        return AttackResult(
            attack_name="truncation_attack",
            mode=mode_enum.value,
            algorithm_id=cfg.algorithm_id,
            target_component=target_field,
            mutation_description=f"Truncated {truncate_bytes} bytes from {target_field}",
            expected_result="rejected",
            actual_result=actual,
            accepted=not rejected,
            rejected=rejected,
            rejection_type=rejection_type,
            information_leak_detected=plaintext_recovered,
            plaintext_recovered=plaintext_recovered,
            passed=passed,
        )

    @staticmethod
    def simulate_malformed_message_attack(
        malformation_type: str = "missing_field",
    ) -> AttackResult:
        """
        Attack J: Submit structurally invalid JSON/dictionary bundles.
        Expected: Controlled MalformedMessageError rejection without leaking secrets.
        """
        cfg = ModeFactory.build(Mode.A)
        comm, rx_sk, msg = AttackSimulator._create_baseline_exchange(cfg)

        d = msg.to_dict()
        if malformation_type == "missing_field":
            del d["signature"]
            desc = "Removed required 'signature' field from dictionary"
        elif malformation_type == "invalid_base64":
            d["ciphertext"] = "!!!NotBase64!!!"
            desc = "Injected non-base64 characters into ciphertext field"
        else:
            d["protocol_version"] = 12345  # wrong type
            desc = "Injected integer for protocol_version string"

        rejection_type = None
        rejected = False

        try:
            tampered_msg = SecureMessage.from_dict(d)
            comm.receive(tampered_msg, rx_sk)
            actual = "accepted"
        except (MalformedMessageError, PQCFrameworkError) as exc:
            rejected = True
            rejection_type = type(exc).__name__
            actual = "rejected"

        passed = rejected and (rejection_type == "MalformedMessageError")
        return AttackResult(
            attack_name="malformed_message",
            mode="A",
            algorithm_id=cfg.algorithm_id,
            target_component="wire_structure",
            mutation_description=desc,
            expected_result="rejected",
            actual_result=actual,
            accepted=not rejected,
            rejected=rejected,
            rejection_type=rejection_type,
            information_leak_detected=False,
            plaintext_recovered=False,
            passed=passed,
        )

    @staticmethod
    def simulate_cross_mode_substitution(
        sender_mode: Mode | str,
        receiver_mode: Mode | str,
        sender_sig: str | None = None,
        receiver_sig: str | None = None,
    ) -> AttackResult:
        """
        Attack Cross-Mode: Attempt to send message created under sender_mode to receiver_mode receiver.
        Expected: ModeMismatchError rejection.
        """
        s_mode = Mode.from_string(sender_mode)
        r_mode = Mode.from_string(receiver_mode)

        cfg_sender = ModeFactory.build(s_mode, sig_provider_type=sender_sig or "mldsa")
        cfg_receiver = ModeFactory.build(r_mode, sig_provider_type=receiver_sig or "mldsa")

        comm_sender = SecureCommunicator(cfg_sender)
        comm_receiver = SecureCommunicator(cfg_receiver)

        # Receiver generates keypair for its own mode
        rx_kp = cfg_receiver.key_exchange.generate_keypair()

        # Sender generates message using sender's communicator (with compatible/fallback key if same KE, or sender's own)
        # Note: If KE types differ, sender sending with incompatible key raises TypeError or produces message
        plaintext_recovered = False
        rejection_type = None
        rejected = False

        try:
            # Generate sender message
            try:
                _, msg = comm_sender.send(DEFAULT_TEST_PLAINTEXT, rx_kp.public_key)
            except Exception:
                # If key types differ at send time, use sender's own keypair to form valid wire bundle
                dummy_rx = cfg_sender.key_exchange.generate_keypair()
                _, msg = comm_sender.send(DEFAULT_TEST_PLAINTEXT, dummy_rx.public_key)

            # Receiver attempts to receive
            recovered = comm_receiver.receive(msg, rx_kp.private_key)
            if recovered == DEFAULT_TEST_PLAINTEXT:
                plaintext_recovered = True
            actual = "accepted"
        except (ModeMismatchError, PQCFrameworkError, TypeError, InvalidKeyError) as exc:
            rejected = True
            rejection_type = type(exc).__name__
            actual = "rejected"

        passed = rejected and not plaintext_recovered and (rejection_type == "ModeMismatchError")
        return AttackResult(
            attack_name="cross_mode_substitution",
            mode=f"{s_mode.value}->{r_mode.value}",
            algorithm_id=f"{cfg_sender.algorithm_id} -> {cfg_receiver.algorithm_id}",
            target_component="algorithm_id / receiver_binding",
            mutation_description=f"Submitted Mode {s_mode.value} message to Mode {r_mode.value} receiver",
            expected_result="rejected",
            actual_result=actual,
            accepted=not rejected,
            rejected=rejected,
            rejection_type=rejection_type,
            information_leak_detected=plaintext_recovered,
            plaintext_recovered=plaintext_recovered,
            passed=passed,
        )

    @staticmethod
    def simulate_replay_experiment(
        mode: Mode | str = Mode.B,
        sig_type: str | None = None,
    ) -> AttackResult:
        """
        Replay Experiment: Investigate behavior when an identical legitimate message is submitted twice.
        Note: The current protocol layer is a stateless message encryption format without a sequence/cache state.
        This experiment verifies and documents this factual behavior without mislabeling it.
        """
        mode_enum = Mode.from_string(mode)
        cfg = ModeFactory.build(mode_enum, sig_provider_type=sig_type or "mldsa")
        comm, rx_sk, msg = AttackSimulator._create_baseline_exchange(cfg)

        # First receive
        first_decrypted = comm.receive(msg, rx_sk, aad=b"sec-test-aad")
        assert first_decrypted == DEFAULT_TEST_PLAINTEXT

        # Second receive (replay identical message)
        replay_accepted = False
        rejection_type = None

        try:
            second_decrypted = comm.receive(msg, rx_sk, aad=b"sec-test-aad")
            if second_decrypted == DEFAULT_TEST_PLAINTEXT:
                replay_accepted = True
            actual = "accepted"
        except Exception as exc:
            rejection_type = type(exc).__name__
            actual = "rejected"

        # The protocol layer is stateless point-to-point without anti-replay cache
        return AttackResult(
            attack_name="replay_experiment",
            mode=mode_enum.value,
            algorithm_id=cfg.algorithm_id,
            target_component="replay_nonce_cache",
            mutation_description="Submitted identical valid SecureMessage bundle twice to receiver",
            expected_result="accepted (stateless protocol)",
            actual_result=actual,
            accepted=replay_accepted,
            rejected=not replay_accepted,
            rejection_type=rejection_type,
            information_leak_detected=False,
            plaintext_recovered=replay_accepted,
            passed=True,  # Test passed as characterization of stateless design
        )

    @classmethod
    def run_comprehensive_suite(cls) -> list[AttackResult]:
        """
        Run a full suite of all defined attack scenarios across all modes.
        """
        results: list[AttackResult] = []

        # 1. Ciphertext bit flips across all modes
        for m in [Mode.A, Mode.B, Mode.C, Mode.D]:
            results.append(cls.simulate_ciphertext_bit_flip(mode=m))

        # 2. Nonce tampering across all modes
        for m in [Mode.A, Mode.B, Mode.C, Mode.D]:
            results.append(cls.simulate_nonce_tampering(mode=m))

        # 3. Signature tampering across all modes and Mode D variants
        results.append(cls.simulate_signature_tampering(mode=Mode.A))
        results.append(cls.simulate_signature_tampering(mode=Mode.B))
        results.append(cls.simulate_signature_tampering(mode=Mode.C))
        results.append(cls.simulate_signature_tampering(mode=Mode.D, sig_type="mldsa"))
        results.append(cls.simulate_signature_tampering(mode=Mode.D, sig_type="slhdsa"))
        results.append(cls.simulate_signature_tampering(mode=Mode.D, sig_type="ecdsa"))

        # 4. KEM Ciphertext tampering (Modes B, C, D)
        results.append(cls.simulate_kem_ciphertext_tampering(mode=Mode.B))
        results.append(cls.simulate_kem_ciphertext_tampering(mode=Mode.C))
        results.append(cls.simulate_kem_ciphertext_tampering(mode=Mode.D, sig_type="mldsa"))

        # 5. ECDH component tampering (Modes A and D)
        results.append(cls.simulate_ecdh_component_tampering(mode=Mode.A))
        results.append(cls.simulate_ecdh_component_tampering(mode=Mode.D))

        # 6. Signature Public Key tampering
        for m in [Mode.A, Mode.B, Mode.C, Mode.D]:
            results.append(cls.simulate_signature_public_key_tampering(mode=m))

        # 7. Algorithm ID tampering
        results.append(cls.simulate_algorithm_id_tampering(source_mode=Mode.A, target_suite_id=PQC_MLKEM_MLDSA_AES256_GCM))
        results.append(cls.simulate_algorithm_id_tampering(source_mode=Mode.B, target_suite_id=PQC_MLKEM_SLHDSA_AES256_GCM))
        results.append(cls.simulate_algorithm_id_tampering(source_mode=Mode.C, target_suite_id=HYBRID_ECDH_MLKEM_MLDSA_AES256_GCM))
        results.append(cls.simulate_algorithm_id_tampering(source_mode=Mode.D, target_suite_id=HYBRID_ECDH_MLKEM_ECDSA_AES256_GCM, sig_type="mldsa"))

        # 8. Truncation attacks
        results.append(cls.simulate_truncation_attack(mode=Mode.A, target_field="ciphertext"))
        results.append(cls.simulate_truncation_attack(mode=Mode.B, target_field="signature"))
        results.append(cls.simulate_truncation_attack(mode=Mode.C, target_field="signature"))
        results.append(cls.simulate_truncation_attack(mode=Mode.D, target_field="ke_ciphertext"))

        # 9. Malformed messages
        results.append(cls.simulate_malformed_message_attack(malformation_type="missing_field"))
        results.append(cls.simulate_malformed_message_attack(malformation_type="invalid_base64"))

        # 10. Cross-Mode substitutions (all pairs)
        cross_pairs = [
            (Mode.A, Mode.B), (Mode.A, Mode.C), (Mode.A, Mode.D),
            (Mode.B, Mode.A), (Mode.B, Mode.C), (Mode.B, Mode.D),
            (Mode.C, Mode.A), (Mode.C, Mode.B), (Mode.C, Mode.D),
            (Mode.D, Mode.A), (Mode.D, Mode.B), (Mode.D, Mode.C),
        ]
        for s_m, r_m in cross_pairs:
            results.append(cls.simulate_cross_mode_substitution(sender_mode=s_m, receiver_mode=r_m))

        # 11. Intra-Mode D cross-signature substitutions
        intra_d_pairs = [
            ("mldsa", "ecdsa"),
            ("ecdsa", "slhdsa"),
            ("slhdsa", "mldsa"),
        ]
        for s_sig, r_sig in intra_d_pairs:
            results.append(cls.simulate_cross_mode_substitution(
                sender_mode=Mode.D, receiver_mode=Mode.D, sender_sig=s_sig, receiver_sig=r_sig
            ))

        # 12. Replay experiment
        results.append(cls.simulate_replay_experiment(mode=Mode.B))

        return results
