"""
src/security_tests/attack_result.py
Post-Quantum Secure Communication & Migration Framework

Structured result data model for controlled adversarial attack simulations.

ARCHITECTURE.md § 3.2 & Phase 9 Specifications.
Security Invariants:
  - Never captures, logs, or stores private keys, shared secrets, or AES keys.
  - Contains strictly non-sensitive telemetry, mutation details, and verification outcomes.
"""

from __future__ import annotations

import dataclasses
from typing import Any


@dataclasses.dataclass(frozen=True)
class AttackResult:
    """
    Structured outcome of a controlled adversarial simulation or tamper injection.

    Attributes
    ----------
    attack_name:
        Human-readable name of the attack scenario (e.g. 'ciphertext_bit_flip').
    mode:
        Mode under test ('A', 'B', 'C', 'D').
    algorithm_id:
        Cryptographic suite identifier of the target message.
    target_component:
        Message component targeted for mutation (e.g. 'ciphertext', 'nonce', 'signature').
    mutation_description:
        Detailed explanation of the exact mutation applied.
    expected_result:
        Expected outcome ('rejected' or 'accepted').
    actual_result:
        Observed outcome ('rejected' or 'accepted').
    accepted:
        Whether the receiver accepted the mutated message.
    rejected:
        Whether the receiver rejected the mutated message.
    rejection_type:
        Exception class name or detection mechanism (e.g. 'SignatureVerificationError').
    information_leak_detected:
        Whether any unencrypted plaintext or secret key material leaked.
    plaintext_recovered:
        Whether original plaintext was recovered by an adversary/unauthorized path.
    passed:
        Whether actual result matched the security expectation (passed security invariant).
    """

    attack_name: str
    mode: str
    algorithm_id: str
    target_component: str
    mutation_description: str
    expected_result: str
    actual_result: str
    accepted: bool
    rejected: bool
    rejection_type: str | None
    information_leak_detected: bool
    plaintext_recovered: bool
    passed: bool

    def to_dict(self) -> dict[str, Any]:
        """
        Produce a JSON-serializable dictionary summary.
        Guaranteed to contain NO private keys, shared secrets, or AES keys.
        """
        return {
            "attack_name": self.attack_name,
            "mode": self.mode,
            "algorithm_id": self.algorithm_id,
            "target_component": self.target_component,
            "mutation_description": self.mutation_description,
            "expected_result": self.expected_result,
            "actual_result": self.actual_result,
            "accepted": self.accepted,
            "rejected": self.rejected,
            "rejection_type": self.rejection_type,
            "information_leak_detected": self.information_leak_detected,
            "plaintext_recovered": self.plaintext_recovered,
            "passed": self.passed,
        }

    def __repr__(self) -> str:
        status_str = "PASS" if self.passed else "FAIL"
        return (
            f"<AttackResult [{status_str}] attack={self.attack_name!r} mode={self.mode} "
            f"target={self.target_component!r} rejection={self.rejection_type!r}>"
        )
