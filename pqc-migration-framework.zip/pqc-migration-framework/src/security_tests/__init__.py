"""
src/security_tests/__init__.py
Post-Quantum Secure Communication & Migration Framework

Controlled Adversarial Attack & Tampering Simulation Layer.
"""

from src.security_tests.attack_result import AttackResult
from src.security_tests.attack_simulator import AttackSimulator

__all__ = [
    "AttackResult",
    "AttackSimulator",
]
