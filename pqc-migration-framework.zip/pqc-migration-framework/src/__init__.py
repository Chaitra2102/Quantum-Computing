# src/__init__.py
# Post-Quantum Secure Communication & Migration Framework
# Phase 2 — Classical Cryptographic Baseline
