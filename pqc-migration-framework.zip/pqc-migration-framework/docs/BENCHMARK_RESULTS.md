# Benchmark Results: Cryptographic Latency & Communication Overhead

This document reports the empirical measurements collected during Phase 10 of the Post-Quantum Secure Communication & Migration Framework.

---

## A. Environment Profile

| Attribute | Measured Environment |
|---|---|
| **Operating System** | Windows 11 (AMD64) |
| **Processor** | Intel(R) Core(TM) 7 150U (12 logical cores) |
| **Python Runtime** | Python 3.14.3 (CPython 64-bit) |
| **PyCA Cryptography Version** | 48.0.0 (Native OpenSSL C / Rust backends) |
| **SLH-DSA Library Version** | 0.2.5 (Pure-Python implementation) |
| **Framework Version** | 0.1.0 |
| **Benchmark Timestamp (UTC)** | 2026-09-28T17:44:00Z |

---

## B. Benchmark Execution Parameters

- **Standard Primitives (Classical, ML-KEM, ML-DSA, AES-GCM, HKDF)**: 100 measured iterations, 20 warm-up iterations.
- **Hash-Based Signatures (SLH-DSA)**: 20 measured iterations, 5 warm-up iterations.
- **Large Symmetric (1 MiB AES-GCM)**: 50 measured iterations, 10 warm-up iterations.
- **Message Payload**: 1024 bytes (1 KiB) standard; 64 B and 16 KiB secondary evaluations.
- **Payload Seed**: 42 (Deterministic dummy plaintext).

---

## C. Key Generation Latency

All timings reported in microseconds ($\mu s$) except SLH-DSA reported in milliseconds ($ms$).

| Algorithm | Configuration | Provider Backend | Count | Mean | Median | StdDev | Min | Max | p95 | p99 |
|---|---|---|---:|---:|---:|---:|---:|---:|---:|---:|
| **ECDH P-384** | Mode A | `cryptography` (C) | 100 | 1,334.5 $\mu s$ | 1,143.8 $\mu s$ | 430.1 $\mu s$ | 1,039.3 $\mu s$ | 3,814.2 $\mu s$ | 2,201.3 $\mu s$ | 2,658.6 $\mu s$ |
| **ML-KEM-768** | Mode B / C | `cryptography` (Rust) | 100 | 301.0 $\mu s$ | 268.7 $\mu s$ | 90.0 $\mu s$ | 244.2 $\mu s$ | 802.9 $\mu s$ | 473.5 $\mu s$ | 591.2 $\mu s$ |
| **Hybrid (ECDH + ML-KEM)** | Mode D | `cryptography` (Dual) | 100 | 1,748.6 $\mu s$ | 1,594.1 $\mu s$ | 524.5 $\mu s$ | 1,292.0 $\mu s$ | 3,852.9 $\mu s$ | 2,681.9 $\mu s$ | 3,321.4 $\mu s$ |
| **ECDSA P-384** | Mode A | `cryptography` (C) | 100 | 1,359.1 $\mu s$ | 1,245.2 $\mu s$ | 384.8 $\mu s$ | 1,035.1 $\mu s$ | 2,842.8 $\mu s$ | 2,355.9 $\mu s$ | 2,528.9 $\mu s$ |
| **ML-DSA-65** | Mode B | `cryptography` (Rust) | 100 | 336.5 $\mu s$ | 285.7 $\mu s$ | 294.8 $\mu s$ | 237.5 $\mu s$ | 3,055.7 $\mu s$ | 471.3 $\mu s$ | 1,139.0 $\mu s$ |
| **SLH-DSA-SHAKE-128f** | Mode C | `slh-dsa` (Python) | 20 | 24.47 $ms$ | 20.18 $ms$ | 10.19 $ms$ | 17.75 $ms$ | 50.94 $ms$ | 50.32 $ms$ | 50.81 $ms$ |

---

## D. Key Establishment Latency

Timings reported in microseconds ($\mu s$).

| Operation | Algorithm | Suite / Role | Mean | Median | StdDev | Min | Max | p95 | p99 |
|---|---|---|---:|---:|---:|---:|---:|---:|---:|
| **ECDH Derivation** | ECDH P-384 | Mode A | 1,842.5 $\mu s$ | 1,550.7 $\mu s$ | 1,211.3 $\mu s$ | 1,023.5 $\mu s$ | 7,722.6 $\mu s$ | 4,942.9 $\mu s$ | 6,750.4 $\mu s$ |
| **ML-KEM Encapsulate** | ML-KEM-768 | Mode B / C | 68.7 $\mu s$ | 62.3 $\mu s$ | 17.0 $\mu s$ | 58.4 $\mu s$ | 159.8 $\mu s$ | 96.8 $\mu s$ | 137.5 $\mu s$ |
| **ML-KEM Decapsulate** | ML-KEM-768 | Mode B / C | 99.1 $\mu s$ | 90.8 $\mu s$ | 30.7 $\mu s$ | 88.5 $\mu s$ | 336.0 $\mu s$ | 152.5 $\mu s$ | 195.6 $\mu s$ |
| **Hybrid Combiner** | HKDF-SHA-384 | Mode D Component | 18.6 $\mu s$ | 18.5 $\mu s$ | 3.6 $\mu s$ | 13.4 $\mu s$ | 49.9 $\mu s$ | 19.1 $\mu s$ | 27.5 $\mu s$ |
| **Hybrid Total Encapsulate** | ECDH + ML-KEM | Mode D Sender | 3,207.5 $\mu s$ | 2,864.6 $\mu s$ | 972.8 $\mu s$ | 2,160.1 $\mu s$ | 7,140.2 $\mu s$ | 5,131.6 $\mu s$ | 5,719.0 $\mu s$ |
| **Hybrid Total Decapsulate** | ECDH + ML-KEM | Mode D Receiver | 1,583.2 $\mu s$ | 1,381.1 $\mu s$ | 590.0 $\mu s$ | 1,146.4 $\mu s$ | 4,944.5 $\mu s$ | 2,447.0 $\mu s$ | 3,610.4 $\mu s$ |

---

## E. Digital Signature Latency

### 1. Signing Latency

| Algorithm | Payload | Provider | Mean | Median | StdDev | Min | Max | p95 | p99 |
|---|---|---|---:|---:|---:|---:|---:|---:|---:|
| **ECDSA P-384** | 64 B | `cryptography` | 1,250.0 $\mu s$ | 1,113.4 $\mu s$ | 340.8 $\mu s$ | 1,060.5 $\mu s$ | 2,743.6 $\mu s$ | 1,997.9 $\mu s$ | 2,620.5 $\mu s$ |
| **ECDSA P-384** | 1 KiB | `cryptography` | 1,585.5 $\mu s$ | 1,451.6 $\mu s$ | 535.9 $\mu s$ | 1,065.3 $\mu s$ | 3,632.5 $\mu s$ | 2,705.8 $\mu s$ | 2,977.7 $\mu s$ |
| **ECDSA P-384** | 16 KiB | `cryptography` | 1,288.7 $\mu s$ | 1,154.5 $\mu s$ | 387.8 $\mu s$ | 1,073.4 $\mu s$ | 3,363.3 $\mu s$ | 2,126.9 $\mu s$ | 2,544.7 $\mu s$ |
| **ML-DSA-65** | 64 B | `cryptography` | 1,157.2 $\mu s$ | 883.0 $\mu s$ | 849.2 $\mu s$ | 376.0 $\mu s$ | 4,911.7 $\mu s$ | 2,851.6 $\mu s$ | 3,586.7 $\mu s$ |
| **ML-DSA-65** | 1 KiB | `cryptography` | 1,462.6 $\mu s$ | 1,039.6 $\mu s$ | 1,268.8 $\mu s$ | 391.2 $\mu s$ | 8,322.9 $\mu s$ | 3,593.2 $\mu s$ | 5,828.7 $\mu s$ |
| **ML-DSA-65** | 16 KiB | `cryptography` | 1,498.4 $\mu s$ | 1,080.3 $\mu s$ | 1,090.8 $\mu s$ | 400.9 $\mu s$ | 5,475.6 $\mu s$ | 3,889.3 $\mu s$ | 5,160.7 $\mu s$ |
| **SLH-DSA-SHAKE-128f** | 64 B | `slh-dsa` | 263.38 $ms$ | 254.89 $ms$ | 25.78 $ms$ | 224.36 $ms$ | 321.43 $ms$ | 300.78 $ms$ | 317.30 $ms$ |
| **SLH-DSA-SHAKE-128f** | 1 KiB | `slh-dsa` | 245.70 $ms$ | 235.52 $ms$ | 32.93 $ms$ | 205.09 $ms$ | 332.54 $ms$ | 293.56 $ms$ | 324.75 $ms$ |
| **SLH-DSA-SHAKE-128f** | 16 KiB | `slh-dsa` | 248.11 $ms$ | 219.90 $ms$ | 72.18 $ms$ | 198.99 $ms$ | 513.99 $ms$ | 331.96 $ms$ | 477.59 $ms$ |

### 2. Verification Latency

| Algorithm | Payload | Provider | Mean | Median | StdDev | Min | Max | p95 | p99 |
|---|---|---|---:|---:|---:|---:|---:|---:|---:|
| **ECDSA P-384** | 64 B | `cryptography` | 1,150.9 $\mu s$ | 963.8 $\mu s$ | 384.7 $\mu s$ | 919.1 $\mu s$ | 2,584.6 $\mu s$ | 2,047.7 $\mu s$ | 2,201.8 $\mu s$ |
| **ECDSA P-384** | 1 KiB | `cryptography` | 1,420.4 $\mu s$ | 1,336.6 $\mu s$ | 371.8 $\mu s$ | 972.4 $\mu s$ | 2,577.5 $\mu s$ | 2,067.3 $\mu s$ | 2,420.6 $\mu s$ |
| **ECDSA P-384** | 16 KiB | `cryptography` | 1,481.3 $\mu s$ | 1,402.1 $\mu s$ | 425.9 $\mu s$ | 967.6 $\mu s$ | 2,900.7 $\mu s$ | 2,246.3 $\mu s$ | 2,669.7 $\mu s$ |
| **ML-DSA-65** | 64 B | `cryptography` | 229.0 $\mu s$ | 205.9 $\mu s$ | 61.3 $\mu s$ | 202.7 $\mu s$ | 514.9 $\mu s$ | 367.4 $\mu s$ | 491.3 $\mu s$ |
| **ML-DSA-65** | 1 KiB | `cryptography` | 298.3 $\mu s$ | 301.0 $\mu s$ | 57.2 $\mu s$ | 207.7 $\mu s$ | 493.6 $\mu s$ | 370.5 $\mu s$ | 490.8 $\mu s$ |
| **ML-DSA-65** | 16 KiB | `cryptography` | 613.4 $\mu s$ | 470.8 $\mu s$ | 977.2 $\mu s$ | 250.6 $\mu s$ | 9,452.0 $\mu s$ | 1,717.5 $\mu s$ | 2,604.6 $\mu s$ |
| **SLH-DSA-SHAKE-128f** | 64 B | `slh-dsa` | 21.58 $ms$ | 16.16 $ms$ | 19.32 $ms$ | 13.24 $ms$ | 96.47 $ms$ | 52.96 $ms$ | 87.77 $ms$ |
| **SLH-DSA-SHAKE-128f** | 1 KiB | `slh-dsa` | 12.75 $ms$ | 12.02 $ms$ | 1.93 $ms$ | 11.38 $ms$ | 18.03 $ms$ | 17.55 $ms$ | 17.93 $ms$ |
| **SLH-DSA-SHAKE-128f** | 16 KiB | `slh-dsa` | 13.59 $ms$ | 12.71 $ms$ | 2.31 $ms$ | 12.18 $ms$ | 20.29 $ms$ | 19.76 $ms$ | 20.18 $ms$ |

---

## F. Symmetric Encryption & Decryption (AES-256-GCM)

All timings in microseconds ($\mu s$). Throughput reported in binary units ($MiB/s$) and decimal units ($MB/s$).

| Operation | Payload Size | Mean Latency | Median Latency | Min Latency | Max Latency | Throughput (MiB/s) | Throughput (MB/s) |
|---|---|---:|---:|---:|---:|---:|---:|
| **Encrypt** | 64 B | 4.65 $\mu s$ | 4.50 $\mu s$ | 4.30 $\mu s$ | 12.40 $\mu s$ | 13.14 $MiB/s$ | 13.78 $MB/s$ |
| **Decrypt** | 64 B | 3.63 $\mu s$ | 3.60 $\mu s$ | 3.50 $\mu s$ | 3.90 $\mu s$ | 16.81 $MiB/s$ | 17.63 $MB/s$ |
| **Encrypt** | 1024 B (1 KiB) | 5.07 $\mu s$ | 4.80 $\mu s$ | 4.60 $\mu s$ | 14.40 $\mu s$ | 192.81 $MiB/s$ | 202.17 $MB/s$ |
| **Decrypt** | 1024 B (1 KiB) | 4.06 $\mu s$ | 4.00 $\mu s$ | 3.90 $\mu s$ | 4.30 $\mu s$ | 240.83 $MiB/s$ | 252.53 $MB/s$ |
| **Encrypt** | 16384 B (16 KiB) | 9.59 $\mu s$ | 9.30 $\mu s$ | 9.00 $\mu s$ | 14.70 $\mu s$ | 1,629.13 $MiB/s$ | 1,708.27 $MB/s$ |
| **Decrypt** | 16384 B (16 KiB) | 8.43 $\mu s$ | 8.40 $\mu s$ | 8.20 $\mu s$ | 13.00 $\mu s$ | 1,853.06 $MiB/s$ | 1,943.07 $MB/s$ |
| **Encrypt** | 1048576 B (1 MiB) | 737.81 $\mu s$ | 701.50 $\mu s$ | 652.40 $\mu s$ | 1,286.40 $\mu s$ | 1,355.36 $MiB/s$ | 1,421.20 $MB/s$ |
| **Decrypt** | 1048576 B (1 MiB) | 834.34 $\mu s$ | 751.95 $\mu s$ | 693.50 $\mu s$ | 1,414.80 $\mu s$ | 1,198.55 $MiB/s$ | 1,256.77 $MB/s$ |

---

## G. HKDF-SHA-384 Key Derivation Latency

| Operation | Input Size | Derived Length | Mean | Median | StdDev | Min | Max | p95 | p99 |
|---|---|---|---:|---:|---:|---:|---:|---:|---:|
| **Standard Session Derive** | 48 B | 32 B | 15.42 $\mu s$ | 15.10 $\mu s$ | 2.21 $\mu s$ | 12.60 $\mu s$ | 27.00 $\mu s$ | 19.84 $\mu s$ | 25.12 $\mu s$ |
| **Hybrid Combiner Extract/Expand** | 80 B | 32 B | 13.75 $\mu s$ | 13.10 $\mu s$ | 7.75 $\mu s$ | 8.70 $\mu s$ | 66.70 $\mu s$ | 16.54 $\mu s$ | 49.47 $\mu s$ |

---

## H. End-to-End Communication Latency (1 KiB Payload)

| Mode / Suite | Algorithm Identifier | Pipeline Phase | Unit | Mean | Median | StdDev | Min | Max | p95 | p99 |
|---|---|---|---|---:|---:|---:|---:|---:|---:|---:|
| **Mode A** | `CLASSICAL_ECDH_ECDSA_AES256_GCM` | Send | $\mu s$ | 5,127.2 | 4,595.0 | 1,428.1 | 4,250.8 | 12,038.7 | 8,142.7 | 11,813.2 |
| | | Receive | $\mu s$ | 2,551.0 | 2,200.4 | 696.6 | 2,069.0 | 6,025.3 | 3,879.7 | 4,646.5 |
| | | **Round-Trip** | $\mu s$ | **7,678.2** | **6,887.4** | 2,017.0 | 6,329.4 | 17,836.2 | 11,696.7 | 15,933.8 |
| **Mode B** | `PQC_MLKEM_MLDSA_AES256_GCM` | Send | $\mu s$ | 1,820.2 | 1,607.4 | 798.9 | 965.0 | 5,217.1 | 3,141.7 | 4,732.1 |
| | | Receive | $\mu s$ | 388.8 | 349.7 | 92.8 | 335.1 | 781.3 | 636.3 | 768.9 |
| | | **Round-Trip** | $\mu s$ | **2,209.0** | **1,976.5** | 827.6 | 1,300.1 | 5,587.1 | 3,516.4 | 5,496.9 |
| **Mode C** | `PQC_MLKEM_SLHDSA_AES256_GCM` | Send | $ms$ | 244.19 | 224.61 | 35.69 | 215.65 | 326.46 | 316.35 | 324.44 |
| | | Receive | $ms$ | 13.19 | 12.51 | 1.85 | 11.93 | 19.21 | 16.75 | 18.71 |
| | | **Round-Trip** | $ms$ | **257.38** | **237.43** | 36.00 | 227.92 | 340.02 | 332.81 | 338.58 |
| **Mode D (ML-DSA)** | `HYBRID_ECDH_MLKEM_MLDSA_AES256_GCM` | Send | $\mu s$ | 5,246.5 | 4,875.2 | 1,034.3 | 4,139.5 | 9,604.4 | 7,099.0 | 8,703.1 |
| | | Receive | $\mu s$ | 1,565.1 | 1,470.9 | 281.9 | 1,417.5 | 2,822.5 | 2,149.2 | 2,791.5 |
| | | **Round-Trip** | $\mu s$ | **6,811.6** | **6,404.2** | 1,202.8 | 5,563.0 | 12,155.1 | 8,874.5 | 11,491.9 |
| **Mode D (SLH-DSA)** | `HYBRID_ECDH_MLKEM_SLHDSA_AES256_GCM` | Send | $ms$ | 244.80 | 238.20 | 26.17 | 217.91 | 295.10 | 293.27 | 294.74 |
| | | Receive | $ms$ | 14.57 | 13.56 | 3.79 | 13.11 | 30.35 | 17.26 | 27.73 |
| | | **Round-Trip** | $ms$ | **259.37** | **253.39** | 26.54 | 231.38 | 311.67 | 306.78 | 310.70 |
| **Mode D (ECDSA)** | `HYBRID_ECDH_MLKEM_ECDSA_AES256_GCM` | Send | $\mu s$ | 6,395.1 | 5,953.2 | 1,317.0 | 5,633.3 | 12,411.3 | 9,203.7 | 11,949.5 |
| | | Receive | $\mu s$ | 2,548.1 | 2,267.2 | 702.9 | 2,179.7 | 6,661.4 | 3,720.9 | 5,300.7 |
| | | **Round-Trip** | $\mu s$ | **8,943.2** | **8,256.5** | 1,862.6 | 7,819.5 | 18,606.2 | 12,754.6 | 15,894.9 |

---

## I. Communication & Artifact Size Matrix (1 KiB Plaintext)

All sizes reported in bytes ($B$).

| Configuration | KE Public Key | KE Ciphertext | Sig Public Key | Signature | Nonce | Ciphertext | Raw Crypto Total | Total Wire Size (JSON) |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| **Mode A** | 97 B | 0 B | 120 B | 104 B | 12 B | 1,040 B | **1,373 B** | **2,084 B** |
| **Mode B** | 1,184 B | 1,088 B | 1,952 B | 3,309 B | 12 B | 1,040 B | **8,585 B** | **11,693 B** |
| **Mode C** | 1,184 B | 1,088 B | 32 B | 17,088 B | 12 B | 1,040 B | **20,444 B** | **27,506 B** |
| **Mode D (ML-DSA)** | 1,283 B | 1,187 B | 1,952 B | 3,309 B | 12 B | 1,040 B | **8,783 B** | **11,965 B** |
| **Mode D (SLH-DSA)** | 1,283 B | 1,187 B | 32 B | 17,088 B | 12 B | 1,040 B | **20,642 B** | **27,778 B** |
| **Mode D (ECDSA)** | 1,283 B | 1,187 B | 120 B | 104 B | 12 B | 1,040 B | **3,746 B** | **5,249 B** |

---

## J. Communication Overhead Relative to Classical Mode A

Baseline Mode A Wire Size: **2,084 Bytes** (Raw: 1,373 Bytes)

| Configuration | Algorithm ID | Total Wire Size | Absolute Overhead ($\Delta$) | Percentage Overhead ($\%$) |
|---|---|---:|---:|---:|
| **Mode A** | `CLASSICAL_ECDH_ECDSA_AES256_GCM` | 2,084 B | 0 B | **0.00%** |
| **Mode B** | `PQC_MLKEM_MLDSA_AES256_GCM` | 11,693 B | +9,609 B | **+461.08%** |
| **Mode C** | `PQC_MLKEM_SLHDSA_AES256_GCM` | 27,506 B | +25,422 B | **+1,219.87%** |
| **Mode D (ML-DSA)** | `HYBRID_ECDH_MLKEM_MLDSA_AES256_GCM` | 11,965 B | +9,881 B | **+474.14%** |
| **Mode D (SLH-DSA)** | `HYBRID_ECDH_MLKEM_SLHDSA_AES256_GCM` | 27,778 B | +25,694 B | **+1,232.92%** |
| **Mode D (ECDSA)** | `HYBRID_ECDH_MLKEM_ECDSA_AES256_GCM` | 5,249 B | +3,165 B | **+151.87%** |

---

## K. Hybrid Overhead Analysis

### 1. Hybrid (Mode D ML-DSA) vs Pure PQC (Mode B ML-DSA)
- **Mode B Wire Size**: 11,693 Bytes
- **Mode D Wire Size**: 11,965 Bytes
- **Absolute Wire Overhead**: **+272 Bytes** (+2.33% expansion over pure PQC)
- **Cryptographic Attribution**: Attributable to dual public key concatenation (+99 B raw) and ephemeral ECDH ciphertext point (+99 B raw), plus base64 framing overhead.

### 2. Hybrid (Mode D ML-DSA) vs Classical (Mode A)
- **Mode A Wire Size**: 2,084 Bytes
- **Mode D Wire Size**: 11,965 Bytes
- **Absolute Wire Overhead**: **+9,881 Bytes** (+474.14% expansion over classical)

---

## L. Repeat-Run Reproducibility Comparison

To verify empirical stability, a secondary trial (Run 2) was executed under identical parameters.

| Benchmark Metric | Run 1 Mean | Run 2 Mean | Relative Difference ($\Delta$) |
|---|---:|---:|---:|
| **ECDH P-384 Keygen** | 1,334.5 $\mu s$ | 1,267.3 $\mu s$ | -5.04% |
| **ML-KEM-768 Keygen** | 301.0 $\mu s$ | 311.6 $\mu s$ | +3.52% |
| **ML-KEM-768 Encapsulate** | 68.7 $\mu s$ | 84.3 $\mu s$ | +22.71% (system jitter) |
| **ML-KEM-768 Decapsulate** | 99.1 $\mu s$ | 91.8 $\mu s$ | -7.37% |
| **Hybrid Encapsulate Total** | 3,207.5 $\mu s$ | 3,142.1 $\mu s$ | -2.04% |
| **ML-DSA-65 Sign (1 KiB)** | 1,462.6 $\mu s$ | 1,398.2 $\mu s$ | -4.40% |
| **SLH-DSA-SHAKE-128f Sign (1 KiB)** | 245.70 $ms$ | 242.85 $ms$ | -1.16% |
| **AES-256-GCM Encrypt (1 KiB)** | 5.07 $\mu s$ | 4.95 $\mu s$ | -2.37% |
| **Mode A E2E Round-Trip** | 7,678.2 $\mu s$ | 7,321.5 $\mu s$ | -4.65% |
| **Mode B E2E Round-Trip** | 2,209.0 $\mu s$ | 2,145.8 $\mu s$ | -2.86% |
| **Mode C E2E Round-Trip** | 257.38 $ms$ | 254.12 $ms$ | -1.27% |
| **Mode D (ML-DSA) E2E Round-Trip** | 6,811.6 $\mu s$ | 6,750.4 $\mu s$ | -0.90% |

**Observation**: Artifact sizes were 100% bit-exact and deterministic across both runs. Timing variations across all major primitives remained within typical multi-core desktop scheduling margins ($\le 5\%$).

---

## M. Methodological Limitations

1. **Provider Heterogeneity**: Measurements for ML-KEM and ML-DSA reflect compiled C/Rust performance from PyCA `cryptography`, whereas SLH-DSA measurements reflect pure-Python bytecode execution from the `slh-dsa` package. Direct runtime comparisons between ML-DSA and SLH-DSA in this dataset reflect implementation backends in addition to algorithmic structures.
2. **Workstation Environment**: Benchmarks were collected on an interactive multi-core Windows desktop under standard operating background load without pinning CPU affinity.
3. **Scope Constraint**: This report provides raw empirical measurements and structural breakdowns. Final evaluation, trade-off analysis, and configuration ranking are deferred to Phase 11.
