# Framework Reproducibility Guide

**Project:** Post-Quantum Secure Communication & Migration Framework  
**Document:** `docs/REPRODUCIBILITY.md`  
**Phase:** Phase 14 — Final Research Synthesis & Project Archival  
**Status:** FROZEN  

---

## 1. Environment Specifications

To reproduce the test suite, interactive dashboard, and migration experiments, configure an environment matching the reference testbed:

- **Operating System:** Windows 11 (AMD64 / x86_64) or compatible Linux/macOS
- **Python Version:** Python 3.14.3 (CPython 64-bit)
- **Primary Cryptographic Provider:** PyCA `cryptography` 48.0.0 (C / Rust native backend)
- **Hash-Based Signature Provider:** `slh-dsa` 0.2.5 (Pure Python)
- **Testing Framework:** `pytest` 8.4.1
- **Visualization Stack:** `streamlit` 1.64.0, `plotly` 7.1.0, `pandas` 3.0.1, `matplotlib` 3.10.9

---

## 2. Dependency Installation

Clone or extract the repository and install all required runtime and analysis dependencies:

```bash
pip install -r requirements.txt
pip install streamlit plotly pandas
```

---

## 3. Repository Structure

```
pqc-migration-framework/
├── src/
│   ├── communication/      # High-level SecureCommunicator, Session, MessageBundle
│   ├── config/             # CryptoConfig, ModeFactory, Mode definitions
│   ├── dashboard/          # Streamlit research dashboard application
│   ├── exceptions/         # Cryptographic & protocol exception taxonomy
│   ├── migration/          # MigrationStage, MigrationPath, MigrationExperimentRunner
│   ├── providers/          # Classical, PQC, Hybrid, and Symmetric provider implementations
│   └── security_tests/     # Adversarial attack simulator and mutation engine
├── tests/                  # 566 unit and integration test suite
├── results/
│   ├── benchmarks/         # Authoritative Phase 10 benchmark JSON and CSV datasets
│   ├── analysis/           # Phase 11 comparative analysis metrics
│   └── migration/          # Phase 12 migration results, compatibility, and delta datasets
└── docs/                   # Comprehensive technical reports, specifications, and architecture docs
```

---

## 4. Test Suite Execution

Execute the full automated regression test suite:

```bash
pytest -q
```

**Expected Result:**
```
============================ 566 passed in ~39s =============================
0 failed, 0 skipped, 0 errors
```

Execute specific test modules:
```bash
# Cryptographic provider unit tests
pytest tests/unit/ -v

# High-level communication integration tests
pytest tests/integration/ -v

# Adversarial security & tamper mutation tests
pytest tests/security/ -v

# Migration experimentation tests
pytest tests/migration/ -v

# Dashboard data-loading and visualization tests
pytest tests/dashboard/ -v
```

---

## 5. Launching the Interactive Dashboard

Launch the Streamlit research dashboard locally:

```bash
streamlit run src/dashboard/app.py
```

The application will open in your default browser at `http://localhost:8501`.

---

## 6. Authoritative Dataset Locations

The framework uses frozen, machine-readable datasets for analysis and dashboard rendering:
- Benchmark Summary: `results/benchmarks/benchmark_summary.json`
- Benchmark Size Matrix: `results/benchmarks/benchmark_sizes.json`
- Migration Results: `results/migration/migration_results.json`
- Migration History: `results/migration/migration_history.json`
- Cross-Suite Compatibility Matrix: `results/migration/migration_compatibility.csv`
- Transition Deltas: `results/migration/migration_deltas.csv`
- Comparative Metrics: `results/analysis/comparative_metrics.json`
