# Security Scope, Threat Model & Defensive Research Boundaries

**Project:** Post-Quantum Secure Communication & Migration Framework  
**Document:** `docs/SECURITY_SCOPE.md`  
**Phase:** Phase 14 — Final Research Synthesis & Project Archival  
**Status:** FROZEN  

---

## 1. Defensive Research Purpose

This framework is developed strictly for **defensive cryptographic research, migration analysis, and protocol robustness validation**. It evaluates how secure communication systems can transition from classical to post-quantum algorithms without compromising data confidentiality or message authentication.

The framework does **not** implement offensive tooling, automated exploits, malware payloads, key exfiltration mechanisms, or network attack infrastructure.

---

## 2. Threat Model & Attacker Capabilities

### In-Scope Attacker Capabilities
- **Channel Interception:** The adversary can intercept serialized `SecureMessage` payloads transmitted across untrusted channels.
- **Message Mutation (Tampering):** The adversary can flip arbitrary bits within the ciphertext, nonce, signature, public keys, and algorithm suite identifiers.
- **Message Injection & Substitution:** The adversary can inject malformed JSON framing, truncated fields, or messages generated under different cryptographic suites.

### Out-of-Scope Attacker Capabilities (Attacker Limitations)
- **Zero Private Key Access:** The adversary does not possess private signing keys, private KEX keys, or AES session keys.
- **Zero Memory Access:** The adversary cannot read internal memory state, intermediate HKDF keying material, or unencrypted plaintext buffers.
- **No Physical Quantum Computer:** The adversary does not possess a quantum computer capable of running Shor's algorithm during the active benchmark execution.

---

## 3. Evaluated Security Vectors vs Out-of-Scope Vectors

| Testing Dimension | Specific Vector Evaluated | Framework Defense Mechanism | Observed Outcome |
|---|---|---|:---:|
| **Message Integrity** | 1-bit mutation in ciphertext | AES-256-GCM auth tag & signature | **REJECTED (100%)** |
| **Nonce Integrity** | 1-bit mutation in GCM nonce | Signed canonical data $(C \parallel N)$ | **REJECTED (100%)** |
| **Authentication** | 1-bit mutation in signature bytes | Strict digital signature verification | **REJECTED (100%)** |
| **Suite Binding** | Altered algorithm suite identifier | Exact `algorithm_id` matching | **REJECTED (100%)** |
| **Framing Robustness** | Truncated fields & malformed JSON | Strict schema parsing & length checks | **REJECTED (100%)** |
| **Cross-Suite Isolation**| Mode A sent to Mode D receiver (30 pairs) | Suite mismatch rejection | **REJECTED (100%)** |
| **Replay Protection** | Duplicate message retransmission | Stateless protocol (Outside scope) | **Identified for hardening** |
| **Side-Channel Attacks**| Power analysis & timing leakage | Constant-time provider primitives | **Outside scope** |
| **Hardware Faults** | Glitch / laser fault injection | Conventional hardware environment | **Outside scope** |
| **Network Denial of Service**| High-volume packet flooding | Transport-level concerns | **Outside scope** |

---

## 4. Secret Non-Exposure Invariant

The framework enforces strict separation between secret keying material and public message framing:
- **`SecureMessage` Bundles:** Contain only ephemeral public keys, ciphertext, nonce, signature, and non-sensitive metadata.
- **Session Results & Logs:** Never log, serialize, or expose private keys, shared secrets, AES keys, or HKDF intermediate material.
- **Dashboard & Artifacts:** All visualization datasets in `results/` are verified 100% secret-free.

---

## 5. Replay Limitation Statement

> [!IMPORTANT]
> The migration framework operates on a stateless message model. Replay detection, sequence numbers, timestamp validation windows, and sliding-window caches are outside the current experimental scope and remain identified for future transport-layer protocol hardening.
