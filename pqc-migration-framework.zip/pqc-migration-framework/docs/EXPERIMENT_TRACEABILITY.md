# Research Experiment Traceability Matrix

**Project:** Post-Quantum Secure Communication & Migration Framework  
**Document:** `docs/EXPERIMENT_TRACEABILITY.md`  
**Phase:** Phase 14 — Final Research Synthesis & Project Archival  
**Status:** FROZEN  

---

## 1. Traceability Mapping

This matrix establishes complete bidirectional traceability between the project's research questions, implementation phases, empirical datasets, and interactive dashboard tabs.

```
======================================================================================================================================
RESEARCH QUESTION TRACEABILITY MATRIX
======================================================================================================================================
RQ ID  Topic                        Phase   Authoritative Dataset                              Source File / Test                   Dashboard Tab
--------------------------------------------------------------------------------------------------------------------------------------
RQ1    ML-KEM vs ECDH KEX           P10/P11 results/benchmarks/benchmark_summary.json          benchmarks/benchmark_kex.py          Tab 3 (Performance)
                                            results/analysis/comparative_metrics.json          tests/unit/pqc/test_mlkem.py         Tab 8 (Findings)

RQ2    ML-DSA vs ECDSA Signatures   P10/P11 results/benchmarks/benchmark_summary.json          benchmarks/benchmark_signatures.py   Tab 3 (Performance)
                                            results/benchmarks/benchmark_sizes.json            tests/unit/pqc/test_mldsa.py         Tab 8 (Findings)

RQ3    SLH-DSA Characteristics      P10/P11 results/benchmarks/benchmark_summary.json          benchmarks/benchmark_signatures.py   Tab 3 (Performance)
                                            results/benchmarks/benchmark_sizes.json            tests/unit/pqc/test_slhdsa.py        Tab 8 (Findings)

RQ4    Communication Wire Overhead  P10/P11 results/benchmarks/benchmark_sizes.json            benchmarks/benchmark_sizes.py        Tab 4 (Overhead)
                                            results/analysis/comparative_metrics.json          tests/unit/communication/            Tab 8 (Findings)

RQ5    Hybrid Construction Overhead P10/P12 results/benchmarks/benchmark_summary.json          benchmarks/benchmark_kex.py          Tab 3 (Performance)
                                            results/migration/migration_deltas.csv             tests/unit/hybrid/test_hybrid_kem.py Tab 5 (Migration)

RQ6    Security & Tamper Robustness P09/P12 results/migration/migration_results.json           src/security_tests/attack_simulator  Tab 7 (Security)
                                            results/migration/migration_compatibility.csv      tests/security/                      Tab 8 (Findings)

RQ7    Crypto-Agility & Migration   P12     results/migration/migration_results.json           src/migration/migration_experiment   Tab 5 (Migration)
                                            results/migration/migration_deltas.csv             tests/migration/                     Tab 6 (Compatibility)
======================================================================================================================================
```

---

## 2. Experimental Verification Checklist

- [x] **RQ1 Verified:** ML-KEM-768 keygen (301.0 $\mu s$) vs ECDH (1,334.5 $\mu s$); encap/decap (167.8 $\mu s$) vs ECDH derivation (1,842.5 $\mu s$).
- [x] **RQ2 Verified:** ML-DSA-65 verification (298.3 $\mu s$) vs ECDSA (1,420.4 $\mu s$); artifact sizes (+1,526.7% PK, +3,081.7% Sig).
- [x] **RQ3 Verified:** SLH-DSA-SHAKE-128f signing (245.70 ms), compact PK (32 B), large signature (17,088 B).
- [x] **RQ4 Verified:** Serialization expansion (+51.78% Mode A, +36.20% Mode B, +36.23% Mode D ML-DSA).
- [x] **RQ5 Verified:** Incremental hybrid overhead (+2.33% / +272 B wire size vs pure PQC Mode B; 18.55 $\mu s$ HKDF combiner).
- [x] **RQ6 Verified:** 100% of tamper mutations and 100% of mismatched suite interactions rejected.
- [x] **RQ7 Verified:** 5 migration paths executed with 100% functional continuity.
