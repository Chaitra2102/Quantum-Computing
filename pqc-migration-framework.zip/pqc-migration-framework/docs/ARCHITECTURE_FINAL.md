# Final System Architecture & Provider Integration

**Project:** Post-Quantum Secure Communication & Migration Framework  
**Document:** `docs/ARCHITECTURE_FINAL.md`  
**Phase:** Phase 14 — Final Research Synthesis & Project Archival  
**Status:** FROZEN  

---

## 1. System Architecture Overview

The framework implements a layered, provider-agnostic architecture designed to decouple high-level secure messaging and staged migration workflows from concrete cryptographic implementations.

```mermaid
flowchart TD
    subgraph OperationalLayer ["Operational & Presentation Layer"]
        CLI["CLI Interface (src/main_cli.py)"]
        Dashboard["Streamlit Research Dashboard (src/dashboard/app.py)"]
        MigRunner["Migration Experiment Engine (src/migration/migration_experiment.py)"]
    end

    subgraph CommunicationLayer ["High-Level Secure Communication Layer"]
        Session["SecureSession (src/communication/session.py)"]
        Comm["SecureCommunicator (src/communication/secure_communicator.py)"]
        MsgBundle["SecureMessage Bundle (src/communication/message_bundle.py)"]
    end

    subgraph AgilityLayer ["Crypto-Agility & Configuration Layer"]
        Factory["ModeFactory (src/config/crypto_config.py)"]
        Config["CryptoConfig (Immutable Struct)"]
        Modes["Mode Definitions (A, B, C, D)"]
    end

    subgraph MultiProviderLayer ["AD-17 Multi-Provider Implementation Layer"]
        CP["PyCA cryptography 48.0.0 (C / Rust)"]
        SP["slh-dsa 0.2.5 (Pure Python)"]
        HybridKEM["Hybrid Dual KEM Combiner"]
    end

    subgraph Primitives ["Cryptographic Primitives"]
        ECDH["ECDH P-384"]
        ECDSA["ECDSA P-384"]
        MLKEM["ML-KEM-768 / 1024 (FIPS 203)"]
        MLDSA["ML-DSA-65 (FIPS 204)"]
        SLHDSA["SLH-DSA-SHAKE-128f (FIPS 205)"]
        AES["AES-256-GCM"]
        HKDF["HKDF-SHA-384"]
    end

    OperationalLayer --> CommunicationLayer
    CommunicationLayer --> AgilityLayer
    AgilityLayer --> MultiProviderLayer
    
    CP --> ECDH
    CP --> ECDSA
    CP --> MLKEM
    CP --> MLDSA
    CP --> AES
    CP --> HKDF
    SP --> SLHDSA
    HybridKEM --> ECDH
    HybridKEM --> MLKEM
    HybridKEM --> HKDF
```

---

## 2. Multi-Provider Architecture (AD-17)

Adopted in Architectural Decision 17 (AD-17) to resolve native compilation constraints on Windows AMD64 / Python 3.14:
- **PyCA `cryptography` 48.0.0:** High-throughput native C/Rust backend for ECDH, ECDSA, ML-KEM, ML-DSA, AES-GCM, and HKDF.
- **`slh-dsa` 0.2.5:** Pure Python reference implementation for state-free hash-based signatures.
- **Hybrid Secret Combiner:** Concatenates shared secrets via `HKDF-SHA-384(ECDH_ss || MLKEM_ss)` using domain separation labels.

---

## 3. Communication Modes

| Mode | Canonical Suite Identifier | Key Establishment | Digital Signature | Symmetric Cipher |
|---|---|---|---|---|
| **Mode A** | `CLASSICAL_ECDH_ECDSA_AES256_GCM` | ECDH P-384 | ECDSA P-384 | AES-256-GCM + HKDF-SHA-384 |
| **Mode B** | `PQC_MLKEM_MLDSA_AES256_GCM` | ML-KEM-768 | ML-DSA-65 | AES-256-GCM + HKDF-SHA-384 |
| **Mode C** | `PQC_MLKEM_SLHDSA_AES256_GCM` | ML-KEM-768 | SLH-DSA-SHAKE-128f | AES-256-GCM + HKDF-SHA-384 |
| **Mode D** | `HYBRID_ECDH_MLKEM_MLDSA_AES256_GCM`<br>`HYBRID_ECDH_MLKEM_SLHDSA_AES256_GCM`<br>`HYBRID_ECDH_MLKEM_ECDSA_AES256_GCM` | ECDH P-384 + ML-KEM-768 | Configurable:<br>ML-DSA-65 / SLH-DSA / ECDSA | AES-256-GCM + HKDF-SHA-384 |

---

## 4. Layer Separation & Invariants

1. **Strict Verify-then-Decrypt:** The receiver always verifies digital signatures before attempting key derivation or symmetric decryption.
2. **Zero Secret Leakage:** Private keys, intermediate shared secrets, and AES session keys are never stored in serialized message bundles or public inspection structures.
3. **Explicit Suite Binding:** Messages explicitly encapsulate their `algorithm_id`, and receivers reject mismatched configurations immediately without silent fallback.
