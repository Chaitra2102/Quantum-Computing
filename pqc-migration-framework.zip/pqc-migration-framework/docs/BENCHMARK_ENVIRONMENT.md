# Benchmark Hardware & Software Environment

This document records the exact physical and software execution environment used to generate the benchmark datasets in Phase 10 of the Post-Quantum Secure Communication & Migration Framework.

---

## 1. System Platform & Hardware

| Parameter | Recorded Value |
|---|---|
| **Operating System** | Windows 11 (AMD64) |
| **OS Architecture** | 64-bit (`x86_64` / `AMD64`) |
| **CPU Model** | Intel(R) Core(TM) 7 150U |
| **Logical CPU Cores / Threads** | 12 |
| **Timer Precision** | High-Resolution Monotonic (`time.perf_counter_ns()`, < 100 ns resolution) |
| **System Load State** | Normal interactive developer desktop workstation |

---

## 2. Software Runtime & Dependencies

| Component / Package | Version | Purpose in Framework |
|---|---|---|
| **Python** | 3.14.3 (CPython 64-bit) | Framework execution runtime |
| **PyCA cryptography** | 48.0.0 | Classical (ECDH/ECDSA P-384, AES-256-GCM, HKDF-SHA-384) & PQC (ML-KEM-768/1024, ML-DSA-65) |
| **slh-dsa** | 0.2.5 | Hash-based PQC signature provider (SLH-DSA-SHAKE-128f, Pure-Python) |
| **pytest** | 8.4.1 | Automated verification and regression test suite |
| **Project Version** | 0.1.0 (Phase 10 Benchmark Suite) | Research codebase baseline |

---

## 3. Cryptographic Suite Provider Mapping (AD-17)

| Cryptographic Operation | Mode | Provider Library | Implementation Backend |
|---|---|---|---|
| **ECDH P-384** | Mode A, Mode D | `cryptography` 48.0.0 | Native OpenSSL / C |
| **ECDSA P-384 / SHA-384** | Mode A, Mode D | `cryptography` 48.0.0 | Native OpenSSL / C |
| **ML-KEM-768** | Mode B, Mode C, Mode D | `cryptography` 48.0.0 | Native Rust / C backend |
| **ML-DSA-65** | Mode B, Mode D | `cryptography` 48.0.0 | Native Rust / C backend |
| **SLH-DSA-SHAKE-128f** | Mode C, Mode D | `slh-dsa` 0.2.5 | Pure-Python implementation |
| **AES-256-GCM** | All Modes | `cryptography` 48.0.0 | Hardware AES-NI accelerated (OpenSSL C) |
| **HKDF-SHA-384** | All Modes | `cryptography` 48.0.0 | Native OpenSSL / C |

---

## 4. Benchmark Execution Parameters

| Parameter | Standard Primitives | SLH-DSA Primitives | Symmetric Payloads |
|---|---|---|---|
| **Measured Iterations ($N$)** | 100 | 20 | 100 (64B, 1KiB, 16KiB) / 50 (1MiB) |
| **Warm-up Iterations** | 20 | 5 | 20 (64B, 1KiB, 16KiB) / 10 (1MiB) |
| **Reported Metric Unit** | Microseconds ($\mu s$) | Milliseconds ($ms$) | Microseconds ($\mu s$) / Throughput ($MiB/s$) |
| **Payload Sizes Evaluated** | 64 B, 1024 B (1 KiB), 16384 B (16 KiB) | 64 B, 1024 B, 16384 B | 64 B, 1 KiB, 16 KiB, 1 MiB |
| **Payload Seed** | 42 (Deterministic dummy plaintext; does NOT override crypto RNG) | 42 | 42 |

---

## 5. Security and Non-Exposure Guarantees

- **No Secret Material Logged**: Benchmark results contain operation names, parameters, execution times, payload sizes, and statistical metrics. Private keys, ephemeral keys, shared secrets, and AES session keys are excluded from benchmark output.
- **Provider Randomness Integrity**: All cryptographic key generations, encapsulations, nonces, and signings invoke their respective secure cryptographic RNG sources.
