# Project Archival Manifest & Artifact Inventory

**Project:** Post-Quantum Secure Communication & Migration Framework  
**Document:** `docs/ARCHIVE_MANIFEST.md`  
**Phase:** Phase 14 — Final Research Synthesis & Project Archival  
**Status:** COMPLETE AND FROZEN  

---

## 1. Project Archival State

- **Version:** 1.0.0 (Frozen)
- **Completed Phases:** Phase 0 through Phase 14 (100% Complete)
- **Total Test Suite:** 566 unit, integration, security, migration, and dashboard tests (**100% Passing, 0 Failed, 0 Skipped, 0 Errors**)
- **Archival Date:** 2026-09-28

---

## 2. Directory & Component Inventory

### Source Directory (`src/`)
- `src/config/`: Configuration management, `Mode` enum, `CryptoConfig`, `ModeFactory`.
- `src/communication/`: `SecureCommunicator`, `SecureSession`, `SecureMessage`, `MessageBundle`.
- `src/providers/`:
  - `classical/`: `ECDHProvider` (P-384), `ECDSAProvider` (P-384).
  - `pqc/`: `MLKEMProvider` (768/1024), `MLDSAProvider` (65), `SLHDSAProvider` (SHAKE-128f).
  - `hybrid/`: `HybridKEProvider` (Dual KEX + Combiner).
  - `symmetric/`: `AESGCMProvider` (256-bit), `HKDFProvider` (SHA-384).
- `src/security_tests/`: `AttackSimulator`, mutation engines, attack result models.
- `src/migration/`: `MigrationStage`, `MigrationPath`, `MigrationExperimentRunner`, result models.
- `src/dashboard/`: `app.py`, `data_loader.py`, `charts.py`, `metrics.py`, `components.py`.
- `src/main_cli.py`: Operational command-line interface.

### Test Directory (`tests/`)
- `tests/unit/`: 370 tests covering all cryptographic providers, symmetric ciphers, and config layers.
- `tests/integration/`: High-level session and communication pipeline workflow tests.
- `tests/security/`: 49 adversarial attack and tamper mutation tests.
- `tests/analysis/`: Comparative metrics and figure generation verification tests.
- `tests/migration/`: 42 tests covering migration stages, paths, transitions, and compatibility.
- `tests/dashboard/`: 20 tests covering data loading, schema validation, and chart generation.

### Experimental Datasets (`results/`)
- `results/benchmarks/`: Authoritative Phase 10 benchmark summary (`benchmark_summary.json`), size matrix (`benchmark_sizes.json`), raw logs, and CSV outputs.
- `results/analysis/`: Phase 11 comparative metrics (`comparative_metrics.json`), research question results, and CSV comparisons.
- `results/migration/`: Phase 12 migration results (`migration_results.json`), history (`migration_history.json`), compatibility matrix (`migration_compatibility.csv`), and deltas (`migration_deltas.csv`).

### Documentation Suite (`docs/`)
- `docs/FINAL_RESEARCH_REPORT.md`: Comprehensive academic and research synthesis report.
- `docs/MIGRATION_EXPERIMENT.md`: Phase 12 post-quantum migration study report.
- `docs/COMPARATIVE_ANALYSIS.md`: Phase 11 comparative findings report.
- `docs/BENCHMARK_RESULTS.md`: Phase 10 benchmark analysis report.
- `docs/BENCHMARKING.md` & `docs/BENCHMARK_ENVIRONMENT.md`: Benchmarking methodology and testbed specifications.
- `docs/DASHBOARD.md`: Phase 13 interactive dashboard guide.
- `docs/ARCHITECTURE_FINAL.md`: Final system architecture and provider mapping.
- `docs/EXPERIMENT_TRACEABILITY.md`: Bidirectional research question traceability matrix.
- `docs/SECURITY_SCOPE.md`: Defensive research scope, threat model, and boundaries.
- `docs/REPRODUCIBILITY.md`: Environment setup and test execution instructions.
- `docs/ARCHIVE_MANIFEST.md`: Complete project archival inventory.
- `docs/PHASE_14_FINAL_REPORT.md`: Final completion report.
