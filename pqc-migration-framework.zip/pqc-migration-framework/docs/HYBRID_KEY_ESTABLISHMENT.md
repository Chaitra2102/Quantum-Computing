# Hybrid Key Establishment Report (Phase 7)
# Post-Quantum Secure Communication & Migration Framework

**Date:** 2026-09-28  
**Phase:** 7 — Hybrid Key Establishment (Mode D)  
**Status:** COMPLETE  
**Standards Reference:** NIST SP 800-56C Rev. 2 / RFC 5869 / NIST FIPS 203 / NIST FIPS 186-5

---

## 1. Executive Summary

Phase 7 implements **Mode D (Hybrid Key Establishment)**, combining classical **ECDH on NIST P-384** with post-quantum **ML-KEM-768 (FIPS 203)** through an **HKDF-SHA-384** secret combiner.

Mode D is defined as:
$$\text{Hybrid (ECDH P-384 + ML-KEM-768)} + \text{HKDF-SHA-384} + \text{AES-256-GCM} + \text{Configurable Digital Signature}$$

All **371 framework tests** pass with 100% fidelity, validating composite key generation, dual shared secret derivation, deterministic HKDF combination, cross-mode isolation, tampering rejection, and protocol negotiation.

---

## 2. Motivation for Hybrid Key Establishment

During transition to post-quantum cryptography, hybrid key establishment serves as the primary risk-mitigation strategy recommended by NIST, BSI, ANSSI, and the IETF:
1. **Defense-in-Depth ("2-of-2 Security"):** Communications remain confidential as long as *either* the classical algorithm (ECDH) *or* the post-quantum algorithm (ML-KEM) remains unbroken.
2. **Hedge Against Cryptanalytic Uncertainty:** While lattice problems (M-LWE) have undergone extensive cryptanalysis during the NIST PQC standardization process, hybrid schemes protect against unexpected algebraic shortcuts without sacrificing established classical assurance.
3. **Compliance Bridge:** Allows systems to satisfy current FIPS / Common Criteria requirements (which mandate classical algorithms) while providing forward secrecy against "Store Now, Decrypt Later" (SNDL) quantum attacks.

---

## 3. Architecture & Primitives Breakdown

### Standards vs. Project Constructions

| Component | Standard / Specification | Origin / Status |
|---|---|---|
| **Classical Component** | NIST SP 800-56A / SEC 2 (P-384 / secp384r1) | Standardized Primitive |
| **Post-Quantum Component** | NIST FIPS 203 (ML-KEM-768) | Standardized Primitive |
| **Key Derivation Function** | RFC 5869 / FIPS 180-4 (HKDF-SHA-384) | Standardized Primitive |
| **Symmetric Authenticated Cipher** | NIST SP 800-38D (AES-256-GCM) | Standardized Primitive |
| **Hybrid Secret Combiner** | Project-Level HKDF Dual-Secret Composition | Framework Construction |

---

## 4. Hybrid Secret Combiner Specification

The `HybridSecretCombiner` (`src/providers/hybrid/hybrid_combiner.py`) deterministically merges the independently derived classical and post-quantum shared secrets:

```
+--------------------------+       +----------------------------+
|    ECDH Shared Secret    |       |    ML-KEM Shared Secret    |
|   (ecdh_ss - 48 bytes)   |       |   (mlkem_ss - 32 bytes)    |
+--------------------------+       +----------------------------+
             │                                    │
             └──────────────────┬─────────────────┘
                                ▼
         IKM = ecdh_shared_secret || mlkem_shared_secret (80 bytes)
                                │
                                ▼
           HKDF-Extract(salt=None, IKM) -> PRK (48 bytes)
                                │
                                ▼
     HKDF-Expand(PRK, info=b"pqcf-v1-hybrid-ecdh-mlkem-shared-secret", L=48)
                                │
                                ▼
                   Combined Hybrid Shared Secret
                             (48 bytes)
```

### Exact Parameters:
- **Concatenation Order:** `ecdh_shared_secret || mlkem_shared_secret` (Classical first, PQC second).
- **Hash Function:** `SHA-384` (providing 192-bit collision resistance matching P-384 and ML-KEM-768).
- **Salt:** `None` (standard HKDF extraction with zero-filled hash_len buffer per RFC 5869 § 2.2).
- **Domain Separation Context:** `b"pqcf-v1-hybrid-ecdh-mlkem-shared-secret"`.
- **Output Length:** `48 bytes` (384 bits), which subsequently feeds the framework session key derivation pipeline.

---

## 5. End-to-End Workflow in Mode D

```
SENDER (Alice)                                                    RECEIVER (Bob)
=============                                                     ==============
1. Receives Bob's HybridPublicKey
   [ecdh_pk (97 B) + mlkem_pk (1184 B)]
2. Ephemeral Key Exchange:
   ├── Generate Ephemeral ECDH keypair (eph_sk, eph_pk)
   └── ecdh_ss = ECDH(eph_sk, Bob.ecdh_pk)
3. ML-KEM Encapsulation:
   └── (mlkem_ss, mlkem_ct) = ML-KEM-Enc(Bob.mlkem_pk)
4. Combine Secrets:
   └── hybrid_ss = HKDF-SHA-384(ecdh_ss || mlkem_ss)
5. Session Key Derivation:
   └── aes_key = HKDF-SHA-384(hybrid_ss, info=b"pqcf-v1-aes256-session-key")
6. Encrypt & Sign:
   ├── ciphertext, tag = AES-256-GCM(aes_key, nonce, plaintext, aad)
   └── sig = Sign(Alice.sig_sk, ciphertext || nonce)
7. Package SecureMessage:
   ├── algorithm_id = "HYBRID_ECDH_MLKEM_AES256_GCM"
   ├── ke_ciphertext = [eph_pk (97 B) || mlkem_ct (1088 B)]
   └── [ciphertext, nonce, sig, sender_pubkeys]
                                   ──────────────────────────►
                                                                  8. Verify Signature:
                                                                     Verify(Alice.sig_pk, ciphertext || nonce, sig)
                                                                  9. Recover Shared Secrets:
                                                                     ├── ecdh_ss = ECDH(Bob.ecdh_sk, eph_pk)
                                                                     └── mlkem_ss = ML-KEM-Dec(Bob.mlkem_sk, mlkem_ct)
                                                                 10. Combine Secrets:
                                                                     └── hybrid_ss = HKDF-SHA-384(ecdh_ss || mlkem_ss)
                                                                 11. Session Key Derivation:
                                                                     └── aes_key = HKDF-SHA-384(hybrid_ss)
                                                                 12. Authenticated Decryption:
                                                                     └── plaintext = AES-256-GCM-Decrypt(aes_key)
```

---

## 6. Signature Strategies in Mode D & Canonical Suite Identifiers (AD-13 & Corrective Patch)

Mode D supports three explicit digital signature strategies via `ModeFactory.build(Mode.D, sig_provider_type=...)`, each deterministically bound to a canonical composite cryptographic suite identifier (`algorithm_id`):

| Signature Strategy | Parameter Set | Canonical Suite Identifier (`algorithm_id`) | Provider Implementation |
|---|---|---|---|
| **ML-DSA-65** (Default) | FIPS 204 Category 3 | `HYBRID_ECDH_MLKEM_MLDSA_AES256_GCM` | `MLDSAProvider` (`cryptography` 48.0.0) |
| **SLH-DSA-SHAKE-128f** | FIPS 205 Category 1 | `HYBRID_ECDH_MLKEM_SLHDSA_AES256_GCM` | `SLHDSAProvider` (`slh-dsa` 0.2.5) |
| **ECDSA P-384** | FIPS 186-5 / SEC 2 | `HYBRID_ECDH_MLKEM_ECDSA_AES256_GCM` | `ECDSAProvider` (`cryptography` 48.0.0) |

*Note on backward compatibility:* The legacy string identifier `HYBRID_ECDH_MLKEM_AES256_GCM` is retained as an alias for `HYBRID_ECDH_MLKEM_MLDSA_AES256_GCM`.

### Strict Suite Binding & Verification
- `CryptoConfig` enforces compile/build-time validation: instantiating a configuration with a mismatched `algorithm_id` and `SignatureProvider` raises `ConfigurationError`.
- `SecureCommunicator.receive()` strictly verifies that the wire message `algorithm_id` matches the receiver configuration, raising `ModeMismatchError` on cross-signature or cross-mode mismatch.
- Wire-level tampering of `algorithm_id` or cryptographic payloads triggers immediate rejection without decrypting.

---

## 7. Security Properties Verified by Unit & Integration Tests

1. **ECDH Dependency:** Altering 1 bit of `ecdh_ss` alters the derived hybrid key; decapsulation fails.
2. **ML-KEM Dependency:** Altering 1 bit of `mlkem_ss` alters the derived hybrid key; decapsulation fails.
3. **Ordering Invariance:** Swapping concatenation order ($mlkem\_ss \parallel ecdh\_ss$) produces a non-matching output.
4. **Context Isolation:** Using a different HKDF info string produces an orthogonal key.
5. **No Secret Material Exposure:** Raw `ecdh_ss`, `mlkem_ss`, `hybrid_ss`, and `aes_key` are never serialized, transmitted, or logged.
6. **Cross-Mode Rejection:** Mode D messages sent to Mode A, B, or C receivers are immediately rejected with `ModeMismatchError`.
7. **Cross-Signature Rejection:** Mode D (ML-DSA) messages sent to Mode D (ECDSA) or Mode D (SLH-DSA) receivers are immediately rejected with `ModeMismatchError`.
8. **Metadata Tampering Rejection:** Modifying `algorithm_id` on wire messages triggers `ModeMismatchError` and signature invalidation.

---

## 8. Test Execution Summary

| Test Suite | File Path | Tests | Result | Duration |
|---|---|---|---|---|
| **Hybrid Combiner Unit** | `tests/unit/hybrid/test_hybrid_combiner.py` | 10 | **10 PASSED** | ~0.08 s |
| **Hybrid Provider Unit** | `tests/unit/hybrid/test_hybrid_ke_provider.py` | 9 | **9 PASSED** | ~0.35 s |
| **Mode D Integration & Isolation** | `tests/integration/test_hybrid_mode.py` | 14 | **14 PASSED** | ~4.2 s |
| **Crypto-Agility & Validation** | `tests/unit/config/test_crypto_config.py` | 18 | **18 PASSED** | ~0.15 s |
| **Full Regression Suite** | `tests/` | **377** | **377 PASSED** | **13.23 s** |

---

## 9. Limitations & Forward Roadmap

- **Benchmarking Deferred:** Multi-trial performance comparisons across Modes A, B, C, and D are scheduled for **Phase 10**.
- **Migration Engine:** Automated migration orchestration and stage transitions will be implemented in **Phase 12**.
- **Next Step:** Proceed to **Phase 8: High-Level Secure Communication Layer & CLI**.
