# CLI Tooling & Operational Usage Guide (Phase 8)
# Post-Quantum Secure Communication & Migration Framework

**Version:** 1.0.0  
**Phase:** 8 — High-Level Secure Communication Pipeline & CLI Tooling  
**Status:** COMPLETE & VERIFIED  

---

## 1. Overview & Setup Assumptions

Phase 8 provides an operational command-line interface (`main_cli.py`) and high-level session abstraction (`SecureSession`) around the verified cryptographic framework.

### Environment & Dependency Requirements
- **Python:** 3.14.3 (64-bit AMD64)
- **Dependencies:**
  - `cryptography` (48.0.0) — Classical primitives (ECDH, ECDSA, AES-GCM, HKDF) + FIPS 203 (ML-KEM) + FIPS 204 (ML-DSA)
  - `slh-dsa` (0.2.5) — FIPS 205 (SLH-DSA)
  - `pytest` (8.x) — Test runner

No compilation or external C++ build toolchains are required.

---

## 2. CLI Entry Point

The CLI is invoked via Python module execution or direct script execution:

```bash
python -m src.main_cli [OPTIONS]
```

---

## 3. Supported Commands and Flags

| Option | Short Flag | Description | Default |
|---|---|---|---|
| `--mode` | `-m` | Cryptographic mode selection: `A`, `B`, `C`, or `D`. | `None` |
| `--signature` | `-s` | Digital signature strategy for Mode D: `mldsa`, `slhdsa`, `ecdsa`. | `mldsa` (Mode D default) |
| `--message` | `-msg` | Plaintext payload to encrypt, sign, transmit, and decrypt. | `None` |
| `--inspect` | `-i` | Display safe cryptographic configuration and transmission metrics. | `False` |
| `--list-modes` | `-l` | List all supported modes and canonical suite identifiers. | `False` |
| `--json` | `-j` | Output results in structured JSON format without secrets. | `False` |
| `--aad` | | Optional Additional Authenticated Data for AES-256-GCM. | `None` |
| `--kem-param` | | Optional KEM parameter set override (e.g., `ML-KEM-1024`). | `ML-KEM-768` |
| `--sig-param` | | Optional signature parameter set override (e.g., `ML-DSA-87`). | Standard default per sig |
| `--debug` | | Enable debug logging and internal exception tracebacks. | `False` |
| `--help` | `-h` | Display usage and options help menu. | |

---

## 4. Mode Discovery (`--list-modes`)

Inspect all supported cryptographic modes and canonical composite suite identifiers:

```bash
python -m src.main_cli --list-modes
```

### JSON Format:
```bash
python -m src.main_cli --list-modes --json
```

---

## 5. Mode Selection & Workflow Examples

### Mode A — Classical Baseline (ECDH P-384 + ECDSA P-384 + AES-256-GCM + HKDF-SHA-384)
```bash
python -m src.main_cli --mode A --message "Confidential classical transmission"
```

### Mode B — Full Post-Quantum Lattice (ML-KEM-768 + ML-DSA-65 + AES-256-GCM + HKDF-SHA-384)
```bash
python -m src.main_cli --mode B --message "Quantum-resistant lattice payload"
```

### Mode C — Post-Quantum Hash-Based (ML-KEM-768 + SLH-DSA-SHAKE-128f + AES-256-GCM + HKDF-SHA-384)
```bash
python -m src.main_cli --mode C --message "State-independent hash-based authentication"
```

### Mode D — Hybrid Key Establishment (ECDH P-384 + ML-KEM-768 + Configurable Signature)
1. **With Primary Post-Quantum Signature (ML-DSA-65 — Default):**
   ```bash
   python -m src.main_cli --mode D --message "Hybrid defense-in-depth payload"
   ```
2. **With Hash-Based Post-Quantum Signature (SLH-DSA-SHAKE-128f):**
   ```bash
   python -m src.main_cli --mode D --signature slhdsa --message "Hybrid with hash-based signature"
   ```
3. **With Classical Signature (ECDSA P-384 — Transitional Migration):**
   ```bash
   python -m src.main_cli --mode D --signature ecdsa --message "Transitional hybrid migration payload"
   ```

---

## 6. Safe Inspection Mode (`--inspect`)

To inspect cryptographic metadata and provider mappings without performing an exchange:

```bash
python -m src.main_cli --mode D --signature slhdsa --inspect
```

Expected Terminal Output:
```text
==================================================
Cryptographic Configuration Inspection
==================================================
Session ID:         e654cb7294fee49813fc0d0adbfa914c
Mode:               Mode D
Algorithm ID:       HYBRID_ECDH_MLKEM_SLHDSA_AES256_GCM
Key Establishment:  Hybrid (ECDH P-384 + ML-KEM-768)
Signature:          SLH-DSA-SHAKE-128f
Encryption:         AES-256-GCM
KDF:                HKDF-SHA-384
KE Provider:        HybridKEProvider
Sig Provider:       SLHDSAProvider
Status:             INITIALIZED
==================================================
```

---

## 7. Structured JSON Output (`--json`)

Adding `--json` provides schema-stable, machine-readable output suitable for automated testing, pipeline scripting, and migration telemetry:

```bash
python -m src.main_cli --mode B --message "Automated pipeline test" --json
```

Output Schema:
```json
{
  "status": "SUCCESS",
  "session_id": "5209e5df8f2f77d031f93f2c06e5865f",
  "mode": "B",
  "algorithm_id": "PQC_MLKEM_MLDSA_AES256_GCM",
  "recovered_plaintext": "Automated pipeline test",
  "plaintext_bytes_length": 23,
  "key_establishment": "ML-KEM-768",
  "signature": "ML-DSA-65",
  "encryption": "AES-256-GCM",
  "kdf": "HKDF-SHA-384",
  "message_inspection": {
    "protocol_version": "pqcf-v1",
    "algorithm_id": "PQC_MLKEM_MLDSA_AES256_GCM",
    "ciphertext_bytes": 39,
    "nonce_bytes": 12,
    "signature_bytes": 3309,
    "ke_ciphertext_bytes": 1088,
    "sender_ke_public_key_bytes": 1184,
    "sender_sig_public_key_bytes": 1952,
    "message_metadata": {
      "session_id": "5209e5df8f2f77d031f93f2c06e5865f"
    }
  },
  "metadata": {
    "session_id": "5209e5df8f2f77d031f93f2c06e5865f"
  }
}
```

---

## 8. High-Level Python API (`SecureSession`)

Application code and subsequent test/benchmark phases interact with the high-level `SecureSession` class:

```python
from src.communication.session import SecureSession
from src.config.modes import Mode

# 1. Create a session for the target mode
session = SecureSession.create(Mode.D, sig_provider_type="mldsa")

# 2. Run end-to-end communication exchange
result = session.run_exchange("Confidential message payload", aad=b"routing-header")

# 3. Access verified, safe result attributes
print("Status:", result.status)
print("Algorithm ID:", result.algorithm_id)
print("Decrypted Message:", result.plaintext_str)
print("Transmission Metrics:", result.inspect_message())
```

---

## 9. Security Restrictions & Information Invariants

1. **Zero Secret Leakage:**
   - Private keys (`sk`), raw shared secrets (`ss`), and derived symmetric keys (`aes_key`) are never printed to `stdout`/`stderr` or serialized into JSON.
   - String representations (`__repr__`) redact secret material.
2. **Deterministic Mode & Signature Binding:**
   - The CLI rejects invalid modes and incompatible signature strategies with clear error codes.
3. **Defense-in-Depth:**
   - The CLI does not implement custom cryptographic algorithms; all operations execute through `SecureCommunicator`, `ModeFactory`, and audited provider backends.

---

## 10. Error Handling & Exit Codes

| Exit Code | Condition | Description |
|---|---|---|
| `0` | Success | Operation completed successfully. |
| `1` | Cryptographic / Framework Error | Validation failure, signature verification error, mode mismatch, or authentication failure. |
| `2` | Argument Parsing Error | Missing required options or invalid syntax. |
