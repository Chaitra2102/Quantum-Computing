# Interactive Dashboard & Visualization Documentation

**Project:** Post-Quantum Secure Communication & Migration Framework  
**Document:** `docs/DASHBOARD.md`  
**Phase:** Phase 13 — Interactive Dashboard & Visualization  
**Status:** COMPLETE AND FROZEN  

---

## 1. Purpose

The interactive dashboard serves as the central research presentation and visualization layer for the Post-Quantum Secure Communication & Migration Framework. It dynamically ingests machine-readable experimental datasets generated during Phases 10 (Benchmarking), 11 (Comparative Analysis), and 12 (Migration Experimentation), providing a transparent, interactive, and neutral interface for evaluating:
- Cryptographic operational latency (key generation, KEX encapsulation/decapsulation, signing, verification, and symmetric encryption).
- Serialized wire communication overhead and framing expansion.
- Staged post-quantum migration transition paths and quantitative deltas.
- Pairwise cross-suite protocol compatibility and isolation matrices.
- Adversarial tamper rejection and security invariant preservation.

---

## 2. Technology Stack & Architecture

- **Web Framework:** [Streamlit](https://streamlit.io/) 1.64.0 (Python-based local dashboard)
- **Visualization Engine:** [Plotly](https://plotly.com/python/) 7.1.0 (Interactive SVG/WebGL charts with precise hover tooltips)
- **Data Manipulation:** [Pandas](https://pandas.pydata.org/) 3.0.1
- **Platform Compatibility:** Windows 11 (AMD64) / Python 3.14.3

### Dashboard Module Architecture
```
src/dashboard/
├── __init__.py           # Package exports for data loaders
├── app.py                # Main Streamlit application and tab navigation
├── data_loader.py        # Centralized dataset loading and schema validation
├── charts.py             # Interactive Plotly chart builders
├── metrics.py            # Summary tables, research questions, and security models
└── components.py         # Reusable Streamlit UI components and limitation banners
```

---

## 3. Installation & Launch Command

### Prerequisites
Ensure the project virtual environment has the required dependencies installed:
```bash
pip install streamlit plotly pandas
```

### Launching the Dashboard
From the project workspace root, execute:
```bash
streamlit run src/dashboard/app.py
```
The application will automatically launch in your default web browser at `http://localhost:8501`.

---

## 4. Dashboard Sections & Tabbed Navigation

The dashboard organizes research findings into nine dedicated tabs:

### Tab 1: Overview
- High-level factual framework metrics: 4 operational modes (6 concrete configurations), 5 migration scenarios, 36 pairwise compatibility evaluations, and 546 passed regression tests.
- High-level summaries of Mode A (Classical), Mode B (Pure PQC Lattice), Mode C (Pure PQC Hash-Based), and Mode D (Hybrid Dual KEX).
- Reiteration of the **Neutral Presentation Principle** (no ranking, scoring, or algorithm recommendations).

### Tab 2: Cryptographic Modes
- Comprehensive comparison table listing algorithm suite identifiers, key establishment primitives, digital signature schemes, symmetric ciphers, public-key sizes, signature sizes, and provider backends.
- Expandable technical explanation of the **Multi-Provider Architecture (AD-17)**.

### Tab 3: Performance
- **Key Establishment:** Key generation latency (Mean $\pm$ StdDev) and operational latencies (ML-KEM encap/decap vs ECDH derivation vs Hybrid dual-KEX).
- **Digital Signatures:** Distinct, non-misleading visual comparisons separating microsecond-scale implementations (`cryptography` 48.0.0 C/Rust) from millisecond-scale pure-Python implementations (`slh-dsa` 0.2.5).
- **End-to-End Communication Latency:** Detailed send, receive, and round-trip timings for 1 KiB payloads.

### Tab 4: Communication Overhead
- Grouped bar comparisons of Raw Cryptographic Artifacts vs Total Serialized Wire Size.
- Percentage wire overhead relative to Mode A baseline (2,084 B).
- Configuration-aware serialization expansion percentages (+51.78% Mode A, +36.20% Mode B, +34.54% Mode C, +36.23% Mode D ML-DSA, +40.12% Mode D ECDSA).

### Tab 5: Migration Analysis
- Visual overview of the five migration experiments (`EXP_1_PRIMARY_MLDSA`, `EXP_2_ALTERNATIVE_SLHDSA`, `EXP_3_HYBRID_ECDSA`, `EXP_4_ROLLBACK_MLDSA`, `EXP_5_PURE_PQC_TRANSITION`).
- Interactive transition latency delta (%) and wire size delta (Bytes) charts.
- Summary tables reflecting 100% functional continuity across all stages.

### Tab 6: Compatibility Matrix
- Interactive $6 \times 6$ pairwise compatibility heatmap (36 interactions).
- Visual confirmation of 6 accepted matching interactions (**ACCEPT**) and 30 rejected mismatched interactions (**REJECT**), demonstrating 100% cross-suite protocol isolation.

### Tab 7: Security Validation
- Structured adversarial tamper testing table summarizing ciphertext, nonce, signature, algorithm ID, truncation, and malformed message mutations.
- Confirmation of the strict **verify-then-decrypt** discipline across all modes.
- Prominent **Replay Limitation Notice**.

### Tab 8: Research Findings
- Structured, factual synthesis of research questions **RQ1 through RQ7** derived from Phase 11.
- Clear distinction between experimental evidence and implementation limitations.

### Tab 9: System / Dataset Info
- Execution environment specifications (Windows 11 AMD64, Intel Core 7 150U, Python 3.14.3, PyCA cryptography 48.0.0, slh-dsa 0.2.5).
- Real-time dataset loading and validation status table.
- Transparency notice confirming dynamic data ingestion without synthetic fabrication.

---

## 5. Authoritative Data Sources

The dashboard dynamically reads the following machine-readable datasets:
- **Phase 10 Benchmarking:**
  - `results/benchmarks/benchmark_summary.json`
  - `results/benchmarks/benchmark_sizes.json`
- **Phase 12 Migration:**
  - `results/migration/migration_results.json`
  - `results/migration/migration_history.json`
  - `results/migration/migration_compatibility.csv`
  - `results/migration/migration_deltas.csv`

---

## 6. Security & Secret Exposure Controls

> [!IMPORTANT]
> The dashboard strictly adheres to zero-secret exposure policies. Under no circumstances are private keys, intermediate shared secrets, AES session keys, or HKDF intermediate material parsed, rendered, or exposed in the UI.

---

## 7. Methodological & Implementation Limitations

### Multi-Provider Environment (AD-17)
Performance measurements reflect the software provider environment of this testbed:
- `cryptography` 48.0.0 (C/Rust): ECDH, ECDSA, ML-KEM, ML-DSA.
- `slh-dsa` 0.2.5 (Pure Python): SLH-DSA-SHAKE-128f.
Observed latency differences should not be attributed solely to the underlying mathematical algorithms.

### Replay Limitation
The framework protocol is stateless. Replay detection, sliding-window caches, and sequence tracking are outside the current experimental scope and remain identified for future transport-layer hardening.

### No-Ranking Principle
The dashboard is an empirical analysis interface, not a decision or ranking engine. It does not calculate arbitrary composite scores, assign "winner" badges, or declare an "optimal" algorithm.

---

## 8. Verification & Testing

Unit tests for data loaders, schema validation, chart generation, and secret non-exposure are located in `tests/dashboard/`:
- `tests/dashboard/test_data_loader.py` (8 tests)
- `tests/dashboard/test_dashboard_data.py` (12 tests)

Run dashboard-specific tests:
```bash
pytest tests/dashboard/ -v
```

Run complete project regression suite:
```bash
pytest -q
```
All 566 tests pass with zero failures.
