# CLASSICAL_BASELINE.md
# Post-Quantum Secure Communication & Migration Framework
## Phase 2 — Classical Cryptographic Baseline

**Version:** 0.3.0
**Phase Status:** COMPLETE
**Date:** 2026-09-28

---

## 1. Overview

Phase 2 implements the complete classical cryptographic baseline (Mode A).
This is the reference implementation against which ML-KEM, ML-DSA, SLH-DSA,
and Hybrid ECDH+ML-KEM will be compared in later phases.

**Algorithm configuration identifier:** `CLASSICAL_ECDH_ECDSA_AES256_GCM`

---

## 2. Algorithm Decisions (Resolved in Phase 2)

### AD-09 — Curve Selection: P-384 (RESOLVED)

**Decision:** NIST P-384 (secp384r1)

**Rationale:**
- 192-bit classical security level
- Matches ML-KEM-768 security level (~192-bit equivalent) for a fair comparison
- NIST-recommended; widely supported in `cryptography` (PyCA)
- P-384 keys are the right size for the comparison benchmark

### AD-06 (sub-decision) — HKDF Hash: SHA-384 (RESOLVED)

**Decision:** SHA-384

**Rationale:**
- Matches P-384's 192-bit security level per NIST guidelines
- Using SHA-256 with P-384 would truncate to 128-bit security (mismatched)

---

## 3. Component Architecture

### 3.1 Provider Implementations

| Provider | File | Algorithm | Library |
|----------|------|-----------|---------|
| `ECDHProvider` | `src/providers/classical/ecdh_provider.py` | ECDH P-384 | cryptography (PyCA) |
| `ECDSAProvider` | `src/providers/classical/ecdsa_provider.py` | ECDSA P-384 + SHA-384 | cryptography (PyCA) |
| `HKDFDerivationProvider` | `src/providers/symmetric/hkdf_provider.py` | HKDF-SHA-384 | cryptography (PyCA) |
| `AESGCM256Provider` | `src/providers/symmetric/aesgcm_provider.py` | AES-256-GCM | cryptography (PyCA) |

### 3.2 Abstract Interfaces

All providers implement abstract base classes defined in `src/providers/base.py`:

- `KeyExchangeProvider` — key establishment (DH path: `exchange()`; KEM path: stubs)
- `SignatureProvider` — sign/verify + key export/import
- `EncryptionProvider` — encrypt/decrypt with AAD support
- `KeyDerivationProvider` — HKDF abstraction

### 3.3 Configuration Layer

- `src/config/modes.py` — `Mode` enum (A/B/C/D), algorithm identifier constants
- `src/config/crypto_config.py` — `CryptoConfig` dataclass, `ModeFactory`

**Classical identifier (Phase 2 requirement):**
```python
CLASSICAL_ECDH_ECDSA_AES256_GCM = "CLASSICAL_ECDH_ECDSA_AES256_GCM"
```

### 3.4 Communication Layer

- `src/communication/message_bundle.py` — `SecureMessage` (algorithm-agnostic wire format)
- `src/communication/secure_communicator.py` — `SecureCommunicator` (mode-agnostic orchestrator)

---

## 4. Key Establishment Flow (ECDH)

```
Alice                                     Bob
──────                                    ───
ECDHProvider.generate_keypair()           ECDHProvider.generate_keypair()
→ alice_ke_kp                             → bob_ke_kp

Alice sends: bob_ke_kp.public_key (out-of-band for DH setup)
             alice_ke_kp.public_key (in SecureMessage)

Alice: exchange(alice_ke_private, bob_ke_public)  → shared_secret (48 bytes P-384)
Bob:   exchange(bob_ke_private, alice_ke_public)  → shared_secret (identical)
```

**Security notes:**
- Raw ECDH output (48 bytes) is NEVER used directly as an AES key.
- It is always passed through `HKDFDerivationProvider.derive()` first.
- Private keys are never serialised, logged, or included in wire messages.

---

## 5. Key Derivation Flow (HKDF)

```
shared_secret (48 bytes, from ECDH P-384)
        │
        ▼
HKDFDerivationProvider.derive(
    input_keying_material = shared_secret,
    length = 32,          ← AES-256 requires 32 bytes
    salt   = None,        ← optional; improves security with low-entropy IKM
    info   = b"pqcf-v1-aes256-session-key"   ← context label
)
        │
        ▼
aes_key (32 bytes / 256 bits)
```

**Info label design:**
The fixed info label `b"pqcf-v1-aes256-session-key"` ties derived keys to
this framework version and key purpose. In the future hybrid mode (Phase 6),
different info labels will allow independent key derivation from the combined
(ECDH || ML-KEM) shared secret.

---

## 6. Encryption / Decryption Flow (AES-256-GCM)

### Encryption (sender)

```
aes_key (32 bytes)  +  plaintext  [+  aad (optional)]
        │
        ▼
os.urandom(12) → nonce   ← fresh per message (NEVER reused)
        │
        ▼
AESGCM(key).encrypt(nonce, plaintext, aad)
        │
        ▼
EncryptedPayload(
    ciphertext = encrypted_bytes || 16-byte_GCM_auth_tag,
    nonce      = 12-byte nonce
)
```

### Decryption (receiver)

```
aes_key + EncryptedPayload + aad (must match)
        │
        ▼
AESGCM(key).decrypt(nonce, ciphertext, aad)
        │
        ├── authentication passes → plaintext returned
        └── authentication fails  → AuthenticationFailureError raised
                                     (NO plaintext returned)
```

**Security invariants:**
- `os.urandom(12)` generates a fresh nonce per call; nonce reuse is impossible.
- The 16-byte GCM authentication tag is embedded in the ciphertext by the library.
- `AuthenticationFailureError` is raised for ANY authentication mismatch.
- Unauthenticated plaintext is NEVER returned.

---

## 7. Signature / Verification Flow (ECDSA)

### Signing (sender)

```
ECDSA signing key pair: (private_key, public_key) on P-384

signed_data = ciphertext || nonce   ← binds signature to encrypted content + nonce

ECDSAProvider.sign(private_key, signed_data)
        │
        ▼
DER-encoded ECDSA signature bytes
```

### Verification (receiver)

```
sender_public_key  +  signed_data  +  signature
        │
        ▼
ECDSAProvider.verify(public_key, signed_data, signature)
        │
        ├── returns True  → proceed to decryption
        └── returns False → raise SignatureVerificationError (message REJECTED)
```

**Security design:**
- Verification happens BEFORE decryption (verify-then-decrypt ordering).
- `verify()` returns `bool` for incorrect signatures (not raises).
- `InvalidSignatureError` is raised only for structurally malformed signatures.
- `SignatureVerificationError` is raised by `SecureCommunicator.receive()` when `verify()` returns False.

---

## 8. Complete Secure Message Workflow (Mode A)

Per ARCHITECTURE.md § 4 (steps [1]–[10]):

### Sender Side

```
[1] Alice generates KE + signing key pairs
[2] ECDH exchange with Bob's public key → shared_secret (48 bytes)
[3] HKDF(shared_secret) → aes_key (32 bytes)
[4] AES-256-GCM encrypt(aes_key, plaintext) → EncryptedPayload(ciphertext, nonce)
[5] ECDSA sign(ciphertext || nonce) → signature
[6] Assemble SecureMessage:
      { protocol_version, algorithm_id,
        sender_ke_public_key, sender_sig_public_key,
        ciphertext, nonce, signature,
        ke_ciphertext=None }    ← None for DH path (ECDH)
```

### Receiver Side

```
[7]  Import sender's sig public key; VERIFY signature over (ciphertext || nonce)
         REJECT (SignatureVerificationError) if False
[8]  Import sender's KE public key; ECDH exchange → shared_secret
[9]  HKDF(shared_secret) → aes_key (same derivation parameters as sender)
[10] AES-256-GCM decrypt(aes_key, ciphertext, nonce)
         REJECT (AuthenticationFailureError) if auth tag fails
         RETURN plaintext if all verifications pass
```

---

## 9. Message Structure

`SecureMessage` (from `src/communication/message_bundle.py`):

| Field | Type | Description |
|-------|------|-------------|
| `protocol_version` | `str` | `"pqcf-v1"` |
| `algorithm_id` | `str` | `"CLASSICAL_ECDH_ECDSA_AES256_GCM"` |
| `sender_ke_public_key` | `bytes` | P-384 uncompressed point (97 bytes) |
| `sender_sig_public_key` | `bytes` | DER SubjectPublicKeyInfo |
| `ciphertext` | `bytes` | AES-GCM ciphertext + 16-byte auth tag |
| `nonce` | `bytes` | 12-byte GCM nonce |
| `signature` | `bytes` | DER-encoded ECDSA signature |
| `ke_ciphertext` | `None` | KEM ciphertext (DH path → None; PQC → bytes) |
| `metadata` | `dict` | Optional non-sensitive metadata |

**Security invariants:**
- No private keys.
- No shared secrets.
- No AES keys.
- `ke_ciphertext` is `None` for ECDH (DH path). It will be populated for ML-KEM in Phase 3.

**Serialisation:** Base64-encoded fields for JSON compatibility. `to_json()` / `from_json()` / `to_dict()` / `from_dict()` provided.

---

## 10. Tampering Behaviour

| Tampering Type | Detection Mechanism | Exception Raised |
|---------------|---------------------|-----------------|
| Modified ciphertext | Signature check (ciphertext is part of signed data) fires before decryption | `SignatureVerificationError` |
| Modified authentication tag | Signature check fires first; AES-GCM tag check would also catch it | `SignatureVerificationError` |
| Modified signature | ECDSA verification fails | `SignatureVerificationError` |
| Modified signed data (ciphertext+nonce) | ECDSA verification fails | `SignatureVerificationError` |
| Wrong sender public key in message | ECDSA verification fails (real signature ≠ fake key) | `SignatureVerificationError` |
| Wrong decryption key (different shared secret) | AES-GCM authentication tag mismatch | `AuthenticationFailureError` |
| Modified nonce | Signature check fires (nonce is part of signed data) | `SignatureVerificationError` |
| Modified AAD | AES-GCM authentication tag mismatch | `AuthenticationFailureError` |

**Key security property: verify-then-decrypt ordering**

The signature covers `ciphertext || nonce`. Any modification to either field
invalidates the signature, which is detected at step [7] (signature verification)
**before** step [10] (AES-GCM decryption). This means:
- Tampered ciphertext raises `SignatureVerificationError` (not `AuthenticationFailureError`)
  in the workflow layer, because the signature check detects it first.
- AES-GCM's own authentication (`AuthenticationFailureError`) serves as a second
  line of defence for scenarios where the ciphertext is modified without
  invalidating the signature (e.g., in the unit-level `AESGCM256Provider.decrypt()` tests).

---

## 11. Error Handling

| Exception | Module | Trigger |
|-----------|--------|---------|
| `InvalidKeyError` | `src.exceptions` | None/wrong-type/wrong-curve key |
| `InvalidSignatureError` | `src.exceptions` | Malformed (unparseable) signature bytes |
| `SignatureVerificationError` | `src.exceptions` | Signature does not verify (tampering detected) |
| `AuthenticationFailureError` | `src.exceptions` | AES-GCM tag mismatch (ciphertext tampered or wrong key) |
| `MalformedMessageError` | `src.exceptions` | Missing fields in SecureMessage |
| `UnsupportedAlgorithmError` | `src.exceptions` | Requested mode not yet implemented |
| `SerializationError` | `src.exceptions` | JSON serialisation/deserialisation failure |

**Security policy:** No exception message exposes private keys, shared secrets, or AES keys.

---

## 12. Test Strategy

### Unit Tests (`tests/unit/classical/`)

| File | Provider | Tests |
|------|----------|-------|
| `test_ecdh.py` | `ECDHProvider` | Key generation, agreement, secret equality, serialisation, invalid inputs |
| `test_ecdsa.py` | `ECDSAProvider` | Key generation, sign/verify, tampering (returns False), serialisation, invalid inputs |
| `test_hkdf.py` | `HKDFDerivationProvider` | Determinism, sensitivity (IKM/salt/info), output length, invalid inputs |
| `test_aes_gcm.py` | `AESGCM256Provider` | Round-trip, nonce uniqueness, auth failure on ALL modifications, invalid lengths |

### Integration Tests (`tests/integration/`)

| File | Scope |
|------|-------|
| `test_classical_workflow.py` | Complete Mode A workflow; SecureMessage structure; JSON round-trip + decryption |

### Security / Tampering Tests (`tests/security/`)

| File | Tests |
|------|-------|
| `test_tampering.py` | Modified ciphertext, modified signature, modified signed data, wrong verification key, control (happy path) |

**Total: 143 tests, all passing.**

---

## 13. Logging Security

**Allowed in logs:**
- Operation type (e.g., "key agreement succeeded")
- Algorithm/configuration name
- Success/failure
- Byte counts (lengths, not values)
- DEBUG messages for development

**Never logged:**
- Private keys
- Shared secrets (raw ECDH output)
- AES keys (derived)
- Plaintext content
- Nonce values
- Signature values (only lengths)

---

## 14. Crypto-Agility Readiness

Phase 2 establishes the provider pattern that makes Phase 3+ substitution straightforward:

```
SecureCommunicator
    │ depends only on:
    ├── KeyExchangeProvider  → Phase 3: replace ECDHProvider with MLKEMProvider
    ├── SignatureProvider    → Phase 4: replace ECDSAProvider with MLDSAProvider
    ├── EncryptionProvider   → Shared: AESGCM256Provider unchanged
    └── KeyDerivationProvider → Shared: HKDFDerivationProvider unchanged
```

`ModeFactory.build(Mode.B/C/D)` will instantiate PQC providers in their respective phases.
`SecureCommunicator` requires zero modification.

---

*End of CLASSICAL_BASELINE.md — Phase 2 | Version 0.3.0*
