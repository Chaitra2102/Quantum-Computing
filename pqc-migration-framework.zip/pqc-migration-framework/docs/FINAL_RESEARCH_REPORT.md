# POST-QUANTUM SECURE COMMUNICATION & MIGRATION FRAMEWORK
## Experimental Evaluation of Classical, Hybrid, and Post-Quantum Secure Communication Configurations

**Project:** Post-Quantum Secure Communication & Migration Framework  
**Document:** `docs/FINAL_RESEARCH_REPORT.md`  
**Phase:** Phase 14 — Final Research Synthesis & Project Archival  
**Status:** COMPLETE AND FROZEN  

---

## Abstract

The anticipated advent of cryptanalytically relevant quantum computers poses an existential threat to contemporary public-key cryptography, rendering widely deployed key-establishment and digital signature schemes vulnerable to Shor's algorithm. To mitigate "Harvest Now, Decrypt Later" (HNDL) attacks and prepare communication architectures for post-quantum standards, organizations must navigate complex trade-offs between computational performance, serialized wire overhead, protocol compatibility, and implementation provider dependencies.

This report presents an empirical, end-to-end evaluation of a modular **Post-Quantum Secure Communication & Migration Framework** developed on conventional computing hardware (Windows 11 AMD64 / Python 3.14.3). The framework implements and benchmarks four operational communication modes spanning classical cryptography (Mode A: ECDH P-384 + ECDSA P-384), pure post-quantum lattice cryptography (Mode B: ML-KEM-768 + ML-DSA-65), pure post-quantum hash-based cryptography (Mode C: ML-KEM-768 + SLH-DSA-SHAKE-128f), and dual-mechanism hybrid key establishment (Mode D: ECDH P-384 + ML-KEM-768 combined via HKDF-SHA-384 with configurable signature strategies).

Through controlled microbenchmarks (100 iterations, 20 warmup rounds), adversarial tamper injection (49 vectors across 11 mutation categories), staged migration experiments (5 transition scenarios), and a complete $6 \times 6$ pairwise compatibility matrix (36 interactions), this study quantitatively characterizes the computational and network costs of migration. Key findings demonstrate that: (1) ML-KEM-768 key encapsulation and decapsulation required substantially less execution time than ECDH P-384 shared-secret derivation under the tested provider environment; (2) ML-DSA-65 verification was 79.00% faster than ECDSA P-384 verification, but required a +1,526.7% larger public key (1,952 B vs 120 B) and a +3,081.7% larger signature (3,309 B vs 104 B); (3) Hybrid key establishment combines classical ECDH P-384 and post-quantum ML-KEM-768 key-establishment mechanisms, with a measured +2.33% (+272 B) incremental wire size over pure PQC Mode B and a measured HKDF combiner latency of 18.55 $\mu s$; (4) The verify-then-decrypt discipline strictly rejected 100% of tamper mutations; and (5) The crypto-agility layer achieved 100% functional continuity across all migration transitions without silent fallback.

> [!NOTE]
> This study is an experimental software evaluation conducted on conventional computing hardware. It does not execute physical quantum attacks, utilize quantum hardware, perform mathematical security proofs, or claim universal protocol security. Replay detection is outside the experimental scope of this stateless message protocol.

---

## 1. Introduction

### 1.1 Background
Modern secure communication protocols rely heavily on asymmetric cryptography based on the integer factorization problem (RSA) and discrete logarithm problem over elliptic curves (ECDH, ECDSA). In 1994, Peter Shor demonstrated that a sufficiently powerful quantum computer running Shor's algorithm can solve both mathematical problems in polynomial time. Consequently, NIST initiated a post-quantum cryptography (PQC) standardization process, finalizing FIPS 203 (ML-KEM), FIPS 204 (ML-DSA), and FIPS 205 (SLH-DSA) in August 2024.

### 1.2 Problem Statement
Transitioning enterprise communication protocols to PQC is not a trivial drop-in replacement. Post-quantum primitives exhibit fundamentally different performance profiles, non-deterministic execution distributions (e.g., rejection sampling in ML-DSA), and substantially larger cryptographic artifacts that risk IP packet fragmentation across standard MTUs. Furthermore, replacing classical algorithms abruptly introduces catastrophic risks if novel cryptanalytic vulnerabilities emerge in newly standardized lattice assumptions.

### 1.3 Motivation
Hybrid key establishment—combining classical and post-quantum mechanisms—is widely recognized as the most prudent migration strategy. However, empirical data is needed to quantify the exact computational latency, serialization framing overhead, and protocol isolation boundaries of hybrid and pure PQC configurations within agile software architectures.

### 1.4 Research Gap & Practical Problem
While theoretical complexity bounds for PQC primitives are documented, there is a lack of end-to-end, multi-provider software frameworks that experimentally evaluate classical, hybrid, and pure PQC communications under identical cryptographic framing, adversarial tampering, and staged migration workflows.

### 1.5 Project Objectives
1. Implement a provider-agnostic crypto-agility layer supporting classical, hybrid, and pure PQC suites.
2. Quantitatively measure microbenchmark latency and communication payload sizes under standardized experimental conditions.
3. Validate protocol robustness and the verify-then-decrypt discipline against controlled adversarial mutations.
4. Experimentally execute staged migration paths and measure quantitative transition deltas.
5. Provide an interactive, neutral research dashboard and reproducible archival package.

### 1.6 Central Research Question
*How do post-quantum and hybrid cryptographic mechanisms compare to classical standards in computational latency, communication wire overhead, protocol robustness, and migration feasibility within a crypto-agile communication pipeline?*

### 1.7 Supporting Research Questions (RQ1–RQ7)
- **RQ1:** How do key generation, encapsulation, and decapsulation of ML-KEM compare to ECDH P-384?
- **RQ2:** How do ML-DSA-65 signatures compare to classical ECDSA P-384 in execution performance and artifact sizes?
- **RQ3:** What are the computational and communication trade-offs of state-free hash-based SLH-DSA-SHAKE-128f?
- **RQ4:** What wire communication overhead is introduced by PQC artifact sizes and JSON/Base64 serialization?
- **RQ5:** What incremental performance and wire overhead is incurred by combining ECDH and ML-KEM in a hybrid construction?
- **RQ6:** How effectively does the framework maintain message integrity and reject adversarial tampering across modes?
- **RQ7:** Can the framework transition across classical, hybrid, and pure PQC configurations seamlessly using crypto-agility abstractions?

### 1.8 Scope Boundaries
- **In Scope:** Software implementation, microbenchmarking, tamper mutation testing, staged migration modeling, pairwise compatibility matrix, interactive dashboard, and reproducible packaging.
- **Out of Scope:** Physical quantum computer attacks, mathematical cryptanalysis proofs, side-channel analysis, hardware fault injection, network-level DoS, production PKI/CA certificate chain deployment, and transport-level replay detection.

### 1.9 Contributions
1. **Multi-Provider Crypto-Agility Engine:** Clean separation of provider interfaces supporting native C/Rust backends (`cryptography` 48.0.0) and pure Python backends (`slh-dsa` 0.2.5).
2. **Empirical Benchmarking Dataset:** Authoritative latency and size datasets across 4 operational modes and 6 concrete configurations.
3. **Controlled Adversarial Testing Suite:** 49 structured security vectors validating verify-then-decrypt discipline and cross-suite isolation.
4. **Staged Migration Study:** 5 experimental transition paths with exact positive/negative delta tracking.
5. **Interactive Visualization Suite:** Full-featured 9-tab Streamlit dashboard consuming machine-readable JSON/CSV datasets.

---

## 2. Literature Review & Theoretical Foundation

### 2.1 Post-Quantum Cryptographic Standards (NIST FIPS)
- **FIPS 203 (ML-KEM):** Module-Lattice-Based Key-Encapsulation Mechanism derived from CRYSTALS-Kyber. Parameter set ML-KEM-768 targets NIST Security Category 3 (AES-192 equivalent).
- **FIPS 204 (ML-DSA):** Module-Lattice-Based Digital Signature Algorithm derived from CRYSTALS-Dilithium. Parameter set ML-DSA-65 utilizes rejection sampling for Fiat-Shamir with Aborts signatures.
- **FIPS 205 (SLH-DSA):** Stateless Hash-Based Digital Signature Algorithm derived from SPHINCS+. Parameter set SLH-DSA-SHAKE-128f provides security grounded solely in the collision resistance of SHAKE-256.

### 2.2 Classical Baselines
- **ECDH P-384 & ECDSA P-384:** NIST Curve P-384 (secp384r1) providing 192 bits of classical security, vulnerable to polynomial-time quantum period-finding algorithms.
- **AES-256-GCM & HKDF-SHA-384:** Symmetric primitives resilient against quantum attacks via Grover's algorithm ($O(\sqrt{N})$ search complexity leaves 128 bits of post-quantum security).

### 2.3 Hybrid Migration Paradigm
IETF draft specifications (e.g., `draft-ietf-tls-hybrid-design`) emphasize combining established classical algorithms with standardized PQC primitives to safeguard current communications against future quantum decryption without sacrificing classical compliance.

---

## 3. System Requirements

### 3.1 Functional Requirements
- Support independent sender and receiver workflows across Modes A, B, C, and D.
- Perform key pair generation, key establishment, HKDF session key derivation, authenticated AES-256-GCM encryption, digital signing, and payload packaging.
- Recover original plaintext byte-for-byte for arbitrary payloads (64 B to 16 KiB).

### 3.2 Security Requirements
- Enforce strict **verify-then-decrypt** processing order on the receiver.
- Bind algorithm suite identifiers to the message header to prevent mode confusion.
- Never expose private keys, shared secrets, AES keys, or HKDF intermediate material in public APIs or logs.

### 3.3 Performance & Measurement Requirements
- Provide microsecond-precision timing using `time.perf_counter_ns`.
- Isolate initialization, warmup iterations, and statistical outliers.

### 3.4 Migration & Agility Requirements
- Permit runtime switching of cryptographic configurations via `ModeFactory` without modifying application communication logic.
- Validate all forward, rollback, and cross-PQC stage transitions.

### 3.5 Visualization & Reproducibility Requirements
- Ingest recorded experimental datasets dynamically without synthetic fabrication.
- Provide automated regression test suites executing with 100% pass rates.

---

## 4. System Architecture

```mermaid
flowchart TD
    App["Application / CLI Tooling (src/main_cli.py)"]
    Session["SecureSession (src/communication/session.py)"]
    Comm["SecureCommunicator (src/communication/secure_communicator.py)"]
    Factory["ModeFactory & CryptoConfig (src/config/crypto_config.py)"]
    
    App --> Session
    Session --> Comm
    Comm --> Factory
    
    subgraph MultiProviderLayer ["AD-17 Multi-Provider PQC Layer"]
        CP["PyCA cryptography 48.0.0 (C / Rust)"]
        SP["slh-dsa 0.2.5 (Pure Python)"]
        HybridKEM["Hybrid Dual-KEX (ECDH P-384 + ML-KEM-768)"]
    end
    
    Factory --> CP
    Factory --> SP
    Factory --> HybridKEM
    
    subgraph Primitives ["Cryptographic Primitives"]
        ECDH["ECDH P-384"]
        ECDSA["ECDSA P-384"]
        MLKEM["ML-KEM-768 / 1024"]
        MLDSA["ML-DSA-65"]
        SLHDSA["SLH-DSA-SHAKE-128f"]
        AES["AES-256-GCM + HKDF-SHA-384"]
    end
    
    CP --> ECDH
    CP --> ECDSA
    CP --> MLKEM
    CP --> MLDSA
    CP --> AES
    SP --> SLHDSA
```

---

## 5. Cryptographic Configurations

| Configuration Label | Canonical Algorithm Suite Identifier | Key Establishment | Digital Signature | Symmetric Cipher & KDF | Provider Backend |
|---|---|---|---|---|---|
| **Mode A** | `CLASSICAL_ECDH_ECDSA_AES256_GCM` | ECDH P-384 | ECDSA P-384 | AES-256-GCM + HKDF-SHA-384 | PyCA `cryptography` 48.0.0 |
| **Mode B** | `PQC_MLKEM_MLDSA_AES256_GCM` | ML-KEM-768 | ML-DSA-65 | AES-256-GCM + HKDF-SHA-384 | PyCA `cryptography` 48.0.0 |
| **Mode C** | `PQC_MLKEM_SLHDSA_AES256_GCM` | ML-KEM-768 | SLH-DSA-SHAKE-128f | AES-256-GCM + HKDF-SHA-384 | `slh-dsa` 0.2.5 (Pure Python) |
| **Mode D (ML-DSA)** | `HYBRID_ECDH_MLKEM_MLDSA_AES256_GCM` | ECDH P-384 + ML-KEM-768 | ML-DSA-65 | AES-256-GCM + HKDF-SHA-384 | `cryptography` 48.0.0 |
| **Mode D (SLH-DSA)**| `HYBRID_ECDH_MLKEM_SLHDSA_AES256_GCM`| ECDH P-384 + ML-KEM-768 | SLH-DSA-SHAKE-128f | AES-256-GCM + HKDF-SHA-384 | `cryptography` + `slh-dsa` |
| **Mode D (ECDSA)**  | `HYBRID_ECDH_MLKEM_ECDSA_AES256_GCM`  | ECDH P-384 + ML-KEM-768 | ECDSA P-384 | AES-256-GCM + HKDF-SHA-384 | `cryptography` 48.0.0 |

---

## 6. Crypto-Agility Layer

The crypto-agility layer decouples high-level messaging logic from concrete cryptographic implementations:
- **`CryptoConfig`:** An immutable, frozen dataclass binding provider instances (`key_exchange`, `signature`, `encryption`, `kdf`) to a canonical algorithm suite identifier.
- **`ModeFactory`:** A centralized factory validating provider compatibility and assembling validated `CryptoConfig` objects.
- **Strict Suite Binding:** Every `SecureMessage` carries its explicit `algorithm_id`. Receivers enforce strict equality against their configured suite, preventing silent fallback or downgrade attacks.

---

## 7. Secure Communication Workflow

1. **Sender Key Generation:** Generates ephemeral key exchange pair ($pk_{ke}, sk_{ke}$) and signing pair ($pk_{sig}, sk_{sig}$).
2. **Key Establishment:** Computes shared secret $SS$ and optional key exchange ciphertext $C_{ke}$ using receiver's public key.
3. **Key Derivation:** Derives 256-bit AES session key: $K_{aes} = \text{HKDF-Expand}(\text{HKDF-Extract}(SS), \text{"pqcf-v1-aes256-session-key"}, 32)$.
4. **Authenticated Encryption:** Computes ciphertext $C$ and 12-byte nonce $N$: $(C, N) = \text{AES-256-GCM-Encrypt}(K_{aes}, \text{Plaintext}, \text{AAD})$.
5. **Digital Signature:** Computes signature over canonical signed data: $\sigma = \text{Sign}(sk_{sig}, C \parallel N)$.
6. **Message Assembly:** Packages public keys, ciphertext, nonce, signature, and metadata into `SecureMessage`.
7. **Receiver Verification (Verify-then-Decrypt):**
   - Validates `algorithm_id` matches receiver configuration.
   - Imports $pk_{sig}$ and verifies $\sigma$ over $C \parallel N$. **REJECTS immediately if verification fails.**
   - Decapsulates/derives shared secret $SS$ using $sk_{ke, rx}$.
   - Re-derives $K_{aes}$ via HKDF.
   - Decrypts and authenticates $C$ using $K_{aes}, N, \text{AAD}$.

---

## 8. Hybrid Key Establishment Mechanics

The hybrid key establishment construction combines classical ECDH P-384 and post-quantum ML-KEM-768:
- **Hybrid Public Key Structure:** Length-prefixed concatenation of ECDH P-384 uncompressed point (97 B) and ML-KEM-768 public key (1,184 B) = 1,283 B total.
- **Hybrid Ciphertext Structure:** Length-prefixed concatenation of ephemeral ECDH P-384 public key (97 B) and ML-KEM-768 encapsulation ciphertext (1,088 B) = 1,187 B total.
- **Shared Secret Combination:**
  $$SS_{hybrid} = \text{HKDF-SHA-384}\left(\text{IKM} = SS_{ecdh} \parallel SS_{mlkem},\ \text{info} = \text{"pqcf-v1-hybrid-secret-combiner"},\ L = 32\right)$$
- **Empirical Observation:** The HKDF combiner operation required an average of $18.55\ \mu s$, adding minimal computational overhead to the key establishment pipeline.

---

## 9. Security & Adversarial Tampering Experiment

### Threat Model
The adversary can intercept, inspect, and mutate serialized `SecureMessage` fields across communication channels, but possesses no access to private keys, intermediate shared secrets, or internal memory.

### Experimental Security Results (Phase 9 & 12)
49 controlled attack scenarios were evaluated across the defined mutation and protocol categories. All tested tampering and cross-suite mutation scenarios were rejected as expected; replay detection was separately evaluated and remains outside the current stateless protocol scope.

- **Vector 1: Ciphertext Mutation (1-bit flip):** REJECTED (100%) via `SignatureVerificationError`.
- **Vector 2: Nonce Mutation (1-bit flip):** REJECTED (100%) via `SignatureVerificationError`.
- **Vector 3: Signature Mutation (1-bit flip):** REJECTED (100%) via `SignatureVerificationError`.
- **Vector 4: Suite ID Substitution:** REJECTED (100%) via `ModeMismatchError`.
- **Vector 5: KEX Ciphertext Truncation:** REJECTED (100%) via `MalformedMessageError`.
- **Vector 6: Ephemeral Public Key Mutation:** REJECTED (100%) via `InvalidKeyError` / `SignatureVerificationError`.
- **Finding:** The verify-then-decrypt discipline remained unbroken across all 49 adversarial scenarios.

---

## 10. Replay Limitation

> [!IMPORTANT]
> The framework operates on a stateless message model. Replay detection, sequence numbers, and replay caches are outside the current experimental scope.

---

## 11. Performance Benchmarking Methodology

- **Testbed Environment:** Intel Core 7 150U (12 logical cores, 1.80 GHz base), Windows 11 AMD64, Python 3.14.3 (CPython), PyCA `cryptography` 48.0.0, `slh-dsa` 0.2.5.
- **Timing Instrumentation:** `time.perf_counter_ns` with per-iteration isolation and garbage collection suppression during measurement.
- **Sampling Parameters:** 100 measured iterations (20 warmup rounds) for standard primitives; 20 measured iterations (5 warmup rounds) for pure-Python SLH-DSA.

---

## 12. Performance Results

```
========================================================================================================================
MEASURED CRYPTOGRAPHIC PRIMITIVE LATENCIES (PHASE 10 AUTHORITATIVE BENCHMARK)
========================================================================================================================
Operation                          Algorithm / Configuration     Unit    Mean       Median     StdDev    P95       P99
------------------------------------------------------------------------------------------------------------------------
Key Generation (Classical)         ECDH P-384 (Mode A)            μs    1334.514   1143.800   430.139   2201.265  2658.573
Key Generation (PQC)               ML-KEM-768 (Mode B/C)          μs     301.021    268.650    90.031    473.535   591.238
Key Generation (Hybrid)            ECDH + ML-KEM (Mode D)         μs    1748.567   1594.050   524.511   2681.945  3321.369
ECDH Shared Secret Derivation      ECDH P-384                     μs    1842.529   1550.650  1211.265   4942.935  6750.420
ML-KEM Key Encapsulation           ML-KEM-768                     μs      68.657     65.200    14.653     97.970   136.275
ML-KEM Key Decapsulation           ML-KEM-768                     μs      99.118     95.300    15.352    130.345   164.717
Hybrid Total Encapsulation         ECDH + ML-KEM                  μs    3207.502   2824.200  1227.164   5896.790  8197.809
Hybrid Total Decapsulation         ECDH + ML-KEM                  μs    1583.218   1638.100   737.585   3321.450  4412.300
Digital Signing (1 KiB)            ECDSA P-384                    μs    1451.600   1402.100   321.400   2100.500  2450.100
Signature Verification (1 KiB)     ECDSA P-384                    μs    1420.400   1380.500   298.200   1980.200  2310.400
Digital Signing (1 KiB)            ML-DSA-65                      μs    1039.600    985.400   842.100   3593.200  4820.100
Signature Verification (1 KiB)     ML-DSA-65                      μs     298.300    285.100    45.600    390.400   450.200
Digital Signing (1 KiB)            SLH-DSA-SHAKE-128f             ms     245.700    224.613    35.693    316.349   324.438
Signature Verification (1 KiB)     SLH-DSA-SHAKE-128f             ms      12.750     12.505     1.851     16.745    18.714
End-to-End Roundtrip (1 KiB)       Mode A (Classical)             μs    7678.192   6887.350  2016.963  11696.720 15933.816
End-to-End Roundtrip (1 KiB)       Mode B (Pure PQC ML-DSA)       μs    2209.036   1976.450   827.561   3516.365  5496.911
End-to-End Roundtrip (1 KiB)       Mode C (Pure PQC SLH-DSA)      ms     257.379    237.425    36.001    332.812   338.576
End-to-End Roundtrip (1 KiB)       Mode D (Hybrid ML-DSA)         μs    6811.588   6404.150  1202.827   8874.525 11491.899
End-to-End Roundtrip (1 KiB)       Mode D (Hybrid ECDSA)          μs    8943.215   8256.450  1862.608  12754.635 15894.887
========================================================================================================================
```

---

## 13. Communication Overhead Results

```
========================================================================================================================
COMMUNICATION PAYLOAD & WIRE OVERHEAD (1 KiB PLAINTEXT)
========================================================================================================================
Configuration        KE PubKey  KE Ciphertext  Sig PubKey  Signature  Ciphertext  Raw Total  Wire Size  Wire Overhead vs A
------------------------------------------------------------------------------------------------------------------------
Mode A (Classical)     97 B          0 B         120 B       104 B     1,040 B     1,373 B    2,084 B     Baseline (0.0%)
Mode B (PQC ML-DSA) 1,184 B      1,088 B       1,952 B     3,309 B     1,040 B     8,585 B   11,693 B    +9,609 B (+461.08%)
Mode C (PQC SLH-DSA)1,184 B      1,088 B          32 B    17,088 B     1,040 B    20,444 B   27,506 B   +25,422 B (+1,219.87%)
Mode D (ML-DSA)     1,283 B      1,187 B       1,952 B     3,309 B     1,040 B     8,783 B   11,965 B    +9,881 B (+474.14%)
Mode D (SLH-DSA)    1,283 B      1,187 B          32 B    17,088 B     1,040 B    20,642 B   27,778 B   +25,694 B (+1,232.92%)
Mode D (ECDSA)      1,283 B      1,187 B         120 B       104 B     1,040 B     3,746 B    5,249 B    +3,165 B (+151.87%)
========================================================================================================================
```

---

## 14. Comparative Analysis (RQ1–RQ7 Synthesis)

- **RQ1 (ML-KEM vs ECDH):** ML-KEM-768 key generation (301.0 $\mu s$) required 77.44% less execution time than ECDH P-384 (1,334.5 $\mu s$). The combined ML-KEM encapsulation (68.7 $\mu s$) and decapsulation (99.1 $\mu s$) required 167.8 $\mu s$ (-90.89% execution time vs ECDH derivation of 1,842.5 $\mu s$). *Limitation: These operations represent structurally different mechanisms and timing comparisons are empirical.*
- **RQ2 (ML-DSA vs ECDSA):** ML-DSA-65 verification (298.3 $\mu s$) was 79.00% faster than ECDSA P-384 verification (1,420.4 $\mu s$). ML-DSA signing exhibited latency variance due to rejection sampling (median: 1,039.6 $\mu s$, p95: 3,593.2 $\mu s$). ML-DSA artifacts are significantly larger (+1,526.7% public key, +3,081.7% signature).
- **RQ3 (SLH-DSA Characteristics):** SLH-DSA-SHAKE-128f produced the smallest public key (32 B) but the largest signature (17,088 B). Multi-millisecond signing (245.70 ms) reflects the pure-Python implementation environment (AD-17).
- **RQ4 (Communication Overhead):** Base64 and JSON framing expanded payloads by +51.78% (Mode A), +36.20% (Mode B), and +36.23% (Mode D ML-DSA).
- **RQ5 (Hybrid Key Establishment):** Hybrid key establishment combines classical ECDH P-384 and post-quantum ML-KEM-768 key-establishment mechanisms, with a measured +2.33% (+272 B) incremental wire-size increase over pure-PQC Mode B.
- **RQ6 (Security Robustness):** Verify-then-decrypt discipline strictly rejected 100% of tested tamper mutations without mode confusion.
- **RQ7 (Migration Agility):** Crypto-agility abstractions enabled runtime suite switching with 100% functional continuity across all migration stages.

---

## 15. Migration Experimentation & 16. Results

Five migration paths were executed and validated:

```
========================================================================================================================
QUANTITATIVE MIGRATION TRANSITION DELTAS
========================================================================================================================
Transition ID        Source -> Target Suite       Type      Latency Delta (us / %)    Wire Size Delta (Bytes / %)
------------------------------------------------------------------------------------------------------------------------
A -> D (ML-DSA)      Mode A -> Mode D (ML-DSA)   FORWARD     -866.604 us (-11.29%)      +9,881 B (+474.14%)
D (ML-DSA) -> B      Mode D (ML-DSA) -> Mode B   FORWARD   -4,602.552 us (-67.57%)        -272 B (-2.27%)
A -> D (SLH-DSA)     Mode A -> Mode D (SLH-DSA)  FORWARD  +251,686.808 us (+3,277.94%)   +25,694 B (+1,232.92%)
D (SLH-DSA) -> C     Mode D (SLH-DSA) -> Mode C  FORWARD   -1,986.000 us (-0.77%)         -272 B (-0.98%)
A -> D (ECDSA)       Mode A -> Mode D (ECDSA)    FORWARD   +1,265.023 us (+16.48%)      +3,165 B (+151.87%)
D (ML-DSA) -> A      Mode D (ML-DSA) -> Mode A   ROLLBACK    +866.604 us (+12.72%)      -9,881 B (-82.58%)
B -> C               Mode B -> Mode C          INTRA-PQC  +255,169.964 us (+11,551.19%)  +15,813 B (+135.23%)
========================================================================================================================
```

---

## 17. Compatibility Matrix

| Sender $\downarrow$ \ Receiver $\rightarrow$ | Mode A | Mode B | Mode C | Mode D (ML-DSA) | Mode D (SLH-DSA) | Mode D (ECDSA) |
|---|:---:|:---:|:---:|:---:|:---:|:---:|
| **Mode A** | **ACCEPT** | REJECT | REJECT | REJECT | REJECT | REJECT |
| **Mode B** | REJECT | **ACCEPT** | REJECT | REJECT | REJECT | REJECT |
| **Mode C** | REJECT | REJECT | **ACCEPT** | REJECT | REJECT | REJECT |
| **Mode D (ML-DSA)** | REJECT | REJECT | REJECT | **ACCEPT** | REJECT | REJECT |
| **Mode D (SLH-DSA)** | REJECT | REJECT | REJECT | REJECT | **ACCEPT** | REJECT |
| **Mode D (ECDSA)** | REJECT | REJECT | REJECT | REJECT | REJECT | **ACCEPT** |

*Finding: 6/36 matching interactions accepted; 30/36 mismatched interactions strictly rejected. This result applies to the tested compatibility matrix and does not constitute proof of universal protocol security.*

---

## 18. Interactive Dashboard

Built using Streamlit 1.64.0, Plotly 7.1.0, and Pandas 3.0.1 under `src/dashboard/app.py`:
- 9 dedicated tabs covering Overview, Modes, Performance, Overhead, Migration, Compatibility, Security, Findings, and System Info.
- Dynamically ingests recorded experimental datasets without synthetic fabrication.
- Launch command: `streamlit run src/dashboard/app.py`.

---

## 19. Methodological & Experimental Limitations

1. **No Physical Quantum Computing:** Experiments were conducted exclusively on conventional x86_64 hardware.
2. **Provider Dependence (AD-17):** Microbenchmarks reflect the specific provider backends (`cryptography` 48.0.0 vs `slh-dsa` 0.2.5).
3. **Stateless Replay Limitation:** Protocol does not implement anti-replay sequence state tracking.
4. **Out of Scope Dimensions:** Physical side-channel analysis, hardware fault injection, network DoS, production PKI/CA certificate chain rotation, and HSM key storage.

---

## 20. Reproducibility & Verification

- **Regression Test Suite:** `pytest -q` executes 566 unit and integration tests with 0 failures, 0 skips, 0 errors.
- **Dataset Persistence:** Raw and summary benchmark datasets are frozen in `results/benchmarks/` and `results/migration/`.
