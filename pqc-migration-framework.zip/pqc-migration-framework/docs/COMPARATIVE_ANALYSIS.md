# Comparative Analysis & Empirical Research Findings

**Project**: Post-Quantum Secure Communication & Migration Framework  
**Phase**: Phase 11 — Comparative Analysis & Research Findings  
**Date**: September 2026  
**Status**: Authoritative Experimental Evaluation  

---

## 1. Objective

This document provides a rigorous, empirical comparative analysis of the cryptographic performance, communication overhead, security functionality, and architectural trade-offs measured in Phase 10 across:
- **Classical Baseline (Mode A)**: ECDH P-384 + ECDSA P-384 + AES-256-GCM + HKDF-SHA-384
- **Primary Post-Quantum (Mode B)**: ML-KEM-768 + ML-DSA-65 + AES-256-GCM + HKDF-SHA-384
- **Hash-Based Post-Quantum (Mode C)**: ML-KEM-768 + SLH-DSA-SHAKE-128f + AES-256-GCM + HKDF-SHA-384
- **Hybrid Key Establishment (Mode D)**: (ECDH P-384 + ML-KEM-768) dual KEM + (ML-DSA-65 / SLH-DSA-SHAKE-128f / ECDSA P-384) + AES-256-GCM + HKDF-SHA-384

The analysis addresses the primary and supporting research questions (RQ1–RQ7), establishing the empirical foundation for Phase 12 (Migration Experimentation).

---

## 2. Authoritative Data Sources

All quantitative values and metrics in this document are derived directly from the machine-readable Phase 10 datasets:
- [`results/benchmarks/benchmark_summary.json`](file:///c:/Users/prems/.gemini/antigravity-ide/scratch/pqc-migration-framework/results/benchmarks/benchmark_summary.json)
- [`results/benchmarks/benchmark_sizes.json`](file:///c:/Users/prems/.gemini/antigravity-ide/scratch/pqc-migration-framework/results/benchmarks/benchmark_sizes.json)
- [`results/benchmarks/benchmark_raw.json`](file:///c:/Users/prems/.gemini/antigravity-ide/scratch/pqc-migration-framework/results/benchmarks/benchmark_raw.json)
- [`results/analysis/comparative_metrics.json`](file:///c:/Users/prems/.gemini/antigravity-ide/scratch/pqc-migration-framework/results/analysis/comparative_metrics.json)
- [`results/analysis/research_question_results.json`](file:///c:/Users/prems/.gemini/antigravity-ide/scratch/pqc-migration-framework/results/analysis/research_question_results.json)

---

## 3. Experimental Hardware & Software Environment

| Environment Parameter | Measured Specification |
|---|---|
| **Operating System** | Windows 11 (AMD64) |
| **Processor** | Intel(R) Core(TM) 7 150U (12 logical cores) |
| **Python Runtime** | Python 3.14.3 (CPython 64-bit) |
| **Primary Cryptography Library** | PyCA `cryptography` 48.0.0 (Native OpenSSL C / Rust backends) |
| **Alternative PQC Signature Library** | `slh-dsa` 0.2.5 (Pure-Python backend) |
| **Test / Benchmark Harness** | `pytest` 8.4.1 / Custom high-resolution timing runner (`time.perf_counter_ns()`) |

---

## 4. Provider & Backend Context (AD-17)

### TABLE 6: Provider Architecture & Implementation Backends
| Cryptographic Operation | Mode | Provider Library | Implementation Backend | Memory / Runtime Characteristics |
|---|---|---|---|---|
| **ECDH P-384** | Mode A, Mode D | `cryptography` 48.0.0 | Native OpenSSL / C | Native C pointers, OpenSSL assembly optimization |
| **ECDSA P-384** | Mode A, Mode D | `cryptography` 48.0.0 | Native OpenSSL / C | Native C pointers, OpenSSL assembly optimization |
| **ML-KEM-768** | Modes B, C, D | `cryptography` 48.0.0 | Native Rust / C backend | Compiled Rust FIPS 203 implementation |
| **ML-DSA-65** | Modes B, D | `cryptography` 48.0.0 | Native Rust / C backend | Compiled Rust FIPS 204 implementation |
| **SLH-DSA-SHAKE-128f** | Modes C, D | `slh-dsa` 0.2.5 | Pure-Python bytecode | Pure-Python objects, interpreted loop execution |
| **AES-256-GCM** | All Modes | `cryptography` 48.0.0 | Native OpenSSL / C | Hardware AES-NI accelerated |
| **HKDF-SHA-384** | All Modes | `cryptography` 48.0.0 | Native OpenSSL / C | OpenSSL SHA-384 C implementation |

> [!IMPORTANT]
> **Methodological Note on Provider Attribution**: Under the approved AD-17 multi-provider architecture, performance comparisons involving SLH-DSA reflect **both** algorithmic structure (hash tree exploration) and library backend implementation (pure-Python bytecode vs native compiled C/Rust). Unqualified algorithmic claims independent of backend execution are strictly avoided.

---

## 5. RQ1 Analysis: ML-KEM-768 vs ECDH P-384 Key Establishment

### TABLE 1: Key Establishment Performance Comparison
| Operation | Algorithm | Role | Count | Mean ($\mu s$) | Median ($\mu s$) | StdDev ($\mu s$) | p95 ($\mu s$) | Relative to Classical Mean ($\%$) |
|---|---|---|---:|---:|---:|---:|---:|---:|
| **Key Generation** | ECDH P-384 | Mode A | 100 | 1,334.5 | 1,143.8 | 430.1 | 2,201.3 | Baseline (0.00%) |
| **Key Generation** | ML-KEM-768 | Mode B / C | 100 | 301.0 | 268.7 | 90.0 | 473.5 | **-77.44%** |
| **Key Generation** | Hybrid (Dual) | Mode D | 100 | 1,748.6 | 1,594.1 | 524.5 | 2,681.9 | **+31.03%** |
| **Key Derivation** | ECDH P-384 | Mode A | 100 | 1,842.5 | 1,550.7 | 1,211.3 | 4,942.9 | Baseline (0.00%) |
| **Encapsulation** | ML-KEM-768 | Mode B / C Sender | 100 | 68.7 | 62.3 | 17.0 | 96.8 | — |
| **Decapsulation** | ML-KEM-768 | Mode B / C Receiver | 100 | 99.1 | 90.8 | 30.7 | 152.5 | — |
| **Complete KEM Key Agreement** | ML-KEM-768 | Encap + Decap | 100 | 167.8 | 153.1 | — | 249.3 | **-90.89%** vs ECDH Derive |
| **Hybrid Combiner** | HKDF-SHA-384 | Combiner | 100 | 18.6 | 18.5 | 3.6 | 19.1 | Component |
| **Hybrid Total Encapsulate** | ECDH + ML-KEM | Mode D Sender | 100 | 3,207.5 | 2,864.6 | 972.8 | 5,131.6 | **+74.08%** vs ECDH Derive |
| **Hybrid Total Decapsulate** | ECDH + ML-KEM | Mode D Receiver | 100 | 1,583.2 | 1,381.1 | 590.0 | 2,447.0 | **-14.07%** vs ECDH Derive |

### Analysis & Empirical Observations:
1. **Key Generation**: ML-KEM-768 key generation exhibited a mean latency of $301.0\ \mu s$ (median $268.7\ \mu s$), representing a **-77.44%** reduction compared to ECDH P-384 ($1,334.5\ \mu s$). Matrix polynomial sampling over ring $R_q$ in compiled Rust demonstrated lower computational overhead than elliptic curve point generation over $P\text{-}384$.
2. **Key Agreement Workflow**: The measured ML-KEM encapsulation ($68.7\ \mu s$) and decapsulation ($99.1\ \mu s$) operations required substantially less combined execution time ($167.8\ \mu s$) than the measured ECDH shared-secret derivation ($1,842.5\ \mu s$) under the tested environment; however, these operations represent different key-establishment mechanisms and should not be interpreted as a one-to-one algorithmic equivalence.
3. **Tail Latency & Stability**: ML-KEM operations demonstrated tight dispersion ($CV = 29.91\%$ for keygen) compared to ECDH derivation ($CV = 65.74\%$), where scalar multiplication showed greater sensitivity to core frequency scaling.

---

## 6. RQ2 Analysis: ML-DSA-65 vs ECDSA P-384 Digital Signatures

### TABLE 2: Digital Signature Comparison (1 KiB Payload)
| Scheme | Operation | Provider | Mean | Median | StdDev | p95 | CV ($\%$) | Sig Size | PK Size |
|---|---|---|---:|---:|---:|---:|---:|---:|---:|
| **ECDSA P-384** | Signing | `cryptography` | 1,585.5 $\mu s$ | 1,451.6 $\mu s$ | 535.9 $\mu s$ | 2,705.8 $\mu s$ | 33.80% | 104 B | 120 B |
| **ECDSA P-384** | Verification | `cryptography` | 1,420.4 $\mu s$ | 1,336.6 $\mu s$ | 371.8 $\mu s$ | 2,067.3 $\mu s$ | 26.17% | — | — |
| **ML-DSA-65** | Signing | `cryptography` | 1,462.6 $\mu s$ | 1,039.6 $\mu s$ | 1,268.8 $\mu s$ | 3,593.2 $\mu s$ | 86.75% | 3,309 B | 1,952 B |
| **ML-DSA-65** | Verification | `cryptography` | 298.3 $\mu s$ | 301.0 $\mu s$ | 57.2 $\mu s$ | 370.5 $\mu s$ | 19.17% | — | — |

### Analysis & Empirical Observations:
1. **Verification Performance**: ML-DSA-65 verification demonstrated a substantial latency advantage (mean $298.3\ \mu s$, median $301.0\ \mu s$) over ECDSA P-384 (mean $1,420.4\ \mu s$, median $1,336.6\ \mu s$), representing a **-79.00%** reduction in verification latency.
2. **Signing Distribution & Rejection Sampling**: While ML-DSA-65 exhibited a lower median signing latency ($1,039.6\ \mu s$ vs $1,451.6\ \mu s$, a **-28.39%** reduction), its mean ($1,462.6\ \mu s$) and standard deviation ($1,268.8\ \mu s$, $CV = 86.75\%$) were elevated by the rejection sampling loop inherent to Dilithium-based signature generation (p95 was $3,593.2\ \mu s$).
3. **Artifact Size Expansion**: The computational performance of ML-DSA-65 comes at the cost of significantly larger artifacts: the public key expanded from 120 B to 1,952 B (+1,526.67%), and the signature expanded from 104 B to 3,309 B (+3,081.73%).

---

## 7. RQ3 Analysis: SLH-DSA-SHAKE-128f vs ML-DSA-65

### Analysis & Empirical Observations:
1. **Latency Profile in Measured Environment**:
   - SLH-DSA-SHAKE-128f signing for 1 KiB payloads averaged $245.70\ ms$ (median $235.52\ ms$).
   - SLH-DSA-SHAKE-128f verification averaged $12.75\ ms$ (median $12.02\ ms$).
   - In contrast, ML-DSA-65 required $1.46\ ms$ mean signing and $0.30\ ms$ mean verification.
2. **Artifact Trade-Offs**:
   - **Public Key Size**: SLH-DSA public keys are exceptionally compact at **32 Bytes** (a 32-byte public seed and root), compared to **1,952 Bytes** for ML-DSA-65 (**-98.36%** smaller).
   - **Signature Size**: Conversely, SLH-DSA signatures are large at **17,088 Bytes** (comprising FORS few-time signatures and W-OTS+ authentication paths across the hypertree), compared to **3,309 Bytes** for ML-DSA-65 (**+416.41%** larger).
3. **Implementation Context**: Because SLH-DSA is implemented in pure Python (`slh-dsa` 0.2.5), its millisecond latency profile reflects interpreted bytecode execution over intensive tree hash operations.

---

## 8. RQ4 Analysis: Communication & Serialization Overhead

### TABLE 3: Cryptographic Artifact & Wire Size Breakdown (1 KiB Plaintext)
| Configuration | KE Public Key | KE Ciphertext | Sig Public Key | Signature | Nonce + Ciphertext | Raw Crypto Total | Total JSON Wire Size | Wire Overhead vs Mode A ($\Delta$) | Wire Overhead vs Mode A ($\%$) |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| **Mode A** | 97 B | 0 B | 120 B | 104 B | 1,052 B | **1,373 B** | **2,084 B** | 0 B | **0.00%** |
| **Mode B** | 1,184 B | 1,088 B | 1,952 B | 3,309 B | 1,052 B | **8,585 B** | **11,693 B** | +9,609 B | **+461.08%** |
| **Mode C** | 1,184 B | 1,088 B | 32 B | 17,088 B | 1,052 B | **20,444 B** | **27,506 B** | +25,422 B | **+1,219.87%** |
| **Mode D (ML-DSA)** | 1,283 B | 1,187 B | 1,952 B | 3,309 B | 1,052 B | **8,783 B** | **11,965 B** | +9,881 B | **+474.14%** |
| **Mode D (SLH-DSA)** | 1,283 B | 1,187 B | 32 B | 17,088 B | 1,052 B | **20,642 B** | **27,778 B** | +25,694 B | **+1,232.92%** |
| **Mode D (ECDSA)** | 1,283 B | 1,187 B | 120 B | 104 B | 1,052 B | **3,746 B** | **5,249 B** | +3,165 B | **+151.87%** |

### Dominating Overhead Contributors & Serialization Effects:
1. **Mode B (Lattice PQC)**: The ML-DSA public-key and signature components together represented **61.28%** of the raw cryptographic artifact total ($5,261\text{ B} / 8,585\text{ B}$).
2. **Mode C (Hash-Based PQC)**: The SLH-DSA public-key and signature components together represented **83.74%** of the raw cryptographic artifact total ($17,120\text{ B} / 20,444\text{ B}$), with the signature alone accounting for **83.58%** ($17,088\text{ B}$).
3. **Configuration-Aware Serialization Overhead**: JSON serialization and Base64 encoding introduced additional wire overhead beyond raw cryptographic artifact sizes. The magnitude varied by configuration because framing and encoding overhead are applied to artifacts of different sizes:
   - **Mode A**: $+51.78\%$ expansion beyond raw cryptographic bytes ($2,084\text{ B}$ vs $1,373\text{ B}$).
   - **Mode B**: $+36.20\%$ expansion beyond raw cryptographic bytes ($11,693\text{ B}$ vs $8,585\text{ B}$).
   - **Mode C**: $+34.54\%$ expansion beyond raw cryptographic bytes ($27,506\text{ B}$ vs $20,444\text{ B}$).
   - **Mode D (ML-DSA)**: $+36.23\%$ expansion beyond raw cryptographic bytes ($11,965\text{ B}$ vs $8,783\text{ B}$).
   - **Mode D (SLH-DSA)**: $+34.57\%$ expansion beyond raw cryptographic bytes ($27,778\text{ B}$ vs $20,642\text{ B}$).
   - **Mode D (ECDSA)**: $+40.12\%$ expansion beyond raw cryptographic bytes ($5,249\text{ B}$ vs $3,746\text{ B}$).

---

## 9. RQ5 Analysis: Hybrid Construction Trade-offs & Incremental Overhead

### TABLE 5: Hybrid Incremental Overhead Analysis
| Comparison | Baseline Mode | Hybrid Mode | Baseline Wire Size | Hybrid Wire Size | Absolute Overhead ($\Delta$) | Percentage Overhead ($\%$) | Architectural Source |
|---|---|---|---:|---:|---:|---:|---|
| **Hybrid ML-DSA vs Pure PQC** | Mode B | Mode D (ML-DSA) | 11,693 B | 11,965 B | **+272 B** | **+2.33%** | Dual ECDH P-384 PK (99B) + Ephemeral ECDH Point (99B) |
| **Hybrid SLH-DSA vs Pure PQC** | Mode C | Mode D (SLH-DSA) | 27,506 B | 27,778 B | **+272 B** | **+0.99%** | Dual ECDH P-384 PK (99B) + Ephemeral ECDH Point (99B) |
| **Hybrid ECDSA vs Classical** | Mode A | Mode D (ECDSA) | 2,084 B | 5,249 B | **+3,165 B** | **+151.87%** | Addition of ML-KEM-768 PK (1,184B) + Ciphertext (1,088B) |
| **Hybrid ML-DSA vs Classical** | Mode A | Mode D (ML-DSA) | 2,084 B | 11,965 B | **+9,881 B** | **+474.14%** | Combined ML-KEM-768 and ML-DSA-65 components |

### Findings on Hybrid Dual-KEM:
- Retaining classical ECDH P-384 alongside post-quantum ML-KEM-768 introduces **only +272 Bytes (+2.33%)** of incremental serialized wire overhead relative to pure PQC Mode B.
- The `HybridSecretCombiner` (HKDF-SHA-384) adds an imperceptible **18.55 $\mu s$** computation time.
- Total hybrid key encapsulation latency ($3,207.5\ \mu s$) is dominated by the classical ECDH scalar multiplication, demonstrating that classical math remains the computational bottleneck in dual-KEM systems.

---

## 10. RQ6 Analysis: End-to-End Performance vs Communication Overhead

### TABLE 4: End-to-End Communication Latency (1 KiB Plaintext)
| Configuration | Suite Description | Send ($\mu s / ms$) | Receive ($\mu s / ms$) | Round-Trip ($\mu s / ms$) | Round-Trip Normalized ($\mu s$) | RTT Relative to Mode A ($\%$) |
|---|---|---:|---:|---:|---:|---:|
| **Mode A** | Classical ECDH + ECDSA | 5,127.2 $\mu s$ | 2,551.0 $\mu s$ | **7,678.2 $\mu s$** | 7,678.2 $\mu s$ | Baseline (0.00%) |
| **Mode B** | PQC ML-KEM + ML-DSA | 1,820.2 $\mu s$ | 388.8 $\mu s$ | **2,209.0 $\mu s$** | 2,209.0 $\mu s$ | **-71.23%** |
| **Mode C** | PQC ML-KEM + SLH-DSA | 244.19 $ms$ | 13.19 $ms$ | **257.38 $ms$** | 257,379.0 $\mu s$ | **+3,252.07%** |
| **Mode D (ML-DSA)** | Hybrid + ML-DSA | 5,246.5 $\mu s$ | 1,565.1 $\mu s$ | **6,811.6 $\mu s$** | 6,811.6 $\mu s$ | **-11.29%** |
| **Mode D (SLH-DSA)** | Hybrid + SLH-DSA | 244.80 $ms$ | 14.57 $ms$ | **259.37 $ms$** | 259,365.0 $\mu s$ | **+3,277.93%** |
| **Mode D (ECDSA)** | Hybrid + ECDSA | 6,395.1 $\mu s$ | 2,548.1 $\mu s$ | **8,943.2 $\mu s$** | 8,943.2 $\mu s$ | **+16.48%** |

### Synthesis of Latency vs Size Trade-Offs:
- **Mode B**: Achieved the **fastest overall round-trip time (2,209.0 $\mu s$, a -71.23% latency reduction)**, demonstrating that lattice-based primitives reduce computational time significantly on modern CPUs despite the 5.6x wire size expansion.
- **Mode D (ML-DSA)**: Delivered full 2-of-2 hybrid security with a **-11.29% faster round-trip (6,811.6 $\mu s$)** than classical Mode A (7,678.2 $\mu s$), because the fast ML-DSA verification ($298.3\ \mu s$) offset the dual-KEM overhead.
- **Mode C & Mode D (SLH-DSA)**: Mode C and Mode D with SLH-DSA exhibited substantially higher measured end-to-end latency in the tested environment (mean $257.38\ ms$ and $259.37\ ms$), making their latency characteristics an important consideration for applications with stringent response-time requirements.

---

## 11. RQ7 Analysis: Staged Migration Practicality & Crypto-Agility

### TABLE 7: Research Question Findings Matrix
| RQ | Topic | Empirical Evidence | Core Finding | Limitations |
|---|---|---|---|---|
| **RQ1** | ML-KEM vs ECDH | Table 1 / Fig 1 | ML-KEM keygen was 77.4% faster than ECDH; measured encapsulation/decapsulation required 167.8 $\mu s$ vs 1,842.5 $\mu s$ for ECDH derivation. | Structural differences between DH scalar mult and KEM mechanisms. |
| **RQ2** | ML-DSA vs ECDSA | Table 2 / Figs 2–3 | ML-DSA verification was 79.0% faster than ECDSA; signing median was 28.4% faster, with signature size expanding from 104 B to 3,309 B. | Rejection sampling increases signing variance (CV 86.8%). |
| **RQ3** | SLH-DSA vs ML-DSA | Table 2 / Figs 2–3, 7 | SLH-DSA signing required 245.70 $ms$ vs 1.46 $ms$ for ML-DSA; SLH-DSA public key was 98.4% smaller (32 B), but signature was 416.4% larger (17,088 B). | Pure-Python interpreter execution vs native compiled C/Rust backend. |
| **RQ4** | Communication Overhead | Table 3 / Fig 5 | Mode B wire size expanded by +461.1% (11.7 KB) and Mode C by +1,219.9% (27.5 KB) relative to Mode A (2.1 KB); signatures + signing keys dominated payload (61.3% in Mode B, 83.7% in Mode C). | JSON serialization & Base64 encoding added configuration-dependent wire overhead (+34.5% to +51.8%). |
| **RQ5** | Hybrid Construction | Table 5 / Fig 6 | Retaining ECDH alongside ML-KEM added only +272 B (+2.33%) over pure PQC wire size; HKDF combination added 18.6 $\mu s$. | Framework-level dual-KEM composition. |
| **RQ6** | Latency vs Overhead Trade-off | Table 4 / Fig 4 | Mode B reduced local round-trip latency by -71.2% despite larger wire size; Mode D (ML-DSA) remained -11.3% faster than classical Mode A. Mode C and Mode D (SLH-DSA) exhibited substantially higher latency (~258 ms). | Local host computation; network WAN bandwidth not modeled. |
| **RQ7** | Migration Practicality | Security Suite / ModeFactory | Crypto-agility abstraction enabled transparent runtime switching across 6 suites with deterministic cross-mode rejection and 0 code duplication. | Stateless protocol; replay protection not implemented. |

---

## 12. Security Functionality Integration (Phases 2–9)

The comparative analysis incorporates empirical security validation from Phase 9:
1. **Verify-Then-Decrypt Discipline**: In all 6 configurations, digital signature verification precedes ciphertext decryption. Corrupted signatures reject immediately without invoking AES-GCM.
2. **Deterministic Tamper Detection**: 49 distinct attack vectors across 8 adversarial categories (ciphertext tampering, nonce manipulation, signature corruption, key truncation, cross-mode substitution, and metadata alteration) were experimentally rejected.
3. **Cross-Mode Rejection**: Mode confusion and suite downgrade attacks were deterministically prevented by cryptographic suite identifier binding.
4. **Non-Exposure Security**: Zero secret keys, shared secrets, or AES keys were exposed in benchmark outputs, logs, or error exceptions.

---

## 13. Replay Limitation

> [!WARNING]
> **Stateless Protocol Limitation**: As experimentally demonstrated in Phase 9 (Attack Scenario 8), replaying an exact duplicate of a valid, unmodified `SecureMessage` was accepted by the receiver because the current framework operates as a stateless cryptographic engine without sequence counters, timestamps, or session state nonces.
> 
> The current experimental framework intentionally models cryptographic data encapsulation rather than a stateful transport protocol (such as TLS 1.3 or IPsec). Replay protection must be addressed in future network protocol hardening.

---

## 14. Research Figures

The following static figures generated in Phase 11 illustrate the comparative findings:

- **Figure 1**: [fig1_key_establishment_latency.png](file:///c:/Users/prems/.gemini/antigravity-ide/scratch/pqc-migration-framework/docs/figures/fig1_key_establishment_latency.png) — *Key establishment and key generation latency breakdown ($\mu s$)*.
- **Figure 2**: [fig2_signature_signing_latency.png](file:///c:/Users/prems/.gemini/antigravity-ide/scratch/pqc-migration-framework/docs/figures/fig2_signature_signing_latency.png) — *Digital signature signing latency across 64B, 1KiB, 16KiB payloads*.
- **Figure 3**: [fig3_signature_verification_latency.png](file:///c:/Users/prems/.gemini/antigravity-ide/scratch/pqc-migration-framework/docs/figures/fig3_signature_verification_latency.png) — *Digital signature verification latency across payload sizes*.
- **Figure 4**: [fig4_end_to_end_roundtrip_latency.png](file:///c:/Users/prems/.gemini/antigravity-ide/scratch/pqc-migration-framework/docs/figures/fig4_end_to_end_roundtrip_latency.png) — *End-to-end communication round-trip latency comparison*.
- **Figure 5**: [fig5_total_wire_size.png](file:///c:/Users/prems/.gemini/antigravity-ide/scratch/pqc-migration-framework/docs/figures/fig5_total_wire_size.png) — *Cryptographic artifact and wire size breakdown (1 KiB payload)*.
- **Figure 6**: [fig6_hybrid_overhead_breakdown.png](file:///c:/Users/prems/.gemini/antigravity-ide/scratch/pqc-migration-framework/docs/figures/fig6_hybrid_overhead_breakdown.png) — *Hybrid wire overhead relative to Classical and Pure PQC*.
- **Figure 7**: [fig7_signature_size_comparison.png](file:///c:/Users/prems/.gemini/antigravity-ide/scratch/pqc-migration-framework/docs/figures/fig7_signature_size_comparison.png) — *Public key vs signature size comparison (Log scale)*.

---

## 15. Inputs for Phase 12 (Migration Experimentation)

The empirical metrics and trade-off dimensions established in Phase 11 provide the direct inputs for Phase 12:
1. **Migration State Matrix**: Establishing transition paths (Classical $\rightarrow$ Hybrid $\rightarrow$ Pure PQC).
2. **Overhead Budgets**: Using measured wire expansions (+2.33% for Hybrid vs +461% for PQC) to evaluate bandwidth-constrained channels.
3. **Latency Profiles**: Using measured round-trip times (2.2 ms for Mode B vs 6.8 ms for Mode D vs 257 ms for Mode C) to simulate migration performance trade-offs under varying workload conditions.
