# PROJECT_SPEC.md
# Post-Quantum Secure Communication & Migration Framework
## Complete Project Specification — Phase 0

**Version:** 0.2.0  
**Date:** 2026-09-15 (revised 2026-09-15)  
**Status:** Phase 0 — Specification Corrected (no implementation)

> **Revision note (v0.2.0):** Corrected cryptographic dependency architecture. All post-quantum algorithms (ML-KEM, ML-DSA, SLH-DSA) are now assigned to `liboqs-python`. The `cryptography` library is used only for classical algorithms, AES-256-GCM, and HKDF. The SPHINCS+/SLH-DSA lineage distinction is explicitly documented. Hybrid Mode D signature is now explicitly specified. Phase ordering has been revised to a 14-phase plan.

---

## 1. Project Purpose

This project demonstrates how a conventional secure communication system can be migrated toward post-quantum cryptography (PQC). It allows side-by-side comparison between:

1. **Classical cryptography** — ECDH + ECDSA + AES-256
2. **Post-quantum cryptography** — ML-KEM + ML-DSA (or SLH-DSA) + AES-256
3. **Hybrid cryptography** — ECDH + ML-KEM combined + configurable signature + AES-256

### What This Project Is NOT

- Does **not** invent a new cryptographic algorithm.
- Does **not** mathematically prove that any PQC algorithm is secure.
- Does **not** run a quantum computer attack against real keys.
- Does **not** implement Shor's algorithm.

### What This Project DOES

Experimentally demonstrates:
- Functional secure communication across all three configurations
- Quantum-resistant key establishment using standardized NIST PQC (ML-KEM / FIPS 203)
- Quantum-resistant digital signatures (ML-DSA / FIPS 204; SLH-DSA / FIPS 205)
- Message integrity and tamper detection
- Classical vs PQC vs Hybrid performance benchmarks (actual measured results)
- Cryptographic overhead (key sizes, ciphertext sizes, signature sizes)
- Crypto-agility — ability to swap algorithms without rewriting application logic
- A staged migration path from classical to PQC

---

## 2. Research Questions

### Central Research Question

> "How can an existing secure communication system be migrated from classical public-key cryptography to post-quantum cryptography while maintaining security functionality and evaluating the resulting performance, communication overhead, and migration trade-offs?"

### Supporting Research Questions

| ID  | Research Question |
|-----|-------------------|
| RQ1 | How does ML-KEM compare with classical ECDH for key establishment in terms of execution time and key/ciphertext sizes? |
| RQ2 | How does ML-DSA compare with ECDSA for digital signing and verification? |
| RQ3 | How does SLH-DSA compare with ML-DSA as an alternative post-quantum signature family? |
| RQ4 | What performance and communication overhead is introduced by PQC versus classical algorithms? |
| RQ5 | What are the practical differences between classical, PQC, and hybrid configurations? |
| RQ6 | Can the system be designed with crypto-agility so that cryptographic algorithms can be replaced without rewriting application logic? |
| RQ7 | What does a staged migration from classical cryptography to PQC look like in a practical software system? |

> **Important:** These experiments demonstrate functional security properties. They do NOT independently prove the mathematical post-quantum security of the algorithms. Security claims rest on NIST standardization and academic analysis.

---

## 3. Cryptographic Components

### 3.1 Classical Algorithms

| Role | Algorithm | Notes |
|------|-----------|-------|
| Key establishment | ECDH | NIST P-256 or P-384 (TBD Phase 1) |
| Digital signature | ECDSA | Matching curve |
| Bulk encryption | AES-256-GCM | NIST FIPS 197 + authenticated |
| Key derivation | HKDF-SHA-256/384 | NIST SP 800-56C |

### 3.2 Post-Quantum Algorithms

| Role | Algorithm | NIST Standard | Library | Available Parameter Sets |
|------|-----------|---------------|---------|--------------------------|
| Key encapsulation | ML-KEM (Kyber lineage) | FIPS 203 | liboqs-python | ML-KEM-512, ML-KEM-768, ML-KEM-1024 |
| Digital signature | ML-DSA (Dilithium lineage) | FIPS 204 | liboqs-python | ML-DSA-44, ML-DSA-65, ML-DSA-87 |
| Alt. signature | SLH-DSA (SPHINCS+ lineage) | FIPS 205 | liboqs-python | Multiple (SHAKE/SHA2, small/fast variants) |

> **SPHINCS+ vs SLH-DSA terminology:** The research literature (including the literature review this project is based on) refers to the algorithm family as **SPHINCS+**. This is the pre-standardization research name. The NIST-standardized version is **SLH-DSA** (Stateless Hash-Based Digital Signature Algorithm, FIPS 205). This project uses the **SLH-DSA** designation for all implementation and documentation, while acknowledging the SPHINCS+ lineage in academic context. Do NOT implement SPHINCS+ as a separate or legacy algorithm — use the standardized SLH-DSA family exclusively.

Parameter-set selection is an **open decision** deferred to Phase 2 (see DECISIONS.md).

### 3.3 Hybrid Construction

- Hybrid shared secret = HKDF(ECDH_secret || ML-KEM_secret)
- Construction follows established library guidance; no custom combination is invented.

### 3.4 Library Assignment

| Library | Algorithms Provided |
|---------|--------------------|
| `cryptography` 48.0.0 (PyCA) | ECDH, ECDSA, AES-256-GCM, HKDF |
| `liboqs-python` 0.16.x | ML-KEM (FIPS 203), ML-DSA (FIPS 204), SLH-DSA (FIPS 205) |

**Policy:**
- All primitives must use established, vetted libraries only.
- No custom cryptographic primitive implementations are permitted.
- No hardcoded secrets; all keys generated at runtime or from secure sources.
- The library assignment above is fixed and must not be changed without recording a new decision in DECISIONS.md.

---

## 4. Experimental Modes

### Mode A — Classical

| Component | Algorithm |
|-----------|-----------|
| Key establishment | ECDH |
| Digital signature | ECDSA |
| Encryption | AES-256-GCM |

### Mode B — Post-Quantum (ML-DSA)

| Component | Algorithm |
|-----------|-----------|
| Key establishment | ML-KEM |
| Digital signature | ML-DSA |
| Encryption | AES-256-GCM |

### Mode C — Post-Quantum with Hash-Based Signature

| Component | Algorithm |
|-----------|-----------|
| Key establishment | ML-KEM |
| Digital signature | SLH-DSA |
| Encryption | AES-256-GCM |

### Mode D — Hybrid

| Component | Algorithm |
|-----------|-----------|
| Key establishment | ECDH + ML-KEM (combined via HKDF) |
| Digital signature | **ECDSA** or **ML-DSA** (configurable); optionally **ECDSA + ML-DSA** dual-signature if the implementation design supports it |
| Encryption | AES-256-GCM |

> **Hybrid signature note:** Mode D's signature is configurable at runtime via the provider pattern. The benchmark will run Mode D with ECDSA and again with ML-DSA to show the signature component's contribution to overhead. Dual ECDSA + ML-DSA signatures (maximum migration security) may be explored if the implementation supports it, but is not required. Do not implement this in Phase 0.

---

## 5. Functional Requirements

| ID | Requirement | Priority |
|----|-------------|----------|
| FR-01 | Generate cryptographic key pairs for all supported algorithms | MUST |
| FR-02 | Establish a shared/session secret using the configured mode | MUST |
| FR-03 | Derive an AES-256 key from the shared secret via HKDF | MUST |
| FR-04 | Encrypt a plaintext message using AES-256-GCM | MUST |
| FR-05 | Decrypt the ciphertext and recover the original plaintext | MUST |
| FR-06 | Generate a digital signature over the message/ciphertext | MUST |
| FR-07 | Verify a digital signature against the sender's public key | MUST |
| FR-08 | Detect modified or tampered messages | MUST |
| FR-09 | Reject invalid or forged signatures | MUST |
| FR-10 | Allow cryptographic mode to change without rewriting communication logic | MUST |
| FR-11 | Record benchmark measurements: timing and size metrics | MUST |
| FR-12 | Compare classical, PQC, and hybrid configurations via a unified interface | MUST |
| FR-13 | Display or report security-test results | MUST |

---

## 6. Non-Functional Requirements

| ID | Requirement |
|----|-------------|
| NFR-01 | **Correctness** — Cryptographic operations produce verifiably correct results |
| NFR-02 | **Reproducibility** — Experiments reproducible with a documented procedure |
| NFR-03 | **Modular architecture** — Crypto, communication, and benchmark layers cleanly separated |
| NFR-04 | **Crypto-agility** — Algorithm selection via configuration, not hardcoded logic |
| NFR-05 | **Testability** — Unit and integration tests for each cryptographic component |
| NFR-06 | **Measurable performance** — Benchmarks use actual execution time, not simulated values |
| NFR-07 | **No custom primitives** — Only established libraries used |
| NFR-08 | **No hardcoded secrets** — Keys generated at runtime |
| NFR-09 | **No fabricated results** — All measurements from real execution |
| NFR-10 | **Separation of concerns** — Cryptographic logic isolated from application logic |

---

## 7. Security Demonstrations

| Test | Description | Expected Outcome |
|------|-------------|-----------------|
| TEST-1 | Normal encrypted communication end-to-end | Decrypted plaintext matches original |
| TEST-2 | Valid signature verification | verify() succeeds |
| TEST-3 | Modify plaintext before signing | verify() fails |
| TEST-4 | Modify ciphertext after signing | Message rejected |
| TEST-5 | Receiver distinguishes valid from invalid | Valid accepted, invalid rejected |
| TEST-6 | All four modes perform the same communication workflow | Mode-agnostic layer works |

> These tests demonstrate functional security properties within the implemented system. They do NOT constitute a formal cryptographic security proof.

---

## 8. Benchmark Requirements

All benchmarks use **actual execution measurements**. No values may be fabricated.

### Metrics

**Key Establishment:**
- Key generation time (ms)
- Encapsulation time (ms) — ML-KEM
- Decapsulation time (ms) — ML-KEM
- Key exchange round-trip time (ms) — ECDH

**Signatures:**
- Key generation time (ms)
- Signing time (ms)
- Verification time (ms)

**Sizes:**
- Public key size (bytes)
- Private key size (bytes)
- Ciphertext/encapsulation size (bytes)
- Signature size (bytes)

**System-Level:**
- Complete secure-message processing time (ms)
- Total communication overhead (bytes)

### Methodology

- Repeated measurements; minimum iteration count determined in Phase 10 (Benchmarking)
- Report mean, standard deviation, min/max
- Isolate cryptographic operations from I/O
- Document test hardware and OS environment
- Use high-resolution timers (e.g., `time.perf_counter()`)

---

## 9. Migration Experiment

| Stage | Name | Key Establishment | Signature | Encryption |
|-------|------|-------------------|-----------|-----------|
| 1 | Classical | ECDH | ECDSA | AES-256-GCM |
| 2 | Hybrid | ECDH + ML-KEM | ECDSA or ML-DSA (configurable) | AES-256-GCM |
| 3 | Post-Quantum | ML-KEM | ML-DSA | AES-256-GCM |
| 4 | Alt PQC Signature | ML-KEM | SLH-DSA | AES-256-GCM |

Migration evaluates: performance trade-offs, communication overhead, engineering transition effort, and interoperability at each stage.

> Disclaimer: This is the project's experimental migration model, not the only valid strategy.

---

## 10. Crypto-Agility Requirement

The architecture must enforce a clean separation between communication logic and cryptographic implementation.

### Provider Hierarchy (Conceptual)

```
KeyExchangeProvider (abstract)
    ├── ECDHProvider
    ├── MLKEMProvider
    └── HybridProvider (ECDH + ML-KEM)

SignatureProvider (abstract)
    ├── ECDSAProvider
    ├── MLDSAProvider
    └── SLHDSAProvider

EncryptionProvider (abstract)
    └── AESGCM256Provider
```

### Requirements
- Algorithm selection via `CryptoConfig` object or equivalent
- No algorithm-specific `if/else` chains in communication code
- Providers are interchangeable without modifying caller code

---

## 11. Explicit Limitations

1. The project does **not** run a quantum computer attack.
2. The project does **not** implement Shor's algorithm.
3. The project does **not** mathematically prove PQC security.
4. Benchmark results are implementation- and hardware-dependent.
5. Results do not replace formal cryptographic security analysis.
6. Library implementation details affect measured performance.
7. Migration results are specific to this experimental system.
8. The hybrid KDF construction follows library guidance; alternative valid constructions exist.
9. **SPHINCS+ vs SLH-DSA:** The research literature uses the name SPHINCS+. This project implements only the standardized SLH-DSA (FIPS 205). Results labelled SLH-DSA correspond to the SPHINCS+ algorithm family as standardized by NIST.

---

## 12. Research Deliverables

| # | Deliverable |
|---|-------------|
| 1 | Working secure communication application (all four modes) |
| 2 | Classical implementation (Mode A) |
| 3 | PQC implementation (Modes B and C) |
| 4 | Hybrid implementation (Mode D) |
| 5 | Tamper-detection demonstration |
| 6 | Crypto-agility demonstration |
| 7 | Benchmark dataset (raw timing and size measurements) |
| 8 | Performance comparison tables and analysis |
| 9 | Communication-overhead comparison |
| 10 | Migration analysis (per-stage trade-off evaluation) |
| 11 | Graphs and charts |
| 12 | Technical documentation |
| 13 | Reproducible experiment procedure |

---

*End of PROJECT_SPEC.md — Phase 0 | Version 0.2.0*
