# ARCHITECTURE.md
# Post-Quantum Secure Communication & Migration Framework
## High-Level Architecture — Phase 0

**Version:** 0.2.0  
**Date:** 2026-09-15 (revised 2026-09-15)  
**Status:** Phase 0 — Architecture Corrected (no implementation)

> **Revision note (v0.2.0):** Corrected library layer. `cryptography` 48.0.0 is used only for classical algorithms (ECDH, ECDSA) and symmetric primitives (AES-256-GCM, HKDF). All PQC algorithms (ML-KEM / FIPS 203, ML-DSA / FIPS 204, SLH-DSA / FIPS 205) are provided by `liboqs-python` 0.16.x. Phase numbering updated to 14-phase plan.

---

## 1. Architectural Goals

The architecture must satisfy:

1. **Crypto-agility** — Cryptographic algorithms are selected at configuration time, not compile time.
2. **Separation of concerns** — Communication logic never contains algorithm-specific code.
3. **Testability** — Each cryptographic component can be tested in isolation.
4. **Extensibility** — New algorithms can be added as new provider implementations.
5. **No custom primitives** — All algorithm implementations delegate to vetted libraries.
6. **Reproducible benchmarks** — Benchmarking infrastructure is separate from application logic.

---

## 2. Layered Architecture Overview

```
┌─────────────────────────────────────────────────────────┐
│                    Presentation Layer                    │
│         (CLI runner / Web frontend / Test runner)        │
└──────────────────────────┬──────────────────────────────┘
                           │
┌──────────────────────────▼──────────────────────────────┐
│                   Application Layer                      │
│     SecureCommunicator — mode-agnostic send/receive      │
│     MigrationOrchestrator — runs all four stages         │
│     BenchmarkRunner — collects and reports metrics       │
│     SecurityTester — runs all six security tests         │
└───────────────┬──────────────────┬──────────────────────┘
                │                  │
┌───────────────▼────────┐  ┌──────▼──────────────────────┐
│   Crypto-Agility Layer │  │   Configuration Layer        │
│   (Provider Interfaces)│  │   CryptoConfig / ModeSelector│
│                        │  │   (Mode A / B / C / D)       │
│  KeyExchangeProvider   │  └─────────────────────────────┘
│  SignatureProvider     │
│  EncryptionProvider    │
└───────────────┬────────┘
                │
┌───────────────▼─────────────────────────────────────────┐
│              Cryptographic Implementation Layer          │
│                                                          │
│  Classical:          PQC:              Hybrid:           │
│  - ECDHProvider      - MLKEMProvider   - HybridKEProvider│
│  - ECDSAProvider     - MLDSAProvider                     │
│                      - SLHDSAProvider                    │
│                                                          │
│  Symmetric (shared):                                     │
│  - AESGCM256Provider                                     │
│  - HKDFDerivationProvider                                │
└───────────────┬─────────────────────────────────────────┘
                │
┌───────────────▼─────────────────────────────────────────┐
│                   Library Layer (AD-17)                  │
│                                                          │
│  cryptography 48.0.0 (PyCA)                              │
│    - Classical: ECDH/ECDSA (ec module, NIST P-384)       │
│    - Symmetric: AES-256-GCM (AESGCM), HKDF-SHA-384       │
│    - Lattice PQC: ML-KEM (FIPS 203), ML-DSA (FIPS 204)   │
│                                                          │
│  slh-dsa 0.2.5 (FIPS 205 Standardized Package)          │
│    - Hash-Based PQC: SLH-DSA-SHAKE-128f / 128s / 192f    │
│      (SLH-DSA = standardized SPHINCS+ lineage)           │
│                                                          │
│  [Historical/Alternative: liboqs-python via AD-03]       │
└─────────────────────────────────────────────────────────┘
```

---

## 3. Component Responsibilities

### 3.1 Presentation Layer

| Component | Responsibility |
|-----------|----------------|
| `main_cli.py` | Command-line entry point; accepts mode argument and message |
| `web_app/` | Optional frontend (React or simple HTML) showing results |
| `run_tests.py` | Runs all security tests and prints pass/fail |
| `run_benchmark.py` | Executes benchmark suite and saves results to CSV/JSON |

### 3.2 Application Layer

| Component | Responsibility |
|-----------|----------------|
| `SecureCommunicator` | Mode-agnostic send/receive orchestration |
| `MigrationOrchestrator` | Runs Stages 1–4 sequentially for migration experiment |
| `BenchmarkRunner` | Times each cryptographic operation; aggregates statistics |
| `SecurityTester` | Executes Tests 1–6; returns structured pass/fail results |

### 3.3 Crypto-Agility Layer (Provider Interfaces)

#### `KeyExchangeProvider` (Abstract Interface)

```python
# Conceptual interface — not implemented in Phase 0
class KeyExchangeProvider:
    def generate_keypair(self) -> KeyPair
    def encapsulate(self, public_key) -> (shared_secret, ciphertext)    # KEM path
    def decapsulate(self, private_key, ciphertext) -> shared_secret       # KEM path
    def exchange(self, private_key, peer_public_key) -> shared_secret     # DH path
```

#### `SignatureProvider` (Abstract Interface)

```python
class SignatureProvider:
    def generate_keypair(self) -> KeyPair
    def sign(self, private_key, message: bytes) -> bytes
    def verify(self, public_key, message: bytes, signature: bytes) -> bool
```

#### `EncryptionProvider` (Abstract Interface)

```python
class EncryptionProvider:
    def encrypt(self, key: bytes, plaintext: bytes) -> (ciphertext: bytes, nonce: bytes)
    def decrypt(self, key: bytes, ciphertext: bytes, nonce: bytes) -> bytes
```

#### `KeyDerivationProvider` (Abstract Interface)

```python
class KeyDerivationProvider:
    def derive(self, input_keying_material: bytes, length: int, info: bytes) -> bytes
```

### 3.4 Cryptographic Implementation Layer

| Provider Class | Algorithm | Library |
|----------------|-----------|---------|
| `ECDHProvider` | ECDH (P-256 or P-384) | `cryptography` — `asymmetric.ec` |
| `ECDSAProvider` | ECDSA | `cryptography` — `asymmetric.ec` |
| `MLKEMProvider` | ML-KEM (512/768/1024) | `liboqs-python` |
| `MLDSAProvider` | ML-DSA (44/65/87) | `liboqs-python` |
| `SLHDSAProvider` | SLH-DSA variant | `liboqs-python` |
| `HybridKEProvider` | ECDH + ML-KEM combined | Composes ECDHProvider + MLKEMProvider + HKDF |
| `AESGCM256Provider` | AES-256-GCM | `cryptography` — `ciphers.aead.AESGCM` |
| `HKDFDerivationProvider` | HKDF-SHA-256/384 | `cryptography` — `kdf.hkdf.HKDF` |

> **Note:** ML-KEM and ML-DSA are provided by `liboqs-python`, not `cryptography` 48.0.0. Although `cryptography` 48 exposes `mlkem` and `mldsa` modules, these depend on a specific OpenSSL build with PQC support that may not be present in a standard installation. `liboqs-python` provides reliable, pre-built PQC support on all platforms and is the definitive PQC source for this project.

### 3.5 Configuration Layer

```python
# Conceptual — not implemented in Phase 0
class CryptoConfig:
    mode: Mode  # A | B | C | D
    key_exchange: KeyExchangeProvider
    signature: SignatureProvider
    encryption: EncryptionProvider
    kdf: KeyDerivationProvider

class ModeFactory:
    @staticmethod
    def build(mode: Mode) -> CryptoConfig: ...
```

---

## 4. Data Flow — Secure Message (End-to-End)

```
SENDER SIDE
───────────
[1] Generate sender key pairs
      ├── KeyExchangeProvider.generate_keypair() → sender_ke_keypair
      └── SignatureProvider.generate_keypair()   → sender_sig_keypair

[2] Key establishment
    KEM path (ML-KEM / Hybrid):
      └── KeyExchangeProvider.encapsulate(receiver_public_key)
              → (shared_secret, encapsulation_ciphertext)
    DH path (ECDH):
      └── KeyExchangeProvider.exchange(sender_private, receiver_public)
              → shared_secret

[3] Derive AES session key
      └── HKDFDerivationProvider.derive(shared_secret) → aes_key (32 bytes)

[4] Encrypt plaintext
      └── AESGCM256Provider.encrypt(aes_key, plaintext)
              → (ciphertext, nonce)

[5] Sign message
      └── SignatureProvider.sign(sender_private_sig, ciphertext || nonce)
              → signature

[6] Transmitted bundle:
      { encapsulation_ciphertext, nonce, ciphertext, signature,
        sender_public_sig_key }

RECEIVER SIDE
─────────────
[7] Verify signature
      └── SignatureProvider.verify(sender_public_sig_key,
                                   ciphertext || nonce, signature)
              → True / False (REJECT if False)

[8] Recover shared secret
    KEM path: KeyExchangeProvider.decapsulate(receiver_private, encapsulation_ciphertext)
    DH path:  KeyExchangeProvider.exchange(receiver_private, sender_public_ke)
              → shared_secret

[9] Re-derive AES session key
      └── HKDFDerivationProvider.derive(shared_secret) → aes_key

[10] Decrypt ciphertext
      └── AESGCM256Provider.decrypt(aes_key, ciphertext, nonce)
              → plaintext
```

---

## 5. Benchmarking Architecture

```
BenchmarkRunner
    │
    ├── for each mode in [A, B, C, D]:
    │     ├── time KeyExchangeProvider.generate_keypair()      → t_ke_keygen
    │     ├── time KeyExchangeProvider.encapsulate/exchange()  → t_ke_establish
    │     ├── time KeyExchangeProvider.decapsulate()           → t_ke_decap
    │     ├── time SignatureProvider.generate_keypair()        → t_sig_keygen
    │     ├── time SignatureProvider.sign()                    → t_sign
    │     ├── time SignatureProvider.verify()                  → t_verify
    │     ├── time full send/receive pipeline                  → t_total
    │     └── measure all artifact sizes                       → size_*
    │
    └── BenchmarkReport
          ├── raw_results.csv
          ├── summary_statistics.json
          └── charts/ (generated in Phase 11)
```

---

## 6. Security Test Architecture

```
SecurityTester
    │
    ├── TEST-1: happy_path_communication(mode) → pass/fail
    ├── TEST-2: valid_signature_verification(mode) → pass/fail
    ├── TEST-3: tampered_plaintext_rejected(mode) → pass/fail
    ├── TEST-4: tampered_ciphertext_rejected(mode) → pass/fail
    ├── TEST-5: invalid_signature_rejected(mode) → pass/fail
    └── TEST-6: mode_agnostic_communication(all_modes) → pass/fail
```

---

## 7. Proposed Repository Structure

```
pqc-migration-framework/
│
├── README.md
├── PROJECT_SPEC.md
├── ARCHITECTURE.md
├── EXPERIMENT_PLAN.md
├── PHASE_PLAN.md
├── DECISIONS.md
│
├── src/
│   ├── __init__.py
│   │
│   ├── config/
│   │   ├── __init__.py
│   │   ├── crypto_config.py        # CryptoConfig dataclass; ModeFactory
│   │   └── modes.py                # Mode enum: A, B, C, D
│   │
│   ├── providers/
│   │   ├── __init__.py
│   │   ├── base.py                 # Abstract base classes / interfaces
│   │   │
│   │   ├── classical/
│   │   │   ├── __init__.py
│   │   │   ├── ecdh_provider.py    # ECDHProvider
│   │   │   └── ecdsa_provider.py   # ECDSAProvider
│   │   │
│   │   ├── pqc/
│   │   │   ├── __init__.py
│   │   │   ├── mlkem_provider.py   # MLKEMProvider
│   │   │   ├── mldsa_provider.py   # MLDSAProvider
│   │   │   └── slhdsa_provider.py  # SLHDSAProvider (via liboqs)
│   │   │
│   │   ├── hybrid/
│   │   │   ├── __init__.py
│   │   │   └── hybrid_ke_provider.py  # HybridKEProvider
│   │   │
│   │   └── symmetric/
│   │       ├── __init__.py
│   │       ├── aesgcm_provider.py  # AESGCM256Provider
│   │       └── hkdf_provider.py    # HKDFDerivationProvider
│   │
│   ├── communication/
│   │   ├── __init__.py
│   │   ├── secure_communicator.py  # SecureCommunicator (mode-agnostic)
│   │   └── message_bundle.py       # Transmitted message structure
│   │
│   ├── migration/
│   │   ├── __init__.py
│   │   └── migration_orchestrator.py  # Stages 1-4 runner
│   │
│   ├── benchmark/
│   │   ├── __init__.py
│   │   ├── benchmark_runner.py     # Timing harness
│   │   └── benchmark_report.py     # Statistics + output formatting
│   │
│   └── security_tests/
│       ├── __init__.py
│       └── security_tester.py      # Tests 1-6
│
├── tests/
│   ├── unit/
│   │   ├── test_ecdh_provider.py
│   │   ├── test_mlkem_provider.py
│   │   ├── test_mldsa_provider.py
│   │   ├── test_slhdsa_provider.py
│   │   ├── test_hybrid_ke_provider.py
│   │   └── test_aesgcm_provider.py
│   └── integration/
│       ├── test_secure_communicator.py
│       └── test_migration_stages.py
│
├── results/
│   ├── raw/                        # Raw benchmark CSV files
│   ├── summary/                    # JSON summaries
│   └── charts/                     # Generated charts (Phase 4)
│
├── frontend/                       # Optional web frontend (Phase 5)
│
├── docs/
│   ├── api/                        # API documentation
│   └── experiment/                 # Experiment procedure docs
│
├── requirements.txt                # Python dependencies
└── pyproject.toml                  # Project metadata
```

---

## 8. Technology Stack

| Layer | Technology | Version | Rationale |
|-------|-----------|---------|-----------|
| Language | Python | 3.14.3 | Available on system; excellent crypto library ecosystem |
| Classical algorithms + symmetric | cryptography (PyCA) | 48.0.0 | Already installed; provides ECDH, ECDSA, AES-256-GCM, HKDF |
| ALL PQC algorithms | liboqs-python | 0.16.x (to install in Phase 1) | Open Quantum Safe project; provides ML-KEM, ML-DSA, SLH-DSA (FIPS 203/204/205) |
| Frontend | React (Vite) or simple HTML | TBD Phase 13 | Node.js 24.14.0 available; decide scope in Phase 13 |
| Test framework | pytest | latest | Standard Python testing |
| Data export | pandas + matplotlib | latest | Benchmark visualization |

### Why NOT Java

Java is not installed on the system PATH. Installing a JDK, build tool (Maven/Gradle), and Java-specific PQC provider (Bouncy Castle + BCPQC) would add significant setup overhead. Python 3.14 + `liboqs-python` provides all required PQC functionality.

### Why liboqs-python for ALL PQC (not cryptography 48)

Although `cryptography` 48.0.0 exposes `mlkem` and `mldsa` submodules, these depend on an OpenSSL build compiled with PQC algorithm support (via the OpenSSL OQSPROVIDER or equivalent). A standard OpenSSL installation on Windows does not include this provider. Rather than require a custom OpenSSL build, `liboqs-python` 0.16.x is used for all PQC algorithms (ML-KEM, ML-DSA, SLH-DSA). `liboqs-python` ships pre-built wheels for Windows, Linux, and macOS and wraps the Open Quantum Safe liboqs C library, which is a recognized, vetted research-grade PQC implementation. `cryptography` is retained for classical algorithms (ECDH, ECDSA) and symmetric primitives (AES-256-GCM, HKDF) where it is well-proven and already installed.

---

## 9. Interface Boundaries

| Boundary | What crosses it |
|----------|----------------|
| Application → Crypto-Agility | `CryptoConfig` object; provider interface calls |
| Crypto-Agility → Implementation | Concrete provider implementations; raw bytes |
| Implementation → Library | Library API calls; bytes in, bytes out |
| Communication layer → Benchmark | Timing wrappers around provider calls |
| Application → Frontend | JSON REST responses (Phase 5) or stdout |

---

*End of ARCHITECTURE.md — Phase 0 | Version 0.2.0*
