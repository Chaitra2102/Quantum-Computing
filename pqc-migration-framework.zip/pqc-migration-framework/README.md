# Post-Quantum Secure Communication & Migration Framework

**Experimental Evaluation of Classical, Hybrid, and Post-Quantum Secure Communication Configurations**

[![Python 3.14](https://img.shields.io/badge/python-3.14.3-blue.svg)](https://www.python.org/downloads/)
[![Tests Passing](https://img.shields.io/badge/tests-566%20passed-brightgreen.svg)]()
[![Cryptography 48.0.0](https://img.shields.io/badge/cryptography-48.0.0-informational.svg)](https://cryptography.io/)
[![Status](https://img.shields.io/badge/status-COMPLETE%20%26%20FROZEN-success.svg)]()

---

## Abstract & Project Overview

The **Post-Quantum Secure Communication & Migration Framework** is a modular, provider-agnostic research testbed developed to evaluate the transition from classical public-key cryptography (ECDH/ECDSA P-384) to post-quantum standards (ML-KEM, ML-DSA, SLH-DSA) and hybrid key-establishment constructions.

The framework implements a crypto-agile communication pipeline that executes authenticated encryption (AES-256-GCM + HKDF-SHA-384) and digital signatures with strict **verify-then-decrypt** discipline across four operational modes. It includes extensive microbenchmarking, adversarial mutation testing, staged migration modeling, pairwise compatibility matrices, and an interactive Streamlit research dashboard.

---

## Cryptographic Operational Modes

| Mode | Suite Identifier | Key Establishment | Digital Signature | Symmetric Cipher & KDF |
|---|---|---|---|---|
| **Mode A** | `CLASSICAL_ECDH_ECDSA_AES256_GCM` | Classical ECDH P-384 | Classical ECDSA P-384 | AES-256-GCM + HKDF-SHA-384 |
| **Mode B** | `PQC_MLKEM_MLDSA_AES256_GCM` | Pure PQC ML-KEM-768 (FIPS 203) | Pure PQC ML-DSA-65 (FIPS 204) | AES-256-GCM + HKDF-SHA-384 |
| **Mode C** | `PQC_MLKEM_SLHDSA_AES256_GCM` | Pure PQC ML-KEM-768 (FIPS 203) | Pure PQC SLH-DSA-SHAKE-128f (FIPS 205) | AES-256-GCM + HKDF-SHA-384 |
| **Mode D** | `HYBRID_ECDH_MLKEM_MLDSA_AES256_GCM`<br>`HYBRID_ECDH_MLKEM_SLHDSA_AES256_GCM`<br>`HYBRID_ECDH_MLKEM_ECDSA_AES256_GCM` | Hybrid Dual KEX<br>(ECDH P-384 + ML-KEM-768) | Configurable Signatures:<br>ML-DSA-65 / SLH-DSA / ECDSA | AES-256-GCM + HKDF-SHA-384 |

---

## Multi-Provider Architecture (AD-17)

To ensure native cross-platform execution on Windows AMD64 / Python 3.14 without manual C compilation:
- **PyCA `cryptography` 48.0.0 (C / Rust backend):** Provides high-performance native implementations of ECDH P-384, ECDSA P-384, ML-KEM-768/1024, ML-DSA-65, AES-256-GCM, and HKDF-SHA-384.
- **`slh-dsa` 0.2.5 (Pure Python backend):** Provides state-free hash-based digital signatures for SLH-DSA-SHAKE-128f.
- **Hybrid Combiner:** Concatenates shared secrets via `HKDF-SHA-384(ECDH_ss || MLKEM_ss)` with domain separation.

---

## Key Experimental Findings

1. **Key Establishment:** ML-KEM-768 key generation ($301.0\ \mu s$) was 77.44% faster than ECDH P-384 ($1,334.5\ \mu s$). Combined ML-KEM encapsulation ($68.7\ \mu s$) and decapsulation ($99.1\ \mu s$) required $167.8\ \mu s$ (-90.89% execution time vs ECDH derivation of $1,842.5\ \mu s$).
2. **Digital Signatures:** ML-DSA-65 verification ($298.3\ \mu s$) was 79.00% faster than ECDSA P-384 ($1,420.4\ \mu s$). ML-DSA public keys (1,952 B, $+1,526.7\%$) and signatures (3,309 B, $+3,081.7\%$) introduce substantial wire expansion.
3. **Communication Overhead:** 1 KiB plaintext wire sizes: Mode A = 2,084 B; Mode B = 11,693 B ($+461.08\%$); Mode C = 27,506 B ($+1,219.87\%$); Mode D ML-DSA = 11,965 B ($+474.14\%$).
4. **Incremental Hybrid Overhead:** Hybrid key establishment combines classical ECDH P-384 and post-quantum ML-KEM-768 key-establishment mechanisms, with a measured **$+2.33\%$ ($+272\text{ B}$)** incremental wire-size increase over pure-PQC Mode B.
5. **Security Robustness:** 100% of tested tamper mutations (ciphertext, nonce, signature, algorithm ID) were rejected under the verify-then-decrypt discipline.
6. **Cross-Suite Isolation:** In the $6 \times 6$ pairwise compatibility matrix (36 interactions), 6 matching pairs were accepted (**ACCEPT**) and 30 mismatched pairs were rejected (**REJECT**) with 100% protocol isolation.

---

## Quick Start & Usage

### 1. Installation
```bash
git clone <repository_url>
cd pqc-migration-framework
pip install -r requirements.txt
pip install streamlit plotly pandas
```

### 2. Running Automated Tests
```bash
pytest -q
```
*Expected: 566 passed in ~39s (0 failed, 0 skipped, 0 errors).*

### 3. Launching the Interactive Dashboard
```bash
streamlit run src/dashboard/app.py
```
Opens the 9-tab research presentation dashboard at `http://localhost:8501`.

### 4. Running the CLI Interface
```bash
# Execute a secure message exchange in Mode B (ML-KEM + ML-DSA)
python src/main_cli.py --mode B --payload "Confidential migration payload"

# Inspect active cryptographic configuration
python src/main_cli.py --inspect --mode D --sig mldsa
```

---

## Project Structure

```
pqc-migration-framework/
├── src/
│   ├── communication/      # High-level communication pipelines and session managers
│   ├── config/             # CryptoConfig, ModeFactory, and mode definitions
│   ├── dashboard/          # Streamlit visualization application, charts, and loaders
│   ├── migration/          # Migration stages, paths, and experiment execution engine
│   ├── providers/          # Classical, PQC, Hybrid, and Symmetric providers
│   └── security_tests/     # Adversarial attack and mutation testing harness
├── tests/                  # 566 unit, integration, security, migration, dashboard tests
├── results/                # Authoritative JSON and CSV experimental datasets
│   ├── benchmarks/         # Phase 10 microbenchmark datasets
│   ├── analysis/           # Phase 11 comparative metrics
│   └── migration/          # Phase 12 migration results and deltas
└── docs/                   # Comprehensive documentation, research reports, and guides
```

---

## Methodological & Experimental Limitations

- **Software Testbed:** Conducted on conventional x86_64 hardware; no quantum computing hardware was used.
- **Provider Dependence (AD-17):** Microbenchmarks reflect the specific provider backends (`cryptography` 48.0.0 vs `slh-dsa` 0.2.5).
- **Stateless Protocol:** The framework implements a stateless message model; replay detection and sequence numbers are outside the current experimental scope.
- **Scope Boundaries:** Side-channel leakage, hardware fault injection, network DoS, production PKI/CA certificate hierarchies, and HSM key storage are outside the experimental scope.
- **No Rankings:** The project presents experimental observations neutrally without applying subjective scores, rankings, or algorithm recommendations.

---

## Documentation Links

- [Final Research Report](file:///c:/Users/prems/.gemini/antigravity-ide/scratch/pqc-migration-framework/docs/FINAL_RESEARCH_REPORT.md) (`docs/FINAL_RESEARCH_REPORT.md`)
- [Migration Experiment Report](file:///c:/Users/prems/.gemini/antigravity-ide/scratch/pqc-migration-framework/docs/MIGRATION_EXPERIMENT.md) (`docs/MIGRATION_EXPERIMENT.md`)
- [Comparative Analysis Report](file:///c:/Users/prems/.gemini/antigravity-ide/scratch/pqc-migration-framework/docs/COMPARATIVE_ANALYSIS.md) (`docs/COMPARATIVE_ANALYSIS.md`)
- [Benchmark Results](file:///c:/Users/prems/.gemini/antigravity-ide/scratch/pqc-migration-framework/docs/BENCHMARK_RESULTS.md) (`docs/BENCHMARK_RESULTS.md`)
- [Dashboard Guide](file:///c:/Users/prems/.gemini/antigravity-ide/scratch/pqc-migration-framework/docs/DASHBOARD.md) (`docs/DASHBOARD.md`)
- [Final Architecture](file:///c:/Users/prems/.gemini/antigravity-ide/scratch/pqc-migration-framework/docs/ARCHITECTURE_FINAL.md) (`docs/ARCHITECTURE_FINAL.md`)
- [Reproducibility Guide](file:///c:/Users/prems/.gemini/antigravity-ide/scratch/pqc-migration-framework/docs/REPRODUCIBILITY.md) (`docs/REPRODUCIBILITY.md`)
- [Security Scope & Threat Model](file:///c:/Users/prems/.gemini/antigravity-ide/scratch/pqc-migration-framework/docs/SECURITY_SCOPE.md) (`docs/SECURITY_SCOPE.md`)
- [Archive Manifest](file:///c:/Users/prems/.gemini/antigravity-ide/scratch/pqc-migration-framework/docs/ARCHIVE_MANIFEST.md) (`docs/ARCHIVE_MANIFEST.md`)
