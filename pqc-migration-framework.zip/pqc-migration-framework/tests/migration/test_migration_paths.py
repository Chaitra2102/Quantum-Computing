"""
tests/migration/test_migration_paths.py
Post-Quantum Secure Communication & Migration Framework

Unit tests for MigrationStep, MigrationPath, and standard experimental path definitions.
"""

from __future__ import annotations

import pytest

from src.config.modes import (
    CLASSICAL_ECDH_ECDSA_AES256_GCM,
    HYBRID_ECDH_MLKEM_MLDSA_AES256_GCM,
    PQC_MLKEM_MLDSA_AES256_GCM,
    Mode,
)
from src.exceptions import ConfigurationError
from src.migration.migration_path import (
    PATH_ALTERNATIVE_SLHDSA,
    PATH_HYBRID_ECDSA,
    PATH_PRIMARY_MLDSA,
    PATH_PURE_PQC_TRANSITION,
    PATH_ROLLBACK_MLDSA,
    STEP_CLASSICAL_MODE_A,
    STEP_HYBRID_MODE_D_MLDSA,
    STEP_PURE_PQC_MODE_B,
    MigrationPath,
    MigrationStep,
    get_standard_paths,
)
from src.migration.migration_stage import MigrationStage


class TestMigrationStep:
    """Verify MigrationStep construction, config building, and serialization."""

    def test_step_construction(self) -> None:
        step = STEP_CLASSICAL_MODE_A
        assert step.step_id == "step_classical_a"
        assert step.stage == MigrationStage.CLASSICAL
        assert step.mode == Mode.A
        assert step.algorithm_id == CLASSICAL_ECDH_ECDSA_AES256_GCM

    def test_step_build_config(self) -> None:
        cfg_a = STEP_CLASSICAL_MODE_A.build_config()
        assert cfg_a.mode == Mode.A
        assert cfg_a.algorithm_id == CLASSICAL_ECDH_ECDSA_AES256_GCM

        cfg_d = STEP_HYBRID_MODE_D_MLDSA.build_config()
        assert cfg_d.mode == Mode.D
        assert cfg_d.algorithm_id == HYBRID_ECDH_MLKEM_MLDSA_AES256_GCM

        cfg_b = STEP_PURE_PQC_MODE_B.build_config()
        assert cfg_b.mode == Mode.B
        assert cfg_b.algorithm_id == PQC_MLKEM_MLDSA_AES256_GCM

    def test_step_to_dict_is_secret_free(self) -> None:
        d = STEP_HYBRID_MODE_D_MLDSA.to_dict()
        assert "step_id" in d
        assert "stage" in d
        assert "algorithm_id" in d
        assert "private_key" not in d
        assert "shared_secret" not in d


class TestMigrationPath:
    """Verify MigrationPath definitions, step counts, and sequence validation."""

    def test_empty_steps_raises(self) -> None:
        with pytest.raises(ConfigurationError):
            MigrationPath(
                path_id="invalid_empty",
                name="Empty Path",
                description="Invalid empty path",
                steps=[],
            )

    def test_primary_mldsa_path(self) -> None:
        path = PATH_PRIMARY_MLDSA
        assert path.step_count == 3
        assert path.initial_step.stage == MigrationStage.CLASSICAL
        assert path.final_step.stage == MigrationStage.PURE_PQC
        valid, msgs = path.validate_path()
        assert valid is True
        assert len(msgs) == 2

    def test_alternative_slhdsa_path(self) -> None:
        path = PATH_ALTERNATIVE_SLHDSA
        assert path.step_count == 3
        valid, msgs = path.validate_path()
        assert valid is True

    def test_hybrid_ecdsa_path(self) -> None:
        path = PATH_HYBRID_ECDSA
        assert path.step_count == 2
        valid, msgs = path.validate_path()
        assert valid is True

    def test_rollback_path_validation(self) -> None:
        path = PATH_ROLLBACK_MLDSA
        assert path.step_count == 2
        # Allowed with rollback=True
        valid, _ = path.validate_path(allow_rollback=True)
        assert valid is True
        # Disallowed with rollback=False
        invalid, msgs = path.validate_path(allow_rollback=False)
        assert invalid is False

    def test_pure_pqc_transition_path(self) -> None:
        path = PATH_PURE_PQC_TRANSITION
        assert path.step_count == 2
        valid, _ = path.validate_path()
        assert valid is True

    def test_get_standard_paths(self) -> None:
        paths = get_standard_paths()
        assert len(paths) == 5
        assert "EXP_1_PRIMARY_MLDSA" in paths
        assert "EXP_2_ALTERNATIVE_SLHDSA" in paths
        assert "EXP_3_HYBRID_ECDSA" in paths
        assert "EXP_4_ROLLBACK_MLDSA" in paths
        assert "EXP_5_PURE_PQC_TRANSITION" in paths
