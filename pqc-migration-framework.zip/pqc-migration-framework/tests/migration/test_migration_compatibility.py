"""
tests/migration/test_migration_compatibility.py
Post-Quantum Secure Communication & Migration Framework

Unit tests for pairwise cross-suite and cross-stage compatibility matrix and isolation.
"""

from __future__ import annotations

import pytest

from src.config.crypto_config import ModeFactory
from src.config.modes import Mode
from src.migration.migration_experiment import MigrationExperimentRunner
from src.migration.migration_result import CompatibilityResult


class TestMigrationCompatibilityMatrix:
    """Verify pairwise cross-suite isolation across all 6 configurations."""

    @pytest.fixture
    def runner(self) -> MigrationExperimentRunner:
        return MigrationExperimentRunner()

    def test_full_compatibility_matrix(self, runner: MigrationExperimentRunner) -> None:
        results = runner.run_compatibility_matrix()
        # 6 configurations x 6 configurations = 36 pairwise tests
        assert len(results) == 36

        accept_count = 0
        reject_count = 0

        for r in results:
            assert isinstance(r, CompatibilityResult)
            assert r.isolation_preserved is True, f"Failed isolation for sender={r.sender_suite} receiver={r.receiver_suite}"
            if r.expected_outcome == "ACCEPT":
                assert r.actual_outcome == "ACCEPT"
                accept_count += 1
            else:
                assert r.actual_outcome == "REJECT"
                reject_count += 1

        assert accept_count == 6
        assert reject_count == 30
