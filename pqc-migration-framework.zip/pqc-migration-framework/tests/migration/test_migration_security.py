"""
tests/migration/test_migration_security.py
Post-Quantum Secure Communication & Migration Framework

Unit tests for tamper mutation rejection, suite manipulation rejection, and security validation during migration.
"""

from __future__ import annotations

import base64
import pytest

from src.communication.message_bundle import SecureMessage
from src.communication.secure_communicator import SecureCommunicator
from src.exceptions import (
    AuthenticationFailureError,
    ModeMismatchError,
    PQCFrameworkError,
    SignatureVerificationError,
)
from src.migration.migration_path import (
    STEP_CLASSICAL_MODE_A,
    STEP_HYBRID_MODE_D_MLDSA,
    STEP_PURE_PQC_MODE_B,
)


class TestMigrationSecurityValidation:
    """Verify that tampering at any migration stage is strictly rejected."""

    @pytest.mark.parametrize("step", [
        STEP_CLASSICAL_MODE_A,
        STEP_HYBRID_MODE_D_MLDSA,
        STEP_PURE_PQC_MODE_B,
    ])
    def test_tampered_ciphertext_rejected(self, step) -> None:
        cfg = step.build_config()
        comm = SecureCommunicator(cfg)
        rx_kp = cfg.key_exchange.generate_keypair()

        _, msg = comm.send(
            plaintext=b"Sensitive migration message",
            receiver_ke_public_key=rx_kp.public_key,
            aad=b"auth-data",
        )

        d = msg.to_dict()
        ct_bytes = bytearray(msg.ciphertext)
        ct_bytes[0] ^= 0x01
        d["ciphertext"] = base64.b64encode(bytes(ct_bytes)).decode("ascii")
        tampered = SecureMessage.from_dict(d)

        with pytest.raises((SignatureVerificationError, AuthenticationFailureError, PQCFrameworkError)):
            comm.receive(
                message=tampered,
                receiver_ke_private_key=rx_kp.private_key,
                aad=b"auth-data",
            )

    @pytest.mark.parametrize("step", [
        STEP_CLASSICAL_MODE_A,
        STEP_HYBRID_MODE_D_MLDSA,
        STEP_PURE_PQC_MODE_B,
    ])
    def test_tampered_signature_rejected(self, step) -> None:
        cfg = step.build_config()
        comm = SecureCommunicator(cfg)
        rx_kp = cfg.key_exchange.generate_keypair()

        _, msg = comm.send(
            plaintext=b"Sensitive migration message",
            receiver_ke_public_key=rx_kp.public_key,
            aad=b"auth-data",
        )

        d = msg.to_dict()
        sig_bytes = bytearray(msg.signature)
        sig_bytes[0] ^= 0x01
        d["signature"] = base64.b64encode(bytes(sig_bytes)).decode("ascii")
        tampered = SecureMessage.from_dict(d)

        with pytest.raises((SignatureVerificationError, PQCFrameworkError)):
            comm.receive(
                message=tampered,
                receiver_ke_private_key=rx_kp.private_key,
                aad=b"auth-data",
            )

    @pytest.mark.parametrize("step", [
        STEP_CLASSICAL_MODE_A,
        STEP_HYBRID_MODE_D_MLDSA,
        STEP_PURE_PQC_MODE_B,
    ])
    def test_tampered_algorithm_id_rejected(self, step) -> None:
        cfg = step.build_config()
        comm = SecureCommunicator(cfg)
        rx_kp = cfg.key_exchange.generate_keypair()

        _, msg = comm.send(
            plaintext=b"Sensitive migration message",
            receiver_ke_public_key=rx_kp.public_key,
            aad=b"auth-data",
        )

        d = msg.to_dict()
        d["algorithm_id"] = "TAMPERED_ALGORITHM_ID"
        tampered = SecureMessage.from_dict(d)

        with pytest.raises((ModeMismatchError, PQCFrameworkError)):
            comm.receive(
                message=tampered,
                receiver_ke_private_key=rx_kp.private_key,
                aad=b"auth-data",
            )
