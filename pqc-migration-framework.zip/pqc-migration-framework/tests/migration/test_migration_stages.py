"""
tests/migration/test_migration_stages.py
Post-Quantum Secure Communication & Migration Framework

Unit tests for MigrationStage enum, mappings, and transition validation rules.
"""

from __future__ import annotations

import pytest

from src.config.modes import (
    CLASSICAL_ECDH_ECDSA_AES256_GCM,
    HYBRID_ECDH_MLKEM_ECDSA_AES256_GCM,
    HYBRID_ECDH_MLKEM_MLDSA_AES256_GCM,
    HYBRID_ECDH_MLKEM_SLHDSA_AES256_GCM,
    PQC_MLKEM_MLDSA_AES256_GCM,
    PQC_MLKEM_SLHDSA_AES256_GCM,
    Mode,
)
from src.exceptions import ConfigurationError, UnsupportedAlgorithmError
from src.migration.migration_stage import (
    MigrationStage,
    stage_from_mode,
    stage_from_suite,
    validate_stage_transition,
)


class TestMigrationStageDefinitions:
    """Verify enum values and string representations."""

    def test_stage_enum_values(self) -> None:
        assert MigrationStage.CLASSICAL.value == "CLASSICAL"
        assert MigrationStage.HYBRID.value == "HYBRID"
        assert MigrationStage.PURE_PQC.value == "PURE_PQC"
        assert str(MigrationStage.CLASSICAL) == "CLASSICAL"
        assert str(MigrationStage.HYBRID) == "HYBRID"
        assert str(MigrationStage.PURE_PQC) == "PURE_PQC"


class TestStageMapping:
    """Verify mode and suite mappings to stages."""

    def test_stage_from_mode(self) -> None:
        assert stage_from_mode(Mode.A) == MigrationStage.CLASSICAL
        assert stage_from_mode("A") == MigrationStage.CLASSICAL
        assert stage_from_mode(Mode.D) == MigrationStage.HYBRID
        assert stage_from_mode("D") == MigrationStage.HYBRID
        assert stage_from_mode(Mode.B) == MigrationStage.PURE_PQC
        assert stage_from_mode("B") == MigrationStage.PURE_PQC
        assert stage_from_mode(Mode.C) == MigrationStage.PURE_PQC
        assert stage_from_mode("C") == MigrationStage.PURE_PQC

    def test_stage_from_invalid_mode_raises(self) -> None:
        with pytest.raises((ConfigurationError, UnsupportedAlgorithmError)):
            stage_from_mode("INVALID_MODE")

    def test_stage_from_suite(self) -> None:
        assert stage_from_suite(CLASSICAL_ECDH_ECDSA_AES256_GCM) == MigrationStage.CLASSICAL
        assert stage_from_suite(HYBRID_ECDH_MLKEM_MLDSA_AES256_GCM) == MigrationStage.HYBRID
        assert stage_from_suite(HYBRID_ECDH_MLKEM_SLHDSA_AES256_GCM) == MigrationStage.HYBRID
        assert stage_from_suite(HYBRID_ECDH_MLKEM_ECDSA_AES256_GCM) == MigrationStage.HYBRID
        assert stage_from_suite(PQC_MLKEM_MLDSA_AES256_GCM) == MigrationStage.PURE_PQC
        assert stage_from_suite(PQC_MLKEM_SLHDSA_AES256_GCM) == MigrationStage.PURE_PQC

    def test_stage_from_unknown_suite_raises(self) -> None:
        with pytest.raises(ConfigurationError):
            stage_from_suite("UNKNOWN_NONEXISTENT_SUITE")


class TestStageTransitionValidation:
    """Verify validation of forward, flash-cut, rollback, and disallowed transitions."""

    def test_valid_forward_transitions(self) -> None:
        valid1, _ = validate_stage_transition(MigrationStage.CLASSICAL, MigrationStage.HYBRID)
        assert valid1 is True

        valid2, _ = validate_stage_transition(MigrationStage.HYBRID, MigrationStage.PURE_PQC)
        assert valid2 is True

        valid3, _ = validate_stage_transition(MigrationStage.CLASSICAL, MigrationStage.PURE_PQC)
        assert valid3 is True

    def test_valid_intra_stage_transitions(self) -> None:
        valid1, _ = validate_stage_transition(MigrationStage.CLASSICAL, MigrationStage.CLASSICAL)
        assert valid1 is True

        valid2, _ = validate_stage_transition(MigrationStage.HYBRID, MigrationStage.HYBRID)
        assert valid2 is True

        valid3, _ = validate_stage_transition(MigrationStage.PURE_PQC, MigrationStage.PURE_PQC)
        assert valid3 is True

    def test_controlled_rollback_allowed(self) -> None:
        valid1, msg1 = validate_stage_transition(MigrationStage.HYBRID, MigrationStage.CLASSICAL, allow_rollback=True)
        assert valid1 is True
        assert "rollback" in msg1.lower()

        valid2, msg2 = validate_stage_transition(MigrationStage.PURE_PQC, MigrationStage.HYBRID, allow_rollback=True)
        assert valid2 is True
        assert "rollback" in msg2.lower()

        valid3, msg3 = validate_stage_transition(MigrationStage.PURE_PQC, MigrationStage.CLASSICAL, allow_rollback=True)
        assert valid3 is True
        assert "rollback" in msg3.lower()

    def test_rollback_disallowed_when_forbidden(self) -> None:
        valid1, msg1 = validate_stage_transition(MigrationStage.HYBRID, MigrationStage.CLASSICAL, allow_rollback=False)
        assert valid1 is False
        assert "unauthorized" in msg1.lower()

        valid2, msg2 = validate_stage_transition(MigrationStage.PURE_PQC, MigrationStage.HYBRID, allow_rollback=False)
        assert valid2 is False

        valid3, msg3 = validate_stage_transition(MigrationStage.PURE_PQC, MigrationStage.CLASSICAL, allow_rollback=False)
        assert valid3 is False
