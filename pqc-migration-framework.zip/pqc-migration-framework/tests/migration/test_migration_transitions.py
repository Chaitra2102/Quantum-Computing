"""
tests/migration/test_migration_transitions.py
Post-Quantum Secure Communication & Migration Framework

Unit tests for transition delta calculations, classification, and benchmark metrics integration.
"""

from __future__ import annotations

import pytest

from src.config.modes import (
    CLASSICAL_ECDH_ECDSA_AES256_GCM,
    HYBRID_ECDH_MLKEM_MLDSA_AES256_GCM,
    PQC_MLKEM_MLDSA_AES256_GCM,
)
from src.migration.migration_experiment import MigrationExperimentRunner
from src.migration.migration_path import (
    STEP_CLASSICAL_MODE_A,
    STEP_HYBRID_MODE_D_ECDSA,
    STEP_HYBRID_MODE_D_MLDSA,
    STEP_HYBRID_MODE_D_SLHDSA,
    STEP_PURE_PQC_MODE_B,
    STEP_PURE_PQC_MODE_C,
)
from src.migration.migration_result import TransitionResult


class TestTransitionDeltaCalculations:
    """Verify exact calculation of quantitative transition deltas."""

    @pytest.fixture
    def runner(self) -> MigrationExperimentRunner:
        return MigrationExperimentRunner()

    def test_classical_to_hybrid_mldsa_transition(self, runner: MigrationExperimentRunner) -> None:
        delta = runner.calculate_transition_delta(STEP_CLASSICAL_MODE_A, STEP_HYBRID_MODE_D_MLDSA)
        assert isinstance(delta, TransitionResult)
        assert delta.source_stage == "CLASSICAL"
        assert delta.target_stage == "HYBRID"
        assert delta.transition_type == "FORWARD"
        assert delta.transition_valid is True

        # Mode A wire (2084) -> Mode D ML-DSA wire (11965) = +9881 bytes (+474.14%)
        assert delta.wire_size_delta_bytes == 9881
        assert pytest.approx(delta.wire_size_pct_delta, abs=0.05) == 474.14

        # Mode A raw (1373) -> Mode D ML-DSA raw (8783) = +7410 bytes (+539.69%)
        assert delta.raw_crypto_size_delta_bytes == 7410
        assert pytest.approx(delta.raw_crypto_size_pct_delta, abs=0.05) == 539.69

        # Latency delta: 6811.588 - 7678.192 = -866.604 us (-11.29%)
        assert pytest.approx(delta.latency_delta_us, abs=0.1) == -866.604
        assert pytest.approx(delta.latency_pct_delta, abs=0.05) == -11.29

    def test_hybrid_to_pure_pqc_mldsa_transition(self, runner: MigrationExperimentRunner) -> None:
        delta = runner.calculate_transition_delta(STEP_HYBRID_MODE_D_MLDSA, STEP_PURE_PQC_MODE_B)
        assert delta.source_stage == "HYBRID"
        assert delta.target_stage == "PURE_PQC"
        assert delta.transition_type == "FORWARD"
        assert delta.transition_valid is True

        # Mode D ML-DSA wire (11965) -> Mode B wire (11693) = -272 bytes (-2.27%)
        assert delta.wire_size_delta_bytes == -272
        assert pytest.approx(delta.wire_size_pct_delta, abs=0.05) == -2.27

        # Mode D ML-DSA raw (8783) -> Mode B raw (8585) = -198 bytes (-2.25%)
        assert delta.raw_crypto_size_delta_bytes == -198
        assert pytest.approx(delta.raw_crypto_size_pct_delta, abs=0.05) == -2.25

        # Latency delta: 2209.036 - 6811.588 = -4602.552 us (-67.57%)
        assert pytest.approx(delta.latency_delta_us, abs=0.1) == -4602.552
        assert pytest.approx(delta.latency_pct_delta, abs=0.05) == -67.57

    def test_rollback_transition(self, runner: MigrationExperimentRunner) -> None:
        delta = runner.calculate_transition_delta(STEP_HYBRID_MODE_D_MLDSA, STEP_CLASSICAL_MODE_A)
        assert delta.transition_type == "ROLLBACK"
        assert delta.transition_valid is True
        assert delta.wire_size_delta_bytes == -9881
        assert pytest.approx(delta.latency_delta_us, abs=0.1) == 866.604

    def test_intra_pqc_transition(self, runner: MigrationExperimentRunner) -> None:
        delta = runner.calculate_transition_delta(STEP_PURE_PQC_MODE_B, STEP_PURE_PQC_MODE_C)
        assert delta.transition_type == "INTRA_STAGE"
        assert delta.transition_valid is True
        assert delta.wire_size_delta_bytes == (27506 - 11693)
