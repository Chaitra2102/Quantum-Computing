"""
tests/migration/test_migration_functionality.py
Post-Quantum Secure Communication & Migration Framework

Integration tests for functional continuity and plaintext recovery across migration stages and payload sizes.
"""

from __future__ import annotations

import pytest

from src.migration.migration_experiment import MigrationExperimentRunner
from src.migration.migration_path import (
    STEP_CLASSICAL_MODE_A,
    STEP_HYBRID_MODE_D_ECDSA,
    STEP_HYBRID_MODE_D_MLDSA,
    STEP_HYBRID_MODE_D_SLHDSA,
    STEP_PURE_PQC_MODE_B,
    STEP_PURE_PQC_MODE_C,
)


class TestMigrationFunctionality:
    """Verify key establishment, message exchange, and exact plaintext recovery across migration steps."""

    @pytest.fixture
    def runner(self) -> MigrationExperimentRunner:
        return MigrationExperimentRunner()

    @pytest.mark.parametrize("step", [
        STEP_CLASSICAL_MODE_A,
        STEP_HYBRID_MODE_D_MLDSA,
        STEP_PURE_PQC_MODE_B,
        STEP_HYBRID_MODE_D_SLHDSA,
        STEP_PURE_PQC_MODE_C,
        STEP_HYBRID_MODE_D_ECDSA,
    ])
    def test_step_functional_continuity(self, runner: MigrationExperimentRunner, step) -> None:
        payloads = [b"Small payload 64B" + b"X" * 47, b"Medium payload 1KiB" * 53, b"Large 16KiB" * 1024]
        res = runner.run_step(step, payloads=payloads)
        assert res.success is True
        assert res.key_establishment_valid is True
        assert res.authentication_valid is True
        assert res.encryption_valid is True
        assert res.decryption_valid is True
        assert res.plaintext_integrity_valid is True
        assert res.tamper_rejection_valid is True
        assert len(res.payload_bytes_tested) == 3
