"""
tests/migration/test_migration_results.py
Post-Quantum Secure Communication & Migration Framework

Unit tests for migration report generation, history logging, and secret non-exposure.
"""

from __future__ import annotations

import json
from pathlib import Path
import pytest

from src.migration.migration_experiment import MigrationExperimentRunner
from src.migration.migration_path import PATH_PRIMARY_MLDSA
from src.migration.migration_result import MigrationExperimentReport


class TestMigrationResults:
    """Verify MigrationExperimentReport structure, history, and secret non-exposure."""

    @pytest.fixture
    def runner(self) -> MigrationExperimentRunner:
        return MigrationExperimentRunner()

    def test_run_path_report_structure(self, runner: MigrationExperimentRunner) -> None:
        report = runner.run_path(PATH_PRIMARY_MLDSA, payloads=[b"Test payload"])
        assert isinstance(report, MigrationExperimentReport)
        assert report.status == "SUCCESS"
        assert report.all_functional_passed is True
        assert report.all_security_passed is True
        assert len(report.steps) == 3
        assert len(report.transitions) == 2
        assert len(report.history) == 3

    def test_report_is_secret_free(self, runner: MigrationExperimentRunner) -> None:
        report = runner.run_path(PATH_PRIMARY_MLDSA, payloads=[b"Test payload"])
        d = report.to_dict()
        raw_json = json.dumps(d)

        # Confirm absolute absence of secret keywords/keys
        forbidden_substrings = [
            "private_key",
            "shared_secret",
            "aes_key",
            "hkdf_intermediate",
            "raw_secret",
        ]
        for term in forbidden_substrings:
            assert term not in raw_json.lower()

    def test_run_all_experiments_artifact_generation(self, runner: MigrationExperimentRunner) -> None:
        res = runner.run_all_experiments()
        assert res["all_functional_continuity_verified"] is True
        assert res["all_security_tamper_rejected"] is True
        assert res["all_compatibility_isolation_preserved"] is True

        res_dir = Path("results/migration")
        assert (res_dir / "migration_results.json").exists()
        assert (res_dir / "migration_history.json").exists()
        assert (res_dir / "migration_compatibility.csv").exists()
        assert (res_dir / "migration_deltas.csv").exists()
