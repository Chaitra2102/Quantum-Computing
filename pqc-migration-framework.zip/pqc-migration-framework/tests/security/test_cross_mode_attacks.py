"""
tests/security/test_cross_mode_attacks.py
Post-Quantum Secure Communication & Migration Framework

Cross-mode substitution and algorithm identifier tampering security tests.

Phase 9: Validates that messages from one mode cannot be processed by a receiver
configured for a different mode, across all pairwise combinations and Mode D variants.
"""

import pytest

from src.config.modes import (
    CLASSICAL_ECDH_ECDSA_AES256_GCM,
    HYBRID_ECDH_MLKEM_ECDSA_AES256_GCM,
    HYBRID_ECDH_MLKEM_MLDSA_AES256_GCM,
    HYBRID_ECDH_MLKEM_SLHDSA_AES256_GCM,
    PQC_MLKEM_MLDSA_AES256_GCM,
    PQC_MLKEM_SLHDSA_AES256_GCM,
    Mode,
)
from src.security_tests.attack_simulator import AttackSimulator


class TestCrossModeSubstitutionAttacks:
    """Security tests verifying complete cross-mode isolation."""

    @pytest.mark.parametrize(
        ("sender_mode", "receiver_mode"),
        [
            (Mode.A, Mode.B),
            (Mode.A, Mode.C),
            (Mode.A, Mode.D),
            (Mode.B, Mode.A),
            (Mode.B, Mode.C),
            (Mode.B, Mode.D),
            (Mode.C, Mode.A),
            (Mode.C, Mode.B),
            (Mode.C, Mode.D),
            (Mode.D, Mode.A),
            (Mode.D, Mode.B),
            (Mode.D, Mode.C),
        ],
    )
    def test_pairwise_cross_mode_substitution_rejected(
        self, sender_mode: Mode, receiver_mode: Mode
    ):
        result = AttackSimulator.simulate_cross_mode_substitution(
            sender_mode=sender_mode, receiver_mode=receiver_mode
        )
        assert result.passed is True
        assert result.rejected is True
        assert result.rejection_type == "ModeMismatchError"
        assert result.plaintext_recovered is False

    @pytest.mark.parametrize(
        ("sender_sig", "receiver_sig"),
        [
            ("mldsa", "ecdsa"),
            ("ecdsa", "slhdsa"),
            ("slhdsa", "mldsa"),
            ("mldsa", "slhdsa"),
            ("ecdsa", "mldsa"),
            ("slhdsa", "ecdsa"),
        ],
    )
    def test_mode_d_intra_cross_signature_substitution_rejected(
        self, sender_sig: str, receiver_sig: str
    ):
        result = AttackSimulator.simulate_cross_mode_substitution(
            sender_mode=Mode.D,
            receiver_mode=Mode.D,
            sender_sig=sender_sig,
            receiver_sig=receiver_sig,
        )
        assert result.passed is True
        assert result.rejected is True
        assert result.rejection_type == "ModeMismatchError"
        assert result.plaintext_recovered is False


class TestAlgorithmIdTamperingAttacks:
    """Security tests verifying that altering algorithm_id causes immediate rejection."""

    def test_mode_a_claiming_mode_b_rejected(self):
        result = AttackSimulator.simulate_algorithm_id_tampering(
            source_mode=Mode.A, target_suite_id=PQC_MLKEM_MLDSA_AES256_GCM
        )
        assert result.passed is True
        assert result.rejection_type == "ModeMismatchError"

    def test_mode_b_claiming_mode_c_rejected(self):
        result = AttackSimulator.simulate_algorithm_id_tampering(
            source_mode=Mode.B, target_suite_id=PQC_MLKEM_SLHDSA_AES256_GCM
        )
        assert result.passed is True
        assert result.rejection_type == "ModeMismatchError"

    def test_mode_c_claiming_mode_d_rejected(self):
        result = AttackSimulator.simulate_algorithm_id_tampering(
            source_mode=Mode.C, target_suite_id=HYBRID_ECDH_MLKEM_MLDSA_AES256_GCM
        )
        assert result.passed is True
        assert result.rejection_type == "ModeMismatchError"

    def test_mode_d_mldsa_claiming_ecdsa_rejected(self):
        result = AttackSimulator.simulate_algorithm_id_tampering(
            source_mode=Mode.D,
            target_suite_id=HYBRID_ECDH_MLKEM_ECDSA_AES256_GCM,
            sig_type="mldsa",
        )
        assert result.passed is True
        assert result.rejection_type == "ModeMismatchError"
