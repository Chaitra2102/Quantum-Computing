"""
tests/security/test_replay_behavior.py
Post-Quantum Secure Communication & Migration Framework

Replay behavior characterization tests.

Phase 9: Evaluates and documents behavior when legitimate messages are replayed
against the stateless communication layer.
"""

from src.config.modes import Mode
from src.security_tests.attack_simulator import AttackSimulator


class TestReplayBehavior:
    """Characterization tests for message replay in the stateless framework layer."""

    def test_replay_experiment_characterization(self):
        result = AttackSimulator.simulate_replay_experiment(mode=Mode.B)
        assert result.passed is True
        assert result.information_leak_detected is False
        assert result.accepted is True  # Documents stateless point-to-point behavior
