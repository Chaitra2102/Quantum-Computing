"""
tests/security/test_tampering.py
Post-Quantum Secure Communication & Migration Framework

SECURITY / TAMPERING TESTS — Classical Mode A

Demonstrates that the classical system detects ALL forms of tampering.

Test categories:
  A. Modified ciphertext    → AES-GCM authentication failure
  B. Modified signature     → ECDSA verification failure
  C. Modified signed data   → signature verification failure
  D. Wrong verification key → signature verification failure

Security invariants tested:
  - Tampered data is NEVER accepted as authentic plaintext.
  - AuthenticationFailureError is raised for ciphertext tampering.
  - SignatureVerificationError is raised for signature/key tampering.
  - Errors are NOT caught and suppressed.
  - No plaintext is returned from a tampered message.

These tests demonstrate the functional security properties of the system.
They do NOT constitute a formal cryptographic security proof.

ARCHITECTURE.md § 6 — Security Test Architecture (TEST-3, TEST-4, TEST-5)
PROJECT_SPEC.md § 7 — Security Demonstrations
"""

import copy
import os

import pytest

from src.communication.message_bundle import PROTOCOL_VERSION, SecureMessage
from src.communication.secure_communicator import SecureCommunicator
from src.config.crypto_config import CryptoConfig, ModeFactory
from src.config.modes import CLASSICAL_ECDH_ECDSA_AES256_GCM, Mode
from src.exceptions import AuthenticationFailureError, SignatureVerificationError


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture
def mode_a_config() -> CryptoConfig:
    return ModeFactory.build(Mode.A)


@pytest.fixture
def communicator(mode_a_config: CryptoConfig) -> SecureCommunicator:
    return SecureCommunicator(mode_a_config)


@pytest.fixture
def receiver_ke_keypair(mode_a_config: CryptoConfig):
    """Bob's (receiver's) key-establishment key pair."""
    return mode_a_config.key_exchange.generate_keypair()


@pytest.fixture
def sent_message_and_kps(
    communicator: SecureCommunicator,
    receiver_ke_keypair,
):
    """
    Fixture that produces a valid (sender_keypairs, message) tuple.
    Tests use this as the baseline to tamper with.
    """
    plaintext = b"Original authentic message that must not be accepted if tampered."
    sender_kps, message = communicator.send(
        plaintext=plaintext,
        receiver_ke_public_key=receiver_ke_keypair.public_key,
    )
    return sender_kps, message, plaintext


# ---------------------------------------------------------------------------
# Helper: rebuild SecureMessage with one modified field
# ---------------------------------------------------------------------------


def _with(original: SecureMessage, **overrides) -> SecureMessage:
    """
    Create a new SecureMessage replacing specific fields.
    Used to simulate targeted tampering without touching other fields.
    """
    d = original.to_dict()
    import base64
    for field, value in overrides.items():
        if isinstance(value, bytes):
            d[field] = base64.b64encode(value).decode("ascii")
        else:
            d[field] = value
    return SecureMessage.from_dict(d)


def _flip_byte(data: bytes, index: int = 0) -> bytes:
    """Flip a byte in data at the given index."""
    result = bytearray(data)
    result[index] ^= 0xFF
    return bytes(result)


# ---------------------------------------------------------------------------
# A. Modified ciphertext → AES-GCM authentication failure
# ---------------------------------------------------------------------------


class TestTamperingModifiedCiphertext:
    """
    Security requirement A:
    Modified ciphertext MUST be rejected — NO plaintext is returned.

    Important security-architecture note:
    The ECDSA signature covers (ciphertext || nonce). Therefore, when the
    ciphertext is modified AFTER signing, the signature verification step
    (verify-then-decrypt ordering) detects the tampering FIRST and raises
    SignatureVerificationError — before AES-GCM decryption is even attempted.

    Both AuthenticationFailureError and SignatureVerificationError are valid
    security outcomes: in both cases the tampered message is REJECTED and no
    plaintext is returned. Tests in this class accept either exception to
    correctly reflect the verify-then-decrypt security ordering.
    """

    def test_modified_ciphertext_body_rejects_message(
        self,
        communicator: SecureCommunicator,
        receiver_ke_keypair,
        sent_message_and_kps,
    ) -> None:
        """Flipping any byte in the ciphertext body must cause message rejection."""
        _, original_msg, _ = sent_message_and_kps
        tampered_ct = _flip_byte(original_msg.ciphertext, 0)
        tampered_msg = _with(original_msg, ciphertext=tampered_ct)

        # Ciphertext is part of signed data; signature check fires first.
        with pytest.raises((SignatureVerificationError, AuthenticationFailureError)):
            communicator.receive(tampered_msg, receiver_ke_keypair.private_key)

    def test_modified_ciphertext_middle_rejects_message(
        self,
        communicator: SecureCommunicator,
        receiver_ke_keypair,
        sent_message_and_kps,
    ) -> None:
        _, original_msg, _ = sent_message_and_kps
        idx = len(original_msg.ciphertext) // 2
        tampered_ct = _flip_byte(original_msg.ciphertext, idx)
        tampered_msg = _with(original_msg, ciphertext=tampered_ct)

        with pytest.raises((SignatureVerificationError, AuthenticationFailureError)):
            communicator.receive(tampered_msg, receiver_ke_keypair.private_key)

    def test_modified_auth_tag_rejects_message(
        self,
        communicator: SecureCommunicator,
        receiver_ke_keypair,
        sent_message_and_kps,
    ) -> None:
        """The last 16 bytes of ciphertext are the AES-GCM authentication tag."""
        _, original_msg, _ = sent_message_and_kps
        tampered_ct = _flip_byte(original_msg.ciphertext, -1)
        tampered_msg = _with(original_msg, ciphertext=tampered_ct)

        with pytest.raises((SignatureVerificationError, AuthenticationFailureError)):
            communicator.receive(tampered_msg, receiver_ke_keypair.private_key)

    def test_replaced_ciphertext_rejects_message(
        self,
        communicator: SecureCommunicator,
        receiver_ke_keypair,
        sent_message_and_kps,
    ) -> None:
        """Replacing the entire ciphertext with random bytes must be rejected."""
        _, original_msg, _ = sent_message_and_kps
        random_ct = os.urandom(len(original_msg.ciphertext))
        tampered_msg = _with(original_msg, ciphertext=random_ct)

        with pytest.raises((SignatureVerificationError, AuthenticationFailureError)):
            communicator.receive(tampered_msg, receiver_ke_keypair.private_key)

    def test_tampered_ciphertext_is_never_decrypted_to_plaintext(
        self,
        communicator: SecureCommunicator,
        receiver_ke_keypair,
        sent_message_and_kps,
    ) -> None:
        """
        Core security invariant:
        A tampered message must NEVER yield plaintext — it must always raise.
        Both SignatureVerificationError and AuthenticationFailureError are
        valid rejection outcomes.
        """
        _, original_msg, original_plaintext = sent_message_and_kps
        tampered_ct = _flip_byte(original_msg.ciphertext, 0)
        tampered_msg = _with(original_msg, ciphertext=tampered_ct)

        raised = False
        result = None
        try:
            result = communicator.receive(tampered_msg, receiver_ke_keypair.private_key)
        except (SignatureVerificationError, AuthenticationFailureError):
            raised = True

        assert raised, (
            "receive() must raise a security exception for tampered ciphertext. "
            "No plaintext should be returned."
        )
        assert result is None, "No plaintext should be returned for tampered ciphertext."


# ---------------------------------------------------------------------------
# B. Modified signature → ECDSA verification failure
# ---------------------------------------------------------------------------


class TestTamperingModifiedSignature:
    """
    Security requirement B:
    A modified signature MUST result in signature verification failure.
    SignatureVerificationError is raised; decryption is never attempted.
    """

    def test_modified_signature_first_byte_fails(
        self,
        communicator: SecureCommunicator,
        receiver_ke_keypair,
        sent_message_and_kps,
    ) -> None:
        _, original_msg, _ = sent_message_and_kps
        # Flip a byte in the signature body (skip DER header bytes to get a
        # byte-flip that produces an invalid value, not just a parse error)
        tampered_sig = _flip_byte(original_msg.signature, len(original_msg.signature) // 2)
        tampered_msg = _with(original_msg, signature=tampered_sig)

        with pytest.raises(SignatureVerificationError):
            communicator.receive(tampered_msg, receiver_ke_keypair.private_key)

    def test_replaced_signature_with_random_bytes_fails(
        self,
        communicator: SecureCommunicator,
        receiver_ke_keypair,
        sent_message_and_kps,
    ) -> None:
        _, original_msg, _ = sent_message_and_kps
        fake_sig = os.urandom(len(original_msg.signature))
        tampered_msg = _with(original_msg, signature=fake_sig)

        with pytest.raises((SignatureVerificationError, Exception)):
            communicator.receive(tampered_msg, receiver_ke_keypair.private_key)

    def test_tampered_signature_is_checked_before_decryption(
        self,
        communicator: SecureCommunicator,
        receiver_ke_keypair,
        sent_message_and_kps,
    ) -> None:
        """
        Verify-then-decrypt ordering:
        Signature must be checked BEFORE any decryption attempt.
        Tampered signature → SignatureVerificationError (not AuthenticationFailureError).
        """
        _, original_msg, _ = sent_message_and_kps
        tampered_sig = _flip_byte(original_msg.signature, len(original_msg.signature) // 2)
        tampered_msg = _with(original_msg, signature=tampered_sig)

        with pytest.raises(SignatureVerificationError):
            communicator.receive(tampered_msg, receiver_ke_keypair.private_key)


# ---------------------------------------------------------------------------
# C. Modified signed data (ciphertext/nonce) → signature verification failure
# ---------------------------------------------------------------------------


class TestTamperingModifiedSignedData:
    """
    Security requirement C:
    If the data that was signed (ciphertext || nonce) is modified after signing,
    signature verification must FAIL.
    """

    def test_modified_ciphertext_causes_sig_verification_failure_before_decryption(
        self,
        communicator: SecureCommunicator,
        receiver_ke_keypair,
        sent_message_and_kps,
    ) -> None:
        """
        The signature covers (ciphertext || nonce).
        Modifying the ciphertext invalidates the signature, which is
        detected at step 7 (signature verification) before step 10 (decryption).

        Note: Because the signature check happens first and the ciphertext is part
        of the signed data, a tampered ciphertext may cause EITHER
        SignatureVerificationError (signature fails first) OR AuthenticationFailureError
        (if the signature oddly passes — extremely unlikely). Both are acceptable rejections.
        """
        _, original_msg, _ = sent_message_and_kps
        tampered_ct = _flip_byte(original_msg.ciphertext, 0)
        tampered_msg = _with(original_msg, ciphertext=tampered_ct)

        # The message MUST be rejected — either exception is a valid rejection.
        with pytest.raises((SignatureVerificationError, AuthenticationFailureError)):
            communicator.receive(tampered_msg, receiver_ke_keypair.private_key)

    def test_modified_nonce_causes_rejection(
        self,
        communicator: SecureCommunicator,
        receiver_ke_keypair,
        sent_message_and_kps,
    ) -> None:
        """
        Nonce is also part of the signed data. Modifying it invalidates the signature.
        """
        _, original_msg, _ = sent_message_and_kps
        bad_nonce = os.urandom(12)
        while bad_nonce == original_msg.nonce:
            bad_nonce = os.urandom(12)
        tampered_msg = _with(original_msg, nonce=bad_nonce)

        with pytest.raises((SignatureVerificationError, AuthenticationFailureError)):
            communicator.receive(tampered_msg, receiver_ke_keypair.private_key)


# ---------------------------------------------------------------------------
# D. Wrong verification key → signature verification failure
# ---------------------------------------------------------------------------


class TestTamperingWrongVerificationKey:
    """
    Security requirement D:
    Presenting a different sender public key must cause signature verification failure.
    """

    def test_wrong_sig_public_key_fails_verification(
        self,
        mode_a_config: CryptoConfig,
        communicator: SecureCommunicator,
        receiver_ke_keypair,
        sent_message_and_kps,
    ) -> None:
        """
        Replace the sender's signing public key in the message with an attacker's key.
        The signature (created with the real key) must not verify with the attacker's key.
        """
        _, original_msg, _ = sent_message_and_kps
        # Generate an attacker key pair
        attacker_kp = mode_a_config.signature.generate_keypair()
        attacker_pub_bytes = mode_a_config.signature.export_public_key_bytes(
            attacker_kp.public_key
        )
        tampered_msg = _with(original_msg, sender_sig_public_key=attacker_pub_bytes)

        with pytest.raises(SignatureVerificationError):
            communicator.receive(tampered_msg, receiver_ke_keypair.private_key)

    def test_random_bytes_as_sig_key_fails(
        self,
        communicator: SecureCommunicator,
        receiver_ke_keypair,
        sent_message_and_kps,
    ) -> None:
        """A completely invalid signature key must be rejected."""
        _, original_msg, _ = sent_message_and_kps
        # Export a valid key then mangle one byte so it might or might not parse
        invalid_pub = os.urandom(len(original_msg.sender_sig_public_key))
        tampered_msg = _with(original_msg, sender_sig_public_key=invalid_pub)

        # Must not return plaintext — any exception is acceptable
        with pytest.raises(Exception):
            communicator.receive(tampered_msg, receiver_ke_keypair.private_key)

    def test_wrong_ke_public_key_causes_different_shared_secret_and_decryption_failure(
        self,
        mode_a_config: CryptoConfig,
        communicator: SecureCommunicator,
        receiver_ke_keypair,
        sent_message_and_kps,
    ) -> None:
        """
        If the KE public key in the message is swapped, the receiver derives
        a different shared secret and AES key, causing decryption to fail.

        However: since the signature is still from the real sender, step 7
        (signature verification) passes. The failure occurs at step 10
        (AES-GCM decryption).
        """
        _, original_msg, _ = sent_message_and_kps
        attacker_ke_kp = mode_a_config.key_exchange.generate_keypair()
        attacker_ke_pub_bytes = mode_a_config.key_exchange.export_public_key_bytes(
            attacker_ke_kp.public_key
        )
        tampered_msg = _with(original_msg, sender_ke_public_key=attacker_ke_pub_bytes)

        with pytest.raises(AuthenticationFailureError):
            communicator.receive(tampered_msg, receiver_ke_keypair.private_key)


# ---------------------------------------------------------------------------
# E. Valid message — control case (must not raise)
# ---------------------------------------------------------------------------


class TestTamperingControlCase:
    """
    A valid, untampered message MUST be accepted.
    This is the control case to confirm the tests are not trivially broken.
    """

    def test_valid_message_is_accepted(
        self,
        communicator: SecureCommunicator,
        receiver_ke_keypair,
        sent_message_and_kps,
    ) -> None:
        _, original_msg, original_plaintext = sent_message_and_kps
        recovered = communicator.receive(original_msg, receiver_ke_keypair.private_key)
        assert recovered == original_plaintext

    def test_valid_message_returns_exact_plaintext(
        self,
        communicator: SecureCommunicator,
        receiver_ke_keypair,
    ) -> None:
        """Verify the happy path is not affected by the tampering tests."""
        test_msg = b"This message is legitimate and should be accepted."
        _, message = communicator.send(test_msg, receiver_ke_keypair.public_key)
        recovered = communicator.receive(message, receiver_ke_keypair.private_key)
        assert recovered == test_msg
