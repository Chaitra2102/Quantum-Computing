"""
tests/security/test_malformed_messages.py
Post-Quantum Secure Communication & Migration Framework

Malformed message and truncation attack security tests.

Phase 9: Validates robust and safe error handling when encountering truncated payloads,
missing dictionary fields, and corrupted wire encodings without leaking memory/secrets.
"""

import pytest

from src.config.modes import Mode
from src.security_tests.attack_simulator import AttackSimulator


class TestMalformedMessageAttacks:
    """Security tests for structurally invalid wire messages."""

    def test_missing_required_field_rejected(self):
        result = AttackSimulator.simulate_malformed_message_attack(malformation_type="missing_field")
        assert result.passed is True
        assert result.rejected is True
        assert result.rejection_type == "MalformedMessageError"

    def test_invalid_base64_encoding_rejected(self):
        result = AttackSimulator.simulate_malformed_message_attack(malformation_type="invalid_base64")
        assert result.passed is True
        assert result.rejected is True
        assert result.rejection_type == "MalformedMessageError"


class TestTruncationAttacks:
    """Security tests for truncated payloads across modes."""

    @pytest.mark.parametrize(
        ("mode", "target_field"),
        [
            (Mode.A, "ciphertext"),
            (Mode.B, "signature"),
            (Mode.C, "signature"),
            (Mode.D, "ke_ciphertext"),
        ],
    )
    def test_field_truncation_safely_rejected(self, mode: Mode, target_field: str):
        result = AttackSimulator.simulate_truncation_attack(mode=mode, target_field=target_field)
        assert result.passed is True
        assert result.rejected is True
        assert result.plaintext_recovered is False
