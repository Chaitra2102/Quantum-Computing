"""
tests/security/test_pqc_tampering.py
Post-Quantum Secure Communication & Migration Framework

SECURITY TESTS — Tampering and Adversarial Behavior under ML-KEM

Tests verify that any active tampering with transmitted messages is reliably
detected and rejected by the receiver without exposing confidential data.

Test vectors:
  1. Tampered KEM ciphertext (ke_ciphertext flipped bits) -> Rejection.
  2. Tampered AES ciphertext (ciphertext flipped bits) -> Rejection.
  3. Tampered AES nonce -> Rejection.
  4. Tampered digital signature -> Rejection.
  5. Wrong signing public key -> Rejection.
  6. Wrong receiver private key -> Rejection.
  7. Mismatched AAD -> Rejection.
"""

import pytest

from src.communication.message_bundle import SecureMessage
from src.communication.secure_communicator import SecureCommunicator
from src.config.crypto_config import CryptoConfig, ModeFactory
from src.exceptions import (
    AuthenticationFailureError,
    InvalidKeyError,
    PQCFrameworkError,
    SignatureVerificationError,
)


@pytest.fixture
def mlkem_config() -> CryptoConfig:
    return ModeFactory.build_mlkem_baseline("ML-KEM-768")


@pytest.fixture
def comm(mlkem_config: CryptoConfig) -> SecureCommunicator:
    return SecureCommunicator(mlkem_config)


@pytest.fixture
def bob_kp(mlkem_config: CryptoConfig):
    return mlkem_config.key_exchange.generate_keypair()


TEST_PLAINTEXT = b"Classified migration payload for testing tampering detection."


class TestPQCTamperingDetection:
    """Adversarial tampering tests for ML-KEM secure communication."""

    def test_tampered_ke_ciphertext_is_rejected(
        self,
        comm: SecureCommunicator,
        bob_kp,
    ) -> None:
        """Flipping a bit in ke_ciphertext must cause decapsulation to produce wrong secret or error."""
        _, msg = comm.send(TEST_PLAINTEXT, bob_kp.public_key)
        assert msg.ke_ciphertext is not None

        # Flip the first byte
        corrupt_ke_ct = bytes([msg.ke_ciphertext[0] ^ 0xFF]) + msg.ke_ciphertext[1:]
        tampered_msg = SecureMessage(
            protocol_version=msg.protocol_version,
            algorithm_id=msg.algorithm_id,
            sender_ke_public_key=msg.sender_ke_public_key,
            sender_sig_public_key=msg.sender_sig_public_key,
            ciphertext=msg.ciphertext,
            nonce=msg.nonce,
            signature=msg.signature,
            ke_ciphertext=corrupt_ke_ct,
            metadata=msg.metadata,
        )

        # Receiver should fail to authenticate ciphertext (or raise InvalidKeyError)
        with pytest.raises((AuthenticationFailureError, InvalidKeyError, PQCFrameworkError)):
            comm.receive(tampered_msg, bob_kp.private_key)

    def test_tampered_ciphertext_fails_signature_or_auth(
        self,
        comm: SecureCommunicator,
        bob_kp,
    ) -> None:
        """Tampering with AES ciphertext violates signature over (ciphertext || nonce)."""
        _, msg = comm.send(TEST_PLAINTEXT, bob_kp.public_key)

        corrupt_ct = bytes([msg.ciphertext[0] ^ 0x01]) + msg.ciphertext[1:]
        tampered_msg = SecureMessage(
            protocol_version=msg.protocol_version,
            algorithm_id=msg.algorithm_id,
            sender_ke_public_key=msg.sender_ke_public_key,
            sender_sig_public_key=msg.sender_sig_public_key,
            ciphertext=corrupt_ct,
            nonce=msg.nonce,
            signature=msg.signature,
            ke_ciphertext=msg.ke_ciphertext,
        )

        with pytest.raises(SignatureVerificationError):
            comm.receive(tampered_msg, bob_kp.private_key)

    def test_tampered_nonce_fails_signature(
        self,
        comm: SecureCommunicator,
        bob_kp,
    ) -> None:
        """Tampering with the nonce violates the signature."""
        _, msg = comm.send(TEST_PLAINTEXT, bob_kp.public_key)

        corrupt_nonce = bytes([msg.nonce[0] ^ 0xAA]) + msg.nonce[1:]
        tampered_msg = SecureMessage(
            protocol_version=msg.protocol_version,
            algorithm_id=msg.algorithm_id,
            sender_ke_public_key=msg.sender_ke_public_key,
            sender_sig_public_key=msg.sender_sig_public_key,
            ciphertext=msg.ciphertext,
            nonce=corrupt_nonce,
            signature=msg.signature,
            ke_ciphertext=msg.ke_ciphertext,
        )

        with pytest.raises(SignatureVerificationError):
            comm.receive(tampered_msg, bob_kp.private_key)

    def test_tampered_signature_fails_verification(
        self,
        comm: SecureCommunicator,
        bob_kp,
    ) -> None:
        """Corrupt signature bytes must be rejected immediately."""
        _, msg = comm.send(TEST_PLAINTEXT, bob_kp.public_key)

        corrupt_sig = bytes([msg.signature[0] ^ 0x55]) + msg.signature[1:]
        tampered_msg = SecureMessage(
            protocol_version=msg.protocol_version,
            algorithm_id=msg.algorithm_id,
            sender_ke_public_key=msg.sender_ke_public_key,
            sender_sig_public_key=msg.sender_sig_public_key,
            ciphertext=msg.ciphertext,
            nonce=msg.nonce,
            signature=corrupt_sig,
            ke_ciphertext=msg.ke_ciphertext,
        )

        with pytest.raises(SignatureVerificationError):
            comm.receive(tampered_msg, bob_kp.private_key)

    def test_wrong_receiver_private_key_fails_auth(
        self,
        comm: SecureCommunicator,
        mlkem_config: CryptoConfig,
        bob_kp,
    ) -> None:
        """If decapsulation is attempted with Charlie's key instead of Bob's, decryption fails."""
        charlie_kp = mlkem_config.key_exchange.generate_keypair()
        _, msg = comm.send(TEST_PLAINTEXT, bob_kp.public_key)

        with pytest.raises(AuthenticationFailureError):
            comm.receive(msg, charlie_kp.private_key)

    def test_mismatched_aad_fails_authentication(
        self,
        comm: SecureCommunicator,
        bob_kp,
    ) -> None:
        """If sender supplies AAD but receiver supplies different AAD, auth fails."""
        _, msg = comm.send(TEST_PLAINTEXT, bob_kp.public_key, aad=b"correct-aad")

        with pytest.raises(AuthenticationFailureError):
            comm.receive(msg, bob_kp.private_key, aad=b"tampered-aad")
