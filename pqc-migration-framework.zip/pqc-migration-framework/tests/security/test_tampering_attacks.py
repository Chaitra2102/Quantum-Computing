"""
tests/security/test_tampering_attacks.py
Post-Quantum Secure Communication & Migration Framework

Security validation tests for controlled tampering attacks.

Phase 9: Validates rejection of modified ciphertexts, nonces, signatures,
KEM ciphertexts, and public key components across Modes A, B, C, and D.
"""

import pytest

from src.config.modes import Mode
from src.security_tests.attack_simulator import AttackSimulator


class TestTamperingAttacks:
    """Automated security tests for payload and metadata tampering."""

    @pytest.mark.parametrize("mode", [Mode.A, Mode.B, Mode.C, Mode.D])
    def test_ciphertext_tampering_rejected(self, mode: Mode):
        result = AttackSimulator.simulate_ciphertext_bit_flip(mode=mode)
        assert result.passed is True
        assert result.rejected is True
        assert result.plaintext_recovered is False

    @pytest.mark.parametrize("mode", [Mode.A, Mode.B, Mode.C, Mode.D])
    def test_nonce_tampering_rejected(self, mode: Mode):
        result = AttackSimulator.simulate_nonce_tampering(mode=mode)
        assert result.passed is True
        assert result.rejected is True
        assert result.plaintext_recovered is False

    @pytest.mark.parametrize("mode", [Mode.A, Mode.B, Mode.C])
    def test_signature_tampering_rejected(self, mode: Mode):
        result = AttackSimulator.simulate_signature_tampering(mode=mode)
        assert result.passed is True
        assert result.rejected is True
        assert result.rejection_type == "SignatureVerificationError"
        assert result.plaintext_recovered is False

    @pytest.mark.parametrize("sig_type", ["mldsa", "slhdsa", "ecdsa"])
    def test_mode_d_signature_variants_tampering_rejected(self, sig_type: str):
        result = AttackSimulator.simulate_signature_tampering(mode=Mode.D, sig_type=sig_type)
        assert result.passed is True
        assert result.rejected is True
        assert result.rejection_type == "SignatureVerificationError"
        assert result.plaintext_recovered is False

    @pytest.mark.parametrize("mode", [Mode.B, Mode.C, Mode.D])
    def test_kem_ciphertext_tampering_rejected(self, mode: Mode):
        result = AttackSimulator.simulate_kem_ciphertext_tampering(mode=mode)
        assert result.passed is True
        assert result.rejected is True
        assert result.plaintext_recovered is False

    @pytest.mark.parametrize("mode", [Mode.A, Mode.D])
    def test_ecdh_component_tampering_rejected(self, mode: Mode):
        result = AttackSimulator.simulate_ecdh_component_tampering(mode=mode)
        assert result.passed is True
        assert result.rejected is True
        assert result.plaintext_recovered is False

    @pytest.mark.parametrize("mode", [Mode.A, Mode.B, Mode.C, Mode.D])
    def test_signature_public_key_tampering_rejected(self, mode: Mode):
        result = AttackSimulator.simulate_signature_public_key_tampering(mode=mode)
        assert result.passed is True
        assert result.rejected is True
        assert result.plaintext_recovered is False


class TestPostAttackRecovery:
    """Security tests verifying that attack failures do not corrupt subsequent legitimate exchanges."""

    @pytest.mark.parametrize("mode", [Mode.A, Mode.B, Mode.C, Mode.D])
    def test_session_recovers_after_failed_tampering(self, mode: Mode):
        from src.communication.session import SecureSession
        session = SecureSession.create(mode)

        # 1. First legitimate exchange succeeds
        res1 = session.run_exchange("Legitimate Message 1")
        assert res1.status == "SUCCESS"

        # 2. Tampered attempt fails
        attack_res = AttackSimulator.simulate_ciphertext_bit_flip(mode=mode)
        assert attack_res.rejected is True

        # 3. Subsequent fresh legitimate exchange continues to succeed on session
        res2 = session.run_exchange("Legitimate Message 2 (Post-Attack)")
        assert res2.status == "SUCCESS"
        assert res2.plaintext_str == "Legitimate Message 2 (Post-Attack)"
