"""
tests/security/test_hybrid_attacks.py
Post-Quantum Secure Communication & Migration Framework

Hybrid-specific security tests for Mode D (ECDH P-384 + ML-KEM-768).

Phase 9: Validates rejection of tampered ECDH contributions, tampered ML-KEM contributions,
and ensures neither intermediate secret leaks.
"""

import pytest

from src.config.modes import Mode
from src.security_tests.attack_simulator import AttackSimulator


class TestHybridSpecificAttacks:
    """Security tests focused on the dual-secret hybrid construction."""

    def test_hybrid_ecdh_component_tampering_rejected(self):
        result = AttackSimulator.simulate_ecdh_component_tampering(mode=Mode.D)
        assert result.passed is True
        assert result.rejected is True
        assert result.plaintext_recovered is False

    def test_hybrid_mlkem_component_tampering_rejected(self):
        result = AttackSimulator.simulate_kem_ciphertext_tampering(mode=Mode.D, sig_type="mldsa")
        assert result.passed is True
        assert result.rejected is True
        assert result.plaintext_recovered is False

    def test_hybrid_slhdsa_component_tampering_rejected(self):
        result = AttackSimulator.simulate_kem_ciphertext_tampering(mode=Mode.D, sig_type="slhdsa")
        assert result.passed is True
        assert result.rejected is True
        assert result.plaintext_recovered is False

    def test_hybrid_signature_public_key_tampering_rejected(self):
        result = AttackSimulator.simulate_signature_public_key_tampering(mode=Mode.D)
        assert result.passed is True
        assert result.rejected is True
        assert result.plaintext_recovered is False
