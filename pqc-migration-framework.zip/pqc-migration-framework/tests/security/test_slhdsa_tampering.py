"""
tests/security/test_slhdsa_tampering.py
Post-Quantum Secure Communication & Migration Framework

SECURITY TESTS — Tampering and Adversarial Attacks on Mode C (ML-KEM + SLH-DSA)

Verifies that all active tampering attacks on the hash-based PQC communication pipeline
are reliably detected and rejected without leaking secret material.

Covered Scenarios:
  1. Modified ciphertext (bit-flip) -> SignatureVerificationError
  2. Modified AES-GCM nonce -> SignatureVerificationError
  3. Modified SLH-DSA signature -> SignatureVerificationError
  4. Wrong SLH-DSA public key -> SignatureVerificationError
  5. Truncated / malformed SLH-DSA signature -> SignatureVerificationError
  6. Modified ML-KEM ciphertext (ke_ciphertext) -> AuthenticationFailureError
  7. Wrong ML-KEM private key -> AuthenticationFailureError
  8. Mismatched AAD -> AuthenticationFailureError
"""

import pytest

from src.communication.message_bundle import SecureMessage
from src.communication.secure_communicator import SecureCommunicator
from src.config.crypto_config import CryptoConfig, ModeFactory
from src.config.modes import Mode
from src.exceptions import (
    AuthenticationFailureError,
    PQCFrameworkError,
    SignatureVerificationError,
)


@pytest.fixture
def mode_c_config() -> CryptoConfig:
    return ModeFactory.build(Mode.C)


@pytest.fixture
def communicator(mode_c_config: CryptoConfig) -> SecureCommunicator:
    return SecureCommunicator(mode_c_config)


@pytest.fixture
def bob_kp(mode_c_config: CryptoConfig):
    return mode_c_config.key_exchange.generate_keypair()


TEST_PLAINTEXT = b"Sensitive hash-based post-quantum message under adversarial evaluation."


class TestModeCTamperingDetection:
    """Adversarial tampering tests for Mode C (ML-KEM + SLH-DSA)."""

    def test_modified_ciphertext_fails_signature(
        self,
        communicator: SecureCommunicator,
        bob_kp,
    ) -> None:
        """Flipping a bit in the AES ciphertext must be caught by SLH-DSA signature verification."""
        _, msg = communicator.send(TEST_PLAINTEXT, bob_kp.public_key)

        corrupted_ct = bytes([msg.ciphertext[0] ^ 0x01]) + msg.ciphertext[1:]
        tampered_msg = SecureMessage(
            protocol_version=msg.protocol_version,
            algorithm_id=msg.algorithm_id,
            sender_ke_public_key=msg.sender_ke_public_key,
            sender_sig_public_key=msg.sender_sig_public_key,
            ciphertext=corrupted_ct,
            nonce=msg.nonce,
            signature=msg.signature,
            ke_ciphertext=msg.ke_ciphertext,
            metadata=msg.metadata,
        )

        with pytest.raises(SignatureVerificationError):
            communicator.receive(tampered_msg, bob_kp.private_key)

    def test_modified_nonce_fails_signature(
        self,
        communicator: SecureCommunicator,
        bob_kp,
    ) -> None:
        """Flipping a bit in the nonce must be caught by SLH-DSA signature verification."""
        _, msg = communicator.send(TEST_PLAINTEXT, bob_kp.public_key)

        corrupted_nonce = bytes([msg.nonce[0] ^ 0x80]) + msg.nonce[1:]
        tampered_msg = SecureMessage(
            protocol_version=msg.protocol_version,
            algorithm_id=msg.algorithm_id,
            sender_ke_public_key=msg.sender_ke_public_key,
            sender_sig_public_key=msg.sender_sig_public_key,
            ciphertext=msg.ciphertext,
            nonce=corrupted_nonce,
            signature=msg.signature,
            ke_ciphertext=msg.ke_ciphertext,
            metadata=msg.metadata,
        )

        with pytest.raises(SignatureVerificationError):
            communicator.receive(tampered_msg, bob_kp.private_key)

    def test_modified_slhdsa_signature_fails(
        self,
        communicator: SecureCommunicator,
        bob_kp,
    ) -> None:
        """Flipping a bit in the SLH-DSA signature must cause signature rejection."""
        _, msg = communicator.send(TEST_PLAINTEXT, bob_kp.public_key)

        corrupted_sig = bytes([msg.signature[0] ^ 0xFF]) + msg.signature[1:]
        tampered_msg = SecureMessage(
            protocol_version=msg.protocol_version,
            algorithm_id=msg.algorithm_id,
            sender_ke_public_key=msg.sender_ke_public_key,
            sender_sig_public_key=msg.sender_sig_public_key,
            ciphertext=msg.ciphertext,
            nonce=msg.nonce,
            signature=corrupted_sig,
            ke_ciphertext=msg.ke_ciphertext,
            metadata=msg.metadata,
        )

        with pytest.raises(SignatureVerificationError):
            communicator.receive(tampered_msg, bob_kp.private_key)

    def test_wrong_slhdsa_public_key_fails(
        self,
        communicator: SecureCommunicator,
        mode_c_config: CryptoConfig,
        bob_kp,
    ) -> None:
        """Substituting a different SLH-DSA public key must fail signature verification."""
        _, msg = communicator.send(TEST_PLAINTEXT, bob_kp.public_key)

        charlie_sig_kp = mode_c_config.signature.generate_keypair()
        charlie_sig_pub_bytes = mode_c_config.signature.export_public_key_bytes(
            charlie_sig_kp.public_key
        )

        tampered_msg = SecureMessage(
            protocol_version=msg.protocol_version,
            algorithm_id=msg.algorithm_id,
            sender_ke_public_key=msg.sender_ke_public_key,
            sender_sig_public_key=charlie_sig_pub_bytes,
            ciphertext=msg.ciphertext,
            nonce=msg.nonce,
            signature=msg.signature,
            ke_ciphertext=msg.ke_ciphertext,
            metadata=msg.metadata,
        )

        with pytest.raises(SignatureVerificationError):
            communicator.receive(tampered_msg, bob_kp.private_key)

    def test_truncated_signature_fails(
        self,
        communicator: SecureCommunicator,
        bob_kp,
    ) -> None:
        """Truncated signature must fail verification."""
        _, msg = communicator.send(TEST_PLAINTEXT, bob_kp.public_key)

        tampered_msg = SecureMessage(
            protocol_version=msg.protocol_version,
            algorithm_id=msg.algorithm_id,
            sender_ke_public_key=msg.sender_ke_public_key,
            sender_sig_public_key=msg.sender_sig_public_key,
            ciphertext=msg.ciphertext,
            nonce=msg.nonce,
            signature=msg.signature[:100],
            ke_ciphertext=msg.ke_ciphertext,
            metadata=msg.metadata,
        )

        with pytest.raises(SignatureVerificationError):
            communicator.receive(tampered_msg, bob_kp.private_key)

    def test_tampered_ke_ciphertext_fails_auth(
        self,
        communicator: SecureCommunicator,
        bob_kp,
    ) -> None:
        """Altering ML-KEM ciphertext leads to mismatched secret, which fails AES-GCM decryption."""
        _, msg = communicator.send(TEST_PLAINTEXT, bob_kp.public_key)
        assert msg.ke_ciphertext is not None

        corrupted_ke_ct = bytes([msg.ke_ciphertext[0] ^ 0x01]) + msg.ke_ciphertext[1:]
        tampered_msg = SecureMessage(
            protocol_version=msg.protocol_version,
            algorithm_id=msg.algorithm_id,
            sender_ke_public_key=msg.sender_ke_public_key,
            sender_sig_public_key=msg.sender_sig_public_key,
            ciphertext=msg.ciphertext,
            nonce=msg.nonce,
            signature=msg.signature,
            ke_ciphertext=corrupted_ke_ct,
            metadata=msg.metadata,
        )

        with pytest.raises((AuthenticationFailureError, PQCFrameworkError)):
            communicator.receive(tampered_msg, bob_kp.private_key)

    def test_wrong_receiver_ke_key_fails_auth(
        self,
        communicator: SecureCommunicator,
        mode_c_config: CryptoConfig,
        bob_kp,
    ) -> None:
        """Decapsulating with Charlie's ML-KEM private key instead of Bob's fails AES-GCM auth."""
        charlie_ke_kp = mode_c_config.key_exchange.generate_keypair()
        _, msg = communicator.send(TEST_PLAINTEXT, bob_kp.public_key)

        with pytest.raises(AuthenticationFailureError):
            communicator.receive(msg, charlie_ke_kp.private_key)

    def test_mismatched_aad_fails_auth(
        self,
        communicator: SecureCommunicator,
        bob_kp,
    ) -> None:
        """Mismatch in AAD must fail authentication."""
        _, msg = communicator.send(TEST_PLAINTEXT, bob_kp.public_key, aad=b"valid-aad")

        with pytest.raises(AuthenticationFailureError):
            communicator.receive(msg, bob_kp.private_key, aad=b"wrong-aad")
