"""
tests/unit/config/test_crypto_config.py
Post-Quantum Secure Communication & Migration Framework

Unit tests for CryptoConfig, ModeFactory, and crypto-agility validation.

Phase 6: Comprehensive configuration validation, provider type verification,
and protocol negotiation foundation.
"""

import dataclasses
import pytest

from src.config.crypto_config import CryptoConfig, ModeFactory
from src.config.modes import (
    ALL_ALGORITHM_IDS,
    CLASSICAL_ECDH_ECDSA_AES256_GCM,
    HYBRID_ECDH_MLKEM_AES256_GCM,
    HYBRID_ECDH_MLKEM_ECDSA_AES256_GCM,
    HYBRID_ECDH_MLKEM_MLDSA_AES256_GCM,
    HYBRID_ECDH_MLKEM_SLHDSA_AES256_GCM,
    PQC_MLKEM_ECDSA_AES256_GCM,
    PQC_MLKEM_MLDSA_AES256_GCM,
    PQC_MLKEM_SLHDSA_AES256_GCM,
    Mode,
    negotiate_mode,
)
from src.exceptions import (
    ConfigurationError,
    NegotiationError,
    UnsupportedAlgorithmError,
)
from src.providers.classical.ecdh_provider import ECDHProvider
from src.providers.classical.ecdsa_provider import ECDSAProvider
from src.providers.hybrid.hybrid_ke_provider import HybridKEProvider
from src.providers.pqc.mldsa_provider import MLDSAProvider
from src.providers.pqc.mlkem_provider import MLKEMProvider
from src.providers.pqc.slhdsa_provider import SLHDSAProvider
from src.providers.symmetric.aesgcm_provider import AESGCM256Provider
from src.providers.symmetric.hkdf_provider import HKDFDerivationProvider


# ===========================================================================
# 1. Mode Construction & Factory Tests
# ===========================================================================


class TestModeFactoryConstruction:
    """Tests for ModeFactory.build() across all supported modes."""

    def test_build_mode_a_produces_valid_classical_config(self):
        config = ModeFactory.build(Mode.A)
        assert config.mode is Mode.A
        assert config.algorithm_id == CLASSICAL_ECDH_ECDSA_AES256_GCM
        assert isinstance(config.key_exchange, ECDHProvider)
        assert isinstance(config.signature, ECDSAProvider)
        assert isinstance(config.encryption, AESGCM256Provider)
        assert isinstance(config.kdf, HKDFDerivationProvider)

    def test_build_mode_b_produces_valid_mldsa_config(self):
        config = ModeFactory.build(Mode.B)
        assert config.mode is Mode.B
        assert config.algorithm_id == PQC_MLKEM_MLDSA_AES256_GCM
        assert isinstance(config.key_exchange, MLKEMProvider)
        assert isinstance(config.signature, MLDSAProvider)
        assert isinstance(config.encryption, AESGCM256Provider)
        assert isinstance(config.kdf, HKDFDerivationProvider)

    def test_build_mode_c_produces_valid_slhdsa_config(self):
        config = ModeFactory.build(Mode.C)
        assert config.mode is Mode.C
        assert config.algorithm_id == PQC_MLKEM_SLHDSA_AES256_GCM
        assert isinstance(config.key_exchange, MLKEMProvider)
        assert isinstance(config.signature, SLHDSAProvider)
        assert isinstance(config.encryption, AESGCM256Provider)
        assert isinstance(config.kdf, HKDFDerivationProvider)

    def test_build_mlkem_baseline_config(self):
        config = ModeFactory.build_mlkem_baseline("ML-KEM-768")
        assert config.mode is Mode.B
        assert config.algorithm_id == PQC_MLKEM_ECDSA_AES256_GCM
        assert isinstance(config.key_exchange, MLKEMProvider)
        assert isinstance(config.signature, ECDSAProvider)

    def test_build_accepts_string_mode_identifiers(self):
        cfg_a = ModeFactory.build("A")
        assert cfg_a.mode is Mode.A

        cfg_b = ModeFactory.build("MODE_B")
        assert cfg_b.mode is Mode.B

        cfg_c = ModeFactory.build("Mode.C")
        assert cfg_c.mode is Mode.C

    def test_build_mode_d_produces_valid_hybrid_config_default_mldsa(self):
        config = ModeFactory.build(Mode.D)
        assert config.mode is Mode.D
        assert config.algorithm_id == HYBRID_ECDH_MLKEM_MLDSA_AES256_GCM
        assert isinstance(config.key_exchange, HybridKEProvider)
        assert isinstance(config.signature, MLDSAProvider)
        assert isinstance(config.encryption, AESGCM256Provider)
        assert isinstance(config.kdf, HKDFDerivationProvider)

    def test_build_mode_d_signature_variants_have_distinct_suite_ids(self):
        cfg_mldsa = ModeFactory.build(Mode.D, sig_provider_type="mldsa")
        cfg_slhdsa = ModeFactory.build(Mode.D, sig_provider_type="slhdsa")
        cfg_ecdsa = ModeFactory.build(Mode.D, sig_provider_type="ecdsa")

        assert cfg_mldsa.algorithm_id == HYBRID_ECDH_MLKEM_MLDSA_AES256_GCM
        assert isinstance(cfg_mldsa.signature, MLDSAProvider)

        assert cfg_slhdsa.algorithm_id == HYBRID_ECDH_MLKEM_SLHDSA_AES256_GCM
        assert isinstance(cfg_slhdsa.signature, SLHDSAProvider)

        assert cfg_ecdsa.algorithm_id == HYBRID_ECDH_MLKEM_ECDSA_AES256_GCM
        assert isinstance(cfg_ecdsa.signature, ECDSAProvider)

        # Confirm all 3 suite IDs are mutually distinct
        assert cfg_mldsa.algorithm_id != cfg_slhdsa.algorithm_id
        assert cfg_mldsa.algorithm_id != cfg_ecdsa.algorithm_id
        assert cfg_slhdsa.algorithm_id != cfg_ecdsa.algorithm_id

    def test_build_mode_d_unsupported_sig_provider_raises(self):
        with pytest.raises(UnsupportedAlgorithmError):
            ModeFactory.build(Mode.D, sig_provider_type="rsa_4096")

    def test_build_unknown_mode_raises_unsupported(self):
        with pytest.raises(UnsupportedAlgorithmError):
            ModeFactory.build("UNKNOWN_MODE")

    def test_supported_modes_list(self):
        modes = ModeFactory.supported_modes()
        assert modes == [Mode.A, Mode.B, Mode.C, Mode.D]

    def test_get_algorithm_id(self):
        assert ModeFactory.get_algorithm_id(Mode.A) == CLASSICAL_ECDH_ECDSA_AES256_GCM
        assert ModeFactory.get_algorithm_id(Mode.B) == PQC_MLKEM_MLDSA_AES256_GCM
        assert ModeFactory.get_algorithm_id(Mode.C) == PQC_MLKEM_SLHDSA_AES256_GCM
        assert ModeFactory.get_algorithm_id(Mode.D) == HYBRID_ECDH_MLKEM_MLDSA_AES256_GCM


# ===========================================================================
# 2. CryptoConfig Immutability & Validation Tests
# ===========================================================================


class TestCryptoConfigValidation:
    """Tests for CryptoConfig validation and immutability invariants."""

    def test_config_is_immutable(self):
        config = ModeFactory.build(Mode.A)
        with pytest.raises((dataclasses.FrozenInstanceError, AttributeError)):
            config.mode = Mode.B  # type: ignore

    def test_invalid_mode_type_raises_configuration_error(self):
        with pytest.raises(ConfigurationError, match="Invalid mode type"):
            CryptoConfig(
                mode="A",  # type: ignore (string instead of Mode enum)
                algorithm_id=CLASSICAL_ECDH_ECDSA_AES256_GCM,
                key_exchange=ECDHProvider(),
                signature=ECDSAProvider(),
                encryption=AESGCM256Provider(),
                kdf=HKDFDerivationProvider(),
            )

    def test_empty_or_unknown_algorithm_id_raises_configuration_error(self):
        with pytest.raises(ConfigurationError, match="algorithm_id"):
            CryptoConfig(
                mode=Mode.A,
                algorithm_id="",
                key_exchange=ECDHProvider(),
                signature=ECDSAProvider(),
                encryption=AESGCM256Provider(),
                kdf=HKDFDerivationProvider(),
            )

        with pytest.raises(ConfigurationError, match="Unknown or unrecognized"):
            CryptoConfig(
                mode=Mode.A,
                algorithm_id="INVALID_ALGORITHM_ID",
                key_exchange=ECDHProvider(),
                signature=ECDSAProvider(),
                encryption=AESGCM256Provider(),
                kdf=HKDFDerivationProvider(),
            )

    def test_missing_or_invalid_provider_types_raise_configuration_error(self):
        # Invalid key exchange provider
        with pytest.raises(ConfigurationError, match="key_exchange"):
            CryptoConfig(
                mode=Mode.A,
                algorithm_id=CLASSICAL_ECDH_ECDSA_AES256_GCM,
                key_exchange=object(),  # type: ignore
                signature=ECDSAProvider(),
                encryption=AESGCM256Provider(),
                kdf=HKDFDerivationProvider(),
            )

        # Invalid signature provider
        with pytest.raises(ConfigurationError, match="signature"):
            CryptoConfig(
                mode=Mode.A,
                algorithm_id=CLASSICAL_ECDH_ECDSA_AES256_GCM,
                key_exchange=ECDHProvider(),
                signature=object(),  # type: ignore
                encryption=AESGCM256Provider(),
                kdf=HKDFDerivationProvider(),
            )

        # Invalid encryption provider
        with pytest.raises(ConfigurationError, match="encryption"):
            CryptoConfig(
                mode=Mode.A,
                algorithm_id=CLASSICAL_ECDH_ECDSA_AES256_GCM,
                key_exchange=ECDHProvider(),
                signature=ECDSAProvider(),
                encryption=object(),  # type: ignore
                kdf=HKDFDerivationProvider(),
            )

        # Invalid KDF provider
        with pytest.raises(ConfigurationError, match="kdf"):
            CryptoConfig(
                mode=Mode.A,
                algorithm_id=CLASSICAL_ECDH_ECDSA_AES256_GCM,
                key_exchange=ECDHProvider(),
                signature=ECDSAProvider(),
                encryption=AESGCM256Provider(),
                kdf=object(),  # type: ignore
            )

    def test_mismatched_mode_and_providers_raise_configuration_error(self):
        # Mode A with ML-KEM provider
        with pytest.raises(ConfigurationError, match="Mode A requires ECDHProvider"):
            CryptoConfig(
                mode=Mode.A,
                algorithm_id=CLASSICAL_ECDH_ECDSA_AES256_GCM,
                key_exchange=MLKEMProvider(),
                signature=ECDSAProvider(),
                encryption=AESGCM256Provider(),
                kdf=HKDFDerivationProvider(),
            )

        # Mode B with SLH-DSA provider (should be Mode C)
        with pytest.raises(ConfigurationError, match="Mode B requires MLDSAProvider"):
            CryptoConfig(
                mode=Mode.B,
                algorithm_id=PQC_MLKEM_MLDSA_AES256_GCM,
                key_exchange=MLKEMProvider(),
                signature=SLHDSAProvider(),
                encryption=AESGCM256Provider(),
                kdf=HKDFDerivationProvider(),
            )

        # Mode C with ML-DSA provider (should be Mode B)
        with pytest.raises(ConfigurationError, match="Mode C requires SLHDSAProvider"):
            CryptoConfig(
                mode=Mode.C,
                algorithm_id=PQC_MLKEM_SLHDSA_AES256_GCM,
                key_exchange=MLKEMProvider(),
                signature=MLDSAProvider(),
                encryption=AESGCM256Provider(),
                kdf=HKDFDerivationProvider(),
            )

    def test_mode_d_mismatched_signature_and_suite_id_raises_configuration_error(self):
        # Mode D with MLDSAProvider claiming SLHDSA suite
        with pytest.raises(ConfigurationError, match="Mode D with MLDSAProvider requires"):
            CryptoConfig(
                mode=Mode.D,
                algorithm_id=HYBRID_ECDH_MLKEM_SLHDSA_AES256_GCM,
                key_exchange=HybridKEProvider(),
                signature=MLDSAProvider(),
                encryption=AESGCM256Provider(),
                kdf=HKDFDerivationProvider(),
            )

        # Mode D with SLHDSAProvider claiming MLDSA suite
        with pytest.raises(ConfigurationError, match="Mode D with SLHDSAProvider requires"):
            CryptoConfig(
                mode=Mode.D,
                algorithm_id=HYBRID_ECDH_MLKEM_MLDSA_AES256_GCM,
                key_exchange=HybridKEProvider(),
                signature=SLHDSAProvider(),
                encryption=AESGCM256Provider(),
                kdf=HKDFDerivationProvider(),
            )

        # Mode D with ECDSAProvider claiming MLDSA suite
        with pytest.raises(ConfigurationError, match="Mode D with ECDSAProvider requires"):
            CryptoConfig(
                mode=Mode.D,
                algorithm_id=HYBRID_ECDH_MLKEM_MLDSA_AES256_GCM,
                key_exchange=HybridKEProvider(),
                signature=ECDSAProvider(),
                encryption=AESGCM256Provider(),
                kdf=HKDFDerivationProvider(),
            )


# ===========================================================================
# 3. Protocol Negotiation Foundation Tests
# ===========================================================================


class TestProtocolNegotiationFoundation:
    """Tests for negotiate_mode deterministic agreement."""

    def test_negotiate_exact_mutual_match(self):
        client = [Mode.A, Mode.B]
        server = [Mode.B, Mode.C]
        selected = negotiate_mode(client, server)
        assert selected is Mode.B

    def test_negotiate_multiple_mutual_defaults_to_server_preference(self):
        client = [Mode.A, Mode.B, Mode.C]
        server = [Mode.C, Mode.B, Mode.A]  # Server prefers C
        selected = negotiate_mode(client, server)
        assert selected is Mode.C

    def test_negotiate_with_explicit_preference_order(self):
        client = [Mode.A, Mode.B, Mode.C]
        server = [Mode.A, Mode.B, Mode.C]
        # Custom preference: B > C > A
        selected = negotiate_mode(client, server, preference_order=[Mode.B, Mode.C, Mode.A])
        assert selected is Mode.B

    def test_negotiate_no_mutual_modes_raises_negotiation_error(self):
        client = [Mode.A]
        server = [Mode.B, Mode.C]
        with pytest.raises(NegotiationError, match="No mutual mode found"):
            negotiate_mode(client, server)

    def test_negotiate_string_inputs_handled(self):
        client = ["MODE_A", "MODE_C"]
        server = ["MODE_B", "MODE_C"]
        selected = negotiate_mode(client, server)
        assert selected is Mode.C
