"""
tests/unit/cli/test_cli_output.py
Post-Quantum Secure Communication & Migration Framework

Unit tests for CLI output formatting, JSON responses, error safety, and secret non-exposure.

Phase 8: Tests stdout/stderr output formatting, JSON structure validity, and verifies
strict non-exposure of private keys, shared secrets, and symmetric keys.
"""

import json
import pytest

from src.config.modes import (
    CLASSICAL_ECDH_ECDSA_AES256_GCM,
    HYBRID_ECDH_MLKEM_ECDSA_AES256_GCM,
    HYBRID_ECDH_MLKEM_MLDSA_AES256_GCM,
    HYBRID_ECDH_MLKEM_SLHDSA_AES256_GCM,
    PQC_MLKEM_MLDSA_AES256_GCM,
    PQC_MLKEM_SLHDSA_AES256_GCM,
)
from src.main_cli import run_cli


class TestCLIOutputFormatting:
    """Tests for CLI terminal output formatting."""

    def test_list_modes_output_contains_all_modes(self, capsys):
        exit_code = run_cli(["--list-modes"])
        assert exit_code == 0
        captured = capsys.readouterr()

        assert CLASSICAL_ECDH_ECDSA_AES256_GCM in captured.out
        assert PQC_MLKEM_MLDSA_AES256_GCM in captured.out
        assert PQC_MLKEM_SLHDSA_AES256_GCM in captured.out
        assert HYBRID_ECDH_MLKEM_MLDSA_AES256_GCM in captured.out
        assert HYBRID_ECDH_MLKEM_SLHDSA_AES256_GCM in captured.out
        assert HYBRID_ECDH_MLKEM_ECDSA_AES256_GCM in captured.out

    def test_list_modes_json_output(self, capsys):
        exit_code = run_cli(["--list-modes", "--json"])
        assert exit_code == 0
        captured = capsys.readouterr()

        data = json.loads(captured.out)
        assert "supported_modes" in data
        assert "Mode A" in data["supported_modes"]
        assert "Mode B" in data["supported_modes"]
        assert "Mode C" in data["supported_modes"]
        assert "Mode D" in data["supported_modes"]

    def test_inspect_mode_b_output(self, capsys):
        exit_code = run_cli(["--mode", "B", "--inspect"])
        assert exit_code == 0
        captured = capsys.readouterr()

        assert "PQC_MLKEM_MLDSA_AES256_GCM" in captured.out
        assert "ML-KEM-768" in captured.out
        assert "ML-DSA-65" in captured.out
        assert "AES-256-GCM" in captured.out
        assert "HKDF-SHA-384" in captured.out

    def test_inspect_mode_d_slhdsa_json_output(self, capsys):
        exit_code = run_cli(["--mode", "D", "--signature", "slhdsa", "--inspect", "--json"])
        assert exit_code == 0
        captured = capsys.readouterr()

        data = json.loads(captured.out)
        assert data["status"] == "success"
        assert data["inspection"]["algorithm_id"] == HYBRID_ECDH_MLKEM_SLHDSA_AES256_GCM
        assert data["inspection"]["signature"] == "SLH-DSA-SHAKE-128f"


class TestCLISecretNonExposure:
    """Security tests asserting that CLI never leaks private keys, shared secrets, or AES keys."""

    @pytest.mark.parametrize("mode_arg", ["A", "B", "C", "D"])
    def test_cli_execution_never_leaks_secrets_in_terminal_output(self, capsys, mode_arg):
        exit_code = run_cli(["--mode", mode_arg, "--message", "Top secret data"])
        assert exit_code == 0
        captured = capsys.readouterr()

        full_output = captured.out + captured.err
        # Forbidden sensitive keywords & patterns
        forbidden_terms = [
            "private_key",
            "secret_key",
            "shared_secret",
            "aes_key",
            "raw_key",
            "private_bytes",
            "EllipticCurvePrivateKey",
            "MLKEM768PrivateKey",
            "MLDSA65PrivateKey",
        ]
        for term in forbidden_terms:
            assert term not in full_output, f"Forbidden sensitive token '{term}' found in CLI output for mode {mode_arg}"

    @pytest.mark.parametrize("mode_arg", ["A", "B", "C", "D"])
    def test_cli_json_execution_never_leaks_secrets(self, capsys, mode_arg):
        exit_code = run_cli(["--mode", mode_arg, "--message", "Top secret data", "--json"])
        assert exit_code == 0
        captured = capsys.readouterr()

        data = json.loads(captured.out)
        assert data["status"] == "SUCCESS"
        json_dump = json.dumps(data)

        forbidden_terms = ["private_key", "secret_key", "shared_secret", "aes_key"]
        for term in forbidden_terms:
            assert term not in json_dump.lower(), f"Forbidden sensitive token '{term}' found in JSON output"
