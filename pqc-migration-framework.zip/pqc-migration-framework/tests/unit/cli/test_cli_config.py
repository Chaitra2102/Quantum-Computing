"""
tests/unit/cli/test_cli_config.py
Post-Quantum Secure Communication & Migration Framework

Unit tests for CLI argument parsing, option resolution, and configuration validation.

Phase 8: Tests CLI option handling, defaults, parameter overrides, and error catching.
"""

import pytest

from src.main_cli import build_parser, run_cli


class TestCLIArgumentParsing:
    """Tests for CLI parser configuration and defaults."""

    def test_parser_defaults(self):
        parser = build_parser()
        args = parser.parse_args([])
        assert args.mode is None
        assert args.signature is None
        assert args.message is None
        assert args.inspect is False
        assert args.list_modes is False
        assert args.json is False
        assert args.debug is False

    def test_parser_mode_and_message_flags(self):
        parser = build_parser()
        args = parser.parse_args(["-m", "B", "--message", "Test Hello"])
        assert args.mode == "B"
        assert args.message == "Test Hello"

    def test_parser_mode_d_signature_flag(self):
        parser = build_parser()
        args = parser.parse_args(["--mode", "D", "--signature", "slhdsa", "-msg", "Hybrid"])
        assert args.mode == "D"
        assert args.signature == "slhdsa"
        assert args.message == "Hybrid"

    def test_parser_json_and_inspect_flags(self):
        parser = build_parser()
        args = parser.parse_args(["-m", "A", "-i", "-j"])
        assert args.mode == "A"
        assert args.inspect is True
        assert args.json is True

    def test_parser_optional_kem_and_sig_params(self):
        parser = build_parser()
        args = parser.parse_args([
            "--mode", "B",
            "--kem-param", "ML-KEM-1024",
            "--sig-param", "ML-DSA-87",
        ])
        assert args.kem_param == "ML-KEM-1024"
        assert args.sig_param == "ML-DSA-87"


class TestCLIConfigurationValidation:
    """Tests for CLI error handling on invalid configurations."""

    def test_missing_mode_and_list_returns_error_code(self, capsys):
        exit_code = run_cli([])
        assert exit_code == 2
        captured = capsys.readouterr()
        assert "Please specify a cryptographic mode" in captured.err

    def test_invalid_mode_name_returns_error_code(self, capsys):
        exit_code = run_cli(["--mode", "INVALID_MODE", "--message", "Hi"])
        assert exit_code == 1
        captured = capsys.readouterr()
        assert "UnsupportedAlgorithmError" in captured.err

    def test_invalid_mode_d_signature_returns_error_code(self, capsys):
        exit_code = run_cli(["--mode", "D", "--signature", "invalid_sig", "--message", "Hi"])
        assert exit_code == 1
        captured = capsys.readouterr()
        assert "UnsupportedAlgorithmError" in captured.err
