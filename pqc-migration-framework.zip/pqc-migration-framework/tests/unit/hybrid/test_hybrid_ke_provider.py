"""
tests/unit/hybrid/test_hybrid_ke_provider.py
Post-Quantum Secure Communication & Migration Framework

Unit tests for HybridKEProvider (ECDH P-384 + ML-KEM-768).

Phase 7: Verifies composite keypair generation, public key serialization,
encapsulation/decapsulation shared secret equality, and tampering detection.
"""

import pytest

from src.exceptions import InvalidKeyError
from src.providers.base import KeyPair
from src.providers.hybrid.hybrid_ke_provider import (
    HybridKEProvider,
    HybridPrivateKey,
    HybridPublicKey,
)


class TestHybridKEProvider:
    """Unit tests for HybridKEProvider."""

    @pytest.fixture
    def provider(self) -> HybridKEProvider:
        return HybridKEProvider(kem_parameter_set="ML-KEM-768")

    def test_generate_keypair_types(self, provider: HybridKEProvider):
        kp = provider.generate_keypair()
        assert isinstance(kp, KeyPair)
        assert isinstance(kp.private_key, HybridPrivateKey)
        assert isinstance(kp.public_key, HybridPublicKey)

    def test_generate_keypair_randomness(self, provider: HybridKEProvider):
        kp1 = provider.generate_keypair()
        kp2 = provider.generate_keypair()
        pub1_bytes = provider.export_public_key_bytes(kp1.public_key)
        pub2_bytes = provider.export_public_key_bytes(kp2.public_key)
        assert pub1_bytes != pub2_bytes

    def test_public_key_export_import_roundtrip(self, provider: HybridKEProvider):
        kp = provider.generate_keypair()
        pub_bytes = provider.export_public_key_bytes(kp.public_key)

        # Expected size: 2 bytes header + 97 bytes ECDH (P-384) + 1184 bytes ML-KEM-768 = 1283 bytes
        assert len(pub_bytes) == 2 + 97 + 1184

        imported_pub = provider.import_public_key_bytes(pub_bytes)
        assert isinstance(imported_pub, HybridPublicKey)

        re_exported_bytes = provider.export_public_key_bytes(imported_pub)
        assert pub_bytes == re_exported_bytes

    def test_encapsulate_decapsulate_produces_identical_secrets(
        self, provider: HybridKEProvider
    ):
        receiver_kp = provider.generate_keypair()

        # Sender encapsulates against receiver public key
        sender_ss, ciphertext = provider.encapsulate(receiver_kp.public_key)

        # Ciphertext size: 2 bytes header + 97 bytes ephemeral ECDH + 1088 bytes ML-KEM-768 ct = 1187 bytes
        assert len(ciphertext) == 2 + 97 + 1088
        assert len(sender_ss) == 48

        # Receiver decapsulates using receiver private key
        receiver_ss = provider.decapsulate(receiver_kp.private_key, ciphertext)
        assert len(receiver_ss) == 48

        # Invariant: Both derive byte-for-byte identical hybrid secret
        assert sender_ss == receiver_ss

    def test_ephemeral_ecdh_randomized_per_encapsulation(
        self, provider: HybridKEProvider
    ):
        receiver_kp = provider.generate_keypair()

        ss1, ct1 = provider.encapsulate(receiver_kp.public_key)
        ss2, ct2 = provider.encapsulate(receiver_kp.public_key)

        assert ct1 != ct2
        assert ss1 != ss2

    def test_mismatched_receiver_key_fails_decapsulation(
        self, provider: HybridKEProvider
    ):
        alice_kp = provider.generate_keypair()
        bob_kp = provider.generate_keypair()

        # Sender encapsulates for Alice
        sender_ss, ciphertext = provider.encapsulate(alice_kp.public_key)

        # Bob attempts to decapsulate with his private key
        bob_ss = provider.decapsulate(bob_kp.private_key, ciphertext)

        # Result must not match Alice's secret
        assert sender_ss != bob_ss

    def test_corrupted_ecdh_ciphertext_fails(self, provider: HybridKEProvider):
        receiver_kp = provider.generate_keypair()
        sender_ss, ciphertext = provider.encapsulate(receiver_kp.public_key)

        # Corrupt a byte in the ephemeral ECDH public key portion
        corrupted_ct = bytearray(ciphertext)
        corrupted_ct[10] ^= 0x01

        # Corrupted point should raise InvalidKeyError on import or yield wrong secret
        try:
            receiver_ss = provider.decapsulate(receiver_kp.private_key, bytes(corrupted_ct))
            assert receiver_ss != sender_ss
        except InvalidKeyError:
            pass  # Expected if point decoding fails

    def test_corrupted_mlkem_ciphertext_derives_different_secret(
        self, provider: HybridKEProvider
    ):
        receiver_kp = provider.generate_keypair()
        sender_ss, ciphertext = provider.encapsulate(receiver_kp.public_key)

        # Corrupt a byte in the ML-KEM ciphertext portion (near end)
        corrupted_ct = bytearray(ciphertext)
        corrupted_ct[-10] ^= 0x01

        # ML-KEM implicit rejection produces a pseudorandom invalid secret
        receiver_ss = provider.decapsulate(receiver_kp.private_key, bytes(corrupted_ct))
        assert receiver_ss != sender_ss

    def test_exchange_raises_not_implemented(self, provider: HybridKEProvider):
        kp = provider.generate_keypair()
        with pytest.raises(NotImplementedError):
            provider.exchange(kp.private_key, kp.public_key)

    def test_invalid_input_types_raise_invalid_key_error(
        self, provider: HybridKEProvider
    ):
        kp = provider.generate_keypair()

        with pytest.raises(InvalidKeyError, match="HybridPublicKey"):
            provider.export_public_key_bytes(object())

        with pytest.raises(InvalidKeyError):
            provider.import_public_key_bytes(b"short")

        with pytest.raises(InvalidKeyError, match="HybridPublicKey"):
            provider.encapsulate(object())

        with pytest.raises(InvalidKeyError, match="HybridPrivateKey"):
            provider.decapsulate(object(), b"dummy")

        with pytest.raises(InvalidKeyError, match="ciphertext"):
            provider.decapsulate(kp.private_key, "not-bytes")  # type: ignore
