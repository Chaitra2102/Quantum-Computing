"""
tests/unit/hybrid/test_hybrid_combiner.py
Post-Quantum Secure Communication & Migration Framework

Unit tests for HybridSecretCombiner (HKDF-SHA-384 hybrid key combiner).

Phase 7: Verifies hybrid security properties, ordering determinism,
context separation, and input validation.
"""

import pytest

from src.exceptions import InvalidKeyError
from src.providers.hybrid.hybrid_combiner import (
    DEFAULT_HYBRID_INFO,
    DEFAULT_HYBRID_OUTPUT_LENGTH,
    HybridSecretCombiner,
)


class TestHybridSecretCombiner:
    """Tests for the HybridSecretCombiner cryptographic combiner."""

    @pytest.fixture
    def combiner(self) -> HybridSecretCombiner:
        return HybridSecretCombiner()

    @pytest.fixture
    def sample_ecdh_ss(self) -> bytes:
        return b"\x01" * 48  # P-384 shared secret (48 bytes)

    @pytest.fixture
    def sample_mlkem_ss(self) -> bytes:
        return b"\x02" * 32  # ML-KEM-768 shared secret (32 bytes)

    def test_default_initialization(self, combiner: HybridSecretCombiner):
        assert combiner.info == DEFAULT_HYBRID_INFO
        assert combiner.output_length == DEFAULT_HYBRID_OUTPUT_LENGTH

    def test_combine_produces_expected_output_length(
        self,
        combiner: HybridSecretCombiner,
        sample_ecdh_ss: bytes,
        sample_mlkem_ss: bytes,
    ):
        hybrid_ss = combiner.combine(sample_ecdh_ss, sample_mlkem_ss)
        assert isinstance(hybrid_ss, bytes)
        assert len(hybrid_ss) == 48

    def test_combine_is_deterministic(
        self,
        combiner: HybridSecretCombiner,
        sample_ecdh_ss: bytes,
        sample_mlkem_ss: bytes,
    ):
        ss1 = combiner.combine(sample_ecdh_ss, sample_mlkem_ss)
        ss2 = combiner.combine(sample_ecdh_ss, sample_mlkem_ss)
        assert ss1 == ss2

    def test_ecdh_contribution_required(
        self,
        combiner: HybridSecretCombiner,
        sample_ecdh_ss: bytes,
        sample_mlkem_ss: bytes,
    ):
        """Modifying even 1 bit in the classical ECDH secret alters the hybrid output."""
        baseline = combiner.combine(sample_ecdh_ss, sample_mlkem_ss)

        # Mutate 1 byte of ECDH secret
        mutated_ecdh = bytes([sample_ecdh_ss[0] ^ 0x01]) + sample_ecdh_ss[1:]
        mutated_output = combiner.combine(mutated_ecdh, sample_mlkem_ss)

        assert baseline != mutated_output

    def test_mlkem_contribution_required(
        self,
        combiner: HybridSecretCombiner,
        sample_ecdh_ss: bytes,
        sample_mlkem_ss: bytes,
    ):
        """Modifying even 1 bit in the post-quantum ML-KEM secret alters the hybrid output."""
        baseline = combiner.combine(sample_ecdh_ss, sample_mlkem_ss)

        # Mutate 1 byte of ML-KEM secret
        mutated_mlkem = bytes([sample_mlkem_ss[0] ^ 0x01]) + sample_mlkem_ss[1:]
        mutated_output = combiner.combine(sample_ecdh_ss, mutated_mlkem)

        assert baseline != mutated_output

    def test_concatenation_ordering_sensitivity(
        self,
        combiner: HybridSecretCombiner,
        sample_ecdh_ss: bytes,
        sample_mlkem_ss: bytes,
    ):
        """
        ecdh_ss || mlkem_ss must NOT be interchangeable with mlkem_ss || ecdh_ss.
        """
        normal_order = combiner.combine(sample_ecdh_ss, sample_mlkem_ss)
        swapped_order = combiner.combine(sample_mlkem_ss, sample_ecdh_ss)

        assert normal_order != swapped_order

    def test_context_domain_separation(
        self,
        combiner: HybridSecretCombiner,
        sample_ecdh_ss: bytes,
        sample_mlkem_ss: bytes,
    ):
        """Different info context strings produce distinct derived secrets."""
        secret_default = combiner.combine(sample_ecdh_ss, sample_mlkem_ss)
        secret_custom = combiner.combine(
            sample_ecdh_ss,
            sample_mlkem_ss,
            info=b"different-context-string",
        )
        assert secret_default != secret_custom

    def test_salt_handling(
        self,
        combiner: HybridSecretCombiner,
        sample_ecdh_ss: bytes,
        sample_mlkem_ss: bytes,
    ):
        """Supplying explicit salt alters the HKDF extract phase."""
        no_salt = combiner.combine(sample_ecdh_ss, sample_mlkem_ss)
        with_salt = combiner.combine(
            sample_ecdh_ss,
            sample_mlkem_ss,
            salt=b"random-salt-value-384-bits-long-0123456789abcdef",
        )
        assert no_salt != with_salt

    def test_custom_output_length(
        self,
        sample_ecdh_ss: bytes,
        sample_mlkem_ss: bytes,
    ):
        comb32 = HybridSecretCombiner(output_length=32)
        out32 = comb32.combine(sample_ecdh_ss, sample_mlkem_ss)
        assert len(out32) == 32

    def test_invalid_inputs_raise_invalid_key_error(
        self,
        combiner: HybridSecretCombiner,
        sample_ecdh_ss: bytes,
        sample_mlkem_ss: bytes,
    ):
        with pytest.raises(InvalidKeyError, match="ecdh_shared_secret"):
            combiner.combine(b"", sample_mlkem_ss)

        with pytest.raises(InvalidKeyError, match="ecdh_shared_secret"):
            combiner.combine(None, sample_mlkem_ss)  # type: ignore

        with pytest.raises(InvalidKeyError, match="mlkem_shared_secret"):
            combiner.combine(sample_ecdh_ss, b"")

        with pytest.raises(InvalidKeyError, match="mlkem_shared_secret"):
            combiner.combine(sample_ecdh_ss, None)  # type: ignore

        with pytest.raises(InvalidKeyError, match="output_length"):
            HybridSecretCombiner(output_length=-1)

        with pytest.raises(InvalidKeyError, match="info"):
            HybridSecretCombiner(info="not-bytes")  # type: ignore
