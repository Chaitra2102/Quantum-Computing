"""
tests/unit/pqc/test_mlkem.py
Post-Quantum Secure Communication & Migration Framework

UNIT TESTS — MLKEMProvider (FIPS 203)

Tests verify the following properties:
  1. Initialization with supported/unsupported parameter sets.
  2. Key pair generation succeeds and produces distinct keys.
  3. Encapsulation and decapsulation produce identical shared secrets.
  4. Encapsulation is randomized (fresh ephemeral secret per call).
  5. Public keys can be exported and imported (round-trip).
  6. Parameter set dimensions (ML-KEM-768, ML-KEM-1024) conform to FIPS 203.
  7. Invalid inputs (None, incorrect type, corrupt length) are rejected with InvalidKeyError.
  8. DH exchange() raises NotImplementedError.

No benchmarks. Real cryptographic operations only — no mocks.
"""

import pytest
from cryptography.hazmat.primitives.asymmetric.mlkem import (
    MLKEM768PrivateKey,
    MLKEM768PublicKey,
    MLKEM1024PrivateKey,
    MLKEM1024PublicKey,
)

from src.exceptions import InvalidKeyError, UnsupportedAlgorithmError
from src.providers.base import KeyPair
from src.providers.pqc.mlkem_provider import (
    DEFAULT_PARAMETER_SET,
    MLKEMProvider,
)


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture
def provider_768() -> MLKEMProvider:
    return MLKEMProvider("ML-KEM-768")


@pytest.fixture
def provider_1024() -> MLKEMProvider:
    return MLKEMProvider("ML-KEM-1024")


@pytest.fixture
def bob_kp_768(provider_768: MLKEMProvider) -> KeyPair:
    """Receiver key pair (ML-KEM-768)."""
    return provider_768.generate_keypair()


@pytest.fixture
def bob_kp_1024(provider_1024: MLKEMProvider) -> KeyPair:
    """Receiver key pair (ML-KEM-1024)."""
    return provider_1024.generate_keypair()


# ---------------------------------------------------------------------------
# 1. Initialization and configuration
# ---------------------------------------------------------------------------


class TestMLKEMInitialization:
    """Tests for MLKEMProvider construction and parameter set selection."""

    def test_default_parameter_set_is_mlkem_768(self) -> None:
        p = MLKEMProvider()
        assert p.parameter_set == "ML-KEM-768"
        assert p.parameter_set == DEFAULT_PARAMETER_SET

    def test_explicit_mlkem_768_initialization(self, provider_768: MLKEMProvider) -> None:
        assert provider_768.parameter_set == "ML-KEM-768"
        assert provider_768.public_key_size == 1184
        assert provider_768.ciphertext_size == 1088
        assert provider_768.shared_secret_size == 32

    def test_explicit_mlkem_1024_initialization(self, provider_1024: MLKEMProvider) -> None:
        assert provider_1024.parameter_set == "ML-KEM-1024"
        assert provider_1024.public_key_size == 1568
        assert provider_1024.ciphertext_size == 1568
        assert provider_1024.shared_secret_size == 32

    def test_unsupported_parameter_set_raises(self) -> None:
        with pytest.raises(UnsupportedAlgorithmError):
            MLKEMProvider("ML-KEM-512")

    def test_invalid_parameter_set_name_raises(self) -> None:
        with pytest.raises(UnsupportedAlgorithmError):
            MLKEMProvider("INVALID-PARAM-SET")


# ---------------------------------------------------------------------------
# 2. Key generation
# ---------------------------------------------------------------------------


class TestMLKEMKeyGeneration:
    """Tests for generate_keypair()."""

    def test_generate_returns_keypair(self, provider_768: MLKEMProvider) -> None:
        kp = provider_768.generate_keypair()
        assert isinstance(kp, KeyPair)

    def test_private_key_type_768(self, provider_768: MLKEMProvider) -> None:
        kp = provider_768.generate_keypair()
        assert isinstance(kp.private_key, MLKEM768PrivateKey)

    def test_public_key_type_768(self, provider_768: MLKEMProvider) -> None:
        kp = provider_768.generate_keypair()
        assert isinstance(kp.public_key, MLKEM768PublicKey)

    def test_private_key_type_1024(self, provider_1024: MLKEMProvider) -> None:
        kp = provider_1024.generate_keypair()
        assert isinstance(kp.private_key, MLKEM1024PrivateKey)

    def test_public_key_type_1024(self, provider_1024: MLKEMProvider) -> None:
        kp = provider_1024.generate_keypair()
        assert isinstance(kp.public_key, MLKEM1024PublicKey)

    def test_different_calls_produce_different_key_pairs(
        self, provider_768: MLKEMProvider
    ) -> None:
        kp1 = provider_768.generate_keypair()
        kp2 = provider_768.generate_keypair()
        pub1 = provider_768.export_public_key_bytes(kp1.public_key)
        pub2 = provider_768.export_public_key_bytes(kp2.public_key)
        assert pub1 != pub2, "Two key pair generations should produce different keys."


# ---------------------------------------------------------------------------
# 3. Encapsulation & Decapsulation
# ---------------------------------------------------------------------------


class TestMLKEMEncapsulationDecapsulation:
    """Tests for encapsulate() and decapsulate()."""

    def test_encapsulate_returns_shared_secret_and_ciphertext(
        self, provider_768: MLKEMProvider, bob_kp_768: KeyPair
    ) -> None:
        ss, ct = provider_768.encapsulate(bob_kp_768.public_key)
        assert isinstance(ss, bytes)
        assert isinstance(ct, bytes)
        assert len(ss) == 32
        assert len(ct) == 1088

    def test_encapsulate_and_decapsulate_derive_identical_shared_secret_768(
        self, provider_768: MLKEMProvider, bob_kp_768: KeyPair
    ) -> None:
        """Core KEM correctness property: sender and receiver recover the exact same secret."""
        ss_sender, ct = provider_768.encapsulate(bob_kp_768.public_key)
        ss_receiver = provider_768.decapsulate(bob_kp_768.private_key, ct)
        assert ss_sender == ss_receiver, (
            "Encapsulated and decapsulated shared secrets must be identical."
        )

    def test_encapsulate_and_decapsulate_derive_identical_shared_secret_1024(
        self, provider_1024: MLKEMProvider, bob_kp_1024: KeyPair
    ) -> None:
        ss_sender, ct = provider_1024.encapsulate(bob_kp_1024.public_key)
        ss_receiver = provider_1024.decapsulate(bob_kp_1024.private_key, ct)
        assert ss_sender == ss_receiver
        assert len(ct) == 1568
        assert len(ss_sender) == 32

    def test_encapsulate_is_randomized(
        self, provider_768: MLKEMProvider, bob_kp_768: KeyPair
    ) -> None:
        """Calling encapsulate twice with the same public key must yield different ciphertexts and secrets."""
        ss1, ct1 = provider_768.encapsulate(bob_kp_768.public_key)
        ss2, ct2 = provider_768.encapsulate(bob_kp_768.public_key)
        assert ct1 != ct2, "Encapsulation ciphertexts must be fresh."
        assert ss1 != ss2, "Encapsulation shared secrets must be fresh."

    def test_mismatched_private_key_produces_different_secret(
        self, provider_768: MLKEMProvider, bob_kp_768: KeyPair
    ) -> None:
        """Decapsulating with wrong private key should NOT recover Alice's secret."""
        charlie_kp = provider_768.generate_keypair()
        ss_alice, ct = provider_768.encapsulate(bob_kp_768.public_key)
        ss_charlie = provider_768.decapsulate(charlie_kp.private_key, ct)
        assert ss_alice != ss_charlie, "Wrong private key must not recover sender's shared secret."


# ---------------------------------------------------------------------------
# 4. Public Key Export / Import
# ---------------------------------------------------------------------------


class TestMLKEMSerialization:
    """Tests for export_public_key_bytes() and import_public_key_bytes()."""

    def test_export_returns_exact_bytes_768(
        self, provider_768: MLKEMProvider, bob_kp_768: KeyPair
    ) -> None:
        raw = provider_768.export_public_key_bytes(bob_kp_768.public_key)
        assert isinstance(raw, bytes)
        assert len(raw) == 1184

    def test_export_returns_exact_bytes_1024(
        self, provider_1024: MLKEMProvider, bob_kp_1024: KeyPair
    ) -> None:
        raw = provider_1024.export_public_key_bytes(bob_kp_1024.public_key)
        assert isinstance(raw, bytes)
        assert len(raw) == 1568

    def test_import_recovers_working_public_key(
        self, provider_768: MLKEMProvider, bob_kp_768: KeyPair
    ) -> None:
        raw = provider_768.export_public_key_bytes(bob_kp_768.public_key)
        imported_pub = provider_768.import_public_key_bytes(raw)

        # Encapsulate using imported key, decapsulate with original private key
        ss_sender, ct = provider_768.encapsulate(imported_pub)
        ss_receiver = provider_768.decapsulate(bob_kp_768.private_key, ct)
        assert ss_sender == ss_receiver

    def test_export_import_round_trip_equality(
        self, provider_768: MLKEMProvider, bob_kp_768: KeyPair
    ) -> None:
        raw1 = provider_768.export_public_key_bytes(bob_kp_768.public_key)
        imported_pub = provider_768.import_public_key_bytes(raw1)
        raw2 = provider_768.export_public_key_bytes(imported_pub)
        assert raw1 == raw2


# ---------------------------------------------------------------------------
# 5. Invalid Input Rejection
# ---------------------------------------------------------------------------


class TestMLKEMInvalidInputs:
    """Tests that malformed or incorrect inputs raise InvalidKeyError."""

    def test_encapsulate_none_raises(self, provider_768: MLKEMProvider) -> None:
        with pytest.raises(InvalidKeyError):
            provider_768.encapsulate(None)

    def test_encapsulate_wrong_type_raises(self, provider_768: MLKEMProvider) -> None:
        with pytest.raises(InvalidKeyError):
            provider_768.encapsulate("not-a-public-key")

    def test_decapsulate_none_private_key_raises(
        self, provider_768: MLKEMProvider, bob_kp_768: KeyPair
    ) -> None:
        _, ct = provider_768.encapsulate(bob_kp_768.public_key)
        with pytest.raises(InvalidKeyError):
            provider_768.decapsulate(None, ct)

    def test_decapsulate_wrong_type_private_key_raises(
        self, provider_768: MLKEMProvider, bob_kp_768: KeyPair
    ) -> None:
        _, ct = provider_768.encapsulate(bob_kp_768.public_key)
        with pytest.raises(InvalidKeyError):
            provider_768.decapsulate("not-a-key", ct)

    def test_decapsulate_none_ciphertext_raises(
        self, provider_768: MLKEMProvider, bob_kp_768: KeyPair
    ) -> None:
        with pytest.raises(InvalidKeyError):
            provider_768.decapsulate(bob_kp_768.private_key, None)

    def test_decapsulate_truncated_ciphertext_raises(
        self, provider_768: MLKEMProvider, bob_kp_768: KeyPair
    ) -> None:
        _, ct = provider_768.encapsulate(bob_kp_768.public_key)
        with pytest.raises(InvalidKeyError):
            provider_768.decapsulate(bob_kp_768.private_key, ct[:100])

    def test_decapsulate_extended_ciphertext_raises(
        self, provider_768: MLKEMProvider, bob_kp_768: KeyPair
    ) -> None:
        _, ct = provider_768.encapsulate(bob_kp_768.public_key)
        with pytest.raises(InvalidKeyError):
            provider_768.decapsulate(bob_kp_768.private_key, ct + b"extra")

    def test_export_none_raises(self, provider_768: MLKEMProvider) -> None:
        with pytest.raises(InvalidKeyError):
            provider_768.export_public_key_bytes(None)

    def test_export_wrong_type_raises(self, provider_768: MLKEMProvider) -> None:
        with pytest.raises(InvalidKeyError):
            provider_768.export_public_key_bytes(b"invalid-type")

    def test_import_empty_bytes_raises(self, provider_768: MLKEMProvider) -> None:
        with pytest.raises(InvalidKeyError):
            provider_768.import_public_key_bytes(b"")

    def test_import_truncated_bytes_raises(self, provider_768: MLKEMProvider) -> None:
        with pytest.raises(InvalidKeyError):
            provider_768.import_public_key_bytes(b"A" * 100)

    def test_import_wrong_type_raises(self, provider_768: MLKEMProvider) -> None:
        with pytest.raises(InvalidKeyError):
            provider_768.import_public_key_bytes("not-bytes")

    def test_exchange_raises_not_implemented(
        self, provider_768: MLKEMProvider, bob_kp_768: KeyPair
    ) -> None:
        alice_kp = provider_768.generate_keypair()
        with pytest.raises(NotImplementedError):
            provider_768.exchange(alice_kp.private_key, bob_kp_768.public_key)
