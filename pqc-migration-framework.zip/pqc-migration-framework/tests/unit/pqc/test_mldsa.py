"""
tests/unit/pqc/test_mldsa.py
Post-Quantum Secure Communication & Migration Framework

UNIT TESTS — MLDSAProvider (FIPS 204)

Tests verify the following properties:
  1. Initialization and parameter set selection (ML-DSA-44, ML-DSA-65, ML-DSA-87).
  2. Key pair generation succeeds and produces distinct keys.
  3. Digital signature generation and verification over various message sizes.
  4. Rejection of tampered messages, tampered signatures, and wrong public keys.
  5. Public key export and import round-trip.
  6. Parameter set dimensions conform to FIPS 204.
  7. Invalid inputs (None, wrong types, malformed lengths) are safely handled.
  8. No private key material is exposed through serialization.

No benchmarks. Real cryptographic operations only — no mocks.
"""

import pytest
from cryptography.hazmat.primitives.asymmetric.mldsa import (
    MLDSA44PrivateKey,
    MLDSA44PublicKey,
    MLDSA65PrivateKey,
    MLDSA65PublicKey,
    MLDSA87PrivateKey,
    MLDSA87PublicKey,
)

from src.exceptions import (
    InvalidKeyError,
    InvalidSignatureError,
    UnsupportedAlgorithmError,
)
from src.providers.base import KeyPair
from src.providers.pqc.mldsa_provider import (
    DEFAULT_PARAMETER_SET,
    MLDSAProvider,
)


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture
def provider_65() -> MLDSAProvider:
    return MLDSAProvider("ML-DSA-65")


@pytest.fixture
def provider_44() -> MLDSAProvider:
    return MLDSAProvider("ML-DSA-44")


@pytest.fixture
def provider_87() -> MLDSAProvider:
    return MLDSAProvider("ML-DSA-87")


@pytest.fixture
def kp_65(provider_65: MLDSAProvider) -> KeyPair:
    return provider_65.generate_keypair()


@pytest.fixture
def kp_44(provider_44: MLDSAProvider) -> KeyPair:
    return provider_44.generate_keypair()


@pytest.fixture
def kp_87(provider_87: MLDSAProvider) -> KeyPair:
    return provider_87.generate_keypair()


TEST_MESSAGE = b"Standard test message for ML-DSA signature verification."


# ---------------------------------------------------------------------------
# 1. Initialization and Parameter Sets
# ---------------------------------------------------------------------------


class TestMLDSAInitialization:
    """Tests for MLDSAProvider initialization and parameter set validation."""

    def test_default_parameter_set_is_mldsa_65(self) -> None:
        p = MLDSAProvider()
        assert p.parameter_set == "ML-DSA-65"
        assert p.parameter_set == DEFAULT_PARAMETER_SET

    def test_explicit_mldsa_65(self, provider_65: MLDSAProvider) -> None:
        assert provider_65.parameter_set == "ML-DSA-65"
        assert provider_65.public_key_size == 1952
        assert provider_65.signature_size == 3309

    def test_explicit_mldsa_44(self, provider_44: MLDSAProvider) -> None:
        assert provider_44.parameter_set == "ML-DSA-44"
        assert provider_44.public_key_size == 1312
        assert provider_44.signature_size == 2420

    def test_explicit_mldsa_87(self, provider_87: MLDSAProvider) -> None:
        assert provider_87.parameter_set == "ML-DSA-87"
        assert provider_87.public_key_size == 2592
        assert provider_87.signature_size == 4627

    def test_unsupported_parameter_set_raises(self) -> None:
        with pytest.raises(UnsupportedAlgorithmError):
            MLDSAProvider("ML-DSA-INVALID")


# ---------------------------------------------------------------------------
# 2. Key Generation
# ---------------------------------------------------------------------------


class TestMLDSAKeyGeneration:
    """Tests for generate_keypair()."""

    def test_generate_returns_keypair(self, provider_65: MLDSAProvider) -> None:
        kp = provider_65.generate_keypair()
        assert isinstance(kp, KeyPair)

    def test_key_types_65(self, kp_65: KeyPair) -> None:
        assert isinstance(kp_65.private_key, MLDSA65PrivateKey)
        assert isinstance(kp_65.public_key, MLDSA65PublicKey)

    def test_key_types_44(self, kp_44: KeyPair) -> None:
        assert isinstance(kp_44.private_key, MLDSA44PrivateKey)
        assert isinstance(kp_44.public_key, MLDSA44PublicKey)

    def test_key_types_87(self, kp_87: KeyPair) -> None:
        assert isinstance(kp_87.private_key, MLDSA87PrivateKey)
        assert isinstance(kp_87.public_key, MLDSA87PublicKey)

    def test_distinct_keypairs_produced(self, provider_65: MLDSAProvider) -> None:
        kp1 = provider_65.generate_keypair()
        kp2 = provider_65.generate_keypair()
        raw1 = provider_65.export_public_key_bytes(kp1.public_key)
        raw2 = provider_65.export_public_key_bytes(kp2.public_key)
        assert raw1 != raw2


# ---------------------------------------------------------------------------
# 3. Sign and Verify
# ---------------------------------------------------------------------------


class TestMLDSASignVerify:
    """Tests for sign() and verify()."""

    def test_sign_returns_expected_length_bytes_65(
        self, provider_65: MLDSAProvider, kp_65: KeyPair
    ) -> None:
        sig = provider_65.sign(kp_65.private_key, TEST_MESSAGE)
        assert isinstance(sig, bytes)
        assert len(sig) == 3309

    def test_sign_returns_expected_length_bytes_44(
        self, provider_44: MLDSAProvider, kp_44: KeyPair
    ) -> None:
        sig = provider_44.sign(kp_44.private_key, TEST_MESSAGE)
        assert isinstance(sig, bytes)
        assert len(sig) == 2420

    def test_sign_returns_expected_length_bytes_87(
        self, provider_87: MLDSAProvider, kp_87: KeyPair
    ) -> None:
        sig = provider_87.sign(kp_87.private_key, TEST_MESSAGE)
        assert isinstance(sig, bytes)
        assert len(sig) == 4627

    def test_valid_signature_verifies_65(
        self, provider_65: MLDSAProvider, kp_65: KeyPair
    ) -> None:
        sig = provider_65.sign(kp_65.private_key, TEST_MESSAGE)
        assert provider_65.verify(kp_65.public_key, TEST_MESSAGE, sig) is True

    def test_valid_signature_verifies_44(
        self, provider_44: MLDSAProvider, kp_44: KeyPair
    ) -> None:
        sig = provider_44.sign(kp_44.private_key, TEST_MESSAGE)
        assert provider_44.verify(kp_44.public_key, TEST_MESSAGE, sig) is True

    def test_valid_signature_verifies_87(
        self, provider_87: MLDSAProvider, kp_87: KeyPair
    ) -> None:
        sig = provider_87.sign(kp_87.private_key, TEST_MESSAGE)
        assert provider_87.verify(kp_87.public_key, TEST_MESSAGE, sig) is True

    def test_empty_message_signing(
        self, provider_65: MLDSAProvider, kp_65: KeyPair
    ) -> None:
        empty_msg = b""
        sig = provider_65.sign(kp_65.private_key, empty_msg)
        assert provider_65.verify(kp_65.public_key, empty_msg, sig) is True

    def test_large_message_signing(
        self, provider_65: MLDSAProvider, kp_65: KeyPair
    ) -> None:
        large_msg = b"M" * 200_000
        sig = provider_65.sign(kp_65.private_key, large_msg)
        assert provider_65.verify(kp_65.public_key, large_msg, sig) is True


# ---------------------------------------------------------------------------
# 4. Tampering and Rejection
# ---------------------------------------------------------------------------


class TestMLDSATamperingDetection:
    """Tests that any alteration to message, signature, or key causes verification failure."""

    def test_modified_message_fails(
        self, provider_65: MLDSAProvider, kp_65: KeyPair
    ) -> None:
        sig = provider_65.sign(kp_65.private_key, TEST_MESSAGE)
        assert provider_65.verify(kp_65.public_key, TEST_MESSAGE + b"!", sig) is False

    def test_single_byte_message_change_fails(
        self, provider_65: MLDSAProvider, kp_65: KeyPair
    ) -> None:
        sig = provider_65.sign(kp_65.private_key, TEST_MESSAGE)
        tampered_msg = bytes([TEST_MESSAGE[0] ^ 0x01]) + TEST_MESSAGE[1:]
        assert provider_65.verify(kp_65.public_key, tampered_msg, sig) is False

    def test_modified_signature_fails(
        self, provider_65: MLDSAProvider, kp_65: KeyPair
    ) -> None:
        sig = provider_65.sign(kp_65.private_key, TEST_MESSAGE)
        tampered_sig = bytes([sig[0] ^ 0xFF]) + sig[1:]
        assert provider_65.verify(kp_65.public_key, TEST_MESSAGE, tampered_sig) is False

    def test_wrong_public_key_fails(
        self, provider_65: MLDSAProvider, kp_65: KeyPair
    ) -> None:
        other_kp = provider_65.generate_keypair()
        sig = provider_65.sign(kp_65.private_key, TEST_MESSAGE)
        assert provider_65.verify(other_kp.public_key, TEST_MESSAGE, sig) is False

    def test_truncated_signature_fails(
        self, provider_65: MLDSAProvider, kp_65: KeyPair
    ) -> None:
        sig = provider_65.sign(kp_65.private_key, TEST_MESSAGE)
        assert provider_65.verify(kp_65.public_key, TEST_MESSAGE, sig[:100]) is False

    def test_empty_signature_fails(
        self, provider_65: MLDSAProvider, kp_65: KeyPair
    ) -> None:
        assert provider_65.verify(kp_65.public_key, TEST_MESSAGE, b"") is False


# ---------------------------------------------------------------------------
# 5. Public Key Serialization
# ---------------------------------------------------------------------------


class TestMLDSASerialization:
    """Tests for export_public_key_bytes() and import_public_key_bytes()."""

    def test_export_length_65(
        self, provider_65: MLDSAProvider, kp_65: KeyPair
    ) -> None:
        raw = provider_65.export_public_key_bytes(kp_65.public_key)
        assert isinstance(raw, bytes)
        assert len(raw) == 1952

    def test_export_length_44(
        self, provider_44: MLDSAProvider, kp_44: KeyPair
    ) -> None:
        raw = provider_44.export_public_key_bytes(kp_44.public_key)
        assert len(raw) == 1312

    def test_export_length_87(
        self, provider_87: MLDSAProvider, kp_87: KeyPair
    ) -> None:
        raw = provider_87.export_public_key_bytes(kp_87.public_key)
        assert len(raw) == 2592

    def test_import_verifies_original_signature(
        self, provider_65: MLDSAProvider, kp_65: KeyPair
    ) -> None:
        sig = provider_65.sign(kp_65.private_key, TEST_MESSAGE)
        raw = provider_65.export_public_key_bytes(kp_65.public_key)
        imported_pub = provider_65.import_public_key_bytes(raw)
        assert provider_65.verify(imported_pub, TEST_MESSAGE, sig) is True

    def test_export_import_round_trip_equality(
        self, provider_65: MLDSAProvider, kp_65: KeyPair
    ) -> None:
        raw1 = provider_65.export_public_key_bytes(kp_65.public_key)
        imported_pub = provider_65.import_public_key_bytes(raw1)
        raw2 = provider_65.export_public_key_bytes(imported_pub)
        assert raw1 == raw2


# ---------------------------------------------------------------------------
# 6. Invalid Input Handling
# ---------------------------------------------------------------------------


class TestMLDSAInvalidInputs:
    """Tests for invalid input exceptions."""

    def test_sign_none_private_key_raises(
        self, provider_65: MLDSAProvider
    ) -> None:
        with pytest.raises(InvalidKeyError):
            provider_65.sign(None, TEST_MESSAGE)

    def test_sign_wrong_type_private_key_raises(
        self, provider_65: MLDSAProvider
    ) -> None:
        with pytest.raises(InvalidKeyError):
            provider_65.sign("not-a-key", TEST_MESSAGE)

    def test_sign_none_message_raises(
        self, provider_65: MLDSAProvider, kp_65: KeyPair
    ) -> None:
        with pytest.raises(InvalidSignatureError):
            provider_65.sign(kp_65.private_key, None)

    def test_verify_none_public_key_raises(
        self, provider_65: MLDSAProvider
    ) -> None:
        with pytest.raises(InvalidKeyError):
            provider_65.verify(None, TEST_MESSAGE, b"sig")

    def test_verify_wrong_type_public_key_raises(
        self, provider_65: MLDSAProvider
    ) -> None:
        with pytest.raises(InvalidKeyError):
            provider_65.verify(b"not-a-key", TEST_MESSAGE, b"sig")

    def test_verify_none_message_raises(
        self, provider_65: MLDSAProvider, kp_65: KeyPair
    ) -> None:
        with pytest.raises(InvalidSignatureError):
            provider_65.verify(kp_65.public_key, None, b"sig")

    def test_verify_none_signature_raises(
        self, provider_65: MLDSAProvider, kp_65: KeyPair
    ) -> None:
        with pytest.raises(InvalidSignatureError):
            provider_65.verify(kp_65.public_key, TEST_MESSAGE, None)

    def test_export_none_raises(self, provider_65: MLDSAProvider) -> None:
        with pytest.raises(InvalidKeyError):
            provider_65.export_public_key_bytes(None)

    def test_import_empty_bytes_raises(self, provider_65: MLDSAProvider) -> None:
        with pytest.raises(InvalidKeyError):
            provider_65.import_public_key_bytes(b"")

    def test_import_truncated_bytes_raises(self, provider_65: MLDSAProvider) -> None:
        with pytest.raises(InvalidKeyError):
            provider_65.import_public_key_bytes(b"X" * 100)

    def test_import_none_raises(self, provider_65: MLDSAProvider) -> None:
        with pytest.raises(InvalidKeyError):
            provider_65.import_public_key_bytes(None)
