"""
tests/unit/pqc/test_slhdsa.py
Post-Quantum Secure Communication & Migration Framework

UNIT TESTS — SLHDSAProvider (FIPS 205)

Tests verify the following properties:
  1. Initialization and parameter set selection (SLH-DSA-SHAKE-128f default, variants & aliases).
  2. Key pair generation succeeds and produces distinct keys.
  3. Digital signature generation and verification over various message sizes.
  4. Rejection of tampered messages, tampered signatures, and wrong public keys.
  5. Public key export and import round-trip.
  6. Parameter set dimensions conform to FIPS 205.
  7. Invalid inputs (None, wrong types, malformed lengths) are safely handled.
  8. No private key material is exposed through serialization.

No benchmarks. Real cryptographic operations only — no mocks.
"""

import pytest
import slhdsa

from src.exceptions import (
    InvalidKeyError,
    InvalidSignatureError,
    UnsupportedAlgorithmError,
)
from src.providers.base import KeyPair
from src.providers.pqc.slhdsa_provider import (
    DEFAULT_PARAMETER_SET,
    SLHDSAProvider,
)


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture
def provider_128f() -> SLHDSAProvider:
    return SLHDSAProvider("SLH-DSA-SHAKE-128f")


@pytest.fixture
def provider_sha2_128f() -> SLHDSAProvider:
    return SLHDSAProvider("SLH-DSA-SHA2-128f")


@pytest.fixture
def kp_128f(provider_128f: SLHDSAProvider) -> KeyPair:
    return provider_128f.generate_keypair()


TEST_MESSAGE = b"Standard test message for SLH-DSA hash-based signature verification."


# ---------------------------------------------------------------------------
# 1. Initialization and Parameter Sets
# ---------------------------------------------------------------------------


class TestSLHDSAInitialization:
    """Tests for SLHDSAProvider initialization and parameter set validation."""

    def test_default_parameter_set_is_shake_128f(self) -> None:
        p = SLHDSAProvider()
        assert p.parameter_set == "SLH-DSA-SHAKE-128f"
        assert p.parameter_set == DEFAULT_PARAMETER_SET

    def test_explicit_shake_128f(self, provider_128f: SLHDSAProvider) -> None:
        assert provider_128f.parameter_set == "SLH-DSA-SHAKE-128f"
        assert provider_128f.public_key_size == 32
        assert provider_128f.signature_size == 17088

    def test_explicit_sha2_128f(self, provider_sha2_128f: SLHDSAProvider) -> None:
        assert provider_sha2_128f.parameter_set == "SLH-DSA-SHA2-128f"
        assert provider_sha2_128f.public_key_size == 32
        assert provider_sha2_128f.signature_size == 17088

    def test_alias_sphincs_shake_128f(self) -> None:
        p = SLHDSAProvider("SPHINCS+-SHAKE-128f")
        assert p.parameter_set == "SLH-DSA-SHAKE-128f"

    def test_unsupported_parameter_set_raises(self) -> None:
        with pytest.raises(UnsupportedAlgorithmError):
            SLHDSAProvider("SLH-DSA-UNKNOWN-999")


# ---------------------------------------------------------------------------
# 2. Key Generation
# ---------------------------------------------------------------------------


class TestSLHDSAKeyGeneration:
    """Tests for generate_keypair()."""

    def test_generate_returns_keypair(self, provider_128f: SLHDSAProvider) -> None:
        kp = provider_128f.generate_keypair()
        assert isinstance(kp, KeyPair)

    def test_key_types(self, kp_128f: KeyPair) -> None:
        assert isinstance(kp_128f.private_key, slhdsa.SecretKey)
        assert isinstance(kp_128f.public_key, slhdsa.PublicKey)

    def test_distinct_keypairs_produced(self, provider_128f: SLHDSAProvider) -> None:
        kp1 = provider_128f.generate_keypair()
        kp2 = provider_128f.generate_keypair()
        raw1 = provider_128f.export_public_key_bytes(kp1.public_key)
        raw2 = provider_128f.export_public_key_bytes(kp2.public_key)
        assert raw1 != raw2


# ---------------------------------------------------------------------------
# 3. Sign and Verify
# ---------------------------------------------------------------------------


class TestSLHDSASignVerify:
    """Tests for sign() and verify()."""

    def test_sign_returns_expected_length_bytes(
        self, provider_128f: SLHDSAProvider, kp_128f: KeyPair
    ) -> None:
        sig = provider_128f.sign(kp_128f.private_key, TEST_MESSAGE)
        assert isinstance(sig, bytes)
        assert len(sig) == 17088

    def test_valid_signature_verifies(
        self, provider_128f: SLHDSAProvider, kp_128f: KeyPair
    ) -> None:
        sig = provider_128f.sign(kp_128f.private_key, TEST_MESSAGE)
        assert provider_128f.verify(kp_128f.public_key, TEST_MESSAGE, sig) is True

    def test_empty_message_signing(
        self, provider_128f: SLHDSAProvider, kp_128f: KeyPair
    ) -> None:
        empty_msg = b""
        sig = provider_128f.sign(kp_128f.private_key, empty_msg)
        assert provider_128f.verify(kp_128f.public_key, empty_msg, sig) is True

    def test_large_message_signing(
        self, provider_128f: SLHDSAProvider, kp_128f: KeyPair
    ) -> None:
        large_msg = b"H" * 50_000
        sig = provider_128f.sign(kp_128f.private_key, large_msg)
        assert provider_128f.verify(kp_128f.public_key, large_msg, sig) is True


# ---------------------------------------------------------------------------
# 4. Tampering and Rejection
# ---------------------------------------------------------------------------


class TestSLHDSATamperingDetection:
    """Tests that tampering with message, signature, or key causes verification failure."""

    def test_modified_message_fails(
        self, provider_128f: SLHDSAProvider, kp_128f: KeyPair
    ) -> None:
        sig = provider_128f.sign(kp_128f.private_key, TEST_MESSAGE)
        assert provider_128f.verify(kp_128f.public_key, TEST_MESSAGE + b"!", sig) is False

    def test_single_byte_message_change_fails(
        self, provider_128f: SLHDSAProvider, kp_128f: KeyPair
    ) -> None:
        sig = provider_128f.sign(kp_128f.private_key, TEST_MESSAGE)
        tampered_msg = bytes([TEST_MESSAGE[0] ^ 0x01]) + TEST_MESSAGE[1:]
        assert provider_128f.verify(kp_128f.public_key, tampered_msg, sig) is False

    def test_modified_signature_fails(
        self, provider_128f: SLHDSAProvider, kp_128f: KeyPair
    ) -> None:
        sig = provider_128f.sign(kp_128f.private_key, TEST_MESSAGE)
        tampered_sig = bytes([sig[0] ^ 0xFF]) + sig[1:]
        assert provider_128f.verify(kp_128f.public_key, TEST_MESSAGE, tampered_sig) is False

    def test_wrong_public_key_fails(
        self, provider_128f: SLHDSAProvider, kp_128f: KeyPair
    ) -> None:
        other_kp = provider_128f.generate_keypair()
        sig = provider_128f.sign(kp_128f.private_key, TEST_MESSAGE)
        assert provider_128f.verify(other_kp.public_key, TEST_MESSAGE, sig) is False

    def test_truncated_signature_fails(
        self, provider_128f: SLHDSAProvider, kp_128f: KeyPair
    ) -> None:
        sig = provider_128f.sign(kp_128f.private_key, TEST_MESSAGE)
        assert provider_128f.verify(kp_128f.public_key, TEST_MESSAGE, sig[:100]) is False

    def test_empty_signature_fails(
        self, provider_128f: SLHDSAProvider, kp_128f: KeyPair
    ) -> None:
        assert provider_128f.verify(kp_128f.public_key, TEST_MESSAGE, b"") is False


# ---------------------------------------------------------------------------
# 5. Public Key Serialization
# ---------------------------------------------------------------------------


class TestSLHDSASerialization:
    """Tests for export_public_key_bytes() and import_public_key_bytes()."""

    def test_export_length(
        self, provider_128f: SLHDSAProvider, kp_128f: KeyPair
    ) -> None:
        raw = provider_128f.export_public_key_bytes(kp_128f.public_key)
        assert isinstance(raw, bytes)
        assert len(raw) == 32

    def test_import_verifies_original_signature(
        self, provider_128f: SLHDSAProvider, kp_128f: KeyPair
    ) -> None:
        sig = provider_128f.sign(kp_128f.private_key, TEST_MESSAGE)
        raw = provider_128f.export_public_key_bytes(kp_128f.public_key)
        imported_pub = provider_128f.import_public_key_bytes(raw)
        assert provider_128f.verify(imported_pub, TEST_MESSAGE, sig) is True

    def test_export_import_round_trip_equality(
        self, provider_128f: SLHDSAProvider, kp_128f: KeyPair
    ) -> None:
        raw1 = provider_128f.export_public_key_bytes(kp_128f.public_key)
        imported_pub = provider_128f.import_public_key_bytes(raw1)
        raw2 = provider_128f.export_public_key_bytes(imported_pub)
        assert raw1 == raw2


# ---------------------------------------------------------------------------
# 6. Invalid Input Handling
# ---------------------------------------------------------------------------


class TestSLHDSAInvalidInputs:
    """Tests for invalid input exceptions."""

    def test_sign_none_private_key_raises(
        self, provider_128f: SLHDSAProvider
    ) -> None:
        with pytest.raises(InvalidKeyError):
            provider_128f.sign(None, TEST_MESSAGE)

    def test_sign_wrong_type_private_key_raises(
        self, provider_128f: SLHDSAProvider
    ) -> None:
        with pytest.raises(InvalidKeyError):
            provider_128f.sign("not-a-key", TEST_MESSAGE)

    def test_sign_none_message_raises(
        self, provider_128f: SLHDSAProvider, kp_128f: KeyPair
    ) -> None:
        with pytest.raises(InvalidSignatureError):
            provider_128f.sign(kp_128f.private_key, None)

    def test_verify_none_public_key_raises(
        self, provider_128f: SLHDSAProvider
    ) -> None:
        with pytest.raises(InvalidKeyError):
            provider_128f.verify(None, TEST_MESSAGE, b"sig")

    def test_verify_wrong_type_public_key_raises(
        self, provider_128f: SLHDSAProvider
    ) -> None:
        with pytest.raises(InvalidKeyError):
            provider_128f.verify(b"not-a-key", TEST_MESSAGE, b"sig")

    def test_verify_none_message_raises(
        self, provider_128f: SLHDSAProvider, kp_128f: KeyPair
    ) -> None:
        with pytest.raises(InvalidSignatureError):
            provider_128f.verify(kp_128f.public_key, None, b"sig")

    def test_verify_none_signature_raises(
        self, provider_128f: SLHDSAProvider, kp_128f: KeyPair
    ) -> None:
        with pytest.raises(InvalidSignatureError):
            provider_128f.verify(kp_128f.public_key, TEST_MESSAGE, None)

    def test_export_none_raises(self, provider_128f: SLHDSAProvider) -> None:
        with pytest.raises(InvalidKeyError):
            provider_128f.export_public_key_bytes(None)

    def test_import_empty_bytes_raises(self, provider_128f: SLHDSAProvider) -> None:
        with pytest.raises(InvalidKeyError):
            provider_128f.import_public_key_bytes(b"")

    def test_import_truncated_bytes_raises(self, provider_128f: SLHDSAProvider) -> None:
        with pytest.raises(InvalidKeyError):
            provider_128f.import_public_key_bytes(b"X" * 10)

    def test_import_none_raises(self, provider_128f: SLHDSAProvider) -> None:
        with pytest.raises(InvalidKeyError):
            provider_128f.import_public_key_bytes(None)
