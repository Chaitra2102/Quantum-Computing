"""
tests/unit/communication/test_session.py
Post-Quantum Secure Communication & Migration Framework

Unit tests for SecureSession and SessionResult high-level communication layer.

Phase 8: Validates session creation, configuration binding, end-to-end exchange,
safe metadata inspection, and secret non-exposure across Modes A, B, C, and D.
"""

import pytest

from src.communication.session import SecureSession, SessionResult
from src.config.modes import (
    CLASSICAL_ECDH_ECDSA_AES256_GCM,
    HYBRID_ECDH_MLKEM_ECDSA_AES256_GCM,
    HYBRID_ECDH_MLKEM_MLDSA_AES256_GCM,
    HYBRID_ECDH_MLKEM_SLHDSA_AES256_GCM,
    PQC_MLKEM_MLDSA_AES256_GCM,
    PQC_MLKEM_SLHDSA_AES256_GCM,
    Mode,
)
from src.exceptions import PQCFrameworkError, UnsupportedAlgorithmError


class TestSecureSessionCreation:
    """Tests for SecureSession instantiation across all modes."""

    def test_create_mode_a_session(self):
        session = SecureSession.create(Mode.A)
        assert session.mode is Mode.A
        assert session.algorithm_id == CLASSICAL_ECDH_ECDSA_AES256_GCM
        assert session.state == "INITIALIZED"
        assert len(session.session_id) == 32

    def test_create_mode_b_session(self):
        session = SecureSession.create(Mode.B)
        assert session.mode is Mode.B
        assert session.algorithm_id == PQC_MLKEM_MLDSA_AES256_GCM

    def test_create_mode_c_session(self):
        session = SecureSession.create(Mode.C)
        assert session.mode is Mode.C
        assert session.algorithm_id == PQC_MLKEM_SLHDSA_AES256_GCM

    def test_create_mode_d_default_mldsa_session(self):
        session = SecureSession.create(Mode.D)
        assert session.mode is Mode.D
        assert session.algorithm_id == HYBRID_ECDH_MLKEM_MLDSA_AES256_GCM

    def test_create_mode_d_slhdsa_session(self):
        session = SecureSession.create(Mode.D, sig_provider_type="slhdsa")
        assert session.mode is Mode.D
        assert session.algorithm_id == HYBRID_ECDH_MLKEM_SLHDSA_AES256_GCM

    def test_create_mode_d_ecdsa_session(self):
        session = SecureSession.create(Mode.D, sig_provider_type="ecdsa")
        assert session.mode is Mode.D
        assert session.algorithm_id == HYBRID_ECDH_MLKEM_ECDSA_AES256_GCM

    def test_create_with_custom_session_id(self):
        custom_id = "custom-session-123456"
        session = SecureSession.create(Mode.A, session_id=custom_id)
        assert session.session_id == custom_id

    def test_create_invalid_mode_raises(self):
        with pytest.raises(UnsupportedAlgorithmError):
            SecureSession.create("INVALID_MODE")


class TestSecureSessionWorkflow:
    """Tests for SecureSession.run_exchange() across all modes."""

    @pytest.mark.parametrize("mode", [Mode.A, Mode.B, Mode.C])
    def test_session_run_exchange_string_payload(self, mode: Mode):
        session = SecureSession.create(mode)
        message_text = f"Test exchange payload for {mode.value}"
        result = session.run_exchange(message_text, aad=b"auth-context")

        assert isinstance(result, SessionResult)
        assert result.status == "SUCCESS"
        assert result.mode is mode
        assert result.plaintext_str == message_text
        assert session.state == "COMPLETED"
        assert session.last_result is result

    @pytest.mark.parametrize("sig_type", ["mldsa", "slhdsa", "ecdsa"])
    def test_mode_d_session_run_exchange_variants(self, sig_type: str):
        session = SecureSession.create(Mode.D, sig_provider_type=sig_type)
        message_bytes = b"\x00\x01\x02\x03\xfe\xff binary hybrid payload"
        result = session.run_exchange(message_bytes, metadata={"app": "pqc-test"})

        assert result.status == "SUCCESS"
        assert result.plaintext == message_bytes
        assert result.metadata is not None
        assert result.metadata["app"] == "pqc-test"
        assert result.metadata["session_id"] == session.session_id

    def test_invalid_plaintext_type_raises(self):
        session = SecureSession.create(Mode.A)
        with pytest.raises(PQCFrameworkError, match="must be str or bytes"):
            session.run_exchange(12345)  # type: ignore


class TestSecureSessionInspection:
    """Tests for safe metadata inspection without secret exposure."""

    def test_inspect_config_contains_no_secrets(self):
        session = SecureSession.create(Mode.D, sig_provider_type="mldsa")
        cfg_meta = session.inspect_config()

        assert cfg_meta["mode"] == "D"
        assert cfg_meta["algorithm_id"] == HYBRID_ECDH_MLKEM_MLDSA_AES256_GCM
        assert cfg_meta["key_establishment"] == "Hybrid (ECDH P-384 + ML-KEM-768)"
        assert cfg_meta["signature"] == "ML-DSA-65"
        assert cfg_meta["encryption"] == "AES-256-GCM"
        assert cfg_meta["kdf"] == "HKDF-SHA-384"

        # Ensure no sensitive keys exist in dict
        for key in ["private_key", "secret_key", "shared_secret", "aes_key"]:
            assert key not in cfg_meta

    def test_inspect_message_returns_accurate_metrics(self):
        session = SecureSession.create(Mode.B)
        result = session.run_exchange("Inspection test message")
        msg_meta = result.inspect_message()

        assert msg_meta["protocol_version"] == "pqcf-v1"
        assert msg_meta["algorithm_id"] == PQC_MLKEM_MLDSA_AES256_GCM
        assert msg_meta["ciphertext_bytes"] > 0
        assert msg_meta["nonce_bytes"] == 12
        assert msg_meta["signature_bytes"] > 0
        assert msg_meta["ke_ciphertext_bytes"] > 0
        assert msg_meta["sender_ke_public_key_bytes"] > 0
        assert msg_meta["sender_sig_public_key_bytes"] > 0

    def test_session_result_to_dict_serializable_and_clean(self):
        session = SecureSession.create(Mode.A)
        result = session.run_exchange("Clean serialization test")
        res_dict = result.to_dict()

        assert res_dict["status"] == "SUCCESS"
        assert res_dict["recovered_plaintext"] == "Clean serialization test"
        assert res_dict["mode"] == "A"
        assert res_dict["algorithm_id"] == CLASSICAL_ECDH_ECDSA_AES256_GCM

        import json
        json_str = json.dumps(res_dict)
        assert "private" not in json_str.lower()
        assert "secret_key" not in json_str.lower()
        assert "aes_key" not in json_str.lower()
