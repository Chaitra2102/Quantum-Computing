"""
tests/unit/classical/test_hkdf.py
Post-Quantum Secure Communication & Migration Framework

UNIT TESTS — HKDFDerivationProvider

Tests verify the following properties:
  1. Same input parameters produce the same derived key (determinism).
  2. Changed IKM produces a different derived key.
  3. Changed info produces a different derived key.
  4. Changed salt produces a different derived key.
  5. Output has the expected length.
  6. AES-256 length (32 bytes) is correctly produced.
  7. Invalid parameters are rejected.

No benchmarks. Real HKDF-SHA-384 operations — no mocks.
"""

import pytest

from src.exceptions import InvalidKeyError
from src.providers.symmetric.hkdf_provider import AES256_KEY_LENGTH, HKDFDerivationProvider


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture
def provider() -> HKDFDerivationProvider:
    return HKDFDerivationProvider()


# Simulated ECDH shared secret (48 bytes for P-384)
FAKE_SHARED_SECRET = bytes(range(48))  # deterministic for testing
ALT_SHARED_SECRET  = bytes(range(48, 96))


# ---------------------------------------------------------------------------
# 1. Determinism: same inputs → same output
# ---------------------------------------------------------------------------


class TestHKDFDeterminism:
    """Same inputs must always produce the same key."""

    def test_same_inputs_produce_same_output(self, provider: HKDFDerivationProvider) -> None:
        key1 = provider.derive(
            FAKE_SHARED_SECRET,
            AES256_KEY_LENGTH,
            salt=b"test-salt",
            info=b"test-info",
        )
        key2 = provider.derive(
            FAKE_SHARED_SECRET,
            AES256_KEY_LENGTH,
            salt=b"test-salt",
            info=b"test-info",
        )
        assert key1 == key2, "HKDF with identical inputs must produce identical output."

    def test_same_inputs_no_salt_produce_same_output(
        self, provider: HKDFDerivationProvider
    ) -> None:
        key1 = provider.derive(FAKE_SHARED_SECRET, AES256_KEY_LENGTH)
        key2 = provider.derive(FAKE_SHARED_SECRET, AES256_KEY_LENGTH)
        assert key1 == key2


# ---------------------------------------------------------------------------
# 2. Sensitivity to input changes
# ---------------------------------------------------------------------------


class TestHKDFSensitivity:
    """Different inputs must produce different outputs."""

    def test_different_ikm_produces_different_key(
        self, provider: HKDFDerivationProvider
    ) -> None:
        key1 = provider.derive(FAKE_SHARED_SECRET, AES256_KEY_LENGTH)
        key2 = provider.derive(ALT_SHARED_SECRET,  AES256_KEY_LENGTH)
        assert key1 != key2, "Different IKM must produce different derived keys."

    def test_different_info_produces_different_key(
        self, provider: HKDFDerivationProvider
    ) -> None:
        key1 = provider.derive(FAKE_SHARED_SECRET, AES256_KEY_LENGTH, info=b"context-A")
        key2 = provider.derive(FAKE_SHARED_SECRET, AES256_KEY_LENGTH, info=b"context-B")
        assert key1 != key2, "Different info must produce different derived keys."

    def test_different_salt_produces_different_key(
        self, provider: HKDFDerivationProvider
    ) -> None:
        key1 = provider.derive(FAKE_SHARED_SECRET, AES256_KEY_LENGTH, salt=b"salt-1")
        key2 = provider.derive(FAKE_SHARED_SECRET, AES256_KEY_LENGTH, salt=b"salt-2")
        assert key1 != key2, "Different salt must produce different derived keys."

    def test_with_and_without_salt_differs(
        self, provider: HKDFDerivationProvider
    ) -> None:
        key_no_salt   = provider.derive(FAKE_SHARED_SECRET, AES256_KEY_LENGTH, salt=None)
        key_with_salt = provider.derive(FAKE_SHARED_SECRET, AES256_KEY_LENGTH, salt=b"s")
        assert key_no_salt != key_with_salt

    def test_one_byte_ikm_change_produces_different_key(
        self, provider: HKDFDerivationProvider
    ) -> None:
        ikm_a = b"\x00" * 48
        ikm_b = b"\x01" + b"\x00" * 47
        key_a = provider.derive(ikm_a, AES256_KEY_LENGTH)
        key_b = provider.derive(ikm_b, AES256_KEY_LENGTH)
        assert key_a != key_b


# ---------------------------------------------------------------------------
# 3. Output length
# ---------------------------------------------------------------------------


class TestHKDFOutputLength:
    """Output must be exactly the requested length."""

    def test_output_is_32_bytes_for_aes256(self, provider: HKDFDerivationProvider) -> None:
        key = provider.derive(FAKE_SHARED_SECRET, AES256_KEY_LENGTH)
        assert len(key) == AES256_KEY_LENGTH == 32

    def test_output_is_16_bytes_when_requested(
        self, provider: HKDFDerivationProvider
    ) -> None:
        key = provider.derive(FAKE_SHARED_SECRET, 16)
        assert len(key) == 16

    def test_output_is_64_bytes_when_requested(
        self, provider: HKDFDerivationProvider
    ) -> None:
        key = provider.derive(FAKE_SHARED_SECRET, 64)
        assert len(key) == 64

    def test_output_is_48_bytes_when_requested(
        self, provider: HKDFDerivationProvider
    ) -> None:
        key = provider.derive(FAKE_SHARED_SECRET, 48)
        assert len(key) == 48

    def test_output_is_bytes_type(self, provider: HKDFDerivationProvider) -> None:
        key = provider.derive(FAKE_SHARED_SECRET, AES256_KEY_LENGTH)
        assert isinstance(key, bytes)

    def test_aes256_key_length_constant_is_32(self) -> None:
        assert AES256_KEY_LENGTH == 32


# ---------------------------------------------------------------------------
# 4. Invalid parameter rejection
# ---------------------------------------------------------------------------


class TestHKDFInvalidInputs:
    """Invalid parameters must be rejected with appropriate exceptions."""

    def test_empty_ikm_raises(self, provider: HKDFDerivationProvider) -> None:
        with pytest.raises(InvalidKeyError):
            provider.derive(b"", AES256_KEY_LENGTH)

    def test_none_ikm_raises(self, provider: HKDFDerivationProvider) -> None:
        with pytest.raises((InvalidKeyError, TypeError)):
            provider.derive(None, AES256_KEY_LENGTH)

    def test_zero_length_raises(self, provider: HKDFDerivationProvider) -> None:
        with pytest.raises((ValueError, Exception)):
            provider.derive(FAKE_SHARED_SECRET, 0)

    def test_negative_length_raises(self, provider: HKDFDerivationProvider) -> None:
        with pytest.raises((ValueError, Exception)):
            provider.derive(FAKE_SHARED_SECRET, -1)

    def test_none_info_raises(self, provider: HKDFDerivationProvider) -> None:
        with pytest.raises(ValueError):
            provider.derive(FAKE_SHARED_SECRET, AES256_KEY_LENGTH, info=None)

    def test_empty_info_is_accepted(self, provider: HKDFDerivationProvider) -> None:
        """info=b'' (empty bytes) is valid per RFC 5869."""
        key = provider.derive(FAKE_SHARED_SECRET, AES256_KEY_LENGTH, info=b"")
        assert len(key) == AES256_KEY_LENGTH
