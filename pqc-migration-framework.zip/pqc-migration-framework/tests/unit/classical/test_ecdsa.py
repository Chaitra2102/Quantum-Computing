"""
tests/unit/classical/test_ecdsa.py
Post-Quantum Secure Communication & Migration Framework

UNIT TESTS — ECDSAProvider

Tests verify the following properties:
  1. Key pair generation succeeds and produces distinct keys.
  2. Valid signatures verify correctly.
  3. Modified messages fail verification (return False).
  4. Modified signatures fail verification (return False).
  5. Wrong public key fails verification (return False).
  6. Public key export/import round-trip.
  7. Invalid inputs are rejected with appropriate exceptions.

Security: verify() returns False for incorrect signatures, NOT raises.
InvalidSignatureError is only raised for structurally malformed bytes.

No benchmarks. Real cryptographic operations only — no mocks.
"""

import pytest

from cryptography.hazmat.primitives.asymmetric.ec import (
    EllipticCurvePrivateKey,
    EllipticCurvePublicKey,
)

from src.exceptions import InvalidKeyError, InvalidSignatureError
from src.providers.base import KeyPair
from src.providers.classical.ecdsa_provider import ECDSAProvider


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture
def provider() -> ECDSAProvider:
    return ECDSAProvider()


@pytest.fixture
def alice_kp(provider: ECDSAProvider) -> KeyPair:
    return provider.generate_keypair()


@pytest.fixture
def bob_kp(provider: ECDSAProvider) -> KeyPair:
    return provider.generate_keypair()


TEST_MESSAGE = b"The quick brown fox jumps over the lazy dog"
DIFFERENT_MESSAGE = b"A completely different message"


# ---------------------------------------------------------------------------
# 1. Key generation
# ---------------------------------------------------------------------------


class TestECDSAKeyGeneration:
    """Tests for generate_keypair()."""

    def test_generate_returns_keypair(self, provider: ECDSAProvider) -> None:
        kp = provider.generate_keypair()
        assert isinstance(kp, KeyPair)

    def test_private_key_type(self, provider: ECDSAProvider) -> None:
        kp = provider.generate_keypair()
        assert isinstance(kp.private_key, EllipticCurvePrivateKey)

    def test_public_key_type(self, provider: ECDSAProvider) -> None:
        kp = provider.generate_keypair()
        assert isinstance(kp.public_key, EllipticCurvePublicKey)

    def test_different_calls_produce_different_keys(self, provider: ECDSAProvider) -> None:
        kp1 = provider.generate_keypair()
        kp2 = provider.generate_keypair()
        pub1 = provider.export_public_key_bytes(kp1.public_key)
        pub2 = provider.export_public_key_bytes(kp2.public_key)
        assert pub1 != pub2

    def test_key_is_on_p384_curve(self, provider: ECDSAProvider) -> None:
        from cryptography.hazmat.primitives.asymmetric.ec import SECP384R1
        kp = provider.generate_keypair()
        assert isinstance(kp.public_key.curve, SECP384R1)


# ---------------------------------------------------------------------------
# 2. Sign and verify — happy path
# ---------------------------------------------------------------------------


class TestECDSASignVerify:
    """Tests for sign() and verify() — valid cases."""

    def test_sign_returns_bytes(self, provider: ECDSAProvider, alice_kp: KeyPair) -> None:
        sig = provider.sign(alice_kp.private_key, TEST_MESSAGE)
        assert isinstance(sig, bytes)
        assert len(sig) > 0

    def test_valid_signature_verifies(
        self, provider: ECDSAProvider, alice_kp: KeyPair
    ) -> None:
        sig = provider.sign(alice_kp.private_key, TEST_MESSAGE)
        result = provider.verify(alice_kp.public_key, TEST_MESSAGE, sig)
        assert result is True, "Valid signature should verify as True."

    def test_empty_message_can_be_signed_and_verified(
        self, provider: ECDSAProvider, alice_kp: KeyPair
    ) -> None:
        sig = provider.sign(alice_kp.private_key, b"")
        result = provider.verify(alice_kp.public_key, b"", sig)
        assert result is True

    def test_large_message_can_be_signed_and_verified(
        self, provider: ECDSAProvider, alice_kp: KeyPair
    ) -> None:
        large_msg = b"X" * 100_000
        sig = provider.sign(alice_kp.private_key, large_msg)
        result = provider.verify(alice_kp.public_key, large_msg, sig)
        assert result is True

    def test_signature_is_der_encoded(
        self, provider: ECDSAProvider, alice_kp: KeyPair
    ) -> None:
        """DER-encoded ECDSA signatures start with 0x30 (SEQUENCE)."""
        sig = provider.sign(alice_kp.private_key, TEST_MESSAGE)
        assert sig[0] == 0x30, "ECDSA DER signature should start with 0x30 (SEQUENCE tag)."

    def test_verify_returns_bool(
        self, provider: ECDSAProvider, alice_kp: KeyPair
    ) -> None:
        sig = provider.sign(alice_kp.private_key, TEST_MESSAGE)
        result = provider.verify(alice_kp.public_key, TEST_MESSAGE, sig)
        assert isinstance(result, bool)


# ---------------------------------------------------------------------------
# 3. Tampering detection — MUST return False, not raise
# ---------------------------------------------------------------------------


class TestECDSATamperingDetection:
    """Tests that tampering causes verify() to return False."""

    def test_modified_message_fails_verification(
        self, provider: ECDSAProvider, alice_kp: KeyPair
    ) -> None:
        """
        Security property: a signature over message A must not verify for message B.
        """
        sig = provider.sign(alice_kp.private_key, TEST_MESSAGE)
        result = provider.verify(alice_kp.public_key, DIFFERENT_MESSAGE, sig)
        assert result is False, (
            "Signature should NOT verify for a different message."
        )

    def test_modified_message_by_one_byte_fails(
        self, provider: ECDSAProvider, alice_kp: KeyPair
    ) -> None:
        """Even a single bit flip in the message must invalidate the signature."""
        sig = provider.sign(alice_kp.private_key, TEST_MESSAGE)
        tampered = bytearray(TEST_MESSAGE)
        tampered[0] ^= 0x01  # flip one bit
        result = provider.verify(alice_kp.public_key, bytes(tampered), sig)
        assert result is False

    def test_modified_signature_fails_verification(
        self, provider: ECDSAProvider, alice_kp: KeyPair
    ) -> None:
        """A bit-flipped signature must not verify."""
        sig = provider.sign(alice_kp.private_key, TEST_MESSAGE)
        # Flip a byte in the middle of the signature (avoid DER header bytes)
        tampered_sig = bytearray(sig)
        tampered_sig[len(sig) // 2] ^= 0xFF
        result = provider.verify(alice_kp.public_key, TEST_MESSAGE, bytes(tampered_sig))
        assert result is False, (
            "Modified signature should not verify."
        )

    def test_wrong_public_key_fails_verification(
        self,
        provider: ECDSAProvider,
        alice_kp: KeyPair,
        bob_kp: KeyPair,
    ) -> None:
        """
        Security property: a signature by Alice must not verify with Bob's public key.
        """
        sig = provider.sign(alice_kp.private_key, TEST_MESSAGE)
        result = provider.verify(bob_kp.public_key, TEST_MESSAGE, sig)
        assert result is False, (
            "Signature from Alice should not verify with Bob's public key."
        )

    def test_signature_from_different_key_fails(
        self, provider: ECDSAProvider
    ) -> None:
        """Signature produced by key pair 1 must not verify with key pair 2's public key."""
        kp1 = provider.generate_keypair()
        kp2 = provider.generate_keypair()
        sig = provider.sign(kp1.private_key, TEST_MESSAGE)
        result = provider.verify(kp2.public_key, TEST_MESSAGE, sig)
        assert result is False

    def test_empty_signature_returns_false_or_raises_invalid_signature(
        self, provider: ECDSAProvider, alice_kp: KeyPair
    ) -> None:
        """
        An empty signature is not a valid DER-encoded ECDSA signature.
        verify() should either return False or raise InvalidSignatureError.
        It must NOT return True.
        """
        try:
            result = provider.verify(alice_kp.public_key, TEST_MESSAGE, b"")
            assert result is False
        except InvalidSignatureError:
            pass  # Also acceptable — malformed signature

    def test_garbage_signature_returns_false_or_raises_invalid_signature(
        self, provider: ECDSAProvider, alice_kp: KeyPair
    ) -> None:
        try:
            result = provider.verify(alice_kp.public_key, TEST_MESSAGE, b"\x00" * 72)
            assert result is False
        except InvalidSignatureError:
            pass


# ---------------------------------------------------------------------------
# 4. Public key export / import round-trip
# ---------------------------------------------------------------------------


class TestECDSAPublicKeySerialisation:
    """Tests for export_public_key_bytes() and import_public_key_bytes()."""

    def test_export_returns_bytes(self, provider: ECDSAProvider, alice_kp: KeyPair) -> None:
        raw = provider.export_public_key_bytes(alice_kp.public_key)
        assert isinstance(raw, bytes)
        assert len(raw) > 0

    def test_import_returns_public_key_object(
        self, provider: ECDSAProvider, alice_kp: KeyPair
    ) -> None:
        raw = provider.export_public_key_bytes(alice_kp.public_key)
        recovered = provider.import_public_key_bytes(raw)
        assert isinstance(recovered, EllipticCurvePublicKey)

    def test_import_exported_key_verifies_original_signature(
        self, provider: ECDSAProvider, alice_kp: KeyPair
    ) -> None:
        """A signature created with the original key must verify with the imported copy."""
        sig = provider.sign(alice_kp.private_key, TEST_MESSAGE)
        raw = provider.export_public_key_bytes(alice_kp.public_key)
        recovered = provider.import_public_key_bytes(raw)
        result = provider.verify(recovered, TEST_MESSAGE, sig)
        assert result is True

    def test_export_import_round_trip_bytes_equal(
        self, provider: ECDSAProvider, alice_kp: KeyPair
    ) -> None:
        raw = provider.export_public_key_bytes(alice_kp.public_key)
        recovered = provider.import_public_key_bytes(raw)
        raw2 = provider.export_public_key_bytes(recovered)
        assert raw == raw2


# ---------------------------------------------------------------------------
# 5. Invalid input rejection
# ---------------------------------------------------------------------------


class TestECDSAInvalidInputs:
    """Tests that invalid inputs raise appropriate exceptions."""

    def test_sign_none_private_key_raises(self, provider: ECDSAProvider) -> None:
        with pytest.raises(InvalidKeyError):
            provider.sign(None, TEST_MESSAGE)

    def test_sign_wrong_type_key_raises(self, provider: ECDSAProvider) -> None:
        with pytest.raises(InvalidKeyError):
            provider.sign("not-a-key", TEST_MESSAGE)

    def test_sign_none_message_raises(
        self, provider: ECDSAProvider, alice_kp: KeyPair
    ) -> None:
        with pytest.raises((ValueError, TypeError)):
            provider.sign(alice_kp.private_key, None)

    def test_verify_none_public_key_raises(
        self, provider: ECDSAProvider, alice_kp: KeyPair
    ) -> None:
        sig = provider.sign(alice_kp.private_key, TEST_MESSAGE)
        with pytest.raises(InvalidKeyError):
            provider.verify(None, TEST_MESSAGE, sig)

    def test_verify_none_signature_raises(
        self, provider: ECDSAProvider, alice_kp: KeyPair
    ) -> None:
        with pytest.raises(InvalidSignatureError):
            provider.verify(alice_kp.public_key, TEST_MESSAGE, None)

    def test_export_none_raises(self, provider: ECDSAProvider) -> None:
        with pytest.raises(InvalidKeyError):
            provider.export_public_key_bytes(None)

    def test_import_empty_bytes_raises(self, provider: ECDSAProvider) -> None:
        with pytest.raises(InvalidKeyError):
            provider.import_public_key_bytes(b"")

    def test_import_garbage_bytes_raises(self, provider: ECDSAProvider) -> None:
        with pytest.raises(InvalidKeyError):
            provider.import_public_key_bytes(b"\xff" * 100)
