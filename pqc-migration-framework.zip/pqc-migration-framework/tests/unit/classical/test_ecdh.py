"""
tests/unit/classical/test_ecdh.py
Post-Quantum Secure Communication & Migration Framework

UNIT TESTS — ECDHProvider

Tests verify the following properties:
  1. Key pair generation succeeds and produces distinct keys.
  2. Alice→Bob and Bob→Alice key agreement both succeed.
  3. Both sides derive IDENTICAL shared secrets.
  4. Different key pairs produce DIFFERENT shared secrets.
  5. Public keys can be exported/imported (round-trip).
  6. Invalid inputs are rejected with appropriate exceptions.
  7. Wrong-curve keys are rejected.

No benchmarks. Real cryptographic operations only — no mocks.
"""

import pytest

from cryptography.hazmat.primitives.asymmetric.ec import (
    EllipticCurvePrivateKey,
    EllipticCurvePublicKey,
)

from src.exceptions import InvalidKeyError
from src.providers.classical.ecdh_provider import ECDHProvider
from src.providers.base import KeyPair


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture
def provider() -> ECDHProvider:
    return ECDHProvider()


@pytest.fixture
def alice_kp(provider: ECDHProvider) -> KeyPair:
    return provider.generate_keypair()


@pytest.fixture
def bob_kp(provider: ECDHProvider) -> KeyPair:
    return provider.generate_keypair()


# ---------------------------------------------------------------------------
# 1. Key generation
# ---------------------------------------------------------------------------


class TestECDHKeyGeneration:
    """Tests for generate_keypair()."""

    def test_generate_returns_keypair(self, provider: ECDHProvider) -> None:
        kp = provider.generate_keypair()
        assert isinstance(kp, KeyPair)

    def test_private_key_type(self, provider: ECDHProvider) -> None:
        kp = provider.generate_keypair()
        assert isinstance(kp.private_key, EllipticCurvePrivateKey)

    def test_public_key_type(self, provider: ECDHProvider) -> None:
        kp = provider.generate_keypair()
        assert isinstance(kp.public_key, EllipticCurvePublicKey)

    def test_different_calls_produce_different_key_pairs(self, provider: ECDHProvider) -> None:
        kp1 = provider.generate_keypair()
        kp2 = provider.generate_keypair()
        # Public keys should differ (negligible probability of collision).
        pub1 = provider.export_public_key_bytes(kp1.public_key)
        pub2 = provider.export_public_key_bytes(kp2.public_key)
        assert pub1 != pub2, "Two fresh key pairs should have different public keys."

    def test_key_is_on_p384_curve(self, provider: ECDHProvider) -> None:
        from cryptography.hazmat.primitives.asymmetric.ec import SECP384R1
        kp = provider.generate_keypair()
        assert isinstance(kp.public_key.curve, SECP384R1)


# ---------------------------------------------------------------------------
# 2. Key agreement — both parties derive identical shared secrets
# ---------------------------------------------------------------------------


class TestECDHKeyAgreement:
    """Tests for exchange()."""

    def test_alice_to_bob_agreement_succeeds(
        self,
        provider: ECDHProvider,
        alice_kp: KeyPair,
        bob_kp: KeyPair,
    ) -> None:
        """Alice exchanges with Bob's public key — should not raise."""
        secret = provider.exchange(alice_kp.private_key, bob_kp.public_key)
        assert isinstance(secret, bytes)
        assert len(secret) > 0

    def test_bob_to_alice_agreement_succeeds(
        self,
        provider: ECDHProvider,
        alice_kp: KeyPair,
        bob_kp: KeyPair,
    ) -> None:
        """Bob exchanges with Alice's public key — should not raise."""
        secret = provider.exchange(bob_kp.private_key, alice_kp.public_key)
        assert isinstance(secret, bytes)
        assert len(secret) > 0

    def test_both_sides_derive_identical_shared_secret(
        self,
        provider: ECDHProvider,
        alice_kp: KeyPair,
        bob_kp: KeyPair,
    ) -> None:
        """Core ECDH security property: both sides get the same secret."""
        alice_secret = provider.exchange(alice_kp.private_key, bob_kp.public_key)
        bob_secret   = provider.exchange(bob_kp.private_key, alice_kp.public_key)
        assert alice_secret == bob_secret, (
            "ECDH key agreement failed: Alice and Bob derived different shared secrets."
        )

    def test_shared_secret_length_is_48_bytes_for_p384(
        self,
        provider: ECDHProvider,
        alice_kp: KeyPair,
        bob_kp: KeyPair,
    ) -> None:
        """P-384 shared secret should be 48 bytes (384 bits / 8)."""
        secret = provider.exchange(alice_kp.private_key, bob_kp.public_key)
        assert len(secret) == 48, f"Expected 48-byte P-384 secret, got {len(secret)} bytes."

    def test_different_key_pairs_produce_different_shared_secrets(
        self,
        provider: ECDHProvider,
    ) -> None:
        """Independent key pairs must produce independent secrets."""
        alice1_kp = provider.generate_keypair()
        bob1_kp   = provider.generate_keypair()
        alice2_kp = provider.generate_keypair()
        bob2_kp   = provider.generate_keypair()

        secret1 = provider.exchange(alice1_kp.private_key, bob1_kp.public_key)
        secret2 = provider.exchange(alice2_kp.private_key, bob2_kp.public_key)

        assert secret1 != secret2, (
            "Different key pairs should produce different shared secrets."
        )

    def test_mismatched_keys_produce_different_secrets(
        self,
        provider: ECDHProvider,
        alice_kp: KeyPair,
        bob_kp: KeyPair,
    ) -> None:
        """
        Alice + Bob = secret A.
        Alice + Charlie ≠ secret A.
        """
        charlie_kp = provider.generate_keypair()
        alice_bob_secret     = provider.exchange(alice_kp.private_key, bob_kp.public_key)
        alice_charlie_secret = provider.exchange(alice_kp.private_key, charlie_kp.public_key)
        assert alice_bob_secret != alice_charlie_secret


# ---------------------------------------------------------------------------
# 3. Public key export / import round-trip
# ---------------------------------------------------------------------------


class TestECDHPublicKeySerialisation:
    """Tests for export_public_key_bytes() and import_public_key_bytes()."""

    def test_export_returns_bytes(self, provider: ECDHProvider, alice_kp: KeyPair) -> None:
        raw = provider.export_public_key_bytes(alice_kp.public_key)
        assert isinstance(raw, bytes)
        assert len(raw) > 0

    def test_p384_uncompressed_point_is_97_bytes(
        self, provider: ECDHProvider, alice_kp: KeyPair
    ) -> None:
        """P-384 uncompressed point: 0x04 || 48-byte X || 48-byte Y = 97 bytes."""
        raw = provider.export_public_key_bytes(alice_kp.public_key)
        assert len(raw) == 97, f"Expected 97 bytes, got {len(raw)}."
        assert raw[0] == 0x04, "Uncompressed point must start with 0x04."

    def test_import_recovers_equivalent_key(
        self, provider: ECDHProvider, alice_kp: KeyPair
    ) -> None:
        raw = provider.export_public_key_bytes(alice_kp.public_key)
        recovered = provider.import_public_key_bytes(raw)
        # Verify the recovered key works for ECDH.
        kp2 = provider.generate_keypair()
        secret_original  = provider.exchange(kp2.private_key, alice_kp.public_key)
        secret_recovered = provider.exchange(kp2.private_key, recovered)
        assert secret_original == secret_recovered, (
            "Imported key produced a different shared secret than the original."
        )

    def test_export_then_import_is_a_round_trip(
        self, provider: ECDHProvider, alice_kp: KeyPair
    ) -> None:
        raw = provider.export_public_key_bytes(alice_kp.public_key)
        recovered = provider.import_public_key_bytes(raw)
        raw2 = provider.export_public_key_bytes(recovered)
        assert raw == raw2


# ---------------------------------------------------------------------------
# 4. Invalid input rejection
# ---------------------------------------------------------------------------


class TestECDHInvalidInputs:
    """Tests that invalid inputs raise appropriate exceptions."""

    def test_exchange_none_private_key_raises(
        self, provider: ECDHProvider, bob_kp: KeyPair
    ) -> None:
        with pytest.raises(InvalidKeyError):
            provider.exchange(None, bob_kp.public_key)

    def test_exchange_none_public_key_raises(
        self, provider: ECDHProvider, alice_kp: KeyPair
    ) -> None:
        with pytest.raises(InvalidKeyError):
            provider.exchange(alice_kp.private_key, None)

    def test_exchange_wrong_type_private_key_raises(
        self, provider: ECDHProvider, bob_kp: KeyPair
    ) -> None:
        with pytest.raises(InvalidKeyError):
            provider.exchange("not-a-key", bob_kp.public_key)

    def test_exchange_wrong_type_public_key_raises(
        self, provider: ECDHProvider, alice_kp: KeyPair
    ) -> None:
        with pytest.raises(InvalidKeyError):
            provider.exchange(alice_kp.private_key, b"not-a-key")

    def test_import_empty_bytes_raises(self, provider: ECDHProvider) -> None:
        with pytest.raises(InvalidKeyError):
            provider.import_public_key_bytes(b"")

    def test_import_garbage_bytes_raises(self, provider: ECDHProvider) -> None:
        with pytest.raises(InvalidKeyError):
            provider.import_public_key_bytes(b"\xff" * 97)

    def test_export_none_raises(self, provider: ECDHProvider) -> None:
        with pytest.raises(InvalidKeyError):
            provider.export_public_key_bytes(None)

    def test_export_wrong_type_raises(self, provider: ECDHProvider) -> None:
        with pytest.raises(InvalidKeyError):
            provider.export_public_key_bytes(b"not-a-key")

    def test_kem_path_raises_not_implemented(
        self, provider: ECDHProvider, alice_kp: KeyPair
    ) -> None:
        """ECDHProvider must not support KEM path."""
        with pytest.raises(NotImplementedError):
            provider.encapsulate(alice_kp.public_key)

    def test_kem_decapsulate_raises_not_implemented(
        self, provider: ECDHProvider, alice_kp: KeyPair
    ) -> None:
        with pytest.raises(NotImplementedError):
            provider.decapsulate(alice_kp.private_key, b"ciphertext")
