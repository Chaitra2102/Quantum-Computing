"""
tests/unit/classical/test_aes_gcm.py
Post-Quantum Secure Communication & Migration Framework

UNIT TESTS — AESGCM256Provider

Tests verify the following properties:
  1. Encrypt/decrypt round-trip succeeds.
  2. Decrypted plaintext matches the original exactly.
  3. Ciphertext differs when fresh nonces are used (non-determinism).
  4. Modified ciphertext is rejected (authentication failure).
  5. Modified authentication tag is rejected (authentication failure).
  6. Modified AAD is rejected if AAD is used.
  7. Wrong key is rejected (authentication failure).
  8. Invalid key lengths are rejected.
  9. Invalid nonce lengths are rejected.
  10. EncryptedPayload contains expected fields.

Security invariant: AuthenticationFailureError must be raised on ANY
authentication failure. Unauthenticated plaintext is NEVER returned.

No benchmarks. Real AES-256-GCM operations — no mocks.
"""

import os

import pytest

from src.exceptions import AuthenticationFailureError
from src.providers.base import EncryptedPayload
from src.providers.symmetric.aesgcm_provider import (
    AES_KEY_LENGTH,
    GCM_NONCE_LENGTH,
    AESGCM256Provider,
)


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture
def provider() -> AESGCM256Provider:
    return AESGCM256Provider()


@pytest.fixture
def aes_key() -> bytes:
    """A fresh 256-bit AES key."""
    return os.urandom(AES_KEY_LENGTH)


@pytest.fixture
def alt_key() -> bytes:
    """A different 256-bit AES key."""
    return os.urandom(AES_KEY_LENGTH)


TEST_PLAINTEXT = b"Hello, post-quantum world! This is a test message."
EMPTY_PLAINTEXT = b""
LARGE_PLAINTEXT = b"A" * 100_000


# ---------------------------------------------------------------------------
# 1. Encrypt / decrypt round-trip
# ---------------------------------------------------------------------------


class TestAESGCMRoundTrip:
    """Tests that encrypt → decrypt recovers the original plaintext."""

    def test_basic_round_trip(
        self, provider: AESGCM256Provider, aes_key: bytes
    ) -> None:
        payload = provider.encrypt(aes_key, TEST_PLAINTEXT)
        recovered = provider.decrypt(aes_key, payload)
        assert recovered == TEST_PLAINTEXT

    def test_empty_plaintext_round_trip(
        self, provider: AESGCM256Provider, aes_key: bytes
    ) -> None:
        payload = provider.encrypt(aes_key, EMPTY_PLAINTEXT)
        recovered = provider.decrypt(aes_key, payload)
        assert recovered == EMPTY_PLAINTEXT

    def test_large_plaintext_round_trip(
        self, provider: AESGCM256Provider, aes_key: bytes
    ) -> None:
        payload = provider.encrypt(aes_key, LARGE_PLAINTEXT)
        recovered = provider.decrypt(aes_key, payload)
        assert recovered == LARGE_PLAINTEXT

    def test_binary_data_round_trip(
        self, provider: AESGCM256Provider, aes_key: bytes
    ) -> None:
        binary = bytes(range(256)) * 100
        payload = provider.encrypt(aes_key, binary)
        recovered = provider.decrypt(aes_key, payload)
        assert recovered == binary

    def test_round_trip_with_aad(
        self, provider: AESGCM256Provider, aes_key: bytes
    ) -> None:
        aad = b"sender=alice;recipient=bob;version=1"
        payload = provider.encrypt(aes_key, TEST_PLAINTEXT, aad)
        recovered = provider.decrypt(aes_key, payload, aad)
        assert recovered == TEST_PLAINTEXT


# ---------------------------------------------------------------------------
# 2. EncryptedPayload structure
# ---------------------------------------------------------------------------


class TestEncryptedPayloadStructure:
    """Tests that EncryptedPayload has correct structure."""

    def test_encrypt_returns_encrypted_payload(
        self, provider: AESGCM256Provider, aes_key: bytes
    ) -> None:
        payload = provider.encrypt(aes_key, TEST_PLAINTEXT)
        assert isinstance(payload, EncryptedPayload)

    def test_ciphertext_is_bytes(
        self, provider: AESGCM256Provider, aes_key: bytes
    ) -> None:
        payload = provider.encrypt(aes_key, TEST_PLAINTEXT)
        assert isinstance(payload.ciphertext, bytes)

    def test_nonce_is_bytes(
        self, provider: AESGCM256Provider, aes_key: bytes
    ) -> None:
        payload = provider.encrypt(aes_key, TEST_PLAINTEXT)
        assert isinstance(payload.nonce, bytes)

    def test_nonce_is_12_bytes(
        self, provider: AESGCM256Provider, aes_key: bytes
    ) -> None:
        """GCM nonce must be 96 bits (12 bytes)."""
        payload = provider.encrypt(aes_key, TEST_PLAINTEXT)
        assert len(payload.nonce) == GCM_NONCE_LENGTH == 12

    def test_ciphertext_is_longer_than_plaintext_by_16_bytes(
        self, provider: AESGCM256Provider, aes_key: bytes
    ) -> None:
        """
        AES-GCM ciphertext = plaintext || 16-byte auth tag.
        The library appends the tag to the ciphertext.
        """
        payload = provider.encrypt(aes_key, TEST_PLAINTEXT)
        assert len(payload.ciphertext) == len(TEST_PLAINTEXT) + 16

    def test_ciphertext_differs_from_plaintext(
        self, provider: AESGCM256Provider, aes_key: bytes
    ) -> None:
        payload = provider.encrypt(aes_key, TEST_PLAINTEXT)
        # Ciphertext must not be equal to plaintext (very likely true, tested for completeness)
        assert payload.ciphertext[:len(TEST_PLAINTEXT)] != TEST_PLAINTEXT


# ---------------------------------------------------------------------------
# 3. Nonce uniqueness
# ---------------------------------------------------------------------------


class TestAESGCMNonceUniqueness:
    """Tests that fresh nonces are used on each encrypt() call."""

    def test_different_nonces_on_repeated_encryption(
        self, provider: AESGCM256Provider, aes_key: bytes
    ) -> None:
        """
        AES-GCM security requires nonce uniqueness per key.
        The provider must generate a fresh nonce on each call.
        """
        payload1 = provider.encrypt(aes_key, TEST_PLAINTEXT)
        payload2 = provider.encrypt(aes_key, TEST_PLAINTEXT)
        assert payload1.nonce != payload2.nonce, (
            "Each encryption must use a unique nonce."
        )

    def test_ciphertext_differs_with_fresh_nonces(
        self, provider: AESGCM256Provider, aes_key: bytes
    ) -> None:
        payload1 = provider.encrypt(aes_key, TEST_PLAINTEXT)
        payload2 = provider.encrypt(aes_key, TEST_PLAINTEXT)
        assert payload1.ciphertext != payload2.ciphertext, (
            "Same plaintext encrypted twice should produce different ciphertexts."
        )


# ---------------------------------------------------------------------------
# 4. Authentication failure — MUST raise, MUST NOT return plaintext
# ---------------------------------------------------------------------------


class TestAESGCMAuthenticationFailure:
    """
    Security property: any modification to ciphertext, nonce, or AAD
    must cause authentication failure.
    AuthenticationFailureError must be raised — plaintext is NEVER returned.
    """

    def test_modified_ciphertext_raises_auth_failure(
        self, provider: AESGCM256Provider, aes_key: bytes
    ) -> None:
        payload = provider.encrypt(aes_key, TEST_PLAINTEXT)
        # Flip a byte in the ciphertext body (not the tag)
        tampered = bytearray(payload.ciphertext)
        tampered[0] ^= 0xFF
        bad_payload = EncryptedPayload(ciphertext=bytes(tampered), nonce=payload.nonce)

        with pytest.raises(AuthenticationFailureError):
            provider.decrypt(aes_key, bad_payload)

    def test_modified_auth_tag_raises_auth_failure(
        self, provider: AESGCM256Provider, aes_key: bytes
    ) -> None:
        """The last 16 bytes of ciphertext are the GCM authentication tag."""
        payload = provider.encrypt(aes_key, TEST_PLAINTEXT)
        tampered = bytearray(payload.ciphertext)
        tampered[-1] ^= 0xFF  # flip last byte of the auth tag
        bad_payload = EncryptedPayload(ciphertext=bytes(tampered), nonce=payload.nonce)

        with pytest.raises(AuthenticationFailureError):
            provider.decrypt(aes_key, bad_payload)

    def test_wrong_key_raises_auth_failure(
        self,
        provider: AESGCM256Provider,
        aes_key: bytes,
        alt_key: bytes,
    ) -> None:
        payload = provider.encrypt(aes_key, TEST_PLAINTEXT)
        with pytest.raises(AuthenticationFailureError):
            provider.decrypt(alt_key, payload)

    def test_modified_nonce_raises_auth_failure(
        self, provider: AESGCM256Provider, aes_key: bytes
    ) -> None:
        payload = provider.encrypt(aes_key, TEST_PLAINTEXT)
        bad_nonce = os.urandom(GCM_NONCE_LENGTH)
        # Ensure the nonce is actually different
        while bad_nonce == payload.nonce:
            bad_nonce = os.urandom(GCM_NONCE_LENGTH)
        bad_payload = EncryptedPayload(ciphertext=payload.ciphertext, nonce=bad_nonce)

        with pytest.raises(AuthenticationFailureError):
            provider.decrypt(aes_key, bad_payload)

    def test_modified_aad_raises_auth_failure(
        self, provider: AESGCM256Provider, aes_key: bytes
    ) -> None:
        """If AAD was used during encrypt, a different AAD during decrypt must fail."""
        aad = b"authentic-aad"
        payload = provider.encrypt(aes_key, TEST_PLAINTEXT, aad)
        with pytest.raises(AuthenticationFailureError):
            provider.decrypt(aes_key, payload, b"tampered-aad")

    def test_aad_encrypt_no_aad_decrypt_raises(
        self, provider: AESGCM256Provider, aes_key: bytes
    ) -> None:
        """Encrypting with AAD then decrypting without AAD must fail."""
        aad = b"required-context"
        payload = provider.encrypt(aes_key, TEST_PLAINTEXT, aad)
        with pytest.raises(AuthenticationFailureError):
            provider.decrypt(aes_key, payload, None)

    def test_no_aad_encrypt_aad_decrypt_raises(
        self, provider: AESGCM256Provider, aes_key: bytes
    ) -> None:
        """Encrypting without AAD then decrypting with AAD must fail."""
        payload = provider.encrypt(aes_key, TEST_PLAINTEXT, None)
        with pytest.raises(AuthenticationFailureError):
            provider.decrypt(aes_key, payload, b"unexpected-aad")


# ---------------------------------------------------------------------------
# 5. Invalid key / nonce length rejection
# ---------------------------------------------------------------------------


class TestAESGCMInvalidInputs:
    """Invalid parameters must be rejected with appropriate exceptions."""

    def test_wrong_key_length_too_short_raises(
        self, provider: AESGCM256Provider
    ) -> None:
        with pytest.raises(ValueError):
            provider.encrypt(b"tooshort", TEST_PLAINTEXT)

    def test_wrong_key_length_too_long_raises(
        self, provider: AESGCM256Provider
    ) -> None:
        with pytest.raises(ValueError):
            provider.encrypt(os.urandom(64), TEST_PLAINTEXT)

    def test_none_key_encrypt_raises(self, provider: AESGCM256Provider) -> None:
        with pytest.raises(ValueError):
            provider.encrypt(None, TEST_PLAINTEXT)

    def test_none_plaintext_raises(
        self, provider: AESGCM256Provider, aes_key: bytes
    ) -> None:
        with pytest.raises(ValueError):
            provider.encrypt(aes_key, None)

    def test_none_key_decrypt_raises(
        self, provider: AESGCM256Provider, aes_key: bytes
    ) -> None:
        payload = provider.encrypt(aes_key, TEST_PLAINTEXT)
        with pytest.raises(ValueError):
            provider.decrypt(None, payload)

    def test_none_payload_decrypt_raises(
        self, provider: AESGCM256Provider, aes_key: bytes
    ) -> None:
        with pytest.raises(ValueError):
            provider.decrypt(aes_key, None)

    def test_wrong_decrypt_key_length_raises(
        self, provider: AESGCM256Provider, aes_key: bytes
    ) -> None:
        payload = provider.encrypt(aes_key, TEST_PLAINTEXT)
        with pytest.raises(ValueError):
            provider.decrypt(b"\x00" * 16, payload)

    def test_wrong_nonce_length_in_payload_raises(
        self, provider: AESGCM256Provider, aes_key: bytes
    ) -> None:
        payload = provider.encrypt(aes_key, TEST_PLAINTEXT)
        bad_payload = EncryptedPayload(
            ciphertext=payload.ciphertext,
            nonce=b"\x00" * 8,  # wrong length
        )
        with pytest.raises(ValueError):
            provider.decrypt(aes_key, bad_payload)

    def test_key_length_constant_is_32(self) -> None:
        assert AES_KEY_LENGTH == 32

    def test_nonce_length_constant_is_12(self) -> None:
        assert GCM_NONCE_LENGTH == 12
