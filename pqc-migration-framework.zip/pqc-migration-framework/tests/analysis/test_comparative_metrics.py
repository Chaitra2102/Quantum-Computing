"""Unit tests for comparative analysis metrics and math derivation."""

import math
import pytest
from src.analysis.comparator import (
    calculate_cv,
    calculate_relative_diff,
    generate_comparative_metrics,
    load_phase10_datasets,
)


class TestComparativeMetricsMath:
    """Test correctness of comparative calculations and statistical derivations."""

    def test_calculate_relative_diff_positive_expansion(self):
        # 200 vs 100 -> abs = +100, pct = +100.0%
        res = calculate_relative_diff(200.0, 100.0)
        assert res["absolute"] == 100.0
        assert res["percentage"] == 100.0

    def test_calculate_relative_diff_negative_reduction(self):
        # 50 vs 100 -> abs = -50, pct = -50.0%
        res = calculate_relative_diff(50.0, 100.0)
        assert res["absolute"] == -50.0
        assert res["percentage"] == -50.0

    def test_calculate_relative_diff_zero_baseline(self):
        res = calculate_relative_diff(100.0, 0.0)
        assert res["absolute"] == 100.0
        assert res["percentage"] == 0.0

    def test_calculate_cv_valid(self):
        # mean = 100, stddev = 15 -> CV = 15.0%
        assert calculate_cv(100.0, 15.0) == 15.0

    def test_calculate_cv_zero_mean(self):
        assert calculate_cv(0.0, 5.0) == 0.0

    def test_generate_comparative_metrics_structure(self):
        summary_data, sizes_data = load_phase10_datasets()
        metrics = generate_comparative_metrics(summary_data, sizes_data)

        assert "key_establishment" in metrics
        assert "signatures" in metrics
        assert "size_breakdown" in metrics
        assert "hybrid_incremental" in metrics
        assert "end_to_end" in metrics

        # Verify key establishment metrics
        kex = metrics["key_establishment"]
        assert "keygen" in kex
        assert "operations" in kex
        assert kex["keygen"]["ecdh_p384_mean_us"] > 0
        assert kex["keygen"]["mlkem_768_mean_us"] > 0

        # Verify signatures 1KiB
        sig_1k = metrics["signatures"]["1KiB"]
        assert sig_1k["signing"]["mldsa_65_mean_us"] > 0
        assert sig_1k["verification"]["mldsa_65_mean_us"] > 0

        # Verify size breakdown
        sizes = metrics["size_breakdown"]
        assert "Mode A" in sizes
        assert "Mode B" in sizes
        assert "Mode D (ML-DSA)" in sizes
        assert sizes["Mode B"]["overhead_vs_mode_a_wire"]["percentage"] > 400.0
