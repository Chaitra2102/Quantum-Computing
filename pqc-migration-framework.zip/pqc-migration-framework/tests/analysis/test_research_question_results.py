"""Unit tests for research question synthesis and secret non-exposure."""

import pytest
from src.analysis.comparator import (
    generate_comparative_metrics,
    generate_research_question_results,
    load_phase10_datasets,
)


class TestResearchQuestionSynthesis:
    """Validate completeness and schema of Research Question outputs."""

    def test_all_seven_rqs_present_and_complete(self):
        summary_data, sizes_data = load_phase10_datasets()
        metrics = generate_comparative_metrics(summary_data, sizes_data)
        rq_results = generate_research_question_results(metrics)

        assert len(rq_results) == 7

        rq_ids = [item["rq"] for item in rq_results]
        expected_ids = ["RQ1", "RQ2", "RQ3", "RQ4", "RQ5", "RQ6", "RQ7"]
        assert rq_ids == expected_ids

        for item in rq_results:
            assert len(item["title"]) > 5
            assert len(item["question"]) > 10
            assert len(item["finding"]) > 20
            assert len(item["limitation"]) > 10
            assert isinstance(item["evidence"], dict)
            assert len(item["evidence"]) > 0

    def test_no_secrets_in_rq_results(self):
        summary_data, sizes_data = load_phase10_datasets()
        metrics = generate_comparative_metrics(summary_data, sizes_data)
        rq_results = generate_research_question_results(metrics)

        raw_str = str(rq_results).lower()
        assert "private_key" not in raw_str
        assert "shared_secret_bytes" not in raw_str
        assert "password" not in raw_str
