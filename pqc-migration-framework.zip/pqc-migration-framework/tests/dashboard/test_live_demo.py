"""
tests/dashboard/test_live_demo.py
Post-Quantum Secure Communication & Migration Framework

Unit and integration tests for the Phase 13 Live Demonstration engine.
"""

from __future__ import annotations

import json
import pytest

from src.config.modes import (
    CLASSICAL_ECDH_ECDSA_AES256_GCM,
    HYBRID_ECDH_MLKEM_ECDSA_AES256_GCM,
    HYBRID_ECDH_MLKEM_MLDSA_AES256_GCM,
    HYBRID_ECDH_MLKEM_SLHDSA_AES256_GCM,
    PQC_MLKEM_MLDSA_AES256_GCM,
    PQC_MLKEM_SLHDSA_AES256_GCM,
    Mode,
)
from src.dashboard.live_demo import (
    execute_single_demo,
    run_all_live_configurations,
    run_controlled_tamper_demonstration,
)


class TestLiveDemonstrationEngine:
    """Test real cryptographic execution across all live demo configurations."""

    @pytest.mark.parametrize(
        "mode,sig_type,expected_suite",
        [
            (Mode.A, None, CLASSICAL_ECDH_ECDSA_AES256_GCM),
            (Mode.B, None, PQC_MLKEM_MLDSA_AES256_GCM),
            (Mode.C, None, PQC_MLKEM_SLHDSA_AES256_GCM),
            (Mode.D, "mldsa", HYBRID_ECDH_MLKEM_MLDSA_AES256_GCM),
            (Mode.D, "slhdsa", HYBRID_ECDH_MLKEM_SLHDSA_AES256_GCM),
            (Mode.D, "ecdsa", HYBRID_ECDH_MLKEM_ECDSA_AES256_GCM),
        ],
    )
    def test_live_demo_single_execution_succeeds(
        self, mode: Mode, sig_type: str | None, expected_suite: str
    ) -> None:
        test_msg = "Hello Lecturer! Live PQC validation."
        res = execute_single_demo(
            name="Test Suite",
            category="Testing",
            mode=mode,
            sig_type=sig_type,
            plaintext=test_msg,
            aad_str="test-aad-data",
        )
        assert res["overall_status"] == "✓ SUCCESS"
        assert res["verification_status"] == "✓ SUCCESS"
        assert res["decryption_status"] == "✓ SUCCESS"
        assert res["recovered_plaintext"] == test_msg
        assert res["is_match"] is True
        assert res["algorithm_id"] == expected_suite
        assert res["wire_bytes"] > 0
        assert res["elapsed_ms"] > 0
        assert len(res["steps"]) >= 7

    def test_run_all_live_configurations(self) -> None:
        test_msg = "Comprehensive multi-configuration test."
        results = run_all_live_configurations(plaintext=test_msg)
        assert len(results) == 6

        # Check all 6 configurations completed successfully
        for r in results:
            assert r["overall_status"] == "✓ SUCCESS"
            assert r["recovered_plaintext"] == test_msg
            assert r["is_match"] is True
            assert r["wire_bytes"] > 0

    def test_empty_message_handled_safely(self) -> None:
        res = execute_single_demo(
            name="Empty Message Test",
            category="Edge Case",
            mode=Mode.A,
            plaintext="",
        )
        assert res["overall_status"] == "✓ SUCCESS"
        assert res["recovered_plaintext"] == ""
        assert res["is_match"] is True

    def test_invalid_mode_handled_safely(self) -> None:
        res = execute_single_demo(
            name="Invalid Mode Test",
            category="Error Handling",
            mode="INVALID_MODE",
            plaintext="Test",
        )
        assert res["overall_status"] == "✗ FAILED"
        assert res["verification_status"] == "✗ FAILED"
        assert res["error"] is not None

    def test_controlled_tampering_demonstration(self) -> None:
        tamper_results = run_controlled_tamper_demonstration(mode_str="B", sig_type="mldsa")
        assert len(tamper_results) == 3

        for t in tamper_results:
            assert t["detection"] == "✓ PASS"
            assert "REJECTED" in t["recovery"]
            assert "0 Bytes Leaked" in t["recovery"]

    def test_live_demo_results_never_contain_secret_material(self) -> None:
        results = run_all_live_configurations(plaintext="Secret Check Message")
        tamper_res = run_controlled_tamper_demonstration(mode_str="B")

        dumped = json.dumps(results) + json.dumps(tamper_results := tamper_res)
        forbidden_terms = [
            "private_key",
            "shared_secret",
            "aes_key",
            "hkdf_intermediate",
            "raw_secret",
        ]
        for term in forbidden_terms:
            assert term not in dumped.lower()
