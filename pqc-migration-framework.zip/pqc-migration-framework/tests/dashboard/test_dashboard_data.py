"""
tests/dashboard/test_dashboard_data.py
Post-Quantum Secure Communication & Migration Framework

Unit tests for dashboard metrics, charts, and secret non-exposure.
"""

from __future__ import annotations

import json
import plotly.graph_objects as go
import pytest

from src.dashboard.charts import (
    create_compatibility_heatmap,
    create_e2e_latency_chart,
    create_key_establishment_ops_chart,
    create_keygen_latency_chart,
    create_signature_latency_charts,
    create_size_comparison_chart,
    create_transition_deltas_chart,
    create_wire_overhead_chart,
)
from src.dashboard.data_loader import load_all_datasets
from src.dashboard.metrics import (
    get_modes_summary_table,
    get_research_questions_summary,
    get_security_validation_table,
)


class TestDashboardDataAndCharts:
    """Verify chart generation and table formatting from real datasets."""

    @pytest.fixture
    def datasets(self) -> dict:
        return load_all_datasets()

    def test_chart_creation_keygen(self, datasets: dict) -> None:
        fig = create_keygen_latency_chart(datasets["benchmark_summary"])
        assert isinstance(fig, go.Figure)
        assert len(fig.data) > 0

    def test_chart_creation_kex_ops(self, datasets: dict) -> None:
        fig = create_key_establishment_ops_chart(datasets["benchmark_summary"])
        assert isinstance(fig, go.Figure)

    def test_chart_creation_signatures(self, datasets: dict) -> None:
        fig_fast, fig_slh = create_signature_latency_charts(datasets["benchmark_summary"])
        assert isinstance(fig_fast, go.Figure)
        assert isinstance(fig_slh, go.Figure)

    def test_chart_creation_e2e(self, datasets: dict) -> None:
        fig = create_e2e_latency_chart(datasets["benchmark_summary"])
        assert isinstance(fig, go.Figure)

    def test_chart_creation_sizes(self, datasets: dict) -> None:
        fig = create_size_comparison_chart(datasets["benchmark_sizes"])
        assert isinstance(fig, go.Figure)

    def test_chart_creation_wire_overhead(self, datasets: dict) -> None:
        fig = create_wire_overhead_chart(datasets["benchmark_sizes"])
        assert isinstance(fig, go.Figure)

    def test_chart_creation_transition_deltas(self, datasets: dict) -> None:
        fig_lat, fig_wire = create_transition_deltas_chart(datasets["migration_deltas"])
        assert isinstance(fig_lat, go.Figure)
        assert isinstance(fig_wire, go.Figure)

    def test_chart_creation_compat_heatmap(self, datasets: dict) -> None:
        fig = create_compatibility_heatmap(datasets["compatibility_matrix"])
        assert isinstance(fig, go.Figure)

    def test_modes_summary_table(self) -> None:
        df = get_modes_summary_table()
        assert len(df) == 6
        assert "Mode" in df.columns
        assert "Suite Identifier" in df.columns

    def test_security_validation_table(self) -> None:
        df = get_security_validation_table()
        assert len(df) >= 5
        assert "Adversarial Testing Category" in df.columns

    def test_research_questions_summary(self) -> None:
        rqs = get_research_questions_summary()
        assert len(rqs) == 7
        assert "RQ1" in rqs[0]["rq"]
        assert "RQ7" in rqs[6]["rq"]

    def test_dashboard_data_never_contains_secret_material(self, datasets: dict) -> None:
        raw_dump = json.dumps(datasets["benchmark_summary"]) + json.dumps(datasets["benchmark_sizes"]) + json.dumps(datasets["migration_results"])
        forbidden_terms = ["private_key", "shared_secret", "aes_key", "hkdf_intermediate"]
        for term in forbidden_terms:
            assert term not in raw_dump.lower()
