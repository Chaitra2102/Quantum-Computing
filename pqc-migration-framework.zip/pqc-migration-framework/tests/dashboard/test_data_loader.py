"""
tests/dashboard/test_data_loader.py
Post-Quantum Secure Communication & Migration Framework

Unit tests for dataset loading, schema validation, and missing file handling.
"""

from __future__ import annotations

from pathlib import Path
import tempfile
import pandas as pd
import pytest

from src.dashboard.data_loader import (
    DatasetNotFoundError,
    DatasetValidationError,
    load_all_datasets,
    load_benchmark_sizes,
    load_benchmark_summary,
    load_compatibility_matrix,
    load_migration_deltas,
    load_migration_history,
    load_migration_results,
)


class TestDashboardDataLoader:
    """Verify loading and validation of authoritative project datasets."""

    def test_load_benchmark_summary(self) -> None:
        data = load_benchmark_summary()
        assert isinstance(data, dict)
        assert "environment" in data
        assert "key_establishment" in data
        assert "signatures" in data
        assert "end_to_end" in data
        assert data["environment"]["cryptography_version"] == "48.0.0"

    def test_load_benchmark_sizes(self) -> None:
        data = load_benchmark_sizes()
        assert isinstance(data, dict)
        assert "matrix" in data
        assert len(data["matrix"]) >= 4

    def test_load_migration_results(self) -> None:
        data = load_migration_results()
        assert isinstance(data, dict)
        assert "paths" in data
        assert len(data["paths"]) >= 5

    def test_load_migration_history(self) -> None:
        data = load_migration_history()
        assert isinstance(data, list)
        assert len(data) >= 5

    def test_load_compatibility_matrix(self) -> None:
        df = load_compatibility_matrix()
        assert isinstance(df, pd.DataFrame)
        assert len(df) == 36
        assert "sender_suite" in df.columns
        assert "receiver_suite" in df.columns
        assert "actual_outcome" in df.columns

    def test_load_migration_deltas(self) -> None:
        df = load_migration_deltas()
        assert isinstance(df, pd.DataFrame)
        assert len(df) >= 7
        assert "transition_id" in df.columns
        assert "latency_delta_us" in df.columns
        assert "wire_size_delta_bytes" in df.columns

    def test_load_all_datasets(self) -> None:
        all_data = load_all_datasets()
        assert all_data["all_valid"] is True
        for name, status in all_data["validation_status"].items():
            assert status == "VALID"

    def test_missing_file_raises_not_found(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            tmp_path = Path(tmpdir)
            with pytest.raises(DatasetNotFoundError):
                load_benchmark_summary(tmp_path)
            with pytest.raises(DatasetNotFoundError):
                load_benchmark_sizes(tmp_path)
            with pytest.raises(DatasetNotFoundError):
                load_migration_results(tmp_path)
            with pytest.raises(DatasetNotFoundError):
                load_compatibility_matrix(tmp_path)
            with pytest.raises(DatasetNotFoundError):
                load_migration_deltas(tmp_path)
