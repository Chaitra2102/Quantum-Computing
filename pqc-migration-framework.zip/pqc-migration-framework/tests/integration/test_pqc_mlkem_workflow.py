"""
tests/integration/test_pqc_mlkem_workflow.py
Post-Quantum Secure Communication & Migration Framework

INTEGRATION TEST — Post-Quantum ML-KEM Baseline Secure Communication Workflow

Target configuration:
  ML-KEM (FIPS 203) + classical ECDSA + AES-256-GCM + HKDF-SHA-384

Verifies:
  1. Full end-to-end workflow: Alice (sender) -> SecureMessage -> Bob (receiver).
  2. Bob recovers Alice's original plaintext.
  3. KEM encapsulation ciphertext (ke_ciphertext) is present and correctly sized.
  4. SecureMessage contains no private keys, shared secrets, or AES keys.
  5. SecureMessage survives JSON serialization round-trip.
  6. Empty messages, large messages, and AAD are supported.
  7. Both ML-KEM-768 and ML-KEM-1024 configurations function correctly.
"""

import pytest

from src.communication.message_bundle import (
    PROTOCOL_VERSION,
    SecureMessage,
)
from src.communication.secure_communicator import SecureCommunicator
from src.config.crypto_config import CryptoConfig, ModeFactory
from src.config.modes import PQC_MLKEM_ECDSA_AES256_GCM


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture
def mlkem768_config() -> CryptoConfig:
    return ModeFactory.build_mlkem_baseline("ML-KEM-768")


@pytest.fixture
def mlkem1024_config() -> CryptoConfig:
    return ModeFactory.build_mlkem_baseline("ML-KEM-1024")


@pytest.fixture
def comm_768(mlkem768_config: CryptoConfig) -> SecureCommunicator:
    return SecureCommunicator(mlkem768_config)


@pytest.fixture
def comm_1024(mlkem1024_config: CryptoConfig) -> SecureCommunicator:
    return SecureCommunicator(mlkem1024_config)


@pytest.fixture
def bob_ke_kp_768(mlkem768_config: CryptoConfig):
    """Bob's (receiver's) ML-KEM-768 key pair."""
    return mlkem768_config.key_exchange.generate_keypair()


@pytest.fixture
def bob_ke_kp_1024(mlkem1024_config: CryptoConfig):
    """Bob's (receiver's) ML-KEM-1024 key pair."""
    return mlkem1024_config.key_exchange.generate_keypair()


TEST_PLAINTEXT = b"Post-Quantum message secured with ML-KEM-768 + AES-256-GCM"


# ---------------------------------------------------------------------------
# 1. End-to-end communication
# ---------------------------------------------------------------------------


class TestPQCWorkflowEndToEnd:
    """End-to-end tests for ML-KEM secure communication."""

    def test_full_workflow_mlkem768(
        self,
        comm_768: SecureCommunicator,
        bob_ke_kp_768,
    ) -> None:
        """Alice sends with ML-KEM-768 -> Bob receives and decrypts."""
        sender_kps, message = comm_768.send(
            plaintext=TEST_PLAINTEXT,
            receiver_ke_public_key=bob_ke_kp_768.public_key,
        )
        assert message.ke_ciphertext is not None
        assert len(message.ke_ciphertext) == 1088

        recovered = comm_768.receive(
            message=message,
            receiver_ke_private_key=bob_ke_kp_768.private_key,
        )
        assert recovered == TEST_PLAINTEXT

    def test_full_workflow_mlkem1024(
        self,
        comm_1024: SecureCommunicator,
        bob_ke_kp_1024,
    ) -> None:
        """Alice sends with ML-KEM-1024 -> Bob receives and decrypts."""
        sender_kps, message = comm_1024.send(
            plaintext=TEST_PLAINTEXT,
            receiver_ke_public_key=bob_ke_kp_1024.public_key,
        )
        assert message.ke_ciphertext is not None
        assert len(message.ke_ciphertext) == 1568

        recovered = comm_1024.receive(
            message=message,
            receiver_ke_private_key=bob_ke_kp_1024.private_key,
        )
        assert recovered == TEST_PLAINTEXT

    def test_empty_message_workflow(
        self,
        comm_768: SecureCommunicator,
        bob_ke_kp_768,
    ) -> None:
        _, message = comm_768.send(
            plaintext=b"",
            receiver_ke_public_key=bob_ke_kp_768.public_key,
        )
        recovered = comm_768.receive(
            message=message,
            receiver_ke_private_key=bob_ke_kp_768.private_key,
        )
        assert recovered == b""

    def test_large_message_workflow(
        self,
        comm_768: SecureCommunicator,
        bob_ke_kp_768,
    ) -> None:
        large_payload = b"Q" * 150_000
        _, message = comm_768.send(
            plaintext=large_payload,
            receiver_ke_public_key=bob_ke_kp_768.public_key,
        )
        recovered = comm_768.receive(
            message=message,
            receiver_ke_private_key=bob_ke_kp_768.private_key,
        )
        assert recovered == large_payload

    def test_workflow_with_aad(
        self,
        comm_768: SecureCommunicator,
        bob_ke_kp_768,
    ) -> None:
        aad = b"context=post-quantum-migration;epoch=1"
        _, message = comm_768.send(
            plaintext=TEST_PLAINTEXT,
            receiver_ke_public_key=bob_ke_kp_768.public_key,
            aad=aad,
        )
        recovered = comm_768.receive(
            message=message,
            receiver_ke_private_key=bob_ke_kp_768.private_key,
            aad=aad,
        )
        assert recovered == TEST_PLAINTEXT

    def test_fresh_encryption_produces_distinct_ciphertexts(
        self,
        comm_768: SecureCommunicator,
        bob_ke_kp_768,
    ) -> None:
        _, msg1 = comm_768.send(TEST_PLAINTEXT, bob_ke_kp_768.public_key)
        _, msg2 = comm_768.send(TEST_PLAINTEXT, bob_ke_kp_768.public_key)
        assert msg1.ke_ciphertext != msg2.ke_ciphertext
        assert msg1.ciphertext != msg2.ciphertext
        assert msg1.nonce != msg2.nonce


# ---------------------------------------------------------------------------
# 2. SecureMessage structure
# ---------------------------------------------------------------------------


class TestPQCMessageStructure:
    """Tests for message structure under ML-KEM."""

    def test_algorithm_id_is_mlkem_baseline(
        self,
        comm_768: SecureCommunicator,
        bob_ke_kp_768,
    ) -> None:
        _, message = comm_768.send(TEST_PLAINTEXT, bob_ke_kp_768.public_key)
        assert message.algorithm_id == PQC_MLKEM_ECDSA_AES256_GCM

    def test_protocol_version_is_current(
        self,
        comm_768: SecureCommunicator,
        bob_ke_kp_768,
    ) -> None:
        _, message = comm_768.send(TEST_PLAINTEXT, bob_ke_kp_768.public_key)
        assert message.protocol_version == PROTOCOL_VERSION

    def test_ke_ciphertext_is_populated(
        self,
        comm_768: SecureCommunicator,
        bob_ke_kp_768,
    ) -> None:
        _, message = comm_768.send(TEST_PLAINTEXT, bob_ke_kp_768.public_key)
        assert message.ke_ciphertext is not None
        assert isinstance(message.ke_ciphertext, bytes)
        assert len(message.ke_ciphertext) == 1088


# ---------------------------------------------------------------------------
# 3. Serialization round-trip
# ---------------------------------------------------------------------------


class TestPQCMessageSerialization:
    """Tests that PQC SecureMessage survives JSON serialization."""

    def test_json_round_trip(
        self,
        comm_768: SecureCommunicator,
        bob_ke_kp_768,
    ) -> None:
        _, message = comm_768.send(TEST_PLAINTEXT, bob_ke_kp_768.public_key)
        json_str = message.to_json()
        assert isinstance(json_str, str)

        reconstructed = SecureMessage.from_json(json_str)
        assert reconstructed.ke_ciphertext == message.ke_ciphertext

        recovered = comm_768.receive(
            message=reconstructed,
            receiver_ke_private_key=bob_ke_kp_768.private_key,
        )
        assert recovered == TEST_PLAINTEXT

    def test_dict_does_not_contain_private_material(
        self,
        comm_768: SecureCommunicator,
        bob_ke_kp_768,
    ) -> None:
        _, message = comm_768.send(TEST_PLAINTEXT, bob_ke_kp_768.public_key)
        d = message.to_dict()
        sensitive = {"private", "secret", "aes_key"}
        for k in d.keys():
            assert not any(s in k.lower() for s in sensitive)
