"""
tests/integration/test_cli_workflow.py
Post-Quantum Secure Communication & Migration Framework

Integration tests for CLI execution workflows across Modes A, B, C, and D.

Phase 8: Tests full end-to-end command-line executions, parameter sets,
cross-mode isolation, and error handling.
"""

import json
import pytest

from src.config.modes import (
    CLASSICAL_ECDH_ECDSA_AES256_GCM,
    HYBRID_ECDH_MLKEM_ECDSA_AES256_GCM,
    HYBRID_ECDH_MLKEM_MLDSA_AES256_GCM,
    HYBRID_ECDH_MLKEM_SLHDSA_AES256_GCM,
    PQC_MLKEM_MLDSA_AES256_GCM,
    PQC_MLKEM_SLHDSA_AES256_GCM,
)
from src.main_cli import run_cli


class TestCLIWorkflowIntegration:
    """Integration tests executing complete CLI workflows."""

    def test_mode_a_workflow(self, capsys):
        exit_code = run_cli(["--mode", "A", "--message", "Classical message", "--json"])
        assert exit_code == 0
        captured = capsys.readouterr()
        data = json.loads(captured.out)

        assert data["status"] == "SUCCESS"
        assert data["algorithm_id"] == CLASSICAL_ECDH_ECDSA_AES256_GCM
        assert data["recovered_plaintext"] == "Classical message"

    def test_mode_b_workflow(self, capsys):
        exit_code = run_cli(["--mode", "B", "--message", "Lattice message", "--json"])
        assert exit_code == 0
        captured = capsys.readouterr()
        data = json.loads(captured.out)

        assert data["status"] == "SUCCESS"
        assert data["algorithm_id"] == PQC_MLKEM_MLDSA_AES256_GCM
        assert data["recovered_plaintext"] == "Lattice message"

    def test_mode_c_workflow(self, capsys):
        exit_code = run_cli(["--mode", "C", "--message", "Hash-based message", "--json"])
        assert exit_code == 0
        captured = capsys.readouterr()
        data = json.loads(captured.out)

        assert data["status"] == "SUCCESS"
        assert data["algorithm_id"] == PQC_MLKEM_SLHDSA_AES256_GCM
        assert data["recovered_plaintext"] == "Hash-based message"

    def test_mode_d_mldsa_workflow(self, capsys):
        exit_code = run_cli(["--mode", "D", "--signature", "mldsa", "--message", "Hybrid MLDSA", "--json"])
        assert exit_code == 0
        captured = capsys.readouterr()
        data = json.loads(captured.out)

        assert data["status"] == "SUCCESS"
        assert data["algorithm_id"] == HYBRID_ECDH_MLKEM_MLDSA_AES256_GCM
        assert data["recovered_plaintext"] == "Hybrid MLDSA"

    def test_mode_d_slhdsa_workflow(self, capsys):
        exit_code = run_cli(["--mode", "D", "--signature", "slhdsa", "--message", "Hybrid SLHDSA", "--json"])
        assert exit_code == 0
        captured = capsys.readouterr()
        data = json.loads(captured.out)

        assert data["status"] == "SUCCESS"
        assert data["algorithm_id"] == HYBRID_ECDH_MLKEM_SLHDSA_AES256_GCM
        assert data["recovered_plaintext"] == "Hybrid SLHDSA"

    def test_mode_d_ecdsa_workflow(self, capsys):
        exit_code = run_cli(["--mode", "D", "--signature", "ecdsa", "--message", "Hybrid ECDSA", "--json"])
        assert exit_code == 0
        captured = capsys.readouterr()
        data = json.loads(captured.out)

        assert data["status"] == "SUCCESS"
        assert data["algorithm_id"] == HYBRID_ECDH_MLKEM_ECDSA_AES256_GCM
        assert data["recovered_plaintext"] == "Hybrid ECDSA"

    def test_mode_d_default_signature_is_mldsa(self, capsys):
        exit_code = run_cli(["--mode", "D", "--message", "Default Hybrid", "--json"])
        assert exit_code == 0
        captured = capsys.readouterr()
        data = json.loads(captured.out)

        assert data["status"] == "SUCCESS"
        assert data["algorithm_id"] == HYBRID_ECDH_MLKEM_MLDSA_AES256_GCM
        assert data["signature"] == "ML-DSA-65"

    def test_mode_b_custom_parameters_workflow(self, capsys):
        exit_code = run_cli([
            "--mode", "B",
            "--kem-param", "ML-KEM-1024",
            "--sig-param", "ML-DSA-87",
            "--message", "High security lattice",
            "--json",
        ])
        assert exit_code == 0
        captured = capsys.readouterr()
        data = json.loads(captured.out)

        assert data["status"] == "SUCCESS"
        assert data["key_establishment"] == "ML-KEM-1024"
        assert data["signature"] == "ML-DSA-87"
