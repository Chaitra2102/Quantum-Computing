"""
tests/integration/test_hybrid_mode.py
Post-Quantum Secure Communication & Migration Framework

Integration tests for Mode D (Hybrid Key Establishment: ECDH P-384 + ML-KEM-768).

Phase 7: Verifies end-to-end communication, configurable signature strategies,
cross-mode isolation, tampering detection, and protocol negotiation.
"""

import json
import pytest

from src.communication.message_bundle import SecureMessage
from src.communication.secure_communicator import SecureCommunicator
from src.config.crypto_config import CryptoConfig, ModeFactory
from src.config.modes import (
    CLASSICAL_ECDH_ECDSA_AES256_GCM,
    HYBRID_ECDH_MLKEM_AES256_GCM,
    HYBRID_ECDH_MLKEM_ECDSA_AES256_GCM,
    HYBRID_ECDH_MLKEM_MLDSA_AES256_GCM,
    HYBRID_ECDH_MLKEM_SLHDSA_AES256_GCM,
    PQC_MLKEM_MLDSA_AES256_GCM,
    PQC_MLKEM_SLHDSA_AES256_GCM,
    Mode,
    negotiate_mode,
)
from src.exceptions import (
    AuthenticationFailureError,
    ModeMismatchError,
    PQCFrameworkError,
    SignatureVerificationError,
)
from src.providers.classical.ecdsa_provider import ECDSAProvider
from src.providers.hybrid.hybrid_ke_provider import HybridKEProvider
from src.providers.pqc.mldsa_provider import MLDSAProvider
from src.providers.pqc.slhdsa_provider import SLHDSAProvider


# ===========================================================================
# 1. Mode D End-to-End Workflow Tests
# ===========================================================================


class TestModeDWorkflow:
    """End-to-end communication tests for Mode D (Hybrid)."""

    @pytest.fixture
    def mode_d_config(self) -> CryptoConfig:
        return ModeFactory.build(Mode.D)

    def test_mode_d_construction(self, mode_d_config: CryptoConfig):
        assert mode_d_config.mode is Mode.D
        assert mode_d_config.algorithm_id == HYBRID_ECDH_MLKEM_MLDSA_AES256_GCM
        assert isinstance(mode_d_config.key_exchange, HybridKEProvider)
        assert isinstance(mode_d_config.signature, MLDSAProvider)

    def test_mode_d_string_construction(self):
        cfg = ModeFactory.build("MODE_D")
        assert cfg.mode is Mode.D
        assert cfg.algorithm_id == HYBRID_ECDH_MLKEM_MLDSA_AES256_GCM

    def test_mode_d_end_to_end_communication(self, mode_d_config: CryptoConfig):
        comm = SecureCommunicator(mode_d_config)

        # Receiver generates hybrid keypair
        receiver_ke_kp = mode_d_config.key_exchange.generate_keypair()

        # Sender sends message
        plaintext = b"Top secret payload protected by Hybrid ECDH + ML-KEM-768!"
        sender_kps, message = comm.send(
            plaintext=plaintext,
            receiver_ke_public_key=receiver_ke_kp.public_key,
            aad=b"authenticated-routing-header",
            metadata={"priority": "high", "mode": "D"},
        )

        assert message.algorithm_id == HYBRID_ECDH_MLKEM_MLDSA_AES256_GCM
        assert message.ke_ciphertext is not None
        assert message.signature is not None

        # Wire serialization round-trip
        wire_json = json.dumps(message.to_dict())
        restored_message = SecureMessage.from_dict(json.loads(wire_json))

        # Receiver decrypts
        decrypted = comm.receive(
            restored_message,
            receiver_ke_kp.private_key,
            aad=b"authenticated-routing-header",
        )

        assert decrypted == plaintext

    @pytest.mark.parametrize(
        ("sig_type", "expected_suite_id", "expected_sig_cls"),
        [
            ("mldsa", HYBRID_ECDH_MLKEM_MLDSA_AES256_GCM, MLDSAProvider),
            ("slhdsa", HYBRID_ECDH_MLKEM_SLHDSA_AES256_GCM, SLHDSAProvider),
            ("ecdsa", HYBRID_ECDH_MLKEM_ECDSA_AES256_GCM, ECDSAProvider),
        ],
    )
    def test_mode_d_configurable_signature_strategies(
        self, sig_type: str, expected_suite_id: str, expected_sig_cls: type
    ):
        """Mode D supports multiple signature strategies with explicit suite IDs and provider binding."""
        cfg = ModeFactory.build(Mode.D, sig_provider_type=sig_type)
        assert cfg.algorithm_id == expected_suite_id
        assert isinstance(cfg.signature, expected_sig_cls)

        comm = SecureCommunicator(cfg)
        rx_kp = cfg.key_exchange.generate_keypair()
        plaintext = f"Testing Mode D with signature strategy: {sig_type}".encode("utf-8")

        sender_kps, msg = comm.send(plaintext, rx_kp.public_key)
        assert msg.algorithm_id == expected_suite_id

        # Verify signature with sender's actual public key using the provider
        assert cfg.signature.verify(
            public_key=sender_kps["sig"].public_key,
            message=msg.signed_data(),
            signature=msg.signature,  # type: ignore
        )

        recovered = comm.receive(msg, rx_kp.private_key)
        assert recovered == plaintext


# ===========================================================================
# 2. Cross-Mode and Cross-Signature Isolation Tests
# ===========================================================================


class TestModeDIsolation:
    """Verifies that Mode D cannot be cross-interpreted with Mode A, B, C or other Mode D sig variants."""

    def test_mode_d_rejected_by_mode_a_receiver(self):
        cfg_d = ModeFactory.build(Mode.D)
        cfg_a = ModeFactory.build(Mode.A)

        comm_d = SecureCommunicator(cfg_d)
        comm_a = SecureCommunicator(cfg_a)

        rx_kp_d = cfg_d.key_exchange.generate_keypair()
        _, msg_d = comm_d.send(b"Hybrid payload", rx_kp_d.public_key)

        with pytest.raises(ModeMismatchError, match="does not match receiver"):
            comm_a.receive(msg_d, rx_kp_d.private_key)

    def test_mode_d_rejected_by_mode_b_receiver(self):
        cfg_d = ModeFactory.build(Mode.D)
        cfg_b = ModeFactory.build(Mode.B)

        comm_d = SecureCommunicator(cfg_d)
        comm_b = SecureCommunicator(cfg_b)

        rx_kp_d = cfg_d.key_exchange.generate_keypair()
        _, msg_d = comm_d.send(b"Hybrid payload", rx_kp_d.public_key)

        with pytest.raises(ModeMismatchError, match="does not match receiver"):
            comm_b.receive(msg_d, rx_kp_d.private_key)

    def test_mode_d_rejected_by_mode_c_receiver(self):
        cfg_d = ModeFactory.build(Mode.D)
        cfg_c = ModeFactory.build(Mode.C)

        comm_d = SecureCommunicator(cfg_d)
        comm_c = SecureCommunicator(cfg_c)

        rx_kp_d = cfg_d.key_exchange.generate_keypair()
        _, msg_d = comm_d.send(b"Hybrid payload", rx_kp_d.public_key)

        with pytest.raises(ModeMismatchError, match="does not match receiver"):
            comm_c.receive(msg_d, rx_kp_d.private_key)

    def test_mode_a_rejected_by_mode_d_receiver(self):
        cfg_a = ModeFactory.build(Mode.A)
        cfg_d = ModeFactory.build(Mode.D)

        comm_a = SecureCommunicator(cfg_a)
        comm_d = SecureCommunicator(cfg_d)

        rx_kp_a = cfg_a.key_exchange.generate_keypair()
        _, msg_a = comm_a.send(b"Classical payload", rx_kp_a.public_key)

        with pytest.raises(ModeMismatchError, match="does not match receiver"):
            comm_d.receive(msg_a, rx_kp_a.private_key)

    def test_mode_d_mldsa_rejected_by_mode_d_ecdsa_receiver(self):
        """Cross-signature isolation: Mode D (ML-DSA) vs Mode D (ECDSA)."""
        cfg_mldsa = ModeFactory.build(Mode.D, sig_provider_type="mldsa")
        cfg_ecdsa = ModeFactory.build(Mode.D, sig_provider_type="ecdsa")

        comm_mldsa = SecureCommunicator(cfg_mldsa)
        comm_ecdsa = SecureCommunicator(cfg_ecdsa)

        rx_kp = cfg_mldsa.key_exchange.generate_keypair()
        _, msg = comm_mldsa.send(b"ML-DSA hybrid message", rx_kp.public_key)

        with pytest.raises(ModeMismatchError, match="does not match receiver"):
            comm_ecdsa.receive(msg, rx_kp.private_key)

    def test_mode_d_slhdsa_rejected_by_mode_d_mldsa_receiver(self):
        """Cross-signature isolation: Mode D (SLH-DSA) vs Mode D (ML-DSA)."""
        cfg_slhdsa = ModeFactory.build(Mode.D, sig_provider_type="slhdsa")
        cfg_mldsa = ModeFactory.build(Mode.D, sig_provider_type="mldsa")

        comm_slhdsa = SecureCommunicator(cfg_slhdsa)
        comm_mldsa = SecureCommunicator(cfg_mldsa)

        rx_kp = cfg_slhdsa.key_exchange.generate_keypair()
        _, msg = comm_slhdsa.send(b"SLH-DSA hybrid message", rx_kp.public_key)

        with pytest.raises(ModeMismatchError, match="does not match receiver"):
            comm_mldsa.receive(msg, rx_kp.private_key)


# ===========================================================================
# 3. Mode D Active Tampering Detection Tests
# ===========================================================================


class TestModeDTampering:
    """Security tests verifying active adversarial tampering rejection in Mode D."""

    @pytest.fixture
    def comm(self) -> SecureCommunicator:
        return SecureCommunicator(ModeFactory.build(Mode.D))

    def test_tampered_ciphertext_rejected(self, comm: SecureCommunicator):
        rx_kp = comm._config.key_exchange.generate_keypair()
        _, msg = comm.send(b"Confidential text", rx_kp.public_key)

        d = msg.to_dict()
        ct = bytearray(msg.ciphertext)
        ct[0] ^= 0x01
        import base64
        d["ciphertext"] = base64.b64encode(bytes(ct)).decode("ascii")
        tampered_msg = SecureMessage.from_dict(d)

        with pytest.raises(SignatureVerificationError):
            comm.receive(tampered_msg, rx_kp.private_key)

    def test_tampered_nonce_rejected(self, comm: SecureCommunicator):
        rx_kp = comm._config.key_exchange.generate_keypair()
        _, msg = comm.send(b"Confidential text", rx_kp.public_key)

        d = msg.to_dict()
        nonce = bytearray(msg.nonce)
        nonce[0] ^= 0x01
        import base64
        d["nonce"] = base64.b64encode(bytes(nonce)).decode("ascii")
        tampered_msg = SecureMessage.from_dict(d)

        with pytest.raises(SignatureVerificationError):
            comm.receive(tampered_msg, rx_kp.private_key)

    def test_tampered_signature_rejected(self, comm: SecureCommunicator):
        rx_kp = comm._config.key_exchange.generate_keypair()
        _, msg = comm.send(b"Confidential text", rx_kp.public_key)

        d = msg.to_dict()
        sig = bytearray(msg.signature)
        sig[0] ^= 0x01
        import base64
        d["signature"] = base64.b64encode(bytes(sig)).decode("ascii")
        tampered_msg = SecureMessage.from_dict(d)

        with pytest.raises(SignatureVerificationError):
            comm.receive(tampered_msg, rx_kp.private_key)

    def test_tampered_hybrid_kem_ciphertext_rejected(self, comm: SecureCommunicator):
        rx_kp = comm._config.key_exchange.generate_keypair()
        _, msg = comm.send(b"Confidential text", rx_kp.public_key)

        d = msg.to_dict()
        kem_ct = bytearray(msg.ke_ciphertext)  # type: ignore
        kem_ct[-1] ^= 0x01
        import base64
        d["ke_ciphertext"] = base64.b64encode(bytes(kem_ct)).decode("ascii")
        tampered_msg = SecureMessage.from_dict(d)

        # Mismatched shared secret leads to GCM authentication tag failure
        with pytest.raises((AuthenticationFailureError, PQCFrameworkError)):
            comm.receive(tampered_msg, rx_kp.private_key)

    def test_tampered_suite_metadata_rejected(self, comm: SecureCommunicator):
        """Altering the algorithm_id after message creation must be rejected."""
        rx_kp = comm._config.key_exchange.generate_keypair()
        _, msg = comm.send(b"Confidential text", rx_kp.public_key)

        d = msg.to_dict()
        # Tamper algorithm_id from HYBRID_ECDH_MLKEM_MLDSA_AES256_GCM to ECDSA variant
        d["algorithm_id"] = HYBRID_ECDH_MLKEM_ECDSA_AES256_GCM
        tampered_msg = SecureMessage.from_dict(d)

        with pytest.raises(ModeMismatchError, match="does not match receiver"):
            comm.receive(tampered_msg, rx_kp.private_key)


# ===========================================================================
# 4. Protocol Negotiation Involving Mode D
# ===========================================================================


class TestModeDNegotiation:
    """Verifies mode negotiation with Mode D present."""

    def test_negotiate_mode_d_mutual_agreement(self):
        client = [Mode.A, Mode.B, Mode.D]
        server = [Mode.D, Mode.B]
        # Server preference: D first
        selected = negotiate_mode(client, server)
        assert selected is Mode.D

    def test_negotiate_mode_d_with_explicit_priority(self):
        client = [Mode.A, Mode.B, Mode.C, Mode.D]
        server = [Mode.A, Mode.B, Mode.C, Mode.D]
        # Explicit priority: D > B > C > A
        selected = negotiate_mode(
            client,
            server,
            preference_order=[Mode.D, Mode.B, Mode.C, Mode.A],
        )
        assert selected is Mode.D

    def test_negotiate_mode_d_incompatible_raises_error(self):
        client = [Mode.D]
        server = [Mode.A, Mode.B]
        with pytest.raises(PQCFrameworkError):
            negotiate_mode(client, server)
