"""
tests/integration/test_pqc_slhdsa_workflow.py
Post-Quantum Secure Communication & Migration Framework

INTEGRATION TEST — Mode C: Hash-Based PQC Workflow (ML-KEM + SLH-DSA + AES-256-GCM)

Verifies the complete hash-based post-quantum communication pipeline:
  Alice (Sender) -> SecureMessage -> Bob (Receiver)

Algorithm Suite (Mode C):
  - Key Establishment: ML-KEM-768 (FIPS 203)
  - Digital Signature: SLH-DSA-SHAKE-128f (FIPS 205 / SPHINCS+ lineage)
  - Key Derivation:    HKDF-SHA-384
  - Symmetric Cipher:  AES-256-GCM

Properties Verified:
  1. Full end-to-end workflow execution with real cryptographic operations.
  2. Exact plaintext recovery at receiver.
  3. Proper wire representation with no secret leakage.
  4. JSON serialization round-trip across the wire.
  5. Session independence across repeated messages.
  6. Support for empty payloads, large payloads, and AAD.
"""

import pytest

from src.communication.message_bundle import (
    PROTOCOL_VERSION,
    SecureMessage,
)
from src.communication.secure_communicator import SecureCommunicator
from src.config.crypto_config import CryptoConfig, ModeFactory
from src.config.modes import PQC_MLKEM_SLHDSA_AES256_GCM, Mode
from src.providers.pqc.mlkem_provider import MLKEMProvider
from src.providers.pqc.slhdsa_provider import SLHDSAProvider
from src.providers.symmetric.aesgcm_provider import AESGCM256Provider
from src.providers.symmetric.hkdf_provider import HKDFDerivationProvider


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture
def mode_c_config() -> CryptoConfig:
    return ModeFactory.build(Mode.C)


@pytest.fixture
def communicator(mode_c_config: CryptoConfig) -> SecureCommunicator:
    return SecureCommunicator(mode_c_config)


@pytest.fixture
def bob_ke_keypair(mode_c_config: CryptoConfig):
    """Bob's ML-KEM-768 key pair."""
    return mode_c_config.key_exchange.generate_keypair()


TEST_PLAINTEXT = b"Mode C Hash-Based Transmission: ML-KEM-768 + SLH-DSA-SHAKE-128f + AES-256-GCM"


# ---------------------------------------------------------------------------
# 1. Mode C Factory Configuration
# ---------------------------------------------------------------------------


class TestModeCFactory:
    """Tests for ModeFactory.build(Mode.C)."""

    def test_build_mode_c_returns_crypto_config(self, mode_c_config: CryptoConfig) -> None:
        assert isinstance(mode_c_config, CryptoConfig)

    def test_mode_c_algorithm_id(self, mode_c_config: CryptoConfig) -> None:
        assert mode_c_config.algorithm_id == PQC_MLKEM_SLHDSA_AES256_GCM

    def test_mode_c_mode_enum(self, mode_c_config: CryptoConfig) -> None:
        assert mode_c_config.mode is Mode.C

    def test_mode_c_provider_types(self, mode_c_config: CryptoConfig) -> None:
        assert isinstance(mode_c_config.key_exchange, MLKEMProvider)
        assert isinstance(mode_c_config.signature, SLHDSAProvider)
        assert isinstance(mode_c_config.encryption, AESGCM256Provider)
        assert isinstance(mode_c_config.kdf, HKDFDerivationProvider)


# ---------------------------------------------------------------------------
# 2. End-to-End Workflow Execution
# ---------------------------------------------------------------------------


class TestModeCWorkflowEndToEnd:
    """Tests for complete send/receive cycle in Mode C."""

    def test_full_workflow_success(
        self,
        communicator: SecureCommunicator,
        bob_ke_keypair,
    ) -> None:
        """Alice sends Mode C message -> Bob receives and decrypts."""
        sender_kps, message = communicator.send(
            plaintext=TEST_PLAINTEXT,
            receiver_ke_public_key=bob_ke_keypair.public_key,
        )
        assert message.ke_ciphertext is not None
        assert len(message.ke_ciphertext) == 1088
        assert len(message.signature) == 17088

        recovered = communicator.receive(
            message=message,
            receiver_ke_private_key=bob_ke_keypair.private_key,
        )
        assert recovered == TEST_PLAINTEXT

    def test_empty_message_workflow(
        self,
        communicator: SecureCommunicator,
        bob_ke_keypair,
    ) -> None:
        _, message = communicator.send(
            plaintext=b"",
            receiver_ke_public_key=bob_ke_keypair.public_key,
        )
        recovered = communicator.receive(
            message=message,
            receiver_ke_private_key=bob_ke_keypair.private_key,
        )
        assert recovered == b""

    def test_large_message_workflow(
        self,
        communicator: SecureCommunicator,
        bob_ke_keypair,
    ) -> None:
        large_payload = b"W" * 50_000
        _, message = communicator.send(
            plaintext=large_payload,
            receiver_ke_public_key=bob_ke_keypair.public_key,
        )
        recovered = communicator.receive(
            message=message,
            receiver_ke_private_key=bob_ke_keypair.private_key,
        )
        assert recovered == large_payload

    def test_workflow_with_aad(
        self,
        communicator: SecureCommunicator,
        bob_ke_keypair,
    ) -> None:
        aad = b"routing=hash-node-99;security=fips-205"
        _, message = communicator.send(
            plaintext=TEST_PLAINTEXT,
            receiver_ke_public_key=bob_ke_keypair.public_key,
            aad=aad,
        )
        recovered = communicator.receive(
            message=message,
            receiver_ke_private_key=bob_ke_keypair.private_key,
            aad=aad,
        )
        assert recovered == TEST_PLAINTEXT

    def test_session_independence(
        self,
        communicator: SecureCommunicator,
        bob_ke_keypair,
    ) -> None:
        _, msg1 = communicator.send(TEST_PLAINTEXT, bob_ke_keypair.public_key)
        _, msg2 = communicator.send(TEST_PLAINTEXT, bob_ke_keypair.public_key)
        assert msg1.ke_ciphertext != msg2.ke_ciphertext
        assert msg1.ciphertext != msg2.ciphertext
        assert msg1.nonce != msg2.nonce
        assert msg1.signature != msg2.signature


# ---------------------------------------------------------------------------
# 3. Message Structure and Metadata
# ---------------------------------------------------------------------------


class TestModeCMessageStructure:
    """Tests for Mode C message attributes."""

    def test_message_structure_dimensions(
        self,
        communicator: SecureCommunicator,
        bob_ke_keypair,
    ) -> None:
        _, message = communicator.send(TEST_PLAINTEXT, bob_ke_keypair.public_key)
        assert message.protocol_version == PROTOCOL_VERSION
        assert message.algorithm_id == PQC_MLKEM_SLHDSA_AES256_GCM
        assert len(message.sender_ke_public_key) == 1184   # ML-KEM-768
        assert len(message.sender_sig_public_key) == 32    # SLH-DSA-SHAKE-128f
        assert len(message.ke_ciphertext) == 1088          # ML-KEM-768
        assert len(message.signature) == 17088             # SLH-DSA-SHAKE-128f
        assert len(message.nonce) == 12                    # AES-GCM


# ---------------------------------------------------------------------------
# 4. JSON Serialization
# ---------------------------------------------------------------------------


class TestModeCMessageSerialization:
    """Tests for JSON wire format handling."""

    def test_json_round_trip(
        self,
        communicator: SecureCommunicator,
        bob_ke_keypair,
    ) -> None:
        _, message = communicator.send(TEST_PLAINTEXT, bob_ke_keypair.public_key)
        json_str = message.to_json()
        assert isinstance(json_str, str)

        reconstructed = SecureMessage.from_json(json_str)
        recovered = communicator.receive(
            message=reconstructed,
            receiver_ke_private_key=bob_ke_keypair.private_key,
        )
        assert recovered == TEST_PLAINTEXT

    def test_dict_does_not_contain_secret_material(
        self,
        communicator: SecureCommunicator,
        bob_ke_keypair,
    ) -> None:
        _, message = communicator.send(TEST_PLAINTEXT, bob_ke_keypair.public_key)
        d = message.to_dict()
        sensitive_terms = {"private", "secret", "aes_key", "ikm"}
        for k in d.keys():
            assert not any(term in k.lower() for term in sensitive_terms)
