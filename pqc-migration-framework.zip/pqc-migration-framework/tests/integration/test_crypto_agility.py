"""
tests/integration/test_crypto_agility.py
Post-Quantum Secure Communication & Migration Framework

Integration tests for Crypto-Agility Layer (Phase 6).

Verifies:
1. Unified communication workflow operates identically across Mode A, Mode B, and Mode C.
2. Runtime mode switching via CryptoConfig injection without application-level logic changes.
3. Strict mode isolation & downgrade protection: messages from one mode are rejected by another.
4. Serialized metadata preservation and algorithm ID binding.
"""

import json
import pytest

from src.communication.message_bundle import SecureMessage
from src.communication.secure_communicator import SecureCommunicator
from src.config.crypto_config import CryptoConfig, ModeFactory
from src.config.modes import (
    CLASSICAL_ECDH_ECDSA_AES256_GCM,
    PQC_MLKEM_MLDSA_AES256_GCM,
    PQC_MLKEM_SLHDSA_AES256_GCM,
    Mode,
    negotiate_mode,
)
from src.exceptions import ModeMismatchError, PQCFrameworkError


# ===========================================================================
# 1. Runtime Mode Switching & Unified Workflow Tests
# ===========================================================================


class TestRuntimeModeSwitching:
    """
    Tests that the exact same application-level workflow succeeds across
    all supported cryptographic modes (Mode A, Mode B, Mode C).
    """

    @pytest.mark.parametrize(
        "mode,expected_algorithm_id",
        [
            (Mode.A, CLASSICAL_ECDH_ECDSA_AES256_GCM),
            (Mode.B, PQC_MLKEM_MLDSA_AES256_GCM),
            (Mode.C, PQC_MLKEM_SLHDSA_AES256_GCM),
        ],
    )
    def test_unified_workflow_across_modes(self, mode: Mode, expected_algorithm_id: str):
        """
        Demonstrate that switching cryptographic mode requires ONLY passing a different
        CryptoConfig to SecureCommunicator. All 10 communication steps are executed identically.
        """
        # 1. Build configuration for the requested mode
        config: CryptoConfig = ModeFactory.build(mode)
        assert config.mode is mode
        assert config.algorithm_id == expected_algorithm_id

        # 2. Instantiate communicator (application layer)
        comm = SecureCommunicator(config)

        # 3. Receiver generates key material
        receiver_ke_kp = config.key_exchange.generate_keypair()

        # 4. Sender generates message
        plaintext = f"Hello from Crypto-Agility Mode {mode.value}!".encode("utf-8")
        sender_kps, message = comm.send(
            plaintext=plaintext,
            receiver_ke_public_key=receiver_ke_kp.public_key,
            aad=b"header-routing-info",
            metadata={"source": "test_agility", "mode": mode.value},
        )

        assert message.algorithm_id == expected_algorithm_id
        assert message.ciphertext is not None
        assert message.nonce is not None
        assert message.signature is not None

        # 5. Serialization / Deserialization (Simulate Wire Transfer)
        wire_dict = message.to_dict()
        wire_json = json.dumps(wire_dict)
        restored_message = SecureMessage.from_dict(json.loads(wire_json))

        # 6. Receiver receives and decrypts message
        recovered_plaintext = comm.receive(
            message=restored_message,
            receiver_ke_private_key=receiver_ke_kp.private_key,
            aad=b"header-routing-info",
        )

        # 7. Assert fidelity
        assert recovered_plaintext == plaintext

    def test_runtime_switching_in_single_session(self):
        """
        Demonstrate dynamically switching between Mode A -> Mode B -> Mode C
        within the same application process.
        """
        modes = [Mode.A, Mode.B, Mode.C]
        results = []

        for mode in modes:
            cfg = ModeFactory.build(mode)
            comm = SecureCommunicator(cfg)
            rx_kp = cfg.key_exchange.generate_keypair()
            msg_bytes = f"Payload for {mode.name}".encode("utf-8")

            _, wire_msg = comm.send(msg_bytes, rx_kp.public_key)
            decrypted = comm.receive(wire_msg, rx_kp.private_key)
            results.append((decrypted == msg_bytes, wire_msg.algorithm_id))

        assert all(success for success, _ in results)
        assert len(results) == 3


# ===========================================================================
# 2. Mode Isolation & Downgrade Prevention Tests
# ===========================================================================


class TestModeIsolationAndDowngradeProtection:
    """
    Tests ensuring that messages created under one cryptographic mode CANNOT
    be processed by a receiver configured for a different mode.
    """

    def test_mode_a_message_rejected_by_mode_b_receiver(self):
        cfg_a = ModeFactory.build(Mode.A)
        cfg_b = ModeFactory.build(Mode.B)

        comm_a = SecureCommunicator(cfg_a)
        comm_b = SecureCommunicator(cfg_b)

        rx_kp_a = cfg_a.key_exchange.generate_keypair()
        _, msg_a = comm_a.send(b"Secret classical data", rx_kp_a.public_key)

        with pytest.raises(ModeMismatchError, match="does not match receiver"):
            comm_b.receive(msg_a, rx_kp_a.private_key)

    def test_mode_b_message_rejected_by_mode_c_receiver(self):
        cfg_b = ModeFactory.build(Mode.B)
        cfg_c = ModeFactory.build(Mode.C)

        comm_b = SecureCommunicator(cfg_b)
        comm_c = SecureCommunicator(cfg_c)

        rx_kp_b = cfg_b.key_exchange.generate_keypair()
        _, msg_b = comm_b.send(b"Secret PQC Lattice data", rx_kp_b.public_key)

        with pytest.raises(ModeMismatchError, match="does not match receiver"):
            comm_c.receive(msg_b, rx_kp_b.private_key)

    def test_mode_c_message_rejected_by_mode_a_receiver(self):
        cfg_c = ModeFactory.build(Mode.C)
        cfg_a = ModeFactory.build(Mode.A)

        comm_c = SecureCommunicator(cfg_c)
        comm_a = SecureCommunicator(cfg_a)

        rx_kp_c = cfg_c.key_exchange.generate_keypair()
        _, msg_c = comm_c.send(b"Secret PQC Hash data", rx_kp_c.public_key)

        with pytest.raises(ModeMismatchError, match="does not match receiver"):
            comm_a.receive(msg_c, rx_kp_c.private_key)

    def test_mode_b_message_rejected_by_mode_a_receiver(self):
        """Prevent downgrade of PQC message to classical receiver."""
        cfg_b = ModeFactory.build(Mode.B)
        cfg_a = ModeFactory.build(Mode.A)

        comm_b = SecureCommunicator(cfg_b)
        comm_a = SecureCommunicator(cfg_a)

        rx_kp_b = cfg_b.key_exchange.generate_keypair()
        _, msg_b = comm_b.send(b"PQC message", rx_kp_b.public_key)

        with pytest.raises(ModeMismatchError, match="does not match receiver"):
            comm_a.receive(msg_b, rx_kp_b.private_key)

    def test_forged_algorithm_id_in_message_rejected(self):
        """
        If an attacker changes algorithm_id in message metadata to match the receiver,
        the underlying cryptographic parsing/verification fails safely.
        """
        cfg_a = ModeFactory.build(Mode.A)
        cfg_b = ModeFactory.build(Mode.B)

        comm_a = SecureCommunicator(cfg_a)
        comm_b = SecureCommunicator(cfg_b)

        rx_kp_a = cfg_a.key_exchange.generate_keypair()
        _, msg_a = comm_a.send(b"Classical data", rx_kp_a.public_key)

        # Attacker modifies algorithm_id to trick Mode B receiver
        d = msg_a.to_dict()
        d["algorithm_id"] = cfg_b.algorithm_id  # Spoof Mode B
        forged_msg = SecureMessage.from_dict(d)

        with pytest.raises(PQCFrameworkError):
            comm_b.receive(forged_msg, rx_kp_a.private_key)


# ===========================================================================
# 3. Protocol Negotiation Workflow Integration
# ===========================================================================


class TestNegotiatedCommunicationWorkflow:
    """
    Tests full end-to-end communication preceded by mode negotiation.
    """

    def test_negotiated_pqc_session_success(self):
        client_capabilities = [Mode.A, Mode.B, Mode.C]
        server_capabilities = [Mode.B, Mode.C]  # Server does not allow Mode A

        # 1. Negotiate mode
        selected_mode = negotiate_mode(client_capabilities, server_capabilities)
        assert selected_mode is Mode.B

        # 2. Both parties build agreed config
        client_cfg = ModeFactory.build(selected_mode)
        server_cfg = ModeFactory.build(selected_mode)

        client_comm = SecureCommunicator(client_cfg)
        server_comm = SecureCommunicator(server_cfg)

        # 3. Server generates KEM keypair
        server_ke_kp = server_cfg.key_exchange.generate_keypair()

        # 4. Client sends message to server
        _, msg = client_comm.send(b"Post-quantum negotiated payload", server_ke_kp.public_key)

        # 5. Server receives and decrypts
        plaintext = server_comm.receive(msg, server_ke_kp.private_key)
        assert plaintext == b"Post-quantum negotiated payload"
