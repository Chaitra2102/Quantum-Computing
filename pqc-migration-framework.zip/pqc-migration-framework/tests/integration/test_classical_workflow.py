"""
tests/integration/test_classical_workflow.py
Post-Quantum Secure Communication & Migration Framework

INTEGRATION TEST — Classical Secure Communication Workflow (Mode A)

Tests the complete end-to-end workflow:
  Alice (sender) → SecureMessage → Bob (receiver)

Verifies:
  1. Full workflow completes successfully.
  2. Bob recovers Alice's original plaintext.
  3. The SecureMessage contains no private keys or shared secrets.
  4. SecureMessage is serialisable (JSON round-trip).
  5. Algorithm identifier is correct (CLASSICAL_ECDH_ECDSA_AES256_GCM).
  6. Protocol version is correct.
  7. Multiple messages can be exchanged (session independence).
  8. Different plaintexts produce different ciphertexts.
  9. ModeFactory.build(Mode.A) produces a working configuration.

ARCHITECTURE.md § 4 — Data Flow (complete workflow)
PROJECT_SPEC.md § 4 — Mode A: ECDH + ECDSA + AES-256-GCM

No benchmarks. Real cryptographic operations only — no mocks.
"""

import pytest

from src.communication.message_bundle import (
    PROTOCOL_VERSION,
    SecureMessage,
)
from src.communication.secure_communicator import SecureCommunicator
from src.config.crypto_config import CryptoConfig, ModeFactory
from src.config.modes import CLASSICAL_ECDH_ECDSA_AES256_GCM, Mode
from src.providers.classical.ecdh_provider import ECDHProvider


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture
def mode_a_config() -> CryptoConfig:
    """Mode A configuration via ModeFactory."""
    return ModeFactory.build(Mode.A)


@pytest.fixture
def communicator(mode_a_config: CryptoConfig) -> SecureCommunicator:
    return SecureCommunicator(mode_a_config)


@pytest.fixture
def receiver_ke_keypair(mode_a_config: CryptoConfig):
    """Bob's (receiver's) key-establishment key pair."""
    return mode_a_config.key_exchange.generate_keypair()


TEST_PLAINTEXT = b"Hello, Bob! This is a secret message from Alice."


# ---------------------------------------------------------------------------
# 1. ModeFactory
# ---------------------------------------------------------------------------


class TestModeFactory:
    """Tests for ModeFactory.build()."""

    def test_build_mode_a_returns_crypto_config(self) -> None:
        config = ModeFactory.build(Mode.A)
        assert isinstance(config, CryptoConfig)

    def test_mode_a_config_has_algorithm_id(self) -> None:
        config = ModeFactory.build(Mode.A)
        assert config.algorithm_id == CLASSICAL_ECDH_ECDSA_AES256_GCM

    def test_mode_a_config_mode_is_a(self) -> None:
        config = ModeFactory.build(Mode.A)
        assert config.mode is Mode.A

    def test_mode_a_config_has_all_providers(self) -> None:
        config = ModeFactory.build(Mode.A)
        assert config.key_exchange is not None
        assert config.signature is not None
        assert config.encryption is not None
        assert config.kdf is not None

    def test_unsupported_mode_raises(self) -> None:
        from src.exceptions import UnsupportedAlgorithmError
        with pytest.raises(UnsupportedAlgorithmError):
            ModeFactory.build("UNSUPPORTED_INVALID_MODE")


# ---------------------------------------------------------------------------
# 2. End-to-end secure communication workflow
# ---------------------------------------------------------------------------


class TestClassicalWorkflowEndToEnd:
    """
    Integration tests for the complete Alice → Bob workflow.

    Corresponds to ARCHITECTURE.md § 4 steps [1]–[10].
    """

    def test_full_workflow_succeeds(
        self,
        communicator: SecureCommunicator,
        receiver_ke_keypair,
    ) -> None:
        """
        Complete workflow:
          Alice sends → Bob receives → Bob decrypts to original plaintext.
        """
        # Alice sends
        sender_kps, message = communicator.send(
            plaintext=TEST_PLAINTEXT,
            receiver_ke_public_key=receiver_ke_keypair.public_key,
        )
        # Bob receives
        recovered = communicator.receive(
            message=message,
            receiver_ke_private_key=receiver_ke_keypair.private_key,
        )
        assert recovered == TEST_PLAINTEXT

    def test_receiver_obtains_original_plaintext(
        self,
        communicator: SecureCommunicator,
        receiver_ke_keypair,
    ) -> None:
        """Explicit check: decrypted bytes must exactly equal the original."""
        _, message = communicator.send(
            plaintext=TEST_PLAINTEXT,
            receiver_ke_public_key=receiver_ke_keypair.public_key,
        )
        recovered = communicator.receive(
            message=message,
            receiver_ke_private_key=receiver_ke_keypair.private_key,
        )
        assert recovered == TEST_PLAINTEXT
        assert type(recovered) is bytes

    def test_empty_message_workflow(
        self,
        communicator: SecureCommunicator,
        receiver_ke_keypair,
    ) -> None:
        _, message = communicator.send(
            plaintext=b"",
            receiver_ke_public_key=receiver_ke_keypair.public_key,
        )
        recovered = communicator.receive(
            message=message,
            receiver_ke_private_key=receiver_ke_keypair.private_key,
        )
        assert recovered == b""

    def test_large_message_workflow(
        self,
        communicator: SecureCommunicator,
        receiver_ke_keypair,
    ) -> None:
        large_msg = b"X" * 100_000
        _, message = communicator.send(
            plaintext=large_msg,
            receiver_ke_public_key=receiver_ke_keypair.public_key,
        )
        recovered = communicator.receive(
            message=message,
            receiver_ke_private_key=receiver_ke_keypair.private_key,
        )
        assert recovered == large_msg

    def test_workflow_with_aad(
        self,
        communicator: SecureCommunicator,
        receiver_ke_keypair,
    ) -> None:
        aad = b"recipient=bob;protocol=pqcf-v1"
        _, message = communicator.send(
            plaintext=TEST_PLAINTEXT,
            receiver_ke_public_key=receiver_ke_keypair.public_key,
            aad=aad,
        )
        recovered = communicator.receive(
            message=message,
            receiver_ke_private_key=receiver_ke_keypair.private_key,
            aad=aad,
        )
        assert recovered == TEST_PLAINTEXT

    def test_different_plaintexts_produce_different_messages(
        self,
        communicator: SecureCommunicator,
        receiver_ke_keypair,
    ) -> None:
        _, msg1 = communicator.send(b"message one", receiver_ke_keypair.public_key)
        _, msg2 = communicator.send(b"message two", receiver_ke_keypair.public_key)
        assert msg1.ciphertext != msg2.ciphertext

    def test_same_plaintext_produces_different_ciphertexts(
        self,
        communicator: SecureCommunicator,
        receiver_ke_keypair,
    ) -> None:
        """Due to fresh ECDH + fresh nonce, encrypting the same message twice produces different ciphertexts."""
        _, msg1 = communicator.send(TEST_PLAINTEXT, receiver_ke_keypair.public_key)
        _, msg2 = communicator.send(TEST_PLAINTEXT, receiver_ke_keypair.public_key)
        assert msg1.ciphertext != msg2.ciphertext


# ---------------------------------------------------------------------------
# 3. SecureMessage structure validation
# ---------------------------------------------------------------------------


class TestSecureMessageStructure:
    """Tests that the SecureMessage has correct structure and identifiers."""

    def test_message_is_secure_message_type(
        self,
        communicator: SecureCommunicator,
        receiver_ke_keypair,
    ) -> None:
        _, message = communicator.send(TEST_PLAINTEXT, receiver_ke_keypair.public_key)
        assert isinstance(message, SecureMessage)

    def test_message_has_correct_protocol_version(
        self,
        communicator: SecureCommunicator,
        receiver_ke_keypair,
    ) -> None:
        _, message = communicator.send(TEST_PLAINTEXT, receiver_ke_keypair.public_key)
        assert message.protocol_version == PROTOCOL_VERSION

    def test_message_has_correct_algorithm_id(
        self,
        communicator: SecureCommunicator,
        receiver_ke_keypair,
    ) -> None:
        _, message = communicator.send(TEST_PLAINTEXT, receiver_ke_keypair.public_key)
        assert message.algorithm_id == CLASSICAL_ECDH_ECDSA_AES256_GCM

    def test_message_has_ke_public_key_bytes(
        self,
        communicator: SecureCommunicator,
        receiver_ke_keypair,
    ) -> None:
        _, message = communicator.send(TEST_PLAINTEXT, receiver_ke_keypair.public_key)
        assert isinstance(message.sender_ke_public_key, bytes)
        assert len(message.sender_ke_public_key) > 0

    def test_message_has_sig_public_key_bytes(
        self,
        communicator: SecureCommunicator,
        receiver_ke_keypair,
    ) -> None:
        _, message = communicator.send(TEST_PLAINTEXT, receiver_ke_keypair.public_key)
        assert isinstance(message.sender_sig_public_key, bytes)
        assert len(message.sender_sig_public_key) > 0

    def test_message_has_ciphertext(
        self,
        communicator: SecureCommunicator,
        receiver_ke_keypair,
    ) -> None:
        _, message = communicator.send(TEST_PLAINTEXT, receiver_ke_keypair.public_key)
        assert isinstance(message.ciphertext, bytes)
        assert len(message.ciphertext) > 0

    def test_message_has_nonce(
        self,
        communicator: SecureCommunicator,
        receiver_ke_keypair,
    ) -> None:
        _, message = communicator.send(TEST_PLAINTEXT, receiver_ke_keypair.public_key)
        assert isinstance(message.nonce, bytes)
        assert len(message.nonce) == 12  # GCM nonce = 12 bytes

    def test_message_has_signature(
        self,
        communicator: SecureCommunicator,
        receiver_ke_keypair,
    ) -> None:
        _, message = communicator.send(TEST_PLAINTEXT, receiver_ke_keypair.public_key)
        assert isinstance(message.signature, bytes)
        assert len(message.signature) > 0

    def test_message_ke_ciphertext_is_none_for_ecdh(
        self,
        communicator: SecureCommunicator,
        receiver_ke_keypair,
    ) -> None:
        """ECDH (DH path) does not use a KEM ciphertext; ke_ciphertext must be None."""
        _, message = communicator.send(TEST_PLAINTEXT, receiver_ke_keypair.public_key)
        assert message.ke_ciphertext is None


# ---------------------------------------------------------------------------
# 4. JSON serialisation round-trip
# ---------------------------------------------------------------------------


class TestSecureMessageSerialisation:
    """Tests that SecureMessage can survive a JSON serialisation round-trip."""

    def test_json_round_trip_and_decryption_succeeds(
        self,
        communicator: SecureCommunicator,
        receiver_ke_keypair,
    ) -> None:
        """
        Simulate transmission: serialise to JSON → deserialise → decrypt.
        """
        _, message = communicator.send(TEST_PLAINTEXT, receiver_ke_keypair.public_key)
        json_str = message.to_json()
        assert isinstance(json_str, str)

        reconstructed = SecureMessage.from_json(json_str)
        recovered = communicator.receive(
            message=reconstructed,
            receiver_ke_private_key=receiver_ke_keypair.private_key,
        )
        assert recovered == TEST_PLAINTEXT

    def test_to_dict_contains_all_required_fields(
        self,
        communicator: SecureCommunicator,
        receiver_ke_keypair,
    ) -> None:
        _, message = communicator.send(TEST_PLAINTEXT, receiver_ke_keypair.public_key)
        d = message.to_dict()
        required_keys = {
            "protocol_version",
            "algorithm_id",
            "sender_ke_public_key",
            "sender_sig_public_key",
            "ciphertext",
            "nonce",
            "signature",
        }
        assert required_keys.issubset(set(d.keys()))

    def test_dict_does_not_contain_private_keys(
        self,
        communicator: SecureCommunicator,
        receiver_ke_keypair,
    ) -> None:
        _, message = communicator.send(TEST_PLAINTEXT, receiver_ke_keypair.public_key)
        d = message.to_dict()
        sensitive_keywords = {"private", "secret", "aes_key", "shared"}
        for key in d.keys():
            assert not any(kw in key.lower() for kw in sensitive_keywords), (
                f"Field '{key}' suggests private material in wire message."
            )
