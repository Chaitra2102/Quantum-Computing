"""Unit tests for benchmark output schemas and non-secret security guarantees."""

import pytest
from benchmarks.benchmark_sizes import run_size_benchmarks
from benchmarks.benchmark_utils import (
    get_environment_info,
    sanitize_benchmark_record,
)


class TestBenchmarkSchemaAndSecurity:
    """Verify benchmark data contracts, environment reporting, and secret non-exposure."""

    def test_environment_info_schema(self):
        env = get_environment_info()
        required_keys = [
            "operating_system",
            "cpu_model",
            "cpu_logical_cores",
            "python_version",
            "cryptography_version",
            "slh_dsa_version",
            "pytest_version",
            "project_version",
            "benchmark_timestamp_utc",
        ]
        for key in required_keys:
            assert key in env, f"Missing required environment key: {key}"
            assert env[key] is not None

        # Verify no private environment leakage
        env_str = str(env).lower()
        assert "password" not in env_str
        assert "secret" not in env_str

    def test_sanitize_benchmark_record_accepts_clean_data(self):
        clean_record = {
            "operation": "mlkem_encapsulate",
            "algorithm": "ML-KEM-768",
            "iterations": 100,
            "mean": 12.34,
        }
        sanitized = sanitize_benchmark_record(clean_record)
        assert sanitized == clean_record

    def test_sanitize_benchmark_record_rejects_secret_material(self):
        leaky_record_1 = {
            "operation": "sign",
            "private_key": b"super-secret-key-material",
        }
        with pytest.raises(ValueError, match="Security violation: Secret field 'private_key' detected"):
            sanitize_benchmark_record(leaky_record_1)

        leaky_record_2 = {
            "operation": "kdf",
            "shared_secret_bytes": b"derived-secret",
        }
        with pytest.raises(ValueError, match="Security violation: Secret field"):
            sanitize_benchmark_record(leaky_record_2)

    def test_size_benchmarks_schema_and_non_negative(self):
        size_results = run_size_benchmarks(payload_size=1024)
        
        assert "matrix" in size_results
        assert "overhead_relative_to_mode_a" in size_results
        assert "hybrid_comparisons" in size_results

        matrix = size_results["matrix"]
        assert len(matrix) == 6  # Modes A, B, C, D-MLDSA, D-SLHDSA, D-ECDSA

        for row in matrix:
            assert row["payload_bytes"] == 1024
            assert row["ke_public_key_bytes"] > 0
            assert row["sig_public_key_bytes"] > 0
            assert row["signature_bytes"] > 0
            assert row["nonce_bytes"] == 12
            assert row["ciphertext_bytes"] > 0
            assert row["raw_crypto_total_bytes"] > 0
            assert row["wire_json_total_bytes"] > row["raw_crypto_total_bytes"]
