"""Unit tests for statistical distribution calculations in the benchmarking framework."""

import math
import pytest
from benchmarks.benchmark_utils import (
    calculate_percentile,
    calculate_statistics,
    generate_benchmark_payload,
)


class TestStatisticalCalculations:
    """Test correctness of percentile and descriptive statistics functions."""

    def test_percentile_known_sequence(self):
        # Data: [10, 20, 30, 40, 50]
        data = [10.0, 20.0, 30.0, 40.0, 50.0]
        assert calculate_percentile(data, 0.0) == 10.0
        assert calculate_percentile(data, 50.0) == 30.0
        assert calculate_percentile(data, 100.0) == 50.0
        # 95th percentile rank = 0.95 * 4 = 3.8 -> 40 + 0.8 * 10 = 48.0
        assert math.isclose(calculate_percentile(data, 95.0), 48.0)

    def test_percentile_single_element(self):
        data = [42.0]
        assert calculate_percentile(data, 0.0) == 42.0
        assert calculate_percentile(data, 50.0) == 42.0
        assert calculate_percentile(data, 99.0) == 42.0

    def test_percentile_empty_data(self):
        assert calculate_percentile([], 50.0) == 0.0

    def test_calculate_statistics_even_count(self):
        # 10 samples in nanoseconds: [1000, 2000, 3000, 4000, 5000, 6000, 7000, 8000, 9000, 10000]
        samples_ns = [i * 1000 for i in range(1, 11)]
        stats = calculate_statistics(samples_ns, unit="microseconds")

        assert stats["count"] == 10
        assert stats["unit"] == "microseconds"
        assert stats["min"] == 1.0
        assert stats["max"] == 10.0
        assert stats["mean"] == 5.5
        assert stats["median"] == 5.5
        # Standard deviation for [1..10]: ~3.02765
        assert math.isclose(stats["stddev"], 3.028, abs_tol=0.01)
        assert stats["p95"] > stats["median"]
        assert stats["p99"] >= stats["p95"]

    def test_calculate_statistics_odd_count(self):
        samples_ns = [1000, 3000, 2000]
        stats = calculate_statistics(samples_ns, unit="microseconds")

        assert stats["count"] == 3
        assert stats["min"] == 1.0
        assert stats["max"] == 3.0
        assert stats["median"] == 2.0
        assert stats["mean"] == 2.0

    def test_calculate_statistics_single_sample(self):
        samples_ns = [5000]
        stats = calculate_statistics(samples_ns, unit="microseconds")

        assert stats["count"] == 1
        assert stats["min"] == 5.0
        assert stats["max"] == 5.0
        assert stats["mean"] == 5.0
        assert stats["median"] == 5.0
        assert stats["stddev"] == 0.0
        assert stats["p95"] == 5.0
        assert stats["p99"] == 5.0

    def test_calculate_statistics_empty_samples(self):
        stats = calculate_statistics([], unit="milliseconds")
        assert stats["count"] == 0
        assert stats["mean"] == 0.0
        assert stats["stddev"] == 0.0

    def test_generate_benchmark_payload_exact_length(self):
        for size in [64, 1024, 16384, 1048576]:
            payload = generate_benchmark_payload(size, seed=123)
            assert len(payload) == size
            assert isinstance(payload, bytes)
