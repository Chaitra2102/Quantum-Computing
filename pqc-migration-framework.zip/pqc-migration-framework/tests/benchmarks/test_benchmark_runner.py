"""Unit tests for the benchmark runner orchestration and CLI."""

import json
from pathlib import Path
import pytest
from benchmarks.benchmark_runner import run_all_benchmarks


class TestBenchmarkRunner:
    """Test the benchmark runner execution pipeline in quick verification mode."""

    def test_run_all_benchmarks_quick_generates_all_files(self, tmp_path: Path):
        output_dir = tmp_path / "benchmark_test_output"

        results = run_all_benchmarks(
            iterations=2,
            warmup=1,
            slhdsa_iterations=1,
            slhdsa_warmup=1,
            payload_size=512,
            output_dir=str(output_dir),
            seed=999,
            verbose=False,
        )

        assert "summary" in results
        assert "sizes" in results
        assert "raw" in results

        # Verify files created on disk
        summary_file = output_dir / "benchmark_summary.json"
        raw_file = output_dir / "benchmark_raw.json"
        sizes_file = output_dir / "benchmark_sizes.json"
        timings_csv = output_dir / "benchmark_timings.csv"
        sizes_csv = output_dir / "benchmark_sizes.csv"

        assert summary_file.exists()
        assert raw_file.exists()
        assert sizes_file.exists()
        assert timings_csv.exists()
        assert sizes_csv.exists()

        # Check JSON parsing
        with open(summary_file, "r", encoding="utf-8") as f:
            summary_json = json.load(f)
            assert "environment" in summary_json
            assert "key_establishment" in summary_json
            assert "signatures" in summary_json
            assert "symmetric_and_kdf" in summary_json
            assert "end_to_end" in summary_json

        # Check timings CSV content
        with open(timings_csv, "r", encoding="utf-8") as f:
            lines = f.readlines()
            assert len(lines) > 5
            assert "category,name,algorithm" in lines[0]
