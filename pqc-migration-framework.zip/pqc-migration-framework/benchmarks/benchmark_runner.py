"""Benchmark Runner and Orchestrator for PQC Secure Communication Framework.

Executes isolated, reproducible benchmarks across key establishment, digital signatures,
symmetric encryption, HKDF key derivation, end-to-end communication, and message sizing.

Usage:
    python -m benchmarks.benchmark_runner [OPTIONS]

Options:
    --iterations INT         Number of measured iterations for fast operations (default: 100)
    --warmup INT             Number of warm-up iterations for fast operations (default: 20)
    --slhdsa-iterations INT  Number of iterations for SLH-DSA operations (default: 20)
    --slhdsa-warmup INT      Number of warm-up iterations for SLH-DSA operations (default: 5)
    --payload-size INT       Plaintext payload size in bytes (default: 1024)
    --output PATH            Directory to store benchmark result files (default: results/benchmarks)
    --seed INT               Deterministic seed for payload creation (does NOT override crypto RNG)
    --quick                  Execute minimal iterations (2 iters, 1 warmup) for rapid verification
"""

from __future__ import annotations

import argparse
import csv
import json
import os
import sys
from pathlib import Path
from typing import Any, Dict, List, Optional

from benchmarks.benchmark_end_to_end import run_end_to_end_benchmarks
from benchmarks.benchmark_kex import run_kex_benchmarks
from benchmarks.benchmark_signatures import run_signature_benchmarks
from benchmarks.benchmark_sizes import run_size_benchmarks
from benchmarks.benchmark_symmetric import run_symmetric_benchmarks
from benchmarks.benchmark_utils import (
    get_environment_info,
    sanitize_benchmark_record,
)


def export_timings_csv(summary_data: Dict[str, Any], filepath: Path) -> None:
    """Export benchmark summary metrics to CSV for tabular analysis."""
    fieldnames = [
        "category", "name", "algorithm", "configuration", "provider",
        "payload_bytes", "iterations", "warmup", "unit",
        "min", "max", "mean", "median", "stddev", "p95", "p99",
        "throughput_mib_per_sec", "throughput_mb_per_sec"
    ]
    
    rows: List[Dict[str, Any]] = []

    # 1. KEX
    for k, v in summary_data.get("key_establishment", {}).items():
        rows.append({
            "category": "key_establishment",
            "name": k,
            "algorithm": v.get("algorithm", ""),
            "configuration": v.get("configuration", ""),
            "provider": v.get("provider", ""),
            "payload_bytes": "",
            "iterations": v.get("iterations", ""),
            "warmup": v.get("warmup", ""),
            "unit": v.get("unit", "microseconds"),
            "min": v.get("min", ""),
            "max": v.get("max", ""),
            "mean": v.get("mean", ""),
            "median": v.get("median", ""),
            "stddev": v.get("stddev", ""),
            "p95": v.get("p95", ""),
            "p99": v.get("p99", ""),
            "throughput_mib_per_sec": "",
            "throughput_mb_per_sec": "",
        })

    # 2. Signatures
    for k, v in summary_data.get("signatures", {}).items():
        rows.append({
            "category": "signatures",
            "name": k,
            "algorithm": v.get("algorithm", ""),
            "configuration": v.get("configuration", ""),
            "provider": v.get("provider", ""),
            "payload_bytes": v.get("payload_bytes", ""),
            "iterations": v.get("iterations", ""),
            "warmup": v.get("warmup", ""),
            "unit": v.get("unit", "microseconds"),
            "min": v.get("min", ""),
            "max": v.get("max", ""),
            "mean": v.get("mean", ""),
            "median": v.get("median", ""),
            "stddev": v.get("stddev", ""),
            "p95": v.get("p95", ""),
            "p99": v.get("p99", ""),
            "throughput_mib_per_sec": "",
            "throughput_mb_per_sec": "",
        })

    # 3. Symmetric & KDF
    for k, v in summary_data.get("symmetric_and_kdf", {}).items():
        rows.append({
            "category": "symmetric_and_kdf",
            "name": k,
            "algorithm": v.get("algorithm", ""),
            "configuration": v.get("configuration", ""),
            "provider": v.get("provider", ""),
            "payload_bytes": v.get("payload_bytes", v.get("derived_length_bytes", "")),
            "iterations": v.get("iterations", ""),
            "warmup": v.get("warmup", ""),
            "unit": v.get("unit", "microseconds"),
            "min": v.get("min", ""),
            "max": v.get("max", ""),
            "mean": v.get("mean", ""),
            "median": v.get("median", ""),
            "stddev": v.get("stddev", ""),
            "p95": v.get("p95", ""),
            "p99": v.get("p99", ""),
            "throughput_mib_per_sec": v.get("throughput_mib_per_sec", ""),
            "throughput_mb_per_sec": v.get("throughput_mb_per_sec", ""),
        })

    # 4. End-to-End
    for k, v in summary_data.get("end_to_end", {}).items():
        for phase in ["send", "receive", "roundtrip"]:
            phase_data = v.get(phase, {})
            rows.append({
                "category": f"end_to_end_{phase}",
                "name": f"{k}_{phase}",
                "algorithm": v.get("algorithm_id", ""),
                "configuration": k,
                "provider": "Full Framework Pipeline",
                "payload_bytes": v.get("payload_bytes", ""),
                "iterations": v.get("iterations", ""),
                "warmup": v.get("warmup", ""),
                "unit": v.get("unit", "microseconds"),
                "min": phase_data.get("min", ""),
                "max": phase_data.get("max", ""),
                "mean": phase_data.get("mean", ""),
                "median": phase_data.get("median", ""),
                "stddev": phase_data.get("stddev", ""),
                "p95": phase_data.get("p95", ""),
                "p99": phase_data.get("p99", ""),
                "throughput_mib_per_sec": "",
                "throughput_mb_per_sec": "",
            })

    filepath.parent.mkdir(parents=True, exist_ok=True)
    with open(filepath, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)


def export_sizes_csv(size_data: Dict[str, Any], filepath: Path) -> None:
    """Export artifact size measurements and overhead calculations to CSV."""
    matrix = size_data.get("matrix", [])
    if not matrix:
        return

    fieldnames = list(matrix[0].keys())
    filepath.parent.mkdir(parents=True, exist_ok=True)
    with open(filepath, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(matrix)


def run_all_benchmarks(
    iterations: int = 100,
    warmup: int = 20,
    slhdsa_iterations: Optional[int] = None,
    slhdsa_warmup: Optional[int] = None,
    payload_size: int = 1024,
    output_dir: str = "results/benchmarks",
    seed: Optional[int] = 42,
    verbose: bool = True,
) -> Dict[str, Any]:
    """Orchestrate execution of all Phase 10 benchmark suites."""
    if slhdsa_iterations is None:
        slhdsa_iterations = min(iterations, 20)
    if slhdsa_warmup is None:
        slhdsa_warmup = min(warmup, 5)

    out_path = Path(output_dir)
    out_path.mkdir(parents=True, exist_ok=True)

    env_info = get_environment_info()

    if verbose:
        print("=" * 70)
        print("POST-QUANTUM CRYPTOGRAPHIC PERFORMANCE & OVERHEAD BENCHMARK")
        print("=" * 70)
        print(f"OS:                 {env_info['operating_system']}")
        print(f"CPU:                {env_info['cpu_model']} ({env_info['cpu_logical_cores']} cores)")
        print(f"Python:             {env_info['python_version']} ({env_info['python_implementation']})")
        print(f"PyCA Cryptography:  {env_info['cryptography_version']}")
        print(f"SLH-DSA Package:    {env_info['slh_dsa_version']}")
        print(f"Standard Iterations:{iterations} (Warmup: {warmup})")
        print(f"SLH-DSA Iterations: {slhdsa_iterations} (Warmup: {slhdsa_warmup})")
        print(f"Default Payload:    {payload_size} bytes")
        print(f"Output Directory:   {out_path.resolve()}")
        print("=" * 70)

    # 1. Key Establishment
    if verbose:
        print("\n[1/5] Running Key Establishment & Keygen Benchmarks...")
    kex_res = run_kex_benchmarks(iterations=iterations, warmup=warmup)

    # 2. Digital Signatures
    if verbose:
        print("\n[2/5] Running Digital Signature Benchmarks...")
    sig_res = run_signature_benchmarks(
        iterations=iterations,
        warmup=warmup,
        slhdsa_iterations=slhdsa_iterations,
        slhdsa_warmup=slhdsa_warmup,
        payload_sizes=[64, 1024, 16384],
    )

    # 3. Symmetric & HKDF
    if verbose:
        print("\n[3/5] Running Symmetric (AES-256-GCM) & HKDF Benchmarks...")
    sym_res = run_symmetric_benchmarks(
        iterations=iterations,
        warmup=warmup,
        payload_sizes=[64, 1024, 16384, 1048576],
    )

    # 4. Sizes and Overhead
    if verbose:
        print("\n[4/5] Measuring Message Sizes & Communication Overhead...")
    size_res = run_size_benchmarks(payload_size=payload_size)

    # 5. End-to-End Pipeline
    if verbose:
        print("\n[5/5] Running End-to-End Pipeline Benchmarks...")
    e2e_res = run_end_to_end_benchmarks(
        iterations=iterations,
        warmup=warmup,
        slhdsa_iterations=slhdsa_iterations,
        slhdsa_warmup=slhdsa_warmup,
        payload_size=payload_size,
    )

    # Assemble Structured Outputs
    summary_data = {
        "environment": env_info,
        "benchmark_parameters": {
            "iterations": iterations,
            "warmup": warmup,
            "slhdsa_iterations": slhdsa_iterations,
            "slhdsa_warmup": slhdsa_warmup,
            "default_payload_size_bytes": payload_size,
            "payload_seed": seed,
        },
        "key_establishment": kex_res["summary"],
        "signatures": sig_res["summary"],
        "symmetric_and_kdf": sym_res["summary"],
        "end_to_end": e2e_res["summary"],
    }

    raw_data = {
        "environment": env_info,
        "raw_samples": {
            "key_establishment": kex_res["raw_samples"],
            "signatures": sig_res["raw_samples"],
            "symmetric_and_kdf": sym_res["raw_samples"],
            "end_to_end": e2e_res["raw_samples"],
        }
    }

    # Verify no secret leakage
    sanitize_benchmark_record(summary_data)
    sanitize_benchmark_record(size_res)

    # Save to disk
    raw_file = out_path / "benchmark_raw.json"
    summary_file = out_path / "benchmark_summary.json"
    sizes_file = out_path / "benchmark_sizes.json"
    timings_csv_file = out_path / "benchmark_timings.csv"
    sizes_csv_file = out_path / "benchmark_sizes.csv"

    with open(raw_file, "w", encoding="utf-8") as f:
        json.dump(raw_data, f, indent=2)

    with open(summary_file, "w", encoding="utf-8") as f:
        json.dump(summary_data, f, indent=2)

    with open(sizes_file, "w", encoding="utf-8") as f:
        json.dump(size_res, f, indent=2)

    export_timings_csv(summary_data, timings_csv_file)
    export_sizes_csv(size_res, sizes_csv_file)

    if verbose:
        print("\n" + "=" * 70)
        print("BENCHMARK EXECUTION COMPLETE")
        print(f"  Summary JSON: {summary_file}")
        print(f"  Raw JSON:     {raw_file}")
        print(f"  Sizes JSON:   {sizes_file}")
        print(f"  Timings CSV:  {timings_csv_file}")
        print(f"  Sizes CSV:    {sizes_csv_file}")
        print("=" * 70)

    return {
        "summary": summary_data,
        "sizes": size_res,
        "raw": raw_data,
    }


def main() -> None:
    """CLI parser for benchmark suite."""
    parser = argparse.ArgumentParser(
        description="PQC Migration Framework Benchmarking Runner (Phase 10)"
    )
    parser.add_argument(
        "--iterations",
        type=int,
        default=100,
        help="Number of measured iterations for fast operations (default: 100)",
    )
    parser.add_argument(
        "--warmup",
        type=int,
        default=20,
        help="Number of warm-up iterations for fast operations (default: 20)",
    )
    parser.add_argument(
        "--slhdsa-iterations",
        type=int,
        default=None,
        help="Number of iterations for SLH-DSA operations (default: min(iterations, 20))",
    )
    parser.add_argument(
        "--slhdsa-warmup",
        type=int,
        default=None,
        help="Number of warm-up iterations for SLH-DSA operations (default: min(warmup, 5))",
    )
    parser.add_argument(
        "--payload-size",
        type=int,
        default=1024,
        help="Plaintext payload size in bytes (default: 1024)",
    )
    parser.add_argument(
        "--output",
        "-o",
        type=str,
        default="results/benchmarks",
        help="Output directory (default: results/benchmarks)",
    )
    parser.add_argument(
        "--seed",
        type=int,
        default=42,
        help="Seed for deterministic payload generation (does NOT affect crypto RNG)",
    )
    parser.add_argument(
        "--quick",
        action="store_true",
        help="Run minimal iterations (2 iters, 1 warmup) for fast test validation",
    )

    args = parser.parse_args()

    if args.quick:
        iters = 2
        wup = 1
        slh_iters = 1
        slh_wup = 1
    else:
        iters = args.iterations
        wup = args.warmup
        slh_iters = args.slhdsa_iterations
        slh_wup = args.slhdsa_warmup

    try:
        run_all_benchmarks(
            iterations=iters,
            warmup=wup,
            slhdsa_iterations=slh_iters,
            slhdsa_warmup=slh_wup,
            payload_size=args.payload_size,
            output_dir=args.output,
            seed=args.seed,
            verbose=True,
        )
    except Exception as exc:
        print(f"Error executing benchmark suite: {exc}", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
