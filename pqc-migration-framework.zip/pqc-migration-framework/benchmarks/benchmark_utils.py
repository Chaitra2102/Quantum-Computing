"""Utility functions for cryptographic benchmarking.

Provides high-resolution timing, robust statistical distribution calculations,
environment profiling, and non-secret output validation.
"""

from __future__ import annotations

import importlib.metadata
import math
import os
import platform
import time
from datetime import datetime, timezone
from typing import Any, Callable, Dict, List, Optional


def get_environment_info() -> Dict[str, Any]:
    """Capture public hardware, OS, and software environment metadata.
    
    Excludes any private user, hostname, network, or filesystem path information.
    """
    # Safe CPU description
    cpu_desc = platform.processor() or "Unknown CPU"
    # Try to refine CPU brand if generic on Windows
    if not cpu_desc or cpu_desc == "Unknown CPU" or "Intel64" in cpu_desc or "AMD64" in cpu_desc:
        try:
            import winreg  # type: ignore
            key = winreg.OpenKey(
                winreg.HKEY_LOCAL_MACHINE,
                r"HARDWARE\DESCRIPTION\System\CentralProcessor\0"
            )
            val, _ = winreg.QueryValueEx(key, "ProcessorNameString")
            if val:
                cpu_desc = str(val).strip()
        except Exception:
            pass

    def _get_version(pkg: str) -> str:
        try:
            return importlib.metadata.version(pkg)
        except Exception:
            return "unknown"

    return {
        "operating_system": f"{platform.system()} {platform.release()} ({platform.machine()})",
        "cpu_model": cpu_desc,
        "cpu_logical_cores": os.cpu_count() or 1,
        "python_version": platform.python_version(),
        "python_implementation": platform.python_implementation(),
        "cryptography_version": _get_version("cryptography"),
        "slh_dsa_version": _get_version("slh-dsa"),
        "pytest_version": _get_version("pytest"),
        "project_version": "0.1.0",
        "benchmark_timestamp_utc": datetime.now(timezone.utc).isoformat(),
    }


def calculate_percentile(sorted_data: List[float], percentile: float) -> float:
    """Calculate the p-th percentile of sorted data using linear interpolation.
    
    Args:
        sorted_data: Ascending sorted list of numeric values.
        percentile: Percentile value between 0.0 and 100.0.
    """
    if not sorted_data:
        return 0.0
    if len(sorted_data) == 1:
        return sorted_data[0]
    
    rank = (percentile / 100.0) * (len(sorted_data) - 1)
    low_idx = int(math.floor(rank))
    high_idx = int(math.ceil(rank))
    
    if low_idx == high_idx:
        return sorted_data[low_idx]
    
    fraction = rank - low_idx
    return sorted_data[low_idx] + fraction * (sorted_data[high_idx] - sorted_data[low_idx])


def calculate_statistics(
    samples_ns: List[int],
    unit: str = "microseconds"
) -> Dict[str, Any]:
    """Calculate comprehensive statistical summary from nanosecond timing samples.
    
    Supported units: 'nanoseconds', 'microseconds', 'milliseconds', 'seconds'.
    """
    count = len(samples_ns)
    if count == 0:
        return {
            "count": 0,
            "unit": unit,
            "min": 0.0,
            "max": 0.0,
            "mean": 0.0,
            "median": 0.0,
            "stddev": 0.0,
            "p95": 0.0,
            "p99": 0.0,
        }

    # Conversion factor from nanoseconds
    scale = {
        "nanoseconds": 1.0,
        "microseconds": 1_000.0,
        "milliseconds": 1_000_000.0,
        "seconds": 1_000_000_000.0,
    }.get(unit, 1_000.0)

    converted = [s / scale for s in samples_ns]
    sorted_vals = sorted(converted)
    
    min_val = sorted_vals[0]
    max_val = sorted_vals[-1]
    mean_val = sum(converted) / count
    
    # Median
    if count % 2 == 1:
        median_val = sorted_vals[count // 2]
    else:
        median_val = (sorted_vals[count // 2 - 1] + sorted_vals[count // 2]) / 2.0
        
    # Standard deviation (sample stddev with Bessel's correction if count > 1)
    if count > 1:
        variance = sum((x - mean_val) ** 2 for x in converted) / (count - 1)
        stddev_val = math.sqrt(variance)
    else:
        stddev_val = 0.0

    p95_val = calculate_percentile(sorted_vals, 95.0)
    p99_val = calculate_percentile(sorted_vals, 99.0)

    return {
        "count": count,
        "unit": unit,
        "min": round(min_val, 3),
        "max": round(max_val, 3),
        "mean": round(mean_val, 3),
        "median": round(median_val, 3),
        "stddev": round(stddev_val, 3),
        "p95": round(p95_val, 3),
        "p99": round(p99_val, 3),
    }


def benchmark_operation(
    op_callable: Callable[[], Any],
    iterations: int = 100,
    warmup: int = 20,
    setup_callable: Optional[Callable[[], Any]] = None,
) -> List[int]:
    """Execute warm-up iterations followed by timed trial iterations using time.perf_counter_ns().
    
    Args:
        op_callable: Function performing the target cryptographic operation.
        iterations: Number of measured iterations.
        warmup: Number of unmeasured warm-up iterations.
        setup_callable: Optional setup called before each iteration (outside timing).
        
    Returns:
        List of measured elapsed nanoseconds for each measured iteration.
    """
    # 1. Warm-up (unmeasured)
    for _ in range(warmup):
        if setup_callable is not None:
            setup_callable()
        op_callable()

    # 2. Measured iterations
    samples_ns: List[int] = []
    for _ in range(iterations):
        if setup_callable is not None:
            setup_callable()
        t0 = time.perf_counter_ns()
        op_callable()
        t1 = time.perf_counter_ns()
        samples_ns.append(t1 - t0)

    return samples_ns


def generate_benchmark_payload(size_bytes: int, seed: Optional[int] = None) -> bytes:
    """Generate deterministic dummy payload bytes of exact specified size.
    
    Note: This is strictly for deterministic benchmark payload creation (e.g. plaintext
    input data) and MUST NOT be used for cryptographic key generation or RNG.
    """
    if seed is None:
        pattern = b"PQC-MIGRATION-BENCHMARK-PAYLOAD-BLOCK-0123456789ABCDEF"
    else:
        pattern = f"PQC-PAYLOAD-SEED-{seed}-BLOCK-0123456789ABCDEF".encode("utf-8")
    
    repeats = (size_bytes // len(pattern)) + 1
    return (pattern * repeats)[:size_bytes]


def sanitize_benchmark_record(record: Dict[str, Any]) -> Dict[str, Any]:
    """Verify and enforce that no private keys or secret material exist in benchmark output."""
    forbidden_keys = {
        "private_key", "secret", "aes_key", "shared_secret", "raw_key",
        "key_bytes", "private_bytes", "priv_key", "privkey"
    }
    for k in list(record.keys()):
        lower_k = k.lower()
        if any(bad in lower_k for bad in forbidden_keys):
            raise ValueError(f"Security violation: Secret field '{k}' detected in benchmark output!")
    return record
