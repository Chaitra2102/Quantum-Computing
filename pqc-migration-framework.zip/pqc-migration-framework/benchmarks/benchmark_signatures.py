"""Digital Signature Benchmarks.

Measures latency and statistical distributions for:
- Classical ECDSA P-384 (keygen, signing, verification)
- Post-Quantum Lattice ML-DSA-65 (keygen, signing, verification)
- Post-Quantum Hash-based SLH-DSA-SHAKE-128f (keygen, signing, verification)

Note on Provider Attribution:
- ECDSA and ML-DSA are provided by PyCA cryptography (C / Rust backend).
- SLH-DSA is provided by python slh-dsa (Pure Python backend).
Performance differences reflect BOTH algorithmic properties and backend implementation characteristics.
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional

from benchmarks.benchmark_utils import (
    benchmark_operation,
    calculate_statistics,
    generate_benchmark_payload,
)
from src.providers.classical.ecdsa_provider import ECDSAProvider
from src.providers.pqc.mldsa_provider import MLDSAProvider
from src.providers.pqc.slhdsa_provider import SLHDSAProvider


def run_signature_benchmarks(
    iterations: int = 100,
    warmup: int = 20,
    slhdsa_iterations: Optional[int] = None,
    slhdsa_warmup: Optional[int] = None,
    payload_sizes: Optional[List[int]] = None,
) -> Dict[str, Any]:
    """Execute full suite of digital signature benchmarks across all configurations.
    
    Args:
        iterations: Number of measured iterations for fast primitives.
        warmup: Warm-up iterations for fast primitives.
        slhdsa_iterations: Number of measured iterations for SLH-DSA (default: min(iterations, 20)).
        slhdsa_warmup: Warm-up iterations for SLH-DSA (default: min(warmup, 5)).
        payload_sizes: List of message payload sizes in bytes to evaluate (default: [64, 1024, 16384]).
    """
    if slhdsa_iterations is None:
        slhdsa_iterations = min(iterations, 20)
    if slhdsa_warmup is None:
        slhdsa_warmup = min(warmup, 5)
    if payload_sizes is None:
        payload_sizes = [64, 1024, 16384]

    results: Dict[str, Any] = {}
    raw_samples: Dict[str, List[int]] = {}

    ecdsa_prov = ECDSAProvider()
    mldsa_prov = MLDSAProvider(parameter_set="ML-DSA-65")
    slhdsa_prov = SLHDSAProvider(parameter_set="SLH-DSA-SHAKE-128f")

    # -------------------------------------------------------------
    # 1. Signature Key Generation
    # -------------------------------------------------------------
    # ECDSA P-384 Keygen
    samples = benchmark_operation(
        op_callable=lambda: ecdsa_prov.generate_keypair(),
        iterations=iterations,
        warmup=warmup,
    )
    raw_samples["ecdsa_p384_keygen"] = samples
    results["ecdsa_p384_keygen"] = {
        "operation": "key_generation",
        "algorithm": "ECDSA-P384",
        "configuration": "Mode A",
        "provider": "cryptography",
        "iterations": iterations,
        "warmup": warmup,
        **calculate_statistics(samples, unit="microseconds"),
    }

    # ML-DSA-65 Keygen
    samples = benchmark_operation(
        op_callable=lambda: mldsa_prov.generate_keypair(),
        iterations=iterations,
        warmup=warmup,
    )
    raw_samples["mldsa_65_keygen"] = samples
    results["mldsa_65_keygen"] = {
        "operation": "key_generation",
        "algorithm": "ML-DSA-65",
        "configuration": "Mode B",
        "provider": "cryptography",
        "iterations": iterations,
        "warmup": warmup,
        **calculate_statistics(samples, unit="microseconds"),
    }

    # SLH-DSA-SHAKE-128f Keygen
    samples = benchmark_operation(
        op_callable=lambda: slhdsa_prov.generate_keypair(),
        iterations=slhdsa_iterations,
        warmup=slhdsa_warmup,
    )
    raw_samples["slhdsa_shake_128f_keygen"] = samples
    results["slhdsa_shake_128f_keygen"] = {
        "operation": "key_generation",
        "algorithm": "SLH-DSA-SHAKE-128f",
        "configuration": "Mode C",
        "provider": "slh-dsa",
        "iterations": slhdsa_iterations,
        "warmup": slhdsa_warmup,
        **calculate_statistics(samples, unit="milliseconds"),
    }

    # -------------------------------------------------------------
    # 2. Signing and Verification across Payload Sizes
    # -------------------------------------------------------------
    # Pre-generate keypairs outside timed loop
    ecdsa_kp = ecdsa_prov.generate_keypair()
    mldsa_kp = mldsa_prov.generate_keypair()
    slhdsa_kp = slhdsa_prov.generate_keypair()

    for size in payload_sizes:
        payload = generate_benchmark_payload(size)
        size_label = f"{size}B" if size < 1024 else f"{size // 1024}KiB"

        # --- ECDSA P-384 ---
        sig_ecdsa = ecdsa_prov.sign(ecdsa_kp.private_key, payload)
        # Sign
        samples = benchmark_operation(
            op_callable=lambda: ecdsa_prov.sign(ecdsa_kp.private_key, payload),
            iterations=iterations,
            warmup=warmup,
        )
        op_key = f"ecdsa_p384_sign_{size_label}"
        raw_samples[op_key] = samples
        results[op_key] = {
            "operation": f"sign_{size_label}",
            "algorithm": "ECDSA-P384",
            "configuration": "Mode A",
            "provider": "cryptography",
            "payload_bytes": size,
            "iterations": iterations,
            "warmup": warmup,
            **calculate_statistics(samples, unit="microseconds"),
        }
        # Verify
        samples = benchmark_operation(
            op_callable=lambda: ecdsa_prov.verify(ecdsa_kp.public_key, payload, sig_ecdsa),
            iterations=iterations,
            warmup=warmup,
        )
        op_key = f"ecdsa_p384_verify_{size_label}"
        raw_samples[op_key] = samples
        results[op_key] = {
            "operation": f"verify_{size_label}",
            "algorithm": "ECDSA-P384",
            "configuration": "Mode A",
            "provider": "cryptography",
            "payload_bytes": size,
            "iterations": iterations,
            "warmup": warmup,
            **calculate_statistics(samples, unit="microseconds"),
        }

        # --- ML-DSA-65 ---
        sig_mldsa = mldsa_prov.sign(mldsa_kp.private_key, payload)
        # Sign
        samples = benchmark_operation(
            op_callable=lambda: mldsa_prov.sign(mldsa_kp.private_key, payload),
            iterations=iterations,
            warmup=warmup,
        )
        op_key = f"mldsa_65_sign_{size_label}"
        raw_samples[op_key] = samples
        results[op_key] = {
            "operation": f"sign_{size_label}",
            "algorithm": "ML-DSA-65",
            "configuration": "Mode B",
            "provider": "cryptography",
            "payload_bytes": size,
            "iterations": iterations,
            "warmup": warmup,
            **calculate_statistics(samples, unit="microseconds"),
        }
        # Verify
        samples = benchmark_operation(
            op_callable=lambda: mldsa_prov.verify(mldsa_kp.public_key, payload, sig_mldsa),
            iterations=iterations,
            warmup=warmup,
        )
        op_key = f"mldsa_65_verify_{size_label}"
        raw_samples[op_key] = samples
        results[op_key] = {
            "operation": f"verify_{size_label}",
            "algorithm": "ML-DSA-65",
            "configuration": "Mode B",
            "provider": "cryptography",
            "payload_bytes": size,
            "iterations": iterations,
            "warmup": warmup,
            **calculate_statistics(samples, unit="microseconds"),
        }

        # --- SLH-DSA-SHAKE-128f ---
        sig_slhdsa = slhdsa_prov.sign(slhdsa_kp.private_key, payload)
        # Sign
        samples = benchmark_operation(
            op_callable=lambda: slhdsa_prov.sign(slhdsa_kp.private_key, payload),
            iterations=slhdsa_iterations,
            warmup=slhdsa_warmup,
        )
        op_key = f"slhdsa_shake_128f_sign_{size_label}"
        raw_samples[op_key] = samples
        results[op_key] = {
            "operation": f"sign_{size_label}",
            "algorithm": "SLH-DSA-SHAKE-128f",
            "configuration": "Mode C",
            "provider": "slh-dsa",
            "payload_bytes": size,
            "iterations": slhdsa_iterations,
            "warmup": slhdsa_warmup,
            **calculate_statistics(samples, unit="milliseconds"),
        }
        # Verify
        samples = benchmark_operation(
            op_callable=lambda: slhdsa_prov.verify(slhdsa_kp.public_key, payload, sig_slhdsa),
            iterations=slhdsa_iterations,
            warmup=slhdsa_warmup,
        )
        op_key = f"slhdsa_shake_128f_verify_{size_label}"
        raw_samples[op_key] = samples
        results[op_key] = {
            "operation": f"verify_{size_label}",
            "algorithm": "SLH-DSA-SHAKE-128f",
            "configuration": "Mode C",
            "provider": "slh-dsa",
            "payload_bytes": size,
            "iterations": slhdsa_iterations,
            "warmup": slhdsa_warmup,
            **calculate_statistics(samples, unit="milliseconds"),
        }

    return {
        "summary": results,
        "raw_samples": raw_samples,
    }
