"""Communication and Cryptographic Artifact Size Benchmarking.

Quantifies the exact byte footprint of public keys, ciphertexts, signatures,
nonces, and complete wire representations across Modes A, B, C, and D variants.
Computes absolute and percentage communication overhead relative to Classical Mode A.
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional

from benchmarks.benchmark_utils import generate_benchmark_payload
from src.communication.secure_communicator import SecureCommunicator
from src.config.crypto_config import CryptoConfig, Mode, ModeFactory


def run_size_benchmarks(
    payload_size: int = 1024,
) -> Dict[str, Any]:
    """Measure exact sizes of cryptographic components and wire message representation.
    
    Args:
        payload_size: Message payload size in bytes (default: 1024 bytes / 1 KiB).
        
    Returns:
        Dictionary containing size breakdowns per configuration, summary table matrix,
        and relative overhead percentages against Classical Mode A.
    """
    configurations = [
        ("Mode A", "CLASSICAL_ECDH_ECDSA_AES256_GCM", ModeFactory.build(Mode.A)),
        ("Mode B", "PQC_MLKEM_MLDSA_AES256_GCM", ModeFactory.build(Mode.B)),
        ("Mode C", "PQC_MLKEM_SLHDSA_AES256_GCM", ModeFactory.build(Mode.C)),
        ("Mode D (ML-DSA)", "HYBRID_ECDH_MLKEM_MLDSA_AES256_GCM", ModeFactory.build(Mode.D, sig_provider_type="mldsa")),
        ("Mode D (SLH-DSA)", "HYBRID_ECDH_MLKEM_SLHDSA_AES256_GCM", ModeFactory.build(Mode.D, sig_provider_type="slhdsa")),
        ("Mode D (ECDSA)", "HYBRID_ECDH_MLKEM_ECDSA_AES256_GCM", ModeFactory.build(Mode.D, sig_provider_type="ecdsa")),
    ]

    plaintext = generate_benchmark_payload(payload_size)
    size_results: Dict[str, Any] = {}
    matrix_rows: List[Dict[str, Any]] = []

    for label, algo_id, config in configurations:
        comm = SecureCommunicator(config)
        # Receiver keypair
        receiver_kp = config.key_exchange.generate_keypair()
        
        # Perform send operation to construct SecureMessage
        _, msg = comm.send(plaintext, receiver_kp.public_key)
        
        ke_pk_len = len(msg.sender_ke_public_key)
        ke_ct_len = len(msg.ke_ciphertext) if msg.ke_ciphertext is not None else 0
        sig_pk_len = len(msg.sender_sig_public_key)
        sig_len = len(msg.signature)
        nonce_len = len(msg.nonce)
        ct_len = len(msg.ciphertext)
        
        # Raw crypto payload bytes (sum of cryptographic artifacts)
        raw_crypto_total = ke_pk_len + ke_ct_len + sig_pk_len + sig_len + nonce_len + ct_len
        # Wire representation size (JSON UTF-8)
        wire_json_bytes = len(msg.to_json().encode("utf-8"))

        entry = {
            "label": label,
            "algorithm_id": algo_id,
            "payload_bytes": payload_size,
            "ke_public_key_bytes": ke_pk_len,
            "ke_ciphertext_bytes": ke_ct_len,
            "sig_public_key_bytes": sig_pk_len,
            "signature_bytes": sig_len,
            "nonce_bytes": nonce_len,
            "ciphertext_bytes": ct_len,
            "raw_crypto_total_bytes": raw_crypto_total,
            "wire_json_total_bytes": wire_json_bytes,
        }
        size_results[label] = entry
        matrix_rows.append(entry)

    # -------------------------------------------------------------
    # Calculate Overhead Relative to Mode A
    # -------------------------------------------------------------
    mode_a_raw = size_results["Mode A"]["raw_crypto_total_bytes"]
    mode_a_wire = size_results["Mode A"]["wire_json_total_bytes"]

    overhead_analysis: Dict[str, Any] = {}
    for label, entry in size_results.items():
        raw_bytes = entry["raw_crypto_total_bytes"]
        wire_bytes = entry["wire_json_total_bytes"]

        abs_raw_diff = raw_bytes - mode_a_raw
        pct_raw_diff = round(((raw_bytes - mode_a_raw) / mode_a_raw) * 100.0, 2)

        abs_wire_diff = wire_bytes - mode_a_wire
        pct_wire_diff = round(((wire_bytes - mode_a_wire) / mode_a_wire) * 100.0, 2)

        overhead_analysis[label] = {
            "algorithm_id": entry["algorithm_id"],
            "raw_crypto_bytes": raw_bytes,
            "raw_overhead_bytes": abs_raw_diff,
            "raw_overhead_percent": pct_raw_diff,
            "wire_json_bytes": wire_bytes,
            "wire_overhead_bytes": abs_wire_diff,
            "wire_overhead_percent": pct_wire_diff,
        }

    # -------------------------------------------------------------
    # Hybrid Overhead Analysis:
    # 1. Mode D (ML-DSA) vs Mode A (Classical)
    # 2. Mode D (ML-DSA) vs Mode B (ML-KEM/ML-DSA PQC)
    # -------------------------------------------------------------
    hybrid_mldsa_wire = size_results["Mode D (ML-DSA)"]["wire_json_total_bytes"]
    mode_b_wire = size_results["Mode B"]["wire_json_total_bytes"]
    
    hybrid_comparisons = {
        "hybrid_mldsa_vs_classical_mode_a": {
            "baseline_mode": "Mode A",
            "baseline_wire_bytes": mode_a_wire,
            "hybrid_wire_bytes": hybrid_mldsa_wire,
            "absolute_diff_bytes": hybrid_mldsa_wire - mode_a_wire,
            "percentage_overhead": round(((hybrid_mldsa_wire - mode_a_wire) / mode_a_wire) * 100.0, 2),
        },
        "hybrid_mldsa_vs_pure_pqc_mode_b": {
            "baseline_mode": "Mode B",
            "baseline_wire_bytes": mode_b_wire,
            "hybrid_wire_bytes": hybrid_mldsa_wire,
            "absolute_diff_bytes": hybrid_mldsa_wire - mode_b_wire,
            "percentage_overhead": round(((hybrid_mldsa_wire - mode_b_wire) / mode_b_wire) * 100.0, 2),
            "explanation": "Overhead from dual ECDH P-384 public key (97B) and ephemeral ECDH ciphertext component (99B)",
        }
    }

    return {
        "matrix": matrix_rows,
        "overhead_relative_to_mode_a": overhead_analysis,
        "hybrid_comparisons": hybrid_comparisons,
    }
