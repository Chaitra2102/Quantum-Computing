"""End-to-End Secure Communication Pipeline Benchmarks.

Measures the complete transmission and reception latency across all supported modes:
- Mode A (Classical ECDH / ECDSA / AES-GCM)
- Mode B (PQC ML-KEM / ML-DSA / AES-GCM)
- Mode C (PQC ML-KEM / SLH-DSA / AES-GCM)
- Mode D + ML-DSA (Hybrid ECDH+ML-KEM / ML-DSA)
- Mode D + SLH-DSA (Hybrid ECDH+ML-KEM / SLH-DSA)
- Mode D + ECDSA (Hybrid ECDH+ML-KEM / ECDSA)
"""

from __future__ import annotations

import time
from typing import Any, Dict, List, Optional, Tuple

from benchmarks.benchmark_utils import (
    calculate_statistics,
    generate_benchmark_payload,
)
from src.communication.secure_communicator import SecureCommunicator
from src.config.crypto_config import CryptoConfig, Mode, ModeFactory


def benchmark_e2e_workflow(
    config: CryptoConfig,
    plaintext: bytes,
    iterations: int = 50,
    warmup: int = 10,
) -> Tuple[List[int], List[int], List[int]]:
    """Measure sender send(), receiver receive(), and total roundtrip nanoseconds.
    
    Returns:
        (send_samples_ns, receive_samples_ns, roundtrip_samples_ns)
    """
    comm = SecureCommunicator(config)
    receiver_kp = config.key_exchange.generate_keypair()

    # 1. Warm-up
    for _ in range(warmup):
        _, msg = comm.send(plaintext, receiver_kp.public_key)
        _ = comm.receive(msg, receiver_kp.private_key)

    # 2. Measured iterations
    send_samples: List[int] = []
    recv_samples: List[int] = []
    roundtrip_samples: List[int] = []

    for _ in range(iterations):
        # Time Send
        t0 = time.perf_counter_ns()
        _, msg = comm.send(plaintext, receiver_kp.public_key)
        t1 = time.perf_counter_ns()

        # Time Receive
        t2 = time.perf_counter_ns()
        _ = comm.receive(msg, receiver_kp.private_key)
        t3 = time.perf_counter_ns()

        send_ns = t1 - t0
        recv_ns = t3 - t2
        roundtrip_ns = send_ns + recv_ns

        send_samples.append(send_ns)
        recv_samples.append(recv_ns)
        roundtrip_samples.append(roundtrip_ns)

    return send_samples, recv_samples, roundtrip_samples


def run_end_to_end_benchmarks(
    iterations: int = 50,
    warmup: int = 10,
    slhdsa_iterations: Optional[int] = None,
    slhdsa_warmup: Optional[int] = None,
    payload_size: int = 1024,
) -> Dict[str, Any]:
    """Execute end-to-end communication benchmarks across all supported suites.
    
    Args:
        iterations: Iterations for fast modes (A, B, D-MLDSA, D-ECDSA).
        warmup: Warm-up iterations for fast modes.
        slhdsa_iterations: Iterations for hash-based signature modes (C, D-SLHDSA).
        slhdsa_warmup: Warm-up iterations for hash-based signature modes.
        payload_size: Plaintext payload size in bytes (default: 1024 / 1 KiB).
    """
    if slhdsa_iterations is None:
        slhdsa_iterations = min(iterations, 15)
    if slhdsa_warmup is None:
        slhdsa_warmup = min(warmup, 5)

    plaintext = generate_benchmark_payload(payload_size)

    configurations = [
        ("Mode A", "CLASSICAL_ECDH_ECDSA_AES256_GCM", ModeFactory.build(Mode.A), iterations, warmup, "microseconds"),
        ("Mode B", "PQC_MLKEM_MLDSA_AES256_GCM", ModeFactory.build(Mode.B), iterations, warmup, "microseconds"),
        ("Mode C", "PQC_MLKEM_SLHDSA_AES256_GCM", ModeFactory.build(Mode.C), slhdsa_iterations, slhdsa_warmup, "milliseconds"),
        ("Mode D (ML-DSA)", "HYBRID_ECDH_MLKEM_MLDSA_AES256_GCM", ModeFactory.build(Mode.D, sig_provider_type="mldsa"), iterations, warmup, "microseconds"),
        ("Mode D (SLH-DSA)", "HYBRID_ECDH_MLKEM_SLHDSA_AES256_GCM", ModeFactory.build(Mode.D, sig_provider_type="slhdsa"), slhdsa_iterations, slhdsa_warmup, "milliseconds"),
        ("Mode D (ECDSA)", "HYBRID_ECDH_MLKEM_ECDSA_AES256_GCM", ModeFactory.build(Mode.D, sig_provider_type="ecdsa"), iterations, warmup, "microseconds"),
    ]

    results: Dict[str, Any] = {}
    raw_samples: Dict[str, Any] = {}

    for label, algo_id, config, iters, wup, unit in configurations:
        send_ns, recv_ns, rtt_ns = benchmark_e2e_workflow(
            config=config,
            plaintext=plaintext,
            iterations=iters,
            warmup=wup,
        )

        raw_samples[f"{label}_send"] = send_ns
        raw_samples[f"{label}_receive"] = recv_ns
        raw_samples[f"{label}_roundtrip"] = rtt_ns

        send_stats = calculate_statistics(send_ns, unit=unit)
        recv_stats = calculate_statistics(recv_ns, unit=unit)
        rtt_stats = calculate_statistics(rtt_ns, unit=unit)

        results[label] = {
            "algorithm_id": algo_id,
            "payload_bytes": payload_size,
            "iterations": iters,
            "warmup": wup,
            "unit": unit,
            "send": send_stats,
            "receive": recv_stats,
            "roundtrip": rtt_stats,
        }

    return {
        "summary": results,
        "raw_samples": raw_samples,
    }
