"""Benchmarking framework for Post-Quantum Secure Communication & Migration Framework.

This package provides isolated, reproducible, provider-aware cryptographic
and communication overhead benchmarking across Classical (Mode A), PQC (Modes B & C),
and Hybrid (Mode D) configurations.
"""

__version__ = "0.1.0"
