"""Key Establishment & Key Generation Benchmarks.

Measures latency and statistical distributions for:
- Classical ECDH P-384 (keygen & derivation)
- Post-Quantum ML-KEM-768 (keygen, encapsulation, decapsulation)
- Hybrid ECDH P-384 + ML-KEM-768 (component breakdowns & complete dual establishment)
"""

from __future__ import annotations

from typing import Any, Dict, List

from benchmarks.benchmark_utils import benchmark_operation, calculate_statistics
from src.providers.classical.ecdh_provider import ECDHProvider
from src.providers.hybrid import HybridKEProvider, HybridSecretCombiner
from src.providers.pqc.mlkem_provider import MLKEMProvider


def run_kex_benchmarks(
    iterations: int = 100,
    warmup: int = 20
) -> Dict[str, Any]:
    """Execute full suite of key exchange and KEM benchmarks."""
    results: Dict[str, Any] = {}
    raw_samples: Dict[str, List[int]] = {}

    ecdh_prov = ECDHProvider()
    mlkem_prov = MLKEMProvider(parameter_set="ML-KEM-768")
    hybrid_prov = HybridKEProvider(kem_parameter_set="ML-KEM-768")
    combiner = HybridSecretCombiner()

    # -------------------------------------------------------------
    # 1. Key Generation
    # -------------------------------------------------------------
    # Mode A: ECDH P-384 Keygen
    samples = benchmark_operation(
        op_callable=lambda: ecdh_prov.generate_keypair(),
        iterations=iterations,
        warmup=warmup,
    )
    raw_samples["ecdh_p384_keygen"] = samples
    results["ecdh_p384_keygen"] = {
        "operation": "key_generation",
        "algorithm": "ECDH-P384",
        "configuration": "Mode A",
        "provider": "cryptography",
        "iterations": iterations,
        "warmup": warmup,
        **calculate_statistics(samples, unit="microseconds"),
    }

    # Mode B/C: ML-KEM-768 Keygen
    samples = benchmark_operation(
        op_callable=lambda: mlkem_prov.generate_keypair(),
        iterations=iterations,
        warmup=warmup,
    )
    raw_samples["mlkem_768_keygen"] = samples
    results["mlkem_768_keygen"] = {
        "operation": "key_generation",
        "algorithm": "ML-KEM-768",
        "configuration": "Mode B / C",
        "provider": "cryptography",
        "iterations": iterations,
        "warmup": warmup,
        **calculate_statistics(samples, unit="microseconds"),
    }

    # Mode D: Hybrid Keygen (Total)
    samples = benchmark_operation(
        op_callable=lambda: hybrid_prov.generate_keypair(),
        iterations=iterations,
        warmup=warmup,
    )
    raw_samples["hybrid_p384_mlkem768_keygen"] = samples
    results["hybrid_p384_mlkem768_keygen"] = {
        "operation": "key_generation",
        "algorithm": "ECDH-P384 + ML-KEM-768",
        "configuration": "Mode D",
        "provider": "cryptography (Hybrid Dual)",
        "iterations": iterations,
        "warmup": warmup,
        **calculate_statistics(samples, unit="microseconds"),
    }

    # -------------------------------------------------------------
    # 2. Key Establishment: Classical ECDH P-384
    # -------------------------------------------------------------
    alice_kp = ecdh_prov.generate_keypair()
    bob_kp = ecdh_prov.generate_keypair()

    samples = benchmark_operation(
        op_callable=lambda: ecdh_prov.exchange(alice_kp.private_key, bob_kp.public_key),
        iterations=iterations,
        warmup=warmup,
    )
    raw_samples["ecdh_p384_derivation"] = samples
    results["ecdh_p384_derivation"] = {
        "operation": "ecdh_derivation",
        "algorithm": "ECDH-P384",
        "configuration": "Mode A",
        "provider": "cryptography",
        "iterations": iterations,
        "warmup": warmup,
        **calculate_statistics(samples, unit="microseconds"),
    }

    # -------------------------------------------------------------
    # 3. Key Establishment: Post-Quantum ML-KEM-768
    # -------------------------------------------------------------
    kem_kp = mlkem_prov.generate_keypair()
    kem_ss, kem_ct = mlkem_prov.encapsulate(kem_kp.public_key)

    # ML-KEM Encapsulation
    samples = benchmark_operation(
        op_callable=lambda: mlkem_prov.encapsulate(kem_kp.public_key),
        iterations=iterations,
        warmup=warmup,
    )
    raw_samples["mlkem_768_encapsulate"] = samples
    results["mlkem_768_encapsulate"] = {
        "operation": "mlkem_encapsulate",
        "algorithm": "ML-KEM-768",
        "configuration": "Mode B / C",
        "provider": "cryptography",
        "iterations": iterations,
        "warmup": warmup,
        **calculate_statistics(samples, unit="microseconds"),
    }

    # ML-KEM Decapsulation
    samples = benchmark_operation(
        op_callable=lambda: mlkem_prov.decapsulate(kem_kp.private_key, kem_ct),
        iterations=iterations,
        warmup=warmup,
    )
    raw_samples["mlkem_768_decapsulate"] = samples
    results["mlkem_768_decapsulate"] = {
        "operation": "mlkem_decapsulate",
        "algorithm": "ML-KEM-768",
        "configuration": "Mode B / C",
        "provider": "cryptography",
        "iterations": iterations,
        "warmup": warmup,
        **calculate_statistics(samples, unit="microseconds"),
    }

    # -------------------------------------------------------------
    # 4. Key Establishment: Hybrid ECDH P-384 + ML-KEM-768
    # -------------------------------------------------------------
    # Prepare hybrid keypairs
    h_alice_kp = hybrid_prov.generate_keypair()
    h_ss_init, h_ct = hybrid_prov.encapsulate(h_alice_kp.public_key)

    # Component: Hybrid Combiner HKDF(ecdh_ss || mlkem_ss)
    dummy_ecdh_ss = b"\x01" * 48
    dummy_mlkem_ss = b"\x02" * 32
    samples = benchmark_operation(
        op_callable=lambda: combiner.combine(dummy_ecdh_ss, dummy_mlkem_ss),
        iterations=iterations,
        warmup=warmup,
    )
    raw_samples["hybrid_combiner_hkdf"] = samples
    results["hybrid_combiner_hkdf"] = {
        "operation": "hybrid_secret_combination",
        "algorithm": "HKDF-SHA-384(ECDH_ss || MLKEM_ss)",
        "configuration": "Mode D (Combiner)",
        "provider": "cryptography (HKDF)",
        "iterations": iterations,
        "warmup": warmup,
        **calculate_statistics(samples, unit="microseconds"),
    }

    # Complete Hybrid Initiator / Encapsulation (ECDH exchange + ML-KEM encapsulate + combine)
    samples = benchmark_operation(
        op_callable=lambda: hybrid_prov.encapsulate(h_alice_kp.public_key),
        iterations=iterations,
        warmup=warmup,
    )
    raw_samples["hybrid_complete_encapsulate"] = samples
    results["hybrid_complete_encapsulate"] = {
        "operation": "hybrid_encapsulate_total",
        "algorithm": "ECDH-P384 + ML-KEM-768",
        "configuration": "Mode D",
        "provider": "cryptography (Hybrid Dual)",
        "iterations": iterations,
        "warmup": warmup,
        **calculate_statistics(samples, unit="microseconds"),
    }

    # Complete Hybrid Responder / Decapsulation (ECDH exchange + ML-KEM decapsulate + combine)
    samples = benchmark_operation(
        op_callable=lambda: hybrid_prov.decapsulate(h_alice_kp.private_key, h_ct),
        iterations=iterations,
        warmup=warmup,
    )
    raw_samples["hybrid_complete_decapsulate"] = samples
    results["hybrid_complete_decapsulate"] = {
        "operation": "hybrid_decapsulate_total",
        "algorithm": "ECDH-P384 + ML-KEM-768",
        "configuration": "Mode D",
        "provider": "cryptography (Hybrid Dual)",
        "iterations": iterations,
        "warmup": warmup,
        **calculate_statistics(samples, unit="microseconds"),
    }

    return {
        "summary": results,
        "raw_samples": raw_samples,
    }
