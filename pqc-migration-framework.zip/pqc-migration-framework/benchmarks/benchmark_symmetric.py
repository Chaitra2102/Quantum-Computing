"""Symmetric Cryptography and Key Derivation Benchmarks.

Measures latency, statistical distributions, and throughput for:
- AES-256-GCM authenticated encryption and decryption (64 B, 1 KiB, 16 KiB, 1 MiB)
- HKDF-SHA-384 key derivation (standard extraction/expansion and hybrid concatenation combination)
"""

from __future__ import annotations

import os
from typing import Any, Dict, List, Optional

from benchmarks.benchmark_utils import (
    benchmark_operation,
    calculate_statistics,
    generate_benchmark_payload,
)
from src.providers.base import EncryptedPayload
from src.providers.symmetric.aesgcm_provider import AESGCM256Provider
from src.providers.symmetric.hkdf_provider import HKDFDerivationProvider


def run_symmetric_benchmarks(
    iterations: int = 100,
    warmup: int = 20,
    payload_sizes: Optional[List[int]] = None,
) -> Dict[str, Any]:
    """Execute AES-256-GCM and HKDF-SHA-384 performance benchmarks.
    
    Args:
        iterations: Number of measured iterations.
        warmup: Number of warm-up iterations.
        payload_sizes: Plaintext payload sizes in bytes (default: [64, 1024, 16384, 1048576]).
    """
    if payload_sizes is None:
        payload_sizes = [64, 1024, 16384, 1048576]

    results: Dict[str, Any] = {}
    raw_samples: Dict[str, List[int]] = {}

    aes_prov = AESGCM256Provider()
    hkdf_prov = HKDFDerivationProvider()

    # -------------------------------------------------------------
    # 1. AES-256-GCM Encryption & Decryption
    # -------------------------------------------------------------
    key = os.urandom(32)
    associated_data = b"benchmark-authenticated-data"

    for size in payload_sizes:
        plaintext = generate_benchmark_payload(size)
        size_label = (
            f"{size}B" if size < 1024 else
            f"{size // 1024}KiB" if size < 1048576 else
            f"{size // 1048576}MiB"
        )
        
        # Iteration count adjustment for large payload (1 MiB) to avoid excessively long test runs
        current_iters = min(iterations, 50) if size >= 1048576 else iterations
        current_warmup = min(warmup, 10) if size >= 1048576 else warmup

        # Encrypt
        samples_enc = benchmark_operation(
            op_callable=lambda: aes_prov.encrypt(key, plaintext, associated_data),
            iterations=current_iters,
            warmup=current_warmup,
        )
        op_enc_key = f"aes256_gcm_encrypt_{size_label}"
        raw_samples[op_enc_key] = samples_enc
        stats_enc = calculate_statistics(samples_enc, unit="microseconds")
        
        # Calculate throughput (MiB/s) based on mean latency
        mean_sec = (stats_enc["mean"] / 1_000_000.0) if stats_enc["mean"] > 0 else 1e-9
        throughput_mib_s = (size / (1024.0 * 1024.0)) / mean_sec
        throughput_mb_s = (size / 1_000_000.0) / mean_sec

        results[op_enc_key] = {
            "operation": f"aes_encrypt_{size_label}",
            "algorithm": "AES-256-GCM",
            "provider": "cryptography",
            "payload_bytes": size,
            "iterations": current_iters,
            "warmup": current_warmup,
            "throughput_mib_per_sec": round(throughput_mib_s, 2),
            "throughput_mb_per_sec": round(throughput_mb_s, 2),
            **stats_enc,
        }

        # Decrypt setup
        encrypted_payload: EncryptedPayload = aes_prov.encrypt(key, plaintext, associated_data)
        samples_dec = benchmark_operation(
            op_callable=lambda: aes_prov.decrypt(key, encrypted_payload, associated_data),
            iterations=current_iters,
            warmup=current_warmup,
        )
        op_dec_key = f"aes256_gcm_decrypt_{size_label}"
        raw_samples[op_dec_key] = samples_dec
        stats_dec = calculate_statistics(samples_dec, unit="microseconds")

        mean_dec_sec = (stats_dec["mean"] / 1_000_000.0) if stats_dec["mean"] > 0 else 1e-9
        throughput_dec_mib_s = (size / (1024.0 * 1024.0)) / mean_dec_sec
        throughput_dec_mb_s = (size / 1_000_000.0) / mean_dec_sec

        results[op_dec_key] = {
            "operation": f"aes_decrypt_{size_label}",
            "algorithm": "AES-256-GCM",
            "provider": "cryptography",
            "payload_bytes": size,
            "iterations": current_iters,
            "warmup": current_warmup,
            "throughput_mib_per_sec": round(throughput_dec_mib_s, 2),
            "throughput_mb_per_sec": round(throughput_dec_mb_s, 2),
            **stats_dec,
        }

    # -------------------------------------------------------------
    # 2. HKDF-SHA-384 Key Derivation
    # -------------------------------------------------------------
    ikm = os.urandom(48)
    salt = os.urandom(32)
    info = b"pqc-migration-session-key-v1"

    # Standard complete HKDF derivation (extract + expand)
    samples_hkdf = benchmark_operation(
        op_callable=lambda: hkdf_prov.derive(input_keying_material=ikm, length=32, salt=salt, info=info),
        iterations=iterations,
        warmup=warmup,
    )
    raw_samples["hkdf_sha384_derive_32b"] = samples_hkdf
    results["hkdf_sha384_derive_32b"] = {
        "operation": "hkdf_derive",
        "algorithm": "HKDF-SHA-384",
        "provider": "cryptography",
        "derived_length_bytes": 32,
        "iterations": iterations,
        "warmup": warmup,
        **calculate_statistics(samples_hkdf, unit="microseconds"),
    }

    # Project Hybrid Combination HKDF: (ECDH_ss [48B] || MLKEM_ss [32B]) -> 32B
    hybrid_ikm = os.urandom(48) + os.urandom(32)  # 80 bytes
    hybrid_salt = b"\x00" * 48
    hybrid_info = b"pqc-hybrid-ecdh-p384-mlkem768-v1"

    samples_hybrid_hkdf = benchmark_operation(
        op_callable=lambda: hkdf_prov.derive(input_keying_material=hybrid_ikm, length=32, salt=hybrid_salt, info=hybrid_info),
        iterations=iterations,
        warmup=warmup,
    )
    raw_samples["hkdf_sha384_hybrid_combiner"] = samples_hybrid_hkdf
    results["hkdf_sha384_hybrid_combiner"] = {
        "operation": "hkdf_hybrid_combiner",
        "algorithm": "HKDF-SHA-384(ECDH_ss || MLKEM_ss)",
        "provider": "cryptography",
        "derived_length_bytes": 32,
        "iterations": iterations,
        "warmup": warmup,
        **calculate_statistics(samples_hybrid_hkdf, unit="microseconds"),
    }

    return {
        "summary": results,
        "raw_samples": raw_samples,
    }
