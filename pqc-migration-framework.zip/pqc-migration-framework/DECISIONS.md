# DECISIONS.md
# Post-Quantum Secure Communication & Migration Framework
## Architectural Decision Log

**Version:** 0.3.0  
**Date:** 2026-09-28 (revised Phase 5)  
**Status:** Phase 5 — Multi-Provider PQC Architecture Adopted (AD-17)

> **Revision note (v0.3.0):** AD-17 added formally establishing multi-provider PQC architecture (`cryptography` 48.0.0 for ML-KEM and ML-DSA; `slh-dsa` 0.2.5 for SLH-DSA) following Phase 5 environment feasibility verification on Windows AMD64 / Python 3.14. AD-03 preserved historically. Methodological benchmarking constraints recorded.

---

> **Purpose:** This document is the authoritative record of all architectural decisions, both resolved and open. Every decision must be traceable to a requirement, environment finding, or literature source. New decisions added in later phases must include the phase in which they were made.

---

## RESOLVED DECISIONS

---

### AD-01 — Implementation Language: Python

**Phase Made:** 0  
**Status:** RESOLVED

**Context:**  
The project specification suggests Java + Spring Boot as a likely architecture but requires inspecting the environment first.

**Options Considered:**

| Option | Pros | Cons |
|--------|------|------|
| **Python** | Available (3.14.3); `cryptography` 48.0.0 already installed with ML-KEM + ML-DSA built-in; rich crypto ecosystem | Single-threaded GIL for benchmarks (manageable with `perf_counter`) |
| Java | Industry standard backend; Bouncy Castle has PQC support | Java not installed; requires JDK + Maven/Gradle install; adds complexity |
| Node.js | Available (v24.14.0) | Limited native PQC library support; `node-forge` lacks ML-KEM/ML-DSA |

**Decision:** **Python 3.14.3 (64-bit)**

**Rationale:**
- Python is already installed with the required version
- `cryptography` 48.0.0 is already installed and provides classical algorithms (ECDH, ECDSA) and symmetric primitives (AES-256-GCM, HKDF)
- `liboqs-python` is available on PyPI and provides all required PQC algorithms (ML-KEM, ML-DSA, SLH-DSA)
- Java is not on PATH; installing a JDK and build toolchain would add unnecessary setup risk
- Python's `cryptography` library is a vetted, widely used, production-grade library (PyCA project)
- All required algorithms are available via the two-library combination without any custom primitive implementation

**Requirement Satisfied:** FR-01 through FR-13; NFR-07 (no custom primitives)

---

### AD-02 — Classical and Symmetric Library: cryptography 48.0.0 (PyCA)

**Phase Made:** 0  
**Status:** RESOLVED (revised v0.2.0)

**Context:**  
The project requires ECDH, ECDSA, AES-256-GCM, and HKDF for the classical and symmetric layers.

**Options Considered:**

| Library | ECDH/ECDSA | AES-GCM | HKDF | ML-KEM | ML-DSA | Notes |
|---------|-----------|---------|------|--------|--------|-------|
| **cryptography 48.0.0** | ✅ | ✅ | ✅ | See note | See note | Already installed; OpenSSL-backed |
| pycryptodome | ✅ | ✅ | ✅ | ❌ | ❌ | No PQC support; not needed since cryptography is already present |

> **Note on cryptography 48 and PQC:** `cryptography` 48.0.0 exposes `mlkem` and `mldsa` submodules, but these require an OpenSSL build with the OpenSSL OQS Provider (or equivalent) to function. A standard Windows OpenSSL installation does not include this. Rather than depend on a custom OpenSSL build, all PQC algorithms are delegated to `liboqs-python` (see AD-03).

**Decision:** **`cryptography` 48.0.0 (PyCA) for classical algorithms and symmetric primitives only.**

| Scope | Algorithms |
|-------|------------|
| In scope | ECDH, ECDSA, AES-256-GCM, HKDF |
| Out of scope | ML-KEM, ML-DSA, SLH-DSA (all in liboqs-python via AD-03) |

**Rationale:**
- Already installed; no additional setup needed
- Production-grade, FIPS-validated OpenSSL/Rust bindings
- Well-proven for classical cryptography

**Requirement Satisfied:** FR-01 (ECDH/ECDSA keypairs); FR-03 (HKDF); FR-04, FR-05 (AES-256-GCM)

---

### AD-03 — PQC Library: liboqs-python (ALL PQC algorithms)

**Phase Made:** 0  
**Status:** RESOLVED (revised v0.2.0 to cover all PQC, not SLH-DSA only)

**Context:**  
All three PQC algorithm families required by this project (ML-KEM / FIPS 203, ML-DSA / FIPS 204, SLH-DSA / FIPS 205) must be sourced from a vetted library. The `cryptography` 48.0.0 OpenSSL PQC modules are not reliable on a standard Windows installation without a custom OpenSSL build.

**Options Considered:**

| Option | ML-KEM | ML-DSA | SLH-DSA | Platform Risk |
|--------|--------|--------|---------|---------------|
| **liboqs-python 0.16.x** | ✅ | ✅ | ✅ | Low — ships pre-built wheels for Windows |
| cryptography 48 (PQC modules) | Maybe | Maybe | ❌ | High — requires custom OpenSSL build with OQS Provider |
| oqs 0.10.x | ✅ | ✅ | ✅ | Medium — older liboqs binding, less maintained |

**Decision:** **`liboqs-python` 0.16.x for ALL PQC algorithms (ML-KEM, ML-DSA, SLH-DSA).**

| Algorithm | NIST Standard | liboqs mechanism example |
|-----------|--------------|-------------------------|
| ML-KEM | FIPS 203 | `ML-KEM-768` |
| ML-DSA | FIPS 204 | `ML-DSA-65` |
| SLH-DSA | FIPS 205 | `SPHINCS+-SHAKE-128s` (see AD-16 for naming) |

**Rationale:**
- Single, consistent PQC library source — reduces integration complexity
- Pre-built Windows wheels available (no cmake/MSVC build required for standard install)
- Open Quantum Safe project is a recognized, vetted research-grade PQC implementation
- Covers all three required PQC algorithm families
- Avoids dependency on a non-standard OpenSSL build

**Risk:** liboqs-python's pre-built wheels must be available for Python 3.14 on Windows 64-bit. If a pre-built wheel is unavailable, the install requires a CMake + MSVC toolchain build. This must be verified and documented in Phase 1. If installation fails, the fallback is to evaluate `oqs` 0.10.x.

**Requirement Satisfied:** FR-01, FR-02, FR-06, FR-07 (for all PQC modes)

---

### AD-04 — Architecture Pattern: Provider / Strategy Pattern

**Phase Made:** 0  
**Status:** RESOLVED

**Context:**  
The specification requires crypto-agility (FR-10): the ability to switch cryptographic algorithms without rewriting communication logic.

**Options Considered:**

| Pattern | Description |
|---------|-------------|
| **Provider / Strategy** | Abstract base classes; concrete implementations injected via configuration |
| Factory only | Central factory creates algorithm objects; no interface enforcement |
| Inheritance hierarchy | `CommunicationSession` subclasses per mode |
| Plugin system | Dynamic loading of algorithm modules |

**Decision:** **Abstract Base Class (ABC) + Strategy Pattern + Factory**

**Rationale:**
- Strategy pattern cleanly separates algorithm selection from usage
- ABC enforces interface contracts at definition time (Python `abc.ABC`)
- Factory (`ModeFactory`) provides a single point of configuration
- This is the simplest correct implementation of crypto-agility
- No algorithm-specific code in `SecureCommunicator` (satisfies NFR-10)

**Requirement Satisfied:** FR-10; NFR-03; NFR-04; RQ6

---

### AD-05 — Symmetric Encryption: AES-256-GCM

**Phase Made:** 0  
**Status:** RESOLVED

**Context:**  
The specification mandates AES-256 for bulk encryption. The authenticated mode must be selected.

**Decision:** **AES-256-GCM** (Galois/Counter Mode with 256-bit key)

**Rationale:**
- Provides authenticated encryption (confidentiality + integrity in one primitive)
- Eliminates the need for a separate MAC
- NIST standardized; widely accepted
- Available in `cryptography.hazmat.primitives.ciphers.aead.AESGCM`
- 256-bit key is quantum-resistant under Grover's algorithm (128-bit effective security)

**Requirement Satisfied:** FR-04, FR-05; NFR-07

---

### AD-06 — Key Derivation: HKDF

**Phase Made:** 0  
**Status:** RESOLVED

**Context:**  
Shared secrets from ECDH, ML-KEM, and hybrid combinations may not have uniform entropy suitable for direct use as an AES key.

**Decision:** **HKDF-SHA-256 or HKDF-SHA-384** (exact hash to be resolved in Phase 1 based on matching security levels)

**Rationale:**
- HKDF (RFC 5869) is the standard mechanism for key derivation from shared secrets
- Available in `cryptography.hazmat.primitives.kdf.hkdf.HKDF`
- For hybrid mode: both shared secrets (ECDH secret || ML-KEM secret) will be fed as IKM to HKDF

**Open sub-decision:** SHA-256 vs SHA-384 — depends on security level of chosen parameter sets (see AD-09)

**Requirement Satisfied:** FR-03; NFR-07

---

### AD-07 — No Java Backend

**Phase Made:** 0  
**Status:** RESOLVED

**Context:**  
Project specification suggested Java + Spring Boot as a likely architecture.

**Decision:** **Java is NOT used.** Python is the sole backend language.

**Rationale:** Java is not installed on the system PATH. No JDK, no Maven, no Gradle. Installing these would add significant setup risk and delay with no benefit given that Python already provides all required functionality.

**Requirement Satisfied:** Pragmatic environment constraint

---

### AD-08 — Test Framework: pytest

**Phase Made:** 0  
**Status:** RESOLVED

**Context:**  
A testing framework is required for unit and integration tests (NFR-05).

**Decision:** **pytest** (latest stable version)

**Rationale:**
- De facto standard Python testing framework
- Excellent fixture and parametrize support for benchmarks
- Compatible with Python 3.14
- No other testing framework was installed or required

**Requirement Satisfied:** NFR-05

---

## OPEN / DEFERRED DECISIONS

---

### AD-09 — ECDH/ECDSA Curve: P-256 vs P-384

**Phase to Resolve:** Phase 1  
**Status:** OPEN

**Context:**  
The specification requires ECDH for classical key establishment and ECDSA for classical signatures. The choice of curve affects security level and sizes.

**Options:**
- **NIST P-256** (secp256r1): 128-bit classical security; smaller keys; most common
- **NIST P-384** (secp384r1): 192-bit classical security; larger keys; matches ML-KEM-1024 security level better

**Considerations:**
- Security level matching: if ML-KEM-768 (~128-bit PQC security) is used, P-256 matches; if ML-KEM-1024 (~256-bit), P-384 matches
- This decision is coupled to AD-10 (ML-KEM parameter set)

**Decision Criteria:** Choose the curve that matches the security level of the selected ML-KEM parameter set, for consistency across the comparison.

---

### AD-10 — ML-KEM Parameter Set: ML-KEM-768 (Primary) and ML-KEM-1024 (Supported)

**Phase Made:** 3  
**Status:** RESOLVED

**Context:**  
NIST FIPS 203 specifies three ML-KEM parameter sets:
- ML-KEM-512: NIST Security Category 1 (~128 bits)
- ML-KEM-768: NIST Security Category 3 (~192 bits)
- ML-KEM-1024: NIST Security Category 5 (~256 bits)

**Decision:** **ML-KEM-768 is selected as the default/primary parameter set**, with **ML-KEM-1024 fully supported**.

| Parameter Set | Public Key | Ciphertext | Shared Secret | Classical Match | NIST Category |
|---------------|------------|------------|---------------|-----------------|---------------|
| **ML-KEM-768** (default) | 1,184 B | 1,088 B | 32 B | ECDH P-384 / AES-256 | Category 3 (192-bit) |
| **ML-KEM-1024** | 1,568 B | 1,568 B | 32 B | High security | Category 5 (256-bit) |

**Rationale:**
- ML-KEM-768 aligns precisely with the 192-bit classical baseline security level of ECDH P-384 and HKDF-SHA-384 (AD-09).
- Standard FIPS 203 implementation via `cryptography.hazmat.primitives.asymmetric.mlkem` provides robust, audited Rust bindings.
- ML-KEM-1024 is available for high-security comparisons in benchmarking phases.

**Requirement Satisfied:** FR-01, FR-02; NFR-07 (NIST FIPS 203 compliance)

---

### AD-11 — ML-DSA Parameter Set: ML-DSA-65 (Primary) and ML-DSA-44/87 (Supported)

**Phase Made:** 4  
**Status:** RESOLVED

**Context:**  
NIST FIPS 204 defines three ML-DSA parameter sets:
- ML-DSA-44: NIST Security Category 2 (128-bit)
- ML-DSA-65: NIST Security Category 3 (192-bit)
- ML-DSA-87: NIST Security Category 5 (256-bit)

**Decision:** **ML-DSA-65 is selected as the default/primary parameter set**, with **ML-DSA-44 and ML-DSA-87 fully supported**.

| Parameter Set | Public Key | Signature Size | Classical Match | NIST Category |
|---------------|------------|----------------|-----------------|---------------|
| **ML-DSA-65** (default) | 1,952 B | 3,309 B | ECDSA P-384 / ML-KEM-768 | Category 3 (192-bit) |
| **ML-DSA-44** | 1,312 B | 2,420 B | ECDSA P-256 | Category 2 (128-bit) |
| **ML-DSA-87** | 2,592 B | 4,627 B | High security | Category 5 (256-bit) |

**Rationale:**
- ML-DSA-65 matches the 192-bit security level of ECDSA P-384 (AD-09), ML-KEM-768 (AD-10), and AES-256-GCM.
- Consistent security level across all cryptographic primitives in Mode B (Full PQC).
- Standard FIPS 204 implementation via `cryptography.hazmat.primitives.asymmetric.mldsa` provides audited, production-grade Rust bindings.

**Requirement Satisfied:** FR-01, FR-06, FR-07; NFR-07 (NIST FIPS 204 compliance)

---

### AD-12 — SLH-DSA Variant

**Phase Made:** Phase 5  
**Status:** RESOLVED

**Context:**  
NIST FIPS 205 defines Stateless Hash-Based Digital Signature Algorithm (SLH-DSA), the standardized successor to SPHINCS+. The project requires a stateless hash-based signature provider for Mode C comparison.

**Selected Parameter Set:**
- **Primary / Default:** `SLH-DSA-SHAKE-128f` (NIST Security Category 1, SHAKE hash, fast signing)
- **Secondary / Supported Variants:** `SLH-DSA-SHAKE-128s` (small signature variant), `SLH-DSA-SHA2-128f` (SHA2 variant), `SLH-DSA-SHAKE-192f` (Category 3), and SPHINCS+ legacy alias strings.

**Rationale:**
- `SLH-DSA-SHAKE-128f` provides fast signing latency (~150 ms) compared to small variants (`128s` at ~3.4s) while maintaining standard NIST Category 1 security.
- Public key size is compact (32 bytes); signature size is 17,088 bytes.
- Standard FIPS 205 implementation provided via the audited `slh-dsa` package (v0.2.5) with accelerated C-extension backend on Windows AMD64.
- Agility allows switching between variants (e.g., `128s` for bandwidth-constrained, `128f` for latency-sensitive applications) without code changes.

**Requirement Satisfied:** FR-01, FR-06, FR-07; NFR-07 (NIST FIPS 205 compliance)

---

### AD-13 — Hybrid Signature Strategy for Mode D & Canonical Composite Suite Identifiers

**Phase Made:** Phase 7 (Corrective Patch)  
**Status:** RESOLVED

**Context:**  
Mode D provides Hybrid Key Establishment (ECDH P-384 + ML-KEM-768). The digital signature provider in Mode D must be configurable to support varied migration stages, and each configuration must be explicitly and unambiguously bound to its cryptographic suite metadata (`algorithm_id`).

**Decision:**
- **Default / Primary:** `ML-DSA-65` (NIST FIPS 204, 192-bit security matching P-384 and ML-KEM-768) $\rightarrow$ Suite ID: `HYBRID_ECDH_MLKEM_MLDSA_AES256_GCM`.
- **Supported Alternative Strategies:**
  1. `SLH-DSA-SHAKE-128f` (`sig_provider_type="slhdsa"`) $\rightarrow$ Suite ID: `HYBRID_ECDH_MLKEM_SLHDSA_AES256_GCM`.
  2. `ECDSA P-384` (`sig_provider_type="ecdsa"`) $\rightarrow$ Suite ID: `HYBRID_ECDH_MLKEM_ECDSA_AES256_GCM`.
- **Construction & Binding:** `ModeFactory.build(Mode.D, sig_provider_type=...)` dynamically binds the selected signature provider and sets the exact composite suite ID. `CryptoConfig` strictly validates that the signature provider type matches the suite ID, rejecting mismatches with `ConfigurationError`.
- **Backward Compatibility:** `HYBRID_ECDH_MLKEM_AES256_GCM` is retained as an alias for `HYBRID_ECDH_MLKEM_MLDSA_AES256_GCM`.

**Requirement Satisfied:** FR-08, FR-10; Crypto-Agility Architecture; Downgrade & Cross-Mode Protection.

---

### AD-14 — Benchmark Iteration Count (N)

**Phase to Resolve:** Phase 10  
**Status:** OPEN

**Context:**  
The specification requires repeated measurements. The minimum N must be determined empirically.

**Proposed approach:** Run a pilot with N=20; measure coefficient of variation (CV). If CV > 10%, increase N. Target CV < 5%.

**Minimum lower bound:** N = 100 (as specified in EXPERIMENT_PLAN.md)

---

### AD-15 — Frontend Scope

**Phase to Resolve:** Phase 13 planning (before Phase 11 ends)  
**Status:** OPEN

**Context:**  
The specification allows "simple web frontend or React, depending on environment." Node.js 24.14.0 is available.

**Options:**
1. No frontend — CLI + result files only
2. Simple HTML/JS frontend served by a Python HTTP server
3. React (Vite) frontend with REST API (FastAPI)

**Decision Criteria:** Based on project scope and whether a visual demonstration is required for the final deliverable.

---

## Decision Dependency Map

```
AD-09 (curve) ←→ AD-10 (ML-KEM params)
                      ↓
              AD-11 (ML-DSA params) ←→ AD-12 (SLH-DSA variant)
                                              ↓
                                    AD-06 (HKDF hash choice)
AD-13 (hybrid sig) depends on → AD-09, AD-11
AD-14 (benchmark N) depends on → Phase 10 pilot results
AD-15 (frontend) depends on → project scope/audience decision
AD-16 (SPHINCS+/SLH-DSA naming) → resolved in Phase 1 verification
```

---

### AD-17 — Multi-Provider PQC Architecture

**Phase Made:** Phase 5  
**Status:** RESOLVED (supersedes AD-03 for active runtime implementation)

**Context:**  
Phase 0 originally specified `liboqs-python` / `liboqs` as the single PQC library for all post-quantum algorithms (AD-03). During Phase 1 and Phase 5 environment feasibility audits on the target system (Windows AMD64, Python 3.14.3), the following technical constraints were established:
1. `liboqs-python` (0.16.0.1) is a pure-Python wrapper that does not bundle pre-compiled native `oqs.dll` binaries for Python 3.14 on Windows AMD64.
2. Attempting to import `oqs` triggers dynamic compilation routines requiring MSVC/C compiler toolchains that are not present on the system `PATH`.
3. PyCA `cryptography` (48.0.0) ships production-grade, pre-compiled Rust/OpenSSL bindings that natively support NIST FIPS 203 (**ML-KEM**) and NIST FIPS 204 (**ML-DSA**).
4. PyCA `cryptography` does not yet implement NIST FIPS 205 (**SLH-DSA**).
5. The `slh-dsa` package (v0.2.5) provides an audited, FIPS 205 compliant implementation with pre-compiled native C-extension wheels for Windows AMD64 on Python 3.14.

**Decision:** **Adopt a Multi-Provider PQC Architecture across standardized providers.**

**Final Provider Mapping:**

| Cryptographic Primitive | NIST Standard / Profile | Provider Package | Exact Module / Backend |
|---|---|---|---|
| **ECDH Key Exchange** | NIST P-384 (Classical) | `cryptography` 48.0.0 | `hazmat.primitives.asymmetric.ec` |
| **ECDSA Signature** | NIST P-384 / SHA-384 | `cryptography` 48.0.0 | `hazmat.primitives.asymmetric.ec` |
| **HKDF Key Derivation** | HKDF-SHA-384 (RFC 5869) | `cryptography` 48.0.0 | `hazmat.primitives.kdf.hkdf` |
| **AES-GCM Encryption** | AES-256-GCM (NIST SP 800-38D) | `cryptography` 48.0.0 | `hazmat.primitives.ciphers.aead.AESGCM` |
| **ML-KEM Key Encapsulation** | FIPS 203 (ML-KEM-768 / 1024) | `cryptography` 48.0.0 | `hazmat.primitives.asymmetric.mlkem` (Rust backend) |
| **ML-DSA Digital Signature** | FIPS 204 (ML-DSA-65 / 44 / 87) | `cryptography` 48.0.0 | `hazmat.primitives.asymmetric.mldsa` (Rust backend) |
| **SLH-DSA Digital Signature** | FIPS 205 (SLH-DSA-SHAKE-128f / 128s / 192f) | `slh-dsa` 0.2.5 | `slhdsa` (C-extension backend) |

**Architectural Rationale:**
- **Standardized Implementations:** All selected providers strictly implement the final ratified NIST FIPS standards (FIPS 203, FIPS 204, FIPS 205).
- **Zero Compilation Overhead / Reproducibility:** All components execute directly in standard Python 3.14 environments on Windows without requiring manual C++ build toolchains.
- **Provider Abstraction Integrity:** High-level orchestrators (`SecureCommunicator`, `ModeFactory`, `MigrationManager`) interact purely with the abstract `KeyExchangeProvider` and `SignatureProvider` interfaces; no code outside the provider module is aware of the underlying package split.
- **Experimental Completeness:** Enables full, verified execution of Modes A, B, and C with 100% test coverage.

**Important Methodological Limitation (Benchmarking in Phase 10 / Phase 11):**
Because the PQC algorithms are sourced from different underlying software packages (`cryptography` for ML-KEM/ML-DSA vs. `slhdsa` for SLH-DSA):
- Observed performance differences (e.g. execution latencies, CPU utilization) will reflect both **intrinsic algorithmic properties** AND **software/provider implementation characteristics** (e.g., Rust vs. C-extension optimizations, runtime binding overheads).
- The experiment must **NOT** attribute observed timing disparities exclusively to the cryptographic algorithm mathematics without explicit qualification.

**Requirement Satisfied:** FR-01 through FR-13; NFR-07; Crypto-Agility Architecture.

---

*End of DECISIONS.md — Phase 5 Formal Amendment | Version 0.3.0*

