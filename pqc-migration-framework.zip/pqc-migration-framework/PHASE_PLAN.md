# PHASE_PLAN.md
# Post-Quantum Secure Communication & Migration Framework
## Phase-by-Phase Implementation Roadmap

**Version:** 0.2.0  
**Date:** 2026-09-15 (revised 2026-09-15)  
**Current Phase:** Phase 0 — Specification (ACTIVE)

> **Revision note (v0.2.0):** Phase ordering completely revised from 6 to 14 phases. Library dependencies corrected: `cryptography` for classical/symmetric only; `liboqs-python` for all PQC. Phase 1 now requires explicit functional verification of all library dependencies before any implementation begins.

---

## Phase Boundary Rules

- A phase MUST NOT begin until its predecessor's acceptance criteria are met.
- No benchmark results may be fabricated at any phase.
- No cryptographic primitives may be implemented from scratch at any phase.
- All cryptographic operations must use vetted library APIs throughout.
- Architecture decisions from Phase 0 must not be silently changed in later phases; record changes in DECISIONS.md.
- Library assignments are fixed: `cryptography` for classical/symmetric; `liboqs-python` for all PQC.

---

## Phase 0 — Project Specification and Architectural Freeze

**Status:** ACTIVE (being revised to v0.2.0)

**Goal:** Understand the project domain, inspect the environment, and produce the complete specification and architecture as the source of truth for all future phases.

**Tasks:**
- [x] Read and understand the literature review
- [x] Inspect the development environment
- [x] Identify available cryptographic libraries
- [x] Create PROJECT_SPEC.md
- [x] Create ARCHITECTURE.md
- [x] Create EXPERIMENT_PLAN.md
- [x] Create PHASE_PLAN.md
- [x] Create DECISIONS.md
- [x] Create README.md
- [x] Revise all documents to v0.2.0 (corrected library architecture)

**Acceptance Criteria:**
- [ ] All six documents exist and are complete at v0.2.0
- [ ] Research objective is clearly defined
- [ ] Classical/PQC/Hybrid modes are defined
- [ ] Cryptographic components are defined with correct library assignments
- [ ] Functional requirements are defined
- [ ] Benchmark metrics are defined
- [ ] Migration experiment is defined
- [ ] Crypto-agility requirement is defined
- [ ] Limitations are explicitly documented
- [ ] SPHINCS+/SLH-DSA distinction is documented
- [ ] No cryptographic implementation has been added
- [ ] No benchmark numbers have been fabricated
- [ ] Future phases are clearly separated in a 14-phase plan
- [ ] All decisions are traceable to requirements

**Deliverables:** PROJECT_SPEC.md, ARCHITECTURE.md, EXPERIMENT_PLAN.md, PHASE_PLAN.md, DECISIONS.md, README.md (all at v0.2.0)

---

## Phase 1 — Environment Verification and Project Foundation

**Status:** IN PROGRESS — Sections 1.1–1.4 (Verification) COMPLETE; Sections 1.5–1.6 pending

**Goal:** Verify that the complete development environment actually works end-to-end — not just that packages are installed, but that each required operation can be executed. Then scaffold the project structure and crypto-agility infrastructure.

**Dependencies:** Phase 0 complete and approved

> **Verification result (2026-09-15):** All environment checks PASSED. Python 3.14 + `cryptography` (ECDH/ECDSA/AES-GCM/HKDF) + `liboqs-python` (ML-KEM/ML-DSA/SLH-DSA) + `pytest` all confirmed working.

### 1.1 Python Environment Verification

Run the following checks and confirm each passes:

- [x] `python --version` returns Python 3.14.x
- [x] Python can import `cryptography` without errors
- [x] `cryptography.__version__` returns 48.x.x

### 1.2 Classical Library Verification (cryptography)

Run and confirm each of the following actually executes without error:

- [x] `from cryptography.hazmat.primitives.asymmetric import ec` — ECDH/ECDSA module imports
- [x] Generate an EC key pair (P-256 or P-384) — operation succeeds, key object returned
- [x] Perform ECDH exchange between two generated key pairs — shared secret returned
- [x] Sign a test message with ECDSA — signature bytes returned
- [x] Verify the ECDSA signature — verification succeeds
- [x] `from cryptography.hazmat.primitives.ciphers.aead import AESGCM` — AES-GCM imports
- [x] Encrypt and decrypt a test message with AES-256-GCM — roundtrip succeeds
- [x] `from cryptography.hazmat.primitives.kdf.hkdf import HKDF` — HKDF imports
- [x] Derive a 32-byte key from test material via HKDF — key bytes returned

### 1.3 PQC Library Installation and Verification (liboqs-python)

- [x] Install `liboqs-python` 0.16.x: `pip install liboqs-python`
- [x] `import oqs` succeeds without errors
- [x] `oqs.__version__` returns a version string
- [x] **ML-KEM available:** `oqs.KeyEncapsulation('ML-KEM-768')` or equivalent constructs without error
  - Generate a key pair — public key bytes returned
  - Encapsulate using public key — (ciphertext, shared_secret) returned
  - Decapsulate using private key — shared_secret matches
- [x] **ML-DSA available:** `oqs.Signature('ML-DSA-65')` or equivalent constructs without error
  - Generate a key pair — public key bytes returned
  - Sign a test message — signature bytes returned
  - Verify the signature — verification succeeds
- [x] **SLH-DSA available:** Construct an SLH-DSA signature object (variant TBD, e.g., `SPHINCS+-SHAKE-128s` or `SLH-DSA-SHAKE-128s`) without error
  - Generate a key pair — public key bytes returned
  - Sign a test message — signature bytes returned
  - Verify the signature — verification succeeds

> **Note on SLH-DSA naming in liboqs:** The liboqs library may expose SLH-DSA using its SPHINCS+ internal names (e.g., `SPHINCS+-SHAKE-128s` or `SLH-DSA-SHAKE-128s`). Document the exact mechanism name used in DECISIONS.md. This does NOT mean implementing the pre-standardization SPHINCS+ — it is the same algorithm, accessed via the liboqs mechanism name.

### 1.4 Test Framework Verification

- [x] Install pytest: `pip install pytest`
- [x] `pytest --version` returns a version string
- [x] Write and run a trivial pytest test — passes

### 1.5 Project Structure Scaffold

- [ ] Create directory structure from ARCHITECTURE.md Section 7
- [ ] Create `pyproject.toml` with project metadata
- [ ] Create `requirements.txt` with pinned versions of all verified packages
- [ ] Create `src/__init__.py` and all package `__init__.py` files

### 1.6 Crypto-Agility Infrastructure (Interfaces Only)

- [ ] Define abstract base classes: `KeyExchangeProvider`, `SignatureProvider`, `EncryptionProvider`, `KeyDerivationProvider`
- [ ] Implement `Mode` enum (A, B, C, D)
- [ ] Implement `CryptoConfig` dataclass
- [ ] Implement skeleton `ModeFactory` (raises `NotImplementedError` for unimplemented modes)
- [ ] Write unit tests that import and instantiate the config layer without error

**Acceptance Criteria:**
- All 1.1–1.4 verification checks pass (confirmed by execution, not assumption)
- Environment verification results documented in `docs/ENVIRONMENT.md`
- Project structure exists on disk
- Abstract base classes defined
- `requirements.txt` pinned and reproducible
- NO cryptographic provider implementations yet (those come in Phases 2–7)

**Deliverables:** Verified environment report + project scaffold + interface definitions

---

## Phase 2 — Classical Baseline Implementation (Mode A)

**Status:** NOT STARTED

**Goal:** Implement all classical cryptographic providers (ECDH, ECDSA, AES-256-GCM, HKDF) and verify correct operation with unit tests.

**Dependencies:** Phase 1 complete and approved; library verification passed

**Tasks:**
- [ ] Implement `ECDHProvider` using `cryptography.hazmat.primitives.asymmetric.ec`
  - Decide NIST P-256 vs P-384 (record in DECISIONS.md)
- [ ] Implement `ECDSAProvider` using `cryptography`
- [ ] Implement `AESGCM256Provider` using `cryptography`
- [ ] Implement `HKDFDerivationProvider` using `cryptography`
- [ ] Update `ModeFactory` to build a valid `CryptoConfig` for Mode A
- [ ] Write unit tests for each provider
- [ ] All unit tests pass

**Acceptance Criteria:**
- All four classical providers implemented, tested, and passing
- Providers conform to abstract base class interfaces from Phase 1
- No algorithm-specific code outside provider classes
- `ModeFactory.build(Mode.A)` returns a valid config

**Deliverables:** Classical provider implementations + unit tests

---

## Phase 3 — ML-KEM Implementation

**Status:** COMPLETE (2026-09-28)

**Goal:** Implement the ML-KEM key encapsulation provider using FIPS 203 standardized primitives. Verify correct key generation, encapsulation, and decapsulation.

**Dependencies:** Phase 1 complete; parameter set decision resolved (AD-10)

**Tasks:**
- [x] Select ML-KEM parameter set (ML-KEM-768 default, ML-KEM-1024 supported); record in DECISIONS.md (AD-10)
- [x] Implement `MLKEMProvider` conforming to `KeyExchangeProvider`
  - `generate_keypair()` → KeyPair(private_key, public_key)
  - `encapsulate(public_key)` → (shared_secret, ciphertext)
  - `decapsulate(private_key, ciphertext)` → shared_secret
  - `export_public_key_bytes(public_key)` → raw bytes
  - `import_public_key_bytes(raw_bytes)` → MLKEMPublicKey
- [x] Verify encapsulate/decapsulate shared secrets are byte-for-byte identical
- [x] Write comprehensive unit tests (`tests/unit/pqc/test_mlkem.py`: 33 tests)
- [x] Measure and record key/ciphertext sizes (ML-KEM-768: pk=1184 B, ct=1088 B, ss=32 B; ML-KEM-1024: pk=1568 B, ct=1568 B, ss=32 B)
- [x] Write integration and security tests (`tests/integration/test_pqc_mlkem_workflow.py`, `tests/security/test_pqc_tampering.py`)
- [x] Document implementation report in `docs/MLKEM_IMPLEMENTATION.md`

**Acceptance Criteria:**
- [x] `MLKEMProvider` implemented and all unit tests pass (33/33 unit, 193/193 suite)
- [x] Encapsulated and decapsulated shared secrets are byte-for-byte identical
- [x] Provider conforms to `KeyExchangeProvider` abstract interface

**Deliverables:** `MLKEMProvider` + unit/integration/security tests + `docs/MLKEM_IMPLEMENTATION.md`

---

## Phase 4 — ML-DSA Implementation

**Status:** COMPLETE (2026-09-28)

**Goal:** Implement the ML-DSA digital signature provider using FIPS 204 standardized primitives. Verify key generation, signing, and verification.

**Dependencies:** Phase 1 complete; parameter set decision resolved (AD-11)

**Tasks:**
- [x] Select ML-DSA parameter set (ML-DSA-65 primary, ML-DSA-44/87 supported); record in DECISIONS.md (AD-11)
- [x] Implement `MLDSAProvider` conforming to `SignatureProvider`
  - `generate_keypair()` → KeyPair(private_key, public_key)
  - `sign(private_key, message)` → signature_bytes
  - `verify(public_key, message, signature)` → bool
  - `export_public_key_bytes(public_key)` → raw bytes
  - `import_public_key_bytes(raw_bytes)` → MLDSAPublicKey
- [x] Verify that valid signatures pass and tampered messages fail
- [x] Write comprehensive unit tests (`tests/unit/pqc/test_mldsa.py`: 40 tests)
- [x] Measure and record key/signature sizes (ML-DSA-65: pk=1952 B, sig=3309 B; ML-DSA-44: pk=1312 B, sig=2420 B; ML-DSA-87: pk=2592 B, sig=4627 B)
- [x] Implement Mode B (Full PQC: ML-KEM + ML-DSA + AES-256-GCM + HKDF) in `ModeFactory`
- [x] Write Mode B integration tests (`tests/integration/test_pqc_full_workflow.py`) and security tests (`tests/security/test_mldsa_tampering.py`)
- [x] Document implementation in `docs/MLDSA.md`

**Acceptance Criteria:**
- [x] `MLDSAProvider` implemented and all unit tests pass (40/40 unit, 253/253 suite)
- [x] Valid signature → `verify()` returns True
- [x] Tampered message + same signature → `verify()` returns False
- [x] Provider conforms to `SignatureProvider` abstract interface
- [x] Mode B end-to-end communication succeeds with 100% fidelity

**Deliverables:** `MLDSAProvider` + Mode B wiring + unit/integration/security tests + `docs/MLDSA.md`

---

## Phase 5 — SLH-DSA Implementation

**Status:** COMPLETE (2026-09-28)

**Goal:** Implement the SLH-DSA digital signature provider using FIPS 205 standardized primitives (`slh-dsa`). Verify key generation, signing, and verification. Confirm the parameter sets and document them.

**Dependencies:** Phase 1 complete (PQC environment verified and SLH-DSA confirmed available)

**Tasks:**
- [x] Select SLH-DSA parameter set (`SLH-DSA-SHAKE-128f` primary, `128s`/`192f`/SHA2 supported); record in DECISIONS.md (AD-12)
- [x] Implement `SLHDSAProvider` conforming to `SignatureProvider`
  - `generate_keypair()` → KeyPair(private_key, public_key)
  - `sign(private_key, message)` → signature_bytes
  - `verify(public_key, message, signature)` → bool
  - `export_public_key_bytes(public_key)` → raw bytes
  - `import_public_key_bytes(raw_bytes)` → SLHDSAPublicKey
- [x] Verify that valid signatures pass and tampered messages fail
- [x] Write comprehensive unit tests (`tests/unit/pqc/test_slhdsa.py`: 32 tests)
- [x] Measure and record key/signature sizes (`SLH-DSA-SHAKE-128f`: pk=32 B, sig=17,088 B; `128s`: pk=32 B, sig=7,856 B; `192f`: pk=48 B, sig=35,664 B)
- [x] Implement Mode C (PQC Hash-Based: ML-KEM + SLH-DSA + AES-256-GCM + HKDF) in `ModeFactory`
- [x] Write Mode C integration tests (`tests/integration/test_pqc_slhdsa_workflow.py`: 11 tests) and security tests (`tests/security/test_slhdsa_tampering.py`: 8 tests)
- [x] Document implementation in `docs/SLHDSA.md`

**Acceptance Criteria:**
- [x] `SLHDSAProvider` implemented and all unit tests pass (32/32 unit, 305/305 suite)
- [x] Valid signature → `verify()` returns True
- [x] Tampered message + same signature → `verify()` returns False
- [x] Provider conforms to `SignatureProvider` abstract interface
- [x] Mode C end-to-end communication succeeds with 100% fidelity
- [x] Mechanism name, FIPS 205 standard, and SPHINCS+ lineage documented

**Deliverables:** `SLHDSAProvider` + Mode C wiring + unit/integration/security tests + `docs/SLHDSA.md`

---

## Phase 6 — Crypto-Agility: Mode Factory and Provider Integration

**Status:** COMPLETE (2026-09-28)

**Goal:** Complete the crypto-agility layer. Wire all providers from Phases 2–5 into the `ModeFactory`. Verify that mode switching works via configuration only.

**Dependencies:** Phases 2–5 complete

**Tasks:**
- [x] Complete `ModeFactory` for all supported modes:
  - Mode A: ECDHProvider + ECDSAProvider + AESGCM256Provider + HKDFDerivationProvider
  - Mode B: MLKEMProvider + MLDSAProvider + AESGCM256Provider + HKDFDerivationProvider
  - Mode C: MLKEMProvider + SLHDSAProvider + AESGCM256Provider + HKDFDerivationProvider
  - Mode D: HybridKEProvider (Phase 7) + configurable signature + AESGCM256Provider + HKDFDerivationProvider
- [x] Write integration tests that switch mode via config and confirm provider identity (`tests/integration/test_crypto_agility.py`)
- [x] Confirm zero lines of algorithm-specific branching in `SecureCommunicator`
- [x] Implement comprehensive `CryptoConfig` validation (raises `ConfigurationError` on incompatible or missing providers)
- [x] Implement mode isolation and downgrade protection (`ModeMismatchError`)
- [x] Implement protocol negotiation foundation (`negotiate_mode`)
- [x] Document crypto-agility architecture in `docs/CRYPTO_AGILITY.md`

**Acceptance Criteria:**
- [x] `ModeFactory.build(mode)` works for modes A, B, C (D pending Phase 7)
- [x] Mode switching requires only changing the `mode` parameter
- [x] Configuration validation rejects invalid/mismatched configurations
- [x] Mode isolation strictly rejects cross-mode interpretation
- [x] All 334 tests pass

**Deliverables:** Complete `ModeFactory` + `CryptoConfig` validation + unit/integration tests + `docs/CRYPTO_AGILITY.md`

---

## Phase 7 — Hybrid Key Establishment (Mode D)

**Status:** COMPLETE (2026-09-28)

**Goal:** Implement the hybrid key establishment provider combining ECDH and ML-KEM via HKDF.

**Dependencies:** Phase 2 (ECDHProvider) and Phase 3 (MLKEMProvider) complete

**Tasks:**
- [x] Implement `HybridKEProvider` composing `ECDHProvider` (P-384) + `MLKEMProvider` (ML-KEM-768)
- [x] Implement HKDF secret combiner: `HKDF-SHA-384(ECDH_ss || ML-KEM_ss)` → `hybrid_secret`
  - Document the exact KDF construction (concatenation order, info string, length) in DECISIONS.md (AD-13) and `docs/HYBRID_KEY_ESTABLISHMENT.md`
- [x] Wire Mode D into `ModeFactory` (supporting ML-DSA, SLH-DSA, and ECDSA signature strategies)
- [x] Write unit tests for `HybridSecretCombiner` (`tests/unit/hybrid/test_hybrid_combiner.py`: 10 tests)
- [x] Write unit tests for `HybridKEProvider` (`tests/unit/hybrid/test_hybrid_ke_provider.py`: 9 tests)
- [x] Write integration tests for Mode D (`tests/integration/test_hybrid_mode.py`: 11 tests)
- [x] Verify that the hybrid shared secret is identical on both sides and required from both components

**Acceptance Criteria:**
- [x] `HybridKEProvider` implemented and all unit tests pass (19/19 unit, 371/371 suite)
- [x] Both ECDH and ML-KEM contributions are strictly required
- [x] Hybrid shared secret is deterministically correct
- [x] Mode D config fully available in `ModeFactory`

**Deliverables:** `HybridKEProvider` + `HybridSecretCombiner` + unit/integration/security tests + `docs/HYBRID_KEY_ESTABLISHMENT.md`

---

## Phase 8 — Secure Communication Pipeline

**Status:** NOT STARTED

**Goal:** Implement the full mode-agnostic secure communication pipeline (`SecureCommunicator`) and verify end-to-end communication for all four modes.

**Dependencies:** Phases 2–7 complete

**Tasks:**
- [ ] Implement `MessageBundle` (transmitted message structure: encapsulation_ct, nonce, ciphertext, signature, sender_public_sig_key)
- [ ] Implement `SecureCommunicator.send()` — full sender pipeline (Steps 1–6 from ARCHITECTURE.md Section 4)
- [ ] Implement `SecureCommunicator.receive()` — full receiver pipeline (Steps 7–10)
- [ ] Zero algorithm-specific code in `SecureCommunicator` (delegates entirely to providers)
- [ ] Integration tests: end-to-end send/receive for Mode A, B, C, D
- [ ] Verify: decrypted plaintext == original plaintext for all modes
- [ ] Update `ModeFactory` to handle Mode D with both ECDSA and ML-DSA signature variants

**Acceptance Criteria:**
- End-to-end send/receive works for all four modes (A, B, C, D)
- `SecureCommunicator` contains zero algorithm-specific code
- All integration tests pass
- Mode switching works with a single config change

**Deliverables:** `SecureCommunicator`, `MessageBundle`, integration tests

---

## Phase 9 — Attack Simulation (Security Tests)

**Status:** NOT STARTED

**Goal:** Implement and run the security test suite (Tests 1–6). Verify that tamper detection and forgery rejection work correctly for all modes.

**Dependencies:** Phase 8 complete

**Tasks:**
- [ ] Implement `SecurityTester` with all six tests:
  - TEST-1: Normal communication succeeds (all modes)
  - TEST-2: Valid signature verification succeeds (all modes)
  - TEST-3: Tamper plaintext → signature verification fails (all modes)
  - TEST-4: Tamper ciphertext → message rejected (all modes)
  - TEST-5: Invalid/forged signature rejected (all modes)
  - TEST-6: Mode-agnostic communication — all four modes pass
- [ ] Run all tests; record pass/fail results
- [ ] Document any unexpected results
- [ ] Implement `MigrationOrchestrator` skeleton (Stages 1–4 run sequentially using the SecureCommunicator)

**Acceptance Criteria:**
- Tests 1–6 pass for all modes (A, B, C, D)
- All tamper tests correctly reject invalid messages
- Results documented in a structured report

**Deliverables:** `SecurityTester`, test results report

---

## Phase 10 — Benchmarking

**Status:** NOT STARTED

**Goal:** Implement the benchmarking harness and execute all benchmark experiments (E1–E6 from EXPERIMENT_PLAN.md) to produce real, measured data.

**Dependencies:** Phase 8 complete; test environment documented

**Tasks:**
- [ ] Document test hardware, OS, Python version, and library versions in `docs/ENVIRONMENT.md`
- [ ] Implement `BenchmarkRunner` with `time.perf_counter()` timing
- [ ] Implement `BenchmarkReport` with mean, std dev, min, max
- [ ] Pilot run (N=20): measure variance; determine final N (minimum N=100)
- [ ] Run Experiment E1: Key establishment benchmark (ECDH, ML-KEM, Hybrid)
- [ ] Run Experiment E2: Signature benchmark (ECDSA, ML-DSA, SLH-DSA)
- [ ] Run Experiment E3: End-to-end communication benchmark (all four modes)
- [ ] Run Experiment E4: Security test timing (if relevant)
- [ ] Save raw results to `results/raw/` as CSV files
- [ ] Save size measurements (key sizes, ciphertext sizes, signature sizes)

**Acceptance Criteria:**
- All benchmark experiments complete with real measured data
- Raw results saved to `results/raw/`
- No fabricated or estimated numbers
- Test environment fully documented

**Deliverables:** Raw benchmark CSV files + size measurement tables + environment report

---

## Phase 11 — Comparative Analysis and Visualization

**Status:** NOT STARTED

**Goal:** Analyse raw benchmark data, produce comparison tables, generate charts, and address all research questions with evidence.

**Dependencies:** Phase 10 complete with benchmark data

**Tasks:**
- [ ] Install pandas and matplotlib (or equivalent): `pip install pandas matplotlib`
- [ ] Implement statistical analysis: mean, std dev, overhead percentage vs Mode A baseline
- [ ] Generate summary tables for RQ1–RQ7
- [ ] Generate charts:
  - Key establishment timing (grouped bar)
  - Signature timing (grouped bar)
  - Key/ciphertext/signature sizes (grouped bar)
  - End-to-end processing time (grouped bar)
  - Communication overhead comparison
- [ ] Save charts to `results/charts/`
- [ ] Produce Security Test Results table (all six tests × all four modes)
- [ ] Write `results/EXPERIMENT_RESULTS.md` addressing all RQs with actual data
- [ ] Cross-reference results against hypotheses from EXPERIMENT_PLAN.md

**Acceptance Criteria:**
- All benchmark tables populated with real data
- All charts generated and saved
- All seven research questions addressed
- No fabricated numbers anywhere in the report

**Deliverables:** `results/EXPERIMENT_RESULTS.md`, charts, tables

---

## Phase 12 — Migration Experiment

**Status:** NOT STARTED

**Goal:** Run the full staged migration experiment (Stages 1–4) and produce the migration analysis.

**Dependencies:** Phase 10 complete

**Tasks:**
- [ ] Complete `MigrationOrchestrator` to run all four stages with per-stage metrics
- [ ] Stage 1 — Classical: ECDH + ECDSA + AES-256-GCM
- [ ] Stage 2 — Hybrid: ECDH + ML-KEM + (ECDSA or ML-DSA) + AES-256-GCM
- [ ] Stage 3 — Post-Quantum: ML-KEM + ML-DSA + AES-256-GCM
- [ ] Stage 4 — Alt PQC Signature: ML-KEM + SLH-DSA + AES-256-GCM
- [ ] Record per-stage: timing metrics, size metrics, security test pass/fail
- [ ] Document engineering changes at each stage transition
- [ ] Write migration analysis: per-stage trade-off evaluation
- [ ] Produce Migration Analysis table (performance + overhead + engineering notes)

**Acceptance Criteria:**
- All four stages execute successfully
- Per-stage metrics recorded
- Migration analysis written with actual measured data
- Trade-offs clearly documented without overclaiming

**Deliverables:** Migration analysis report, per-stage metrics

---

## Phase 13 — Dashboard / Frontend

**Status:** NOT STARTED — scope to be confirmed

**Goal:** Build an interactive dashboard or web interface demonstrating the secure communication system.

**Dependencies:** Phase 8 complete

**Decision required (before starting):** Whether a frontend adds sufficient value for the project's audience. Record decision in DECISIONS.md.

**If implemented, tasks:**
- [ ] Create REST API (FastAPI) wrapping `SecureCommunicator`
- [ ] Build web frontend (React/Vite or plain HTML/JS with Node.js 24.14.0)
- [ ] Display: mode selector, message input, encrypted output, decrypted output, signature status
- [ ] Show benchmark metrics panel with data from Phase 10–11 results
- [ ] Trigger security tests from UI

**Acceptance Criteria (if in scope):**
- All four modes demonstrable from UI
- Security tests triggerable from UI
- Results displayed correctly

---

## Phase 14 — Documentation and Final Delivery

**Status:** NOT STARTED

**Goal:** Finalize all documentation, ensure full reproducibility, and prepare the complete deliverable package.

**Dependencies:** Phases 1–12 complete (Phase 13 optional)

**Tasks:**
- [ ] Write `docs/experiment/REPRODUCTION_GUIDE.md` — step-by-step reproduction procedure
- [ ] Write `docs/api/API_REFERENCE.md` — provider interface documentation
- [ ] Update `README.md` with final project status
- [ ] Final review of all Phase 0 documents against actual implementation; record any deviations in DECISIONS.md
- [ ] Freeze `requirements.txt` with all pinned versions
- [ ] Write `docs/LIMITATIONS.md` — expand on Phase 0 limitations with observed evidence
- [ ] Verify: a new reader can follow the REPRODUCTION_GUIDE and reproduce the results

**Acceptance Criteria:**
- All documentation complete
- REPRODUCTION_GUIDE tested (can be independently followed)
- All deliverables from PROJECT_SPEC.md Section 12 present
- All Phase 0 acceptance criteria still satisfied

**Deliverables:** Complete project package ready for submission/presentation

---

## Phase Summary Table

| Phase | Description | Key Output | Status |
|-------|-------------|-----------|--------|
| 0 | Specification & Architecture Freeze | 6 specification documents | COMPLETE |
| 1 | Environment Verification & Foundation | Verified env + project scaffold | COMPLETE |
| 2 | Classical Baseline (Mode A) | ECDHProvider, ECDSAProvider, AES, HKDF | COMPLETE |
| 3 | ML-KEM Implementation | MLKEMProvider | COMPLETE |
| 4 | ML-DSA Implementation | MLDSAProvider | COMPLETE |
| 5 | SLH-DSA Implementation | SLHDSAProvider | Not Started |
| 6 | Crypto-Agility Layer | ModeFactory wired for A/B/C | Not Started |
| 7 | Hybrid Key Establishment | HybridKEProvider + Mode D | Not Started |
| 8 | Secure Communication Pipeline | SecureCommunicator (all modes) | Not Started |
| 9 | Attack Simulation | SecurityTester (Tests 1–6) | Not Started |
| 10 | Benchmarking | Raw benchmark data | Not Started |
| 11 | Comparative Analysis | Results report + charts | Not Started |
| 12 | Migration Experiment | Migration analysis | Not Started |
| 13 | Dashboard / Frontend (optional) | Web UI | TBD |
| 14 | Documentation & Final Delivery | Complete package | Not Started |

---

*End of PHASE_PLAN.md — Phase 0 | Version 0.2.0*
