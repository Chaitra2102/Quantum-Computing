# EXPERIMENT_PLAN.md
# Post-Quantum Secure Communication & Migration Framework
## Research Experiment Plan — Phase 0

**Version:** 0.3.0  
**Date:** 2026-09-28 (revised Phase 5)  
**Status:** Phase 5 — Multi-Provider PQC Benchmarking Constraints Added (AD-17)

> **Revision note (v0.3.0):** Controlled variables table updated per AD-17: `cryptography` 48.0.0 provides classical algorithms, symmetric encryption, ML-KEM (FIPS 203), and ML-DSA (FIPS 204); `slh-dsa` 0.2.5 provides SLH-DSA (FIPS 205). Methodological benchmarking limitation explicitly documented in Section 7.

> **Scope Caveat:** All experiments in this plan produce empirical evidence about the *implemented system's* behaviour. They do NOT constitute formal mathematical proofs of post-quantum security. Security claims for ML-KEM, ML-DSA, and SLH-DSA rest on NIST standardization (FIPS 203, 204, 205) and the underlying academic cryptanalytic analysis.

---

## 1. Central Research Question

> "How can an existing secure communication system be migrated from classical public-key cryptography to post-quantum cryptography while maintaining security functionality and evaluating the resulting performance, communication overhead, and migration trade-offs?"

---

## 2. Supporting Research Questions, Hypotheses, and Expected Evidence

### RQ1 — ML-KEM vs ECDH: Key Establishment Performance

**Question:** How does ML-KEM compare with classical ECDH for key establishment in terms of execution time and key/ciphertext sizes?

**Hypothesis:**
- ML-KEM key generation is expected to be **faster** than ECDH key generation due to lattice-based arithmetic vs elliptic curve point multiplication.
- ML-KEM encapsulation/decapsulation is expected to be **comparable to or faster than** ECDH exchange.
- ML-KEM produces **significantly larger** public keys and ciphertexts than ECDH (hundreds of bytes vs tens of bytes).

**Expected Direction:** ML-KEM trades larger key/ciphertext sizes for comparable-or-better timing performance.

**Evidence to collect:**
- ECDH: key gen time, exchange time, public key size (bytes)
- ML-KEM: key gen time, encapsulate time, decapsulate time, public key size, encapsulation size

---

### RQ2 — ML-DSA vs ECDSA: Digital Signature Performance

**Question:** How does ML-DSA compare with ECDSA for digital signing and verification?

**Hypothesis:**
- ML-DSA key generation may be **slower** than ECDSA due to larger internal structures.
- ML-DSA signing is expected to be **slower** than ECDSA signing.
- ML-DSA verification is expected to be **comparable** to ECDSA verification.
- ML-DSA produces **significantly larger** signatures and public keys than ECDSA.

**Expected Direction:** ML-DSA has a significant size overhead (signatures ~2–4 KB vs ECDSA ~64–72 bytes) with moderate timing overhead.

**Evidence to collect:**
- Both: key gen time, sign time, verify time, public key size, private key size, signature size

---

### RQ3 — SLH-DSA vs ML-DSA: Alternative PQC Signature Families

**Question:** How does SLH-DSA compare with ML-DSA as an alternative post-quantum signature family?

**Hypothesis:**
- SLH-DSA signing is expected to be **significantly slower** than ML-DSA due to hash-tree construction.
- SLH-DSA verification is expected to be **faster** than SLH-DSA signing but may be slower than ML-DSA.
- SLH-DSA signatures are expected to be **larger** than ML-DSA signatures for comparable security levels.
- SLH-DSA has a smaller, simpler security assumption (hash functions only) compared to ML-DSA (module lattices).

**Expected Direction:** SLH-DSA is slower and larger than ML-DSA but offers a different (hash-function-only) security foundation.

**Evidence to collect:**
- SLH-DSA vs ML-DSA: same signature metrics as RQ2

---

### RQ4 — Overall PQC Performance and Communication Overhead

**Question:** What performance and communication overhead is introduced by PQC versus classical algorithms?

**Hypothesis:**
- Total end-to-end processing time for PQC (Mode B) is expected to be **higher** than classical (Mode A) due to larger sizes and different arithmetic.
- Total bytes transmitted (public keys + encapsulation + signature) for PQC will be **substantially larger** than classical.
- The overhead is measurable and quantifiable in concrete percentages.

**Evidence to collect:**
- Total processing time per mode
- Total transmitted bytes per mode
- Percentage overhead: Mode B/C/D vs Mode A

---

### RQ5 — Classical vs PQC vs Hybrid: Practical Differences

**Question:** What are the practical differences between classical, PQC, and hybrid configurations?

**Hypothesis:**
- Hybrid (Mode D) will have the **highest** total overhead (both timing and size) because it runs both classical and PQC key establishment.
- Hybrid provides the best security guarantee during transition (secure against both classical and quantum adversaries simultaneously).
- All four modes will produce functionally identical results (same plaintext recovered).

**Evidence to collect:**
- Side-by-side comparison table: timing + sizes for all four modes
- Qualitative: engineering effort to implement each mode

---

### RQ6 — Crypto-Agility Demonstration

**Question:** Can the system be designed with crypto-agility so that cryptographic algorithms can be replaced without rewriting application logic?

**Hypothesis:**
- The provider-pattern architecture will allow mode switching with a single configuration parameter change.
- The `SecureCommunicator` class will produce identical external behaviour regardless of the configured providers.
- The number of lines of `SecureCommunicator` code that change between modes will be **zero** (only the config object changes).

**Evidence to collect:**
- Demonstrate mode switching in a test
- Count lines of application logic that change between modes
- Show the same communication pipeline working with all four modes

---

### RQ7 — Staged Migration: Engineering Analysis

**Question:** What does a staged migration from classical cryptography to PQC look like in a practical software system?

**Hypothesis:**
- Each migration stage can be implemented incrementally without breaking existing functionality.
- The `MigrationOrchestrator` will run all four stages in sequence without code changes between stages.
- Performance metrics will show a measurable progression from Stage 1 (lowest overhead) to Stage 4.

**Evidence to collect:**
- Successful execution of all four stages
- Per-stage timing and size metrics
- Qualitative migration notes (what changes at each stage from the implementer's perspective)

---

## 3. Variables

### Independent Variables (What we control)

| Variable | Values |
|----------|--------|
| Cryptographic mode | A (Classical), B (PQC/ML-DSA), C (PQC/SLH-DSA), D (Hybrid) |
| Algorithm parameter set | To be determined in Phase 1 (e.g., ML-KEM-768 vs ML-KEM-1024) |
| Message length | Fixed control (e.g., 64 bytes, 1 KB, 10 KB) for sensitivity analysis |

### Dependent Variables (What we measure)

| Variable | Unit |
|----------|------|
| Key generation time | milliseconds (ms) |
| Key exchange / encapsulation time | ms |
| Decapsulation time | ms |
| Signing time | ms |
| Verification time | ms |
| End-to-end processing time | ms |
| Public key size | bytes |
| Private key size | bytes |
| Ciphertext / encapsulation size | bytes |
| Signature size | bytes |
| Total transmitted bytes | bytes |

### Controlled Variables (What we keep constant)

| Variable | Fixed Value |
|---|---|
| AES encryption algorithm | AES-256-GCM (NIST SP 800-38D) |
| Key derivation function | HKDF-SHA-384 (RFC 5869) |
| Library — Classical + Lattice PQC | `cryptography` 48.0.0 (ECDH, ECDSA, AES-GCM, HKDF, ML-KEM, ML-DSA) |
| Library — Hash-Based PQC | `slh-dsa` 0.2.5 (SLH-DSA-SHAKE-128f / 128s / 192f) |
| Hardware | Same machine throughout all experiments |
| Python version | 3.14.3 |
| Measurement tool | `time.perf_counter()` |
| Number of iterations | Minimum N = 100 (exact value finalized in Phase 10) |

---

## 4. Experiments

### E1 — Key Establishment Benchmark

**Addresses:** RQ1, RQ4, RQ5

**Procedure:**
1. For each mode A, B, D:
   a. Run key generation N times; record times
   b. Run key exchange/encapsulation N times; record times
   c. Run decapsulation N times (where applicable); record times
   d. Measure public key, private key, and encapsulation sizes
2. Compute mean ± std dev for each measurement
3. Compare ECDH vs ML-KEM vs Hybrid (ECDH + ML-KEM)

**Output:** Table E1 — Key Establishment Metrics

---

### E2 — Digital Signature Benchmark

**Addresses:** RQ2, RQ3, RQ4, RQ5

**Procedure:**
1. For each signature algorithm (ECDSA, ML-DSA, SLH-DSA):
   a. Run key generation N times; record times
   b. Run signing N times on a fixed message; record times
   c. Run verification N times; record times
   d. Measure public key, private key, and signature sizes
2. Compute mean ± std dev for each measurement
3. Compare all three signature algorithms

**Output:** Table E2 — Signature Metrics

---

### E3 — End-to-End Communication Benchmark

**Addresses:** RQ4, RQ5

**Procedure:**
1. For each mode A, B, C, D:
   a. Run complete secure communication pipeline N times
   b. Record total wall-clock time from key gen to successful decryption
   c. Record total bytes in transmitted bundle
2. Compute mean ± std dev
3. Calculate overhead percentage vs Mode A baseline

**Output:** Table E3 — End-to-End Metrics; Table E4 — Communication Overhead

---

### E4 — Security Test Suite

**Addresses:** RQ5, RQ6 (functional correctness)

**Procedure:**
1. For each mode, run Tests 1–6 from PROJECT_SPEC.md Section 7
2. Record pass/fail for each test
3. Document any unexpected results

**Output:** Table E5 — Security Test Results (pass/fail matrix)

---

### E5 — Crypto-Agility Demonstration

**Addresses:** RQ6

**Procedure:**
1. Implement `SecureCommunicator` with the provider pattern
2. Switch mode from A → B → C → D using only a configuration change
3. Verify that all four modes pass Test 6 (mode-agnostic communication)
4. Document the number of lines changed in application logic between modes

**Output:** Qualitative analysis + test results for RQ6

---

### E6 — Staged Migration Experiment

**Addresses:** RQ7

**Procedure:**
1. Run `MigrationOrchestrator` through Stages 1 → 2 → 3 → 4
2. Record per-stage: timing metrics, size metrics, pass/fail of security tests
3. Document engineering changes required at each stage transition
4. Analyse trade-offs: security level change, overhead change, code change

**Output:** Migration Analysis — Table E6; Qualitative migration notes

---

## 5. Comparison Methodology

### Primary Comparison Framework

All metrics will be compared against **Mode A (Classical)** as the baseline.

| Comparison | Primary Metric | Secondary Metric |
|------------|---------------|-----------------|
| RQ1: ML-KEM vs ECDH | Time overhead (%) | Size overhead (bytes) |
| RQ2: ML-DSA vs ECDSA | Time overhead (%) | Signature size increase (bytes) |
| RQ3: SLH-DSA vs ML-DSA | Time overhead (%) | Signature size comparison (bytes) |
| RQ4: Overall PQC overhead | End-to-end time (%) | Total bytes overhead (%) |
| RQ5: Mode comparison | All metrics | Qualitative |

### Statistical Approach

- **Central tendency:** Arithmetic mean across N iterations
- **Dispersion:** Standard deviation and coefficient of variation
- **Outlier handling:** Document but do not remove; note if first-run JIT effects are visible
- **Minimum N:** 100 iterations (to be finalized in Phase 10 based on variance observed in pilot runs)

### Visualization Plan (Phase 4)

| Chart | Type | Data |
|-------|------|------|
| Key establishment time | Grouped bar chart | Modes A, B, D |
| Signature time | Grouped bar chart | ECDSA, ML-DSA, SLH-DSA |
| Key/ciphertext/signature sizes | Stacked or grouped bar | All algorithms |
| End-to-end processing time | Grouped bar | Modes A, B, C, D |
| Communication overhead | Pie or bar | Bytes breakdown per mode |
| Migration stages | Line chart or table | Per-stage metrics |

---

## 6. Expected Evidence Summary

| RQ | Expected Evidence |
|----|-------------------|
| RQ1 | ML-KEM is comparably fast or faster in timing; ~10–100× larger in sizes |
| RQ2 | ML-DSA is moderately slower; signatures ~30–70× larger than ECDSA |
| RQ3 | SLH-DSA is significantly slower to sign; signatures larger than ML-DSA |
| RQ4 | PQC modes have measurably higher overhead; quantified in ms and bytes |
| RQ5 | All modes functionally equivalent; different overhead profiles |
| RQ6 | Mode switch requires zero application code changes |
| RQ7 | All four stages can run with the same application framework |

> **Important:** These are *expected directions* based on the literature. Actual measured results may differ due to implementation, hardware, and library factors. The project will report actual results, not expected values.

---

## 7. Measurement Conditions & Methodological Limitations

### 7.1 Measurement Conditions
- All experiments run on the same machine; hardware specifications documented at start of Phase 10
- Machine is not under significant background load during benchmark runs
- Experiments run in a single Python process (no parallelism)
- Random seed for any random number generation is NOT fixed (uses OS entropy) — this is intentional for cryptographic correctness
- Cold-start effects: first N/10 iterations may be excluded from reported statistics if JIT/library loading effects are apparent (document if done)

### 7.2 Methodological Limitation: Multi-Provider Benchmarking (AD-17)
- Post-quantum algorithms in this framework are provided by distinct software implementations:
  - **Lattice-based (ML-KEM, ML-DSA):** PyCA `cryptography` 48.0.0 (Rust / OpenSSL backend)
  - **Hash-based (SLH-DSA):** `slh-dsa` 0.2.5 (C-extension backend)
- **Experimental Interpretation Rule:** Empirical benchmarking differences observed between ML-DSA (Mode B) and SLH-DSA (Mode C) represent combined effects of:
  1. Underlying cryptographic algorithm mathematical properties (module lattices vs. hash-trees).
  2. Software implementation details, language runtime bindings (Rust vs. C), and optimization levels.
- Benchmark results in Phase 10 / Phase 11 must **never** be reported as pure mathematical algorithm comparisons without explicitly stating this implementation-level covariate.

---

*End of EXPERIMENT_PLAN.md — Phase 5 Formal Amendment | Version 0.3.0*
